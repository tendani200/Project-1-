<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dokotela Online - Your Health, Our Priority</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root{
            --blue-1: #0f4d92;
            --blue-2: #1CA9C9;
            --pastel: #E6F6FF;
            --bright-red: #ff2d55;
            --muted: #64748b;
            --bg: #f6fbff;
            --card-bg: rgba(255,255,255,0.75);
            --glass-border: rgba(255,255,255,0.35);
            --shadow: 0 6px 18px rgba(16,24,40,0.08);
            --radius: 12px;
            --glass-blur: 8px;
            --text-dark: #0f1724;
            --text-muted: #475569;
            --gap: 1rem;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background-color: var(--bg);
            color: var(--text-dark);
            overflow-x: hidden;
        }

        /* Navigation bar */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 40px;
            flex-wrap: wrap;
            position: fixed;
            top: 0;
            width: 100%;
            background-color: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(var(--glass-blur));
            z-index: 1000;
            transition: all 0.3s ease;
            box-shadow: var(--shadow);
            border-bottom: 1px solid var(--glass-border);
        }

        .header-scrolled {
            padding: 10px 40px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: var(--bright-red);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo img {
            height: 40px;
            width: auto;
            transition: all 0.3s ease;
        }

        .logo:hover img {
            transform: scale(1.05);
        }

        nav {
            display: flex;
            gap: 25px;
            align-items: center;
            flex-wrap: wrap;
        }

        nav a {
            text-decoration: none;
            color: var(--text-dark);
            font-size: 16px;
            transition: all 0.3s ease;
            position: relative;
            font-weight: 500;
        }

        nav a::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 2px;
            background-color: var(--blue-2);
            transition: width 0.3s ease;
        }

        nav a:hover::after {
            width: 100%;
        }

        .btn-appointment {
            background-color: var(--blue-1);
            color: white;
            padding: 10px 18px;
            border-radius: 25px;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 8px rgba(15, 77, 146, 0.2);
            font-weight: 600;
        }

        .btn-appointment:hover {
            background-color: var(--blue-2);
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(15, 77, 146, 0.3);
        }

        .login-link {
            font-size: 14px;
            color: var(--text-dark);
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .login-link:hover {
            color: var(--blue-1);
        }

        /* Hero Section with Doctor Image Background */
        .hero {
            text-align: center;
            padding: 180px 40px 100px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            position: relative;
            overflow: hidden;
            background: linear-gradient(rgba(15, 77, 146, 0.7), rgba(28, 169, 201, 0.5)), url('doctorimage.jpg') center/cover no-repeat;
            color: white;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(15, 77, 146, 0.8) 0%, rgba(28, 169, 201, 0.6) 100%);
            z-index: -1;
            animation: fadeIn 1.5s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .hero h1 {
            font-size: 3rem;
            font-weight: 800;
            margin-bottom: 20px;
            max-width: 900px;
            opacity: 0;
            transform: translateY(30px);
            animation: fadeInUp 1s forwards 0.5s;
            text-shadow: 0 2px 4px rgba(0,0,0,0.2);
            line-height: 1.2;
        }

        .hero p {
            font-size: 1.3rem;
            margin-bottom: 30px;
            max-width: 800px;
            line-height: 1.6;
            opacity: 0;
            transform: translateY(30px);
            animation: fadeInUp 1s forwards 1s;
            text-shadow: 0 1px 2px rgba(0,0,0,0.2);
        }

        .hero .btn-appointment {
            opacity: 0;
            transform: translateY(30px);
            animation: fadeInUp 1s forwards 1.2s;
            background-color: white;
            color: var(--blue-1);
            font-weight: 700;
            padding: 12px 30px;
            font-size: 1.1rem;
        }

        .hero .btn-appointment:hover {
            background-color: var(--pastel);
            transform: translateY(-3px);
        }

        @keyframes fadeInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* South'a Animation */
        .south-a {
            position: relative;
            display: inline-block;
        }

        .south-a::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 3px;
            background-color: white;
            animation: drawLine 1.5s forwards 2s;
        }

        @keyframes drawLine {
            to {
                width: 100%;
            }
        }

        /* Mission Section */
        .mission {
            padding: 100px 40px;
            background: linear-gradient(135deg, var(--pastel) 0%, #e9ecef 100%);
        }

        .section-title {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 60px;
            color: var(--text-dark);
            position: relative;
            padding-bottom: 15px;
            opacity: 0;
            transform: translateY(30px);
            transition: all 0.8s ease;
        }

        .section-title.visible {
            opacity: 1;
            transform: translateY(0);
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: linear-gradient(to right, var(--bright-red), var(--blue-2));
            border-radius: 2px;
        }

        .mission-content {
            max-width: 1000px;
            margin: 0 auto;
            background-color: var(--card-bg);
            backdrop-filter: blur(var(--glass-blur));
            padding: 50px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            position: relative;
            overflow: hidden;
            border: 1px solid var(--glass-border);
            opacity: 0;
            transform: translateY(40px);
            transition: all 0.8s ease;
        }

        .mission-content.visible {
            opacity: 1;
            transform: translateY(0);
        }

        .mission-content::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(to right, var(--bright-red), var(--blue-2));
        }

        .mission-intro {
            font-size: 1.3rem;
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 25px;
            line-height: 1.6;
            text-align: center;
        }

        .mission-commitments {
            margin-top: 30px;
        }

        .commitment-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 20px;
            padding: 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
            background-color: rgba(255, 255, 255, 0.5);
        }

        .commitment-item:hover {
            background-color: rgba(28, 169, 201, 0.05);
            transform: translateX(5px);
        }

        .commitment-icon {
            font-size: 24px;
            color: var(--blue-2);
            margin-right: 15px;
            flex-shrink: 0;
            margin-top: 5px;
        }

        .commitment-text {
            flex: 1;
        }

        .commitment-text h3 {
            font-size: 1.2rem;
            margin-bottom: 8px;
            color: var(--text-dark);
        }

        .commitment-text p {
            color: var(--text-muted);
            line-height: 1.6;
        }

        .mission-conclusion {
            margin-top: 30px;
            text-align: center;
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--bright-red);
            padding: 15px;
            border-radius: 8px;
            background-color: rgba(255, 45, 85, 0.05);
        }

        /* About Section */
        .about {
            padding: 100px 40px;
            background-color: var(--bg);
        }

        .about-content {
            max-width: 1000px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            gap: 30px;
            opacity: 0;
            transform: translateY(40px);
            transition: all 0.8s ease;
        }

        .about-content.visible {
            opacity: 1;
            transform: translateY(0);
        }

        .about-text {
            font-size: 1.1rem;
            line-height: 1.7;
            color: var(--text-muted);
            margin-bottom: 20px;
        }

        .about-highlights {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-top: 30px;
        }

        .highlight-item {
            background: linear-gradient(135deg, var(--pastel) 0%, #e9ecef 100%);
            padding: 30px;
            border-radius: 10px;
            text-align: center;
            transition: all 0.3s ease;
            border-left: 4px solid var(--blue-1);
            opacity: 0;
            transform: translateY(20px);
            transition: all 0.6s ease;
        }

        .highlight-item.visible {
            opacity: 1;
            transform: translateY(0);
        }

        .highlight-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }

        .highlight-icon {
            font-size: 40px;
            color: var(--blue-1);
            margin-bottom: 15px;
        }

        .highlight-item h3 {
            font-size: 1.3rem;
            margin-bottom: 10px;
            color: var(--text-dark);
        }

        .highlight-item p {
            color: var(--text-muted);
            line-height: 1.6;
        }

        /* Services Section */
        .services {
            padding: 100px 40px;
            background-color: var(--bg);
        }

        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .service-card {
            text-align: center;
            padding: 40px 25px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            transition: all 0.4s ease;
            background-color: var(--card-bg);
            backdrop-filter: blur(var(--glass-blur));
            position: relative;
            overflow: hidden;
            opacity: 0;
            transform: translateY(40px);
            border: 1px solid var(--glass-border);
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .service-card.visible {
            opacity: 1;
            transform: translateY(0);
        }

        .service-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 0;
            background: linear-gradient(to bottom, var(--bright-red), var(--blue-2));
            transition: height 0.5s ease;
        }

        .service-card:hover::before {
            height: 100%;
        }

        .service-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.12);
        }

        .service-icon {
            font-size: 50px;
            margin-bottom: 20px;
            color: var(--blue-1);
            transition: all 0.3s ease;
        }

        .service-card:hover .service-icon {
            transform: scale(1.1);
            color: var(--bright-red);
        }

        .service-card h3 {
            font-size: 1.5rem;
            margin-bottom: 15px;
            color: var(--text-dark);
            position: relative;
            z-index: 1;
        }

        .service-card p {
            font-size: 1rem;
            color: var(--text-muted);
            line-height: 1.6;
            position: relative;
            z-index: 1;
            margin-bottom: 15px;
        }

        .service-details {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.5s ease;
            text-align: left;
            background-color: rgba(255, 255, 255, 0.7);
            border-radius: 8px;
            padding: 0 15px;
            margin-top: 10px;
        }

        .service-card:hover .service-details {
            max-height: 200px;
            padding: 15px;
        }

        .service-price {
            font-weight: bold;
            color: var(--blue-1);
            margin-top: 10px;
            font-size: 1.1rem;
        }

        .student-price {
            color: var(--bright-red);
            font-size: 0.9rem;
            margin-top: 5px;
        }

        /* Booking Process Section */
        .booking-process {
            padding: 100px 40px;
            background: linear-gradient(135deg, var(--pastel) 0%, #e9ecef 100%);
        }

        .process-steps {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
        }

        .process-step {
            flex: 1;
            min-width: 250px;
            max-width: 300px;
            background-color: var(--card-bg);
            backdrop-filter: blur(var(--glass-blur));
            padding: 30px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            text-align: center;
            transition: all 0.4s ease;
            border: 1px solid var(--glass-border);
            opacity: 0;
            transform: translateY(40px);
        }

        .process-step.visible {
            opacity: 1;
            transform: translateY(0);
        }

        .process-step:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.15);
        }

        .step-number {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, var(--blue-1), var(--blue-2));
            color: white;
            border-radius: 50%;
            font-size: 1.5rem;
            font-weight: bold;
            margin: 0 auto 20px;
            box-shadow: 0 4px 10px rgba(15, 77, 146, 0.3);
        }

        .process-step h3 {
            font-size: 1.4rem;
            margin-bottom: 15px;
            color: var(--text-dark);
        }

        .process-step p {
            color: var(--text-muted);
            line-height: 1.6;
            margin-bottom: 20px;
        }

        .dashboard-preview {
            margin-top: 20px;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }

        .dashboard-preview:hover {
            transform: scale(1.02);
        }

        .dashboard-preview img {
            width: 100%;
            height: auto;
            display: block;
        }

        /* FAQ Section */
        .faq {
            padding: 100px 40px;
            background-color: var(--bg);
        }

        .faq-container {
            max-width: 1000px;
            margin: 0 auto;
        }

        .faq-item {
            margin-bottom: 20px;
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow);
            background-color: var(--card-bg);
            backdrop-filter: blur(var(--glass-blur));
            border: 1px solid var(--glass-border);
            opacity: 0;
            transform: translateY(20px);
            transition: all 0.6s ease;
        }

        .faq-item.visible {
            opacity: 1;
            transform: translateY(0);
        }

        .faq-question {
            padding: 20px 25px;
            background-color: rgba(15, 77, 146, 0.05);
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: all 0.3s ease;
        }

        .faq-question:hover {
            background-color: rgba(15, 77, 146, 0.1);
        }

        .faq-question h3 {
            font-size: 1.2rem;
            color: var(--text-dark);
            margin: 0;
        }

        .faq-toggle {
            font-size: 1.2rem;
            color: var(--blue-1);
            transition: transform 0.3s ease;
        }

        .faq-answer {
            padding: 0 25px;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
            color: var(--text-muted);
        }

        .faq-item.active .faq-answer {
            padding: 20px 25px;
            max-height: 500px;
        }

        .faq-item.active .faq-toggle {
            transform: rotate(45deg);
        }

        .operating-times {
            margin-top: 40px;
            text-align: center;
            padding: 20px;
            background-color: var(--pastel);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }

        .operating-times h3 {
            color: var(--blue-1);
            margin-bottom: 10px;
        }

        /* Reviews Section */
        .reviews {
            padding: 100px 40px;
            background: linear-gradient(135deg, var(--pastel) 0%, #e9ecef 100%);
            text-align: center;
            overflow: hidden;
        }

        .reviews-container {
            position: relative;
            max-width: 1000px;
            margin: 0 auto;
            height: auto;
            overflow: hidden;
        }

        .reviews-track {
            display: flex;
            transition: transform 0.5s ease;
            height: 100%;
        }

        .review-card {
            background: var(--card-bg);
            backdrop-filter: blur(var(--glass-blur));
            padding: 40px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            min-width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            opacity: 0;
            transform: scale(0.9);
            transition: all 0.5s ease;
            border: 1px solid var(--glass-border);
            margin-bottom: 30px;
        }

        .review-card.active {
            opacity: 1;
            transform: scale(1);
        }

        .review-card p {
            font-style: italic;
            margin-bottom: 20px;
            color: var(--text-muted);
            font-size: 1.1rem;
            line-height: 1.6;
        }

        .review-author {
            font-weight: bold;
            color: var(--text-dark);
            font-size: 1rem;
        }

        .review-rating {
            color: #ffc107;
            margin-bottom: 15px;
            font-size: 1.2rem;
        }

        .review-controls {
            margin-top: 30px;
            display: flex;
            justify-content: center;
            gap: 15px;
        }

        .review-control {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background-color: #ddd;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .review-control.active {
            background-color: var(--blue-1);
            transform: scale(1.2);
        }

        .review-form {
            max-width: 600px;
            margin: 50px auto 0;
            background-color: var(--card-bg);
            padding: 30px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            text-align: left;
        }

        .review-form h3 {
            text-align: center;
            margin-bottom: 20px;
            color: var(--blue-1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--text-dark);
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }

        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: var(--blue-2);
        }

        .rating-stars {
            display: flex;
            gap: 5px;
            margin-bottom: 10px;
        }

        .rating-stars i {
            color: #ddd;
            cursor: pointer;
            font-size: 1.5rem;
            transition: color 0.3s;
        }

        .rating-stars i.active {
            color: #ffc107;
        }

        .submit-review {
            background-color: var(--blue-1);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 25px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: block;
            margin: 0 auto;
        }

        .submit-review:hover {
            background-color: var(--blue-2);
            transform: translateY(-2px);
        }

        /* Footer */
        footer {
            margin-top: 80px;
            background: linear-gradient(to right, var(--blue-1), var(--blue-2));
            color: #fff;
            padding: 60px 20px 30px;
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            font-size: 14px;
            gap: 30px;
        }

        .footer-col {
            flex: 1 1 200px;
            margin-bottom: 30px;
        }

        .footer-col h4 {
            margin-bottom: 20px;
            font-size: 18px;
            color: #fff;
            position: relative;
            padding-bottom: 10px;
        }

        .footer-col h4::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 2px;
            background-color: white;
        }

        .footer-col ul {
            list-style: none;
        }

        .footer-col ul li {
            margin-bottom: 12px;
        }

        .footer-col ul li a {
            text-decoration: none;
            color: rgba(255, 255, 255, 0.8);
            font-size: 15px;
            transition: all 0.3s ease;
            display: inline-block;
        }

        .footer-col ul li a:hover {
            color: white;
            transform: translateX(5px);
        }

        .social-icons {
            margin-top: 20px;
            display: flex;
            gap: 15px;
        }

        .social-icons a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background-color: rgba(255,255,255,0.1);
            border-radius: 50%;
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            transition: all 0.3s ease;
        }

        .social-icons a:hover {
            background-color: rgba(255,255,255,0.2);
            transform: translateY(-3px);
        }

        .copyright {
            text-align: center;
            margin-top: 40px;
            width: 100%;
            font-size: 14px;
            color: rgba(255,255,255,0.7);
            padding-top: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }

        /* Scroll to top button */
        .scroll-to-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 50px;
            height: 50px;
            background: linear-gradient(to right, var(--blue-1), var(--blue-2));
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(15, 77, 146, 0.3);
            transition: all 0.3s ease;
            opacity: 0;
            visibility: hidden;
            z-index: 1000;
        }

        .scroll-to-top.visible {
            opacity: 1;
            visibility: visible;
        }

        .scroll-to-top:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(15, 77, 146, 0.4);
        }

        /* Alert/Notification styles */
        .alert {
            position: fixed;
            top: 100px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 8px;
            color: white;
            font-weight: 600;
            z-index: 2000;
            opacity: 0;
            transform: translateX(100%);
            transition: all 0.3s ease;
        }

        .alert.show {
            opacity: 1;
            transform: translateX(0);
        }

        .alert.success {
            background-color: #28a745;
        }

        .alert.error {
            background-color: #dc3545;
        }

        .alert.info {
            background-color: var(--blue-2);
        }

        /* Mobile Navigation */
        .mobile-menu-toggle {
            display: none;
            flex-direction: column;
            cursor: pointer;
            padding: 5px;
        }

        .mobile-menu-toggle span {
            width: 25px;
            height: 3px;
            background-color: var(--text-dark);
            margin: 3px 0;
            transition: 0.3s;
        }

        /* Responsive styles */
        @media (max-width: 768px) {
            header {
                padding: 15px 20px;
            }

            .mobile-menu-toggle {
                display: flex;
            }

            nav {
                position: absolute;
                top: 100%;
                left: 0;
                width: 100%;
                background: rgba(255, 255, 255, 0.95);
                backdrop-filter: blur(var(--glass-blur));
                flex-direction: column;
                gap: 0;
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                transform: translateY(-10px);
                opacity: 0;
                visibility: hidden;
                transition: all 0.3s ease;
                padding: 20px 0;
            }

            nav.active {
                transform: translateY(0);
                opacity: 1;
                visibility: visible;
            }

            nav a {
                padding: 15px 40px;
                border-bottom: 1px solid var(--glass-border);
                width: 100%;
                text-align: left;
            }

            .hero {
                padding: 150px 20px 80px;
            }

            .hero h1 {
                font-size: 2.2rem;
            }
            
            .hero p {
                font-size: 1.1rem;
            }
            
            .services, .mission, .about, .booking-process, .faq, .reviews {
                padding: 60px 20px;
            }
            
            .services-grid {
                grid-template-columns: 1fr;
            }
            
            .mission-content, .about-content {
                padding: 25px;
            }
            
            .commitment-item {
                flex-direction: column;
                text-align: center;
            }
            
            .commitment-icon {
                margin-right: 0;
                margin-bottom: 10px;
            }
            
            .about-highlights {
                grid-template-columns: 1fr;
            }
            
            .process-steps {
                flex-direction: column;
                align-items: center;
            }
            
            .process-step {
                max-width: 100%;
            }
            
            footer {
                padding: 40px 20px 20px;
            }
        }
    </style>
</head>
<body>

    <header id="header">
        <div class="logo">
            <img src="dokotelalogo.png" alt="Dokotela Online Logo">
        </div>
        <div class="mobile-menu-toggle" onclick="toggleMobileMenu()">
            <span></span>
            <span></span>
            <span></span>
        </div>
        <nav id="nav">
            <a href="index.php#home">Home</a>
            <a href="index.php#mission">About</a>
            <a href="index.php#about">Our Mission</a>
            <a href="index.php#services">Services</a>
            <a href="index.php#booking">Booking</a>
            <a href="index.php#faq">FAQ</a>
            <a href="../telemedicine/auth/login.php" class="btn-appointment">Book Appointment</a>
            <a href="../telemedicine/auth/login.php" class="login-link">Login</a>
            <a href="../telemedicine/auth/signup.php" class="login-link">Sign Up</a>
        </nav>
    </header>

    <!-- Hero Section -->
    <section class="hero" id="home">
        <h1>With You Where Ever You Go: The most convenient healthcare in <span class="south-a">South'a</span>!</h1>
        <p>Access quality healthcare from the comfort of your home. Dokotela Online connects you with experienced medical professionals for personalized, convenient and compassionate care.</p>
        <a href="../telemedicine/auth/login.php" class="btn-appointment">Book Appointment</a>
    </section>

    <!-- Mission Section -->
    <section class="mission" id="mission">
        <h2 class="section-title">Our Mission</h2>
        <div class="mission-content">
            <p class="mission-intro">At Dokotela Online, our mission is to make quality healthcare affordable, accessible, and convenient for everyone. We believe that everyone deserves access to medical guidance and support — regardless of where they are or what they can spend.</p>
            
            <div class="mission-commitments">
                <div class="commitment-item">
                    <div class="commitment-icon">
                        <i class="fas fa-bridge-water"></i>
                    </div>
                    <div class="commitment-text">
                        <h3>Bridging the Gap</h3>
                        <p>Bridging the gap between patients and practitioners with seamless virtual consultations.</p>
                    </div>
                </div>
                
                <div class="commitment-item">
                    <div class="commitment-icon">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                    <div class="commitment-text">
                        <h3>Fair Pricing</h3>
                        <p>Charging fair rates — we offer services at half of the usual medical aid rates, ensuring cost is not a barrier.</p>
                    </div>
                </div>
                
                <div class="commitment-item">
                    <div class="commitment-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <div class="commitment-text">
                        <h3>Digital Access</h3>
                        <p>Putting care at your fingertips through user-friendly digital access.</p>
                    </div>
                </div>
                
                <div class="commitment-item">
                    <div class="commitment-icon">
                        <i class="fas fa-hands-helping"></i>
                    </div>
                    <div class="commitment-text">
                        <h3>Holistic Support</h3>
                        <p>Delivering holistic support, not just treatment — helping you understand, manage, and prevent health challenges.</p>
                    </div>
                </div>
            </div>
            
            <p class="mission-conclusion">Because health is your right, not a luxury.</p>
        </div>
    </section>

    <!-- About Section -->
    <section class="about" id="about">
        <h2 class="section-title">About Dokotela Online</h2>
        <div class="about-content">
            <p class="about-text">Dokotela Online is a trusted virtual healthcare platform designed to connect you with qualified medical professionals — anytime, anywhere. We understand that life can be busy, clinics can be full, and access to quality healthcare isn't always easy. That's why we've created a simple, secure, and affordable way to get medical help from the comfort of your home.</p>
            
            <p class="about-text">Our platform brings together a team of experienced general practitioners, who are passionate about providing compassionate, patient-centred care. Whether you need a quick consultation, prescription renewal, or follow-up advice, and even mental health assistance in the comfort of your own home Dokotela Online ensures that you receive the care you deserve — fast, safe, and stress-free.</p>
            
            <p class="about-text">We believe that healthcare should fit into your life — not the other way around. With transparent pricing, reliable practitioners, and a commitment to accessibility, we're redefining how South Africans experience medical consultations.</p>
            
            <p class="about-text">At Dokotela Online, your health is our priority — because every consultation is more than a call; it's care that truly listens.</p>
            
            <div class="about-highlights">
                <div class="highlight-item">
                    <div class="highlight-icon">
                        <i class="fas fa-user-md"></i>
                    </div>
                    <h3>Qualified Professionals</h3>
                    <p>Experienced general practitioners dedicated to your health and well-being.</p>
                </div>
                
                <div class="highlight-item">
                    <div class="highlight-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3>Secure & Private</h3>
                    <p>Your health information is protected with industry-leading security measures.</p>
                </div>
                
                <div class="highlight-item">
                    <div class="highlight-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <h3>Available Anytime</h3>
                    <p>Access medical care when you need it, without long waiting times.</p>
                </div>
                
                <div class="highlight-item">
                    <div class="highlight-icon">
                        <i class="fas fa-heart"></i>
                    </div>
                    <h3>Patient-Centred</h3>
                    <p>Compassionate care that focuses on your unique needs and concerns.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section class="services" id="services">
        <h2 class="section-title">Our Comprehensive Medical Services</h2>
        <div class="services-grid">
            <div class="service-card">
                <div class="service-icon"><i class="fas fa-hospital-user"></i></div>
                <h3>General Medical Consultations</h3>
                <p>Experienced general practitioners providing comprehensive diagnosis, treatment and preventive care for common illnesses and health concerns.</p>
                <div class="service-details">
                    <p>Our general medical consultations cover a wide range of health issues including colds, flu, infections, chronic condition management, and preventive health screenings. Our doctors take time to understand your symptoms and provide personalized treatment plans.</p>
                    <div class="service-price">Price: R350</div>
                    <div class="student-price">Student Price: R300</div>
                </div>
            </div>
            <div class="service-card">
                <div class="service-icon"><i class="fas fa-pills"></i></div>
                <h3>Prescription Services</h3>
                <p>Conveniently request, renew and manage your prescriptions online with our secure and efficient services, ensuring timely access to your medications.</p>
                <div class="service-details">
                    <p>Our prescription service allows you to request new prescriptions or renew existing ones without visiting a physical clinic. Our doctors will review your medical history and issue electronic prescriptions that can be sent directly to your preferred pharmacy.</p>
                    <div class="service-price">Price: R350</div>
                    <div class="student-price">Student Price: R300</div>
                </div>
            </div>
            <div class="service-card">
                <div class="service-icon"><i class="fas fa-share-alt"></i></div>
                <h3>Referrals</h3>
                <p>Streamlined referral services to specialists and allied health professionals, ensuring you get the comprehensive care you need.</p>
                <div class="service-details">
                    <p>If your condition requires specialized care, our doctors can provide referrals to trusted specialists in our network. We'll help coordinate your care and ensure all necessary medical information is shared securely with the specialist.</p>
                    <div class="service-price">Price: R350</div>
                    <div class="student-price">Student Price: R300</div>
                </div>
            </div>
            <div class="service-card">
                <div class="service-icon"><i class="fas fa-brain"></i></div>
                <h3>Mental Health Assistance</h3>
                <p>Confidential consultations and support for your mental well-being, connecting you with therapists and resources for emotional health.</p>
                <div class="service-details">
                    <p>Our mental health services provide confidential support for anxiety, depression, stress, and other mental health concerns. Our qualified therapists offer counseling sessions and can develop personalized treatment plans to support your emotional well-being.</p>
                    <div class="service-price">Price: R350</div>
                    <div class="student-price">Student Price: R300</div>
                </div>
            </div>
            <div class="service-card">
                <div class="service-icon"><i class="fas fa-file-medical"></i></div>
                <h3>Compliance Paperwork</h3>
                <p>Assistance with medical certificates, insurance forms and other essential compliance documentation, made simple and efficient.</p>
                <div class="service-details">
                    <p>We help with all necessary medical documentation including sick notes, medical certificates for work or school, insurance claim forms, and other compliance paperwork. Our doctors ensure all documents are completed accurately and promptly.</p>
                    <div class="service-price">Price: R350</div>
                    <div class="student-price">Student Price: R300</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Booking Process Section -->
    <section class="booking-process" id="booking">
        <h2 class="section-title">Easy Booking Process</h2>
        <div class="process-steps">
            <div class="process-step">
                <div class="step-number">1</div>
                <h3>Login / Sign Up</h3>
                <p>Create your account or log in to access our secure patient portal.</p>
                <i class="fas fa-user-plus" style="font-size: 40px; color: var(--blue-1); margin: 15px 0;"></i>
            </div>
            
            <div class="process-step">
                <div class="step-number">2</div>
                <h3>Access Patient Dashboard</h3>
                <p>Navigate to your personalized dashboard where you can manage all your healthcare needs.</p>
                <div class="dashboard-preview">
                    <img src="patientdashboard.jpeg" alt="Patient Dashboard">
                    <div style="background: linear-gradient(135deg, var(--blue-1), var(--blue-2)); height: 150px; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                        Patient Dashboard Preview
                    </div>
                </div>
            </div>
            
            <div class="process-step">
                <div class="step-number">3</div>
                <h3>Book Appointment</h3>
                <p>Go to the appointments tab and select your preferred date, time, and doctor.</p>
                <i class="fas fa-calendar-check" style="font-size: 40px; color: var(--blue-1); margin: 15px 0;"></i>
            </div>
            
            <div class="process-step">
                <div class="step-number">4</div>
                <h3>Provide Information</h3>
                <p>Fill in your medical information and reason for consultation to help us serve you better.</p>
                <i class="fas fa-notes-medical" style="font-size: 40px; color: var(--blue-1); margin: 15px 0;"></i>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="faq" id="faq">
        <h2 class="section-title">Frequently Asked Questions</h2>
        <div class="faq-container">
            <div class="faq-item">
                <div class="faq-question">
                    <h3>How do I book an appointment?</h3>
                    <span class="faq-toggle">+</span>
                </div>
                <div class="faq-answer">
                    <p>Booking an appointment is quick and easy. Simply click on the “Book Appointment” button, log in to your account, and follow the step-by-step booking process. You’ll be able to choose your preferred date, time, and doctor to ensure your consultation fits perfectly into your schedule.</p>
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">
                    <h3>Are the consultations secure and private?</h3>
                    <span class="faq-toggle">+</span>
                </div>
                <div class="faq-answer">
                    <p>Absolutely. All our consultations take place on a secure, encrypted platform that fully complies with healthcare privacy and data protection regulations. Your personal and medical information is kept strictly confidential and is never shared without your consent. We prioritize your safety and privacy at every step of your healthcare journey.</p>
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">
                    <h3>What if I need a prescription?</h3>
                    <span class="faq-toggle">+</span>
                </div>
                <div class="faq-answer">
                    <p>Yes! Our doctors are licensed to issue electronic prescriptions during your consultation. Once your doctor determines that medication is needed, the prescription can be securely sent directly to your preferred pharmacy. You’ll receive confirmation details, and you can then collect your medication conveniently—no need for a paper script or an extra visit.</p>
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">
                    <h3>How much does a consultation cost?</h3>
                    <span class="faq-toggle">+</span>
                </div>
                <div class="faq-answer">
                    <p>All our consultations are R350 per session. However, if you’re a student, we offer a special discount of R50, making your session R300. We believe in making healthcare accessible and affordable, especially for students who may be managing tight budgets.</p>
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">
                    <h3>Can I get a referral to a specialist?</h3>
                    <span class="faq-toggle">+</span>
                </div>
                <div class="faq-answer">
                    <p>Yes! If during your consultation our doctors determine that you require specialized care, they will provide a referral to a trusted specialist within our network. We work with a range of verified medical professionals to ensure you receive the right follow-up care and continuous support for your health needs.</p>
                </div>
            </div>
        </div>
        
        <div class="operating-times">
            <h3>Operating Hours</h3>
            <p>Our services are available from <strong>9:00 AM to 10:00 PM</strong> daily.</p>
        </div>
    </section>

    <!-- Reviews Section -->
    <section class="reviews">
        <h2 class="section-title">Patient Reviews</h2>
        <div class="reviews-container">
            <div class="reviews-track">
                <div class="review-card active">
                    <div class="review-rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p>"Dokotela Online made my consultation so easy and convenient. The doctor was professional and caring. I didn't have to wait for hours like in a traditional clinic."</p>
                    <div class="review-author">- Jane Doe</div>
                </div>
                <div class="review-card">
                    <div class="review-rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <p>"Quick prescription renewal without leaving home. Highly recommend for busy parents like me. Saved me so much time and hassle!"</p>
                    <div class="review-author">- John Smith</div>
                </div>
                <div class="review-card">
                    <div class="review-rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p>"The mental health support was confidential and helpful. Grateful for this service during a difficult time. My therapist was understanding and professional."</p>
                    <div class="review-author">- Alex Johnson</div>
                </div>
            </div>
        </div>
        <div class="review-controls">
            <div class="review-control active" data-index="0"></div>
            <div class="review-control" data-index="1"></div>
            <div class="review-control" data-index="2"></div>
        </div>
        
        <div class="review-form">
            <h3>Share Your Experience</h3>
            <form id="new-review-form">
                <div class="form-group">
                    <label for="reviewer-name">Your Name</label>
                    <input type="text" id="reviewer-name" required>
                </div>
                <div class="form-group">
                    <label for="review-rating">Rating</label>
                    <div class="rating-stars" id="rating-stars">
                        <i class="far fa-star" data-rating="1"></i>
                        <i class="far fa-star" data-rating="2"></i>
                        <i class="far fa-star" data-rating="3"></i>
                        <i class="far fa-star" data-rating="4"></i>
                        <i class="far fa-star" data-rating="5"></i>
                    </div>
                    <input type="hidden" id="review-rating" value="0" required>
                </div>
                <div class="form-group">
                    <label for="review-comment">Your Review</label>
                    <textarea id="review-comment" rows="4" required></textarea>
                </div>
                <button type="submit" class="submit-review">Submit Review</button>
            </form>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="footer-col">
            <h4>About Us</h4>
            <ul>
                <li><a href="index.php#mission">Our Mission</a></li>
                <li><a href="index.php#about">About</a></li>
                <li><a href="index.php#services">Services</a></li>
                <li><a href="privacy-policy.php">Privacy Policy</a></li>
                <li><a href="#">Terms of Service</a></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4>Quick Links</h4>
            <ul>
                <li><a href="index.php#home">Home</a></li>
                <li><a href="login.php">Book Appointment</a></li>
                <li><a href="login.php">Find a Doctor</a></li>
                <li><a href="index.php#faq">FAQ</a></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4>Contact Info</h4>
            <ul>
                <li><i class="fas fa-phone"></i> +27 67 566 9355</li>
                <li><i class="fas fa-envelope"></i> aphiwe.meyiwa@dokotela-online.com</li>
                <li><i class="fas fa-map-marker-alt"></i> 33 Cayman Road, 1872</li>
            </ul>
            <div class="social-icons">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-linkedin-in"></i></a>
            </div>
        </div>
        <div class="copyright">
            &copy; 2025 Dokotela Online. All rights reserved.
        </div>
    </footer>

    <!-- Scroll to top button -->
    <div class="scroll-to-top" onclick="scrollToTop()">
        <i class="fas fa-arrow-up"></i>
    </div>

    <script>
        // Header scroll effect
        window.addEventListener('scroll', function() {
            const header = document.getElementById('header');
            const scrollToTopBtn = document.querySelector('.scroll-to-top');
            
            if (window.scrollY > 50) {
                header.classList.add('header-scrolled');
            } else {
                header.classList.remove('header-scrolled');
            }
            
            // Show/hide scroll to top button
            if (window.scrollY > 500) {
                scrollToTopBtn.classList.add('visible');
            } else {
                scrollToTopBtn.classList.remove('visible');
            }
            
            // Animate elements on scroll
            animateOnScroll();
        });

        // Mobile menu toggle
        function toggleMobileMenu() {
            const nav = document.getElementById('nav');
            nav.classList.toggle('active');
        }

        // Animate elements on scroll
        function animateOnScroll() {
            const elements = document.querySelectorAll('.section-title, .service-card, .mission-content, .about-content, .highlight-item, .process-step, .faq-item');
            
            elements.forEach(element => {
                const elementPosition = element.getBoundingClientRect().top;
                const screenPosition = window.innerHeight / 1.2;
                
                if (elementPosition < screenPosition) {
                    element.classList.add('visible');
                }
            });
        }

        // Initial call to check elements in view on page load
        window.addEventListener('load', animateOnScroll);

        // Review carousel
        let currentReview = 0;
        const reviews = document.querySelectorAll('.review-card');
        const controls = document.querySelectorAll('.review-control');
        const track = document.querySelector('.reviews-track');
        
        function showReview(index) {
            reviews.forEach(review => review.classList.remove('active'));
            controls.forEach(control => control.classList.remove('active'));
            
            reviews[index].classList.add('active');
            controls[index].classList.add('active');
            track.style.transform = `translateX(-${index * 100}%)`;
            currentReview = index;
        }
        
        // Add click events to controls
        controls.forEach(control => {
            control.addEventListener('click', function() {
                showReview(parseInt(this.getAttribute('data-index')));
            });
        });
        
        // Auto rotate reviews
        setInterval(() => {
            currentReview = (currentReview + 1) % reviews.length;
            showReview(currentReview);
        }, 5000);

        // FAQ functionality
        const faqItems = document.querySelectorAll('.faq-item');
        
        faqItems.forEach(item => {
            const question = item.querySelector('.faq-question');
            
            question.addEventListener('click', () => {
                // Close all other FAQ items
                faqItems.forEach(otherItem => {
                    if (otherItem !== item) {
                        otherItem.classList.remove('active');
                    }
                });
                
                // Toggle current item
                item.classList.toggle('active');
            });
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                if (this.getAttribute('href') === '#') return;
                
                const targetId = this.getAttribute('href').substring(1);
                const target = document.querySelector(`#${targetId}`);
                
                // If target exists on current page, scroll to it
                if (target) {
                    e.preventDefault();
                    window.scrollTo({
                        top: target.offsetTop - 80,
                        behavior: 'smooth'
                    });
                    
                    // Close mobile menu if open
                    const nav = document.getElementById('nav');
                    nav.classList.remove('active');
                } else {
                    // If target doesn't exist, redirect to index.php with the anchor
                    this.href = `index.php#${targetId}`;
                }
            });
        });

        // Scroll to top function
        function scrollToTop() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }

        // Show notification/alert function
        function showAlert(message, type = 'info') {
            const alert = document.createElement('div');
            alert.className = `alert ${type}`;
            alert.textContent = message;
            document.body.appendChild(alert);
            
            // Show alert
            setTimeout(() => alert.classList.add('show'), 100);
            
            // Hide alert after 5 seconds
            setTimeout(() => {
                alert.classList.remove('show');
                setTimeout(() => document.body.removeChild(alert), 300);
            }, 5000);
        }

        // Check for URL parameters to show messages
        window.addEventListener('load', function() {
            const urlParams = new URLSearchParams(window.location.search);
            const message = urlParams.get('message');
            const type = urlParams.get('type');
            
            if (message) {
                showAlert(decodeURIComponent(message), type || 'info');
                
                // Clean URL by removing the parameters
                const cleanUrl = window.location.pathname;
                window.history.replaceState({}, document.title, cleanUrl);
            }
        });

        // Close mobile menu when clicking on a link
        document.querySelectorAll('nav a').forEach(link => {
            link.addEventListener('click', function() {
                const nav = document.getElementById('nav');
                nav.classList.remove('active');
            });
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            const nav = document.getElementById('nav');
            const toggle = document.querySelector('.mobile-menu-toggle');
            
            if (!nav.contains(event.target) && !toggle.contains(event.target)) {
                nav.classList.remove('active');
            }
        });

        // Star rating functionality for review form
        const stars = document.querySelectorAll('.rating-stars i');
        const ratingInput = document.getElementById('review-rating');
        
        stars.forEach(star => {
            star.addEventListener('click', function() {
                const rating = this.getAttribute('data-rating');
                ratingInput.value = rating;
                
                stars.forEach(s => {
                    if (s.getAttribute('data-rating') <= rating) {
                        s.classList.remove('far');
                        s.classList.add('fas', 'active');
                    } else {
                        s.classList.remove('fas', 'active');
                        s.classList.add('far');
                    }
                });
            });
        });

        // Review form submission
        document.getElementById('new-review-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('reviewer-name').value;
            const rating = document.getElementById('review-rating').value;
            const comment = document.getElementById('review-comment').value;
            
            if (rating === '0') {
                showAlert('Please select a rating', 'error');
                return;
            }
            
           
            showAlert('Thank you for your review! It will be published after moderation.', 'success');
            
            // Reset form
            this.reset();
            stars.forEach(star => {
                star.classList.remove('fas', 'active');
                star.classList.add('far');
            });
            ratingInput.value = '0';
        });
    </script>
</body>
</html>