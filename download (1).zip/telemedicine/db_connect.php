<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$servername = "sql206.infinityfree.com";  
$username = "if0_40031860";          
$password = "qzJkHEejybefK";               
$dbname = "if0_40031860_dok";           


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$conn->set_charset("utf8");
?>
