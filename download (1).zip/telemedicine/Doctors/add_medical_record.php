<?php
session_start();
require_once 'db_connect.php';

// Check if doctor is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$doctorUserID = $_SESSION['userID'];

// Get doctor ID from user ID
$doctorQuery = $conn->prepare("SELECT doctorID FROM Doctor WHERE userID = ?");
$doctorQuery->bind_param("i", $doctorUserID);
$doctorQuery->execute();
$doctorResult = $doctorQuery->get_result();
$doctorData = $doctorResult->fetch_assoc();
$doctorQuery->close();

if (!$doctorData) {
    echo json_encode(['success' => false, 'message' => 'Doctor not found']);
    exit();
}

$doctorID = $doctorData['doctorID'];

# Get form data
$patientID = (int) $_POST['patientID'];
$recordDate = $_POST['recordDate'];
$appointmentID = !empty($_POST['appointmentID']) ? (int) $_POST['appointmentID'] : null;
$serviceID = !empty($_POST['serviceID']) ? (int) $_POST['serviceID'] : null;
$diagnosis = trim($_POST['diagnosis']) ?: null;
$symptoms = trim($_POST['symptoms']) ?: null;
$treatment = trim($_POST['treatment']) ?: null;
$notes = trim($_POST['notes']) ?: null;

// Validate required fields
if (empty($patientID) || empty($recordDate) || empty($diagnosis)) {
    echo json_encode(['success' => false, 'message' => 'Required fields missing (Patient, Date, Diagnosis)']);
    exit();
}

try {
    // Insert medical record with all fields
    $stmt = $conn->prepare("
        INSERT INTO MedicalRecord (patientID, doctorID, appointmentID, serviceID, diagnosis, symptoms, treatment, notes, recordDate) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->bind_param("iiiisssss", $patientID, $doctorID, $appointmentID, $serviceID, $diagnosis, $symptoms, $treatment, $notes, $recordDate);
    
    if ($stmt->execute()) {
        $recordID = $conn->insert_id;
        echo json_encode([
            'success' => true, 
            'message' => 'Medical record added successfully',
            'recordID' => $recordID
        ]);
    } else {
        throw new Exception('Failed to insert medical record: ' . $stmt->error);
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    error_log("Add medical record error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error occurred']);
}

$conn->close();
?>