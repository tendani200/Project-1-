<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include '../db_connect.php';

// Check if doctor is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    header("Location:login.php");
    exit();
}

$doctorUserID = $_SESSION['userID'];
$doctorQuery = $conn->prepare("SELECT doctorID FROM Doctor WHERE userID = ?");
$doctorQuery->bind_param("i", $doctorUserID);
$doctorQuery->execute();
$doctorResult = $doctorQuery->get_result();
$doctor = $doctorResult->fetch_assoc();
$doctorQuery->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Doctor Dashboard - Appointments & Schedule</title>
<style>
body { font-family: Arial, sans-serif; background: #f6f8fa; margin: 0; }
.sidebar { position:fixed; left:0; top:0; height:100vh; width:180px; background:#2a4d8f; color:#fff; padding-top:2rem; }
.sidebar ul { list-style:none; padding:0; }
.sidebar li { margin: 0; }
.sidebar a { color:#fff; display:block; padding:1rem; text-decoration:none; }
.sidebar a:hover { background:#1e3c72; }
.dashboard-container { max-width: 900px; margin: 2rem auto; background: #fff; border-radius: 8px; box-shadow: 0 2px 8px #e6eef8; padding: 2rem; }
h1 { color: #2a4d8f; }
h2 { color: #2a4d8f; margin-top:2rem; }
.app-table, .schedule-table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
.app-table th, .app-table td, .schedule-table th, .schedule-table td { padding: 10px; border-bottom: 1px solid #e6eef8; text-align: left; }
.app-table th, .schedule-table th { background: #f0f4fa; }
.patient-link { color: #2a4d8f; text-decoration: underline; cursor: pointer; }
.modal { display: none; position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(0,0,0,0.2); z-index: 1000; }
.modal-content { background: #fff; margin: 10vh auto; padding: 2rem; border-radius: 8px; max-width: 400px; position: relative; }
.close { position: absolute; right: 1rem; top: 1rem; cursor: pointer; font-size: 1.6rem; color: #b0b8c2; }
.muted { color: #888; font-size: 0.95em; }
.btn { padding: 8px 16px; border-radius: 6px; border: none; cursor: pointer; }
.btn-primary { background: #2a4d8f; color: #fff; }
</style>
</head>
<body>
<div class="sidebar">
    <ul>
        <li><a href="#" class="sidebar-link" data-section="appointments">Appointments</a></li>
        <li><a href="#" class="sidebar-link" data-section="patients">Patients</a></li>
        <li><a href="#" class="sidebar-link" data-section="records">Medical Records</a></li>
        <li><a href="#" class="sidebar-link" data-section="schedule">Schedule</a></li>
    </ul>
</div>
<div class="dashboard-container" style="margin-left:200px;">
    <div id="section-appointments" class="dashboard-section" style="display:none;">
        <h1>Your Appointments</h1>
        <div id="appointments-list"></div>
    </div>
    <div id="section-patients" class="dashboard-section" style="display:none;">
        <h1>Your Patients</h1>
        <div id="patients-list"></div>
    </div>
    <div id="section-records" class="dashboard-section" style="display:none;">
        <h1>Medical Records</h1>
        <div id="records-list"></div>
    </div>
    <div id="section-schedule" class="dashboard-section" style="display:none;">
        <h1>Your Upcoming Schedule</h1>
        <div id="schedule-list"></div>
    </div>
</div>
<div class="modal" id="globalModal">
    <div class="modal-content">
        <span class="close" id="modalClose">&times;</span>
        <h3 id="modalTitle">Modal</h3>
        <div id="modalBody" class="muted">Content goes here...</div>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    function openModal(title, content){
        document.getElementById('modalTitle').innerText = title || 'Modal';
        document.getElementById('modalBody').innerHTML = content || '';
        document.getElementById('globalModal').style.display = 'block';
    }
    function closeModal(){
        document.getElementById('globalModal').style.display = 'none';
    }
    document.getElementById('modalClose').addEventListener('click', closeModal);
    document.getElementById('globalModal').addEventListener('click', function(e){
        if(e.target === this) closeModal();
    });

    function showSection(section) {
        document.querySelectorAll('.dashboard-section').forEach(sec => sec.style.display = 'none');
        document.getElementById('section-' + section).style.display = 'block';
        document.querySelectorAll('.sidebar-link').forEach(link => link.classList.remove('active'));
        document.querySelector('.sidebar-link[data-section="' + section + '"]').classList.add('active');
    }

    document.querySelectorAll('.sidebar-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const section = this.getAttribute('data-section');
            showSection(section);
            if(section === 'appointments') loadAppointments();
            if(section === 'patients') loadPatients();
            if(section === 'records') loadRecords();
            if(section === 'schedule') loadSchedule();
        });
    });

    // Default view
    showSection('appointments');
    loadAppointments();

    function loadAppointments() {
        fetch('fetch_doctor_appointment.php')
            .then(res => res.json())
            .then(data => {
                let html = '<table class="app-table"><tr><th>Date</th><th>Time</th><th>Patient</th><th>Service</th><th>Status</th></tr>';
                if(data.length === 0) {
                    html += '<tr><td colspan="5" class="muted">No appointments found.</td></tr>';
                }
                data.forEach(a => {
                    html += `<tr>
                        <td>${a.appointmentDate}</td>
                        <td>${a.appointmentTime}</td>
                        <td>
                            <a href="#" class="patient-link" data-patient-id="${a.patientID}">
                                ${a.patientFirstName} ${a.patientLastName}
                            </a>
                        </td>
                        <td>${a.serviceName || ''}</td>
                        <td>${a.status}</td>
                    </tr>`;
                });
                html += '</table>';
                document.getElementById('appointments-list').innerHTML = html;
                attachPatientLinks('#appointments-list');
            });
    }

    function loadPatients() {
        fetch('fetch_doctor_patients.php')
            .then(res => res.json())
            .then(data => {
                let html = '<table class="app-table"><tr><th>Name</th><th>Email</th></tr>';
                if(data.length === 0) {
                    html += '<tr><td colspan="2" class="muted">No patients found.</td></tr>';
                }
                data.forEach(p => {
                    html += `<tr>
                        <td>
                            <a href="#" class="patient-link" data-patient-id="${p.patientID}">
                                ${p.firstName} ${p.lastName}
                            </a>
                        </td>
                        <td>${p.email}</td>
                    </tr>`;
                });
                html += '</table>';
                document.getElementById('patients-list').innerHTML = html;
                attachPatientLinks('#patients-list');
            });
    }

    function loadRecords() {
        fetch('fetch_doctor_records.php')
            .then(res => res.json())
            .then(data => {
                let html = '<table class="app-table"><tr><th>Date</th><th>Patient</th><th>Notes</th></tr>';
                if(data.length === 0) {
                    html += '<tr><td colspan="3" class="muted">No records found.</td></tr>';
                }
                data.forEach(r => {
                    html += `<tr>
                        <td>${r.recordDate}</td>
                        <td>
                            <a href="#" class="patient-link" data-patient-id="${r.patientID}">
                                ${r.patientName}
                            </a>
                        </td>
                        <td>${r.notes}</td>
                    </tr>`;
                });
                html += '</table>';
                document.getElementById('records-list').innerHTML = html;
                attachPatientLinks('#records-list');
            });
    }

    function loadSchedule() {
        fetch('fetch_doctor_schedule.php')
            .then(res => res.json())
            .then data => {
                let html = '<table class="schedule-table"><tr><th>Date</th><th>Time</th><th>Patient</th><th>Service</th></tr>';
                if(data.length === 0) {
                    html += '<tr><td colspan="4" class="muted">No upcoming schedule found.</td></tr>';
                }
                data.forEach(s => {
                    html += `<tr>
                        <td>${s.appointmentDate}</td>
                        <td>${s.appointmentTime}</td>
                        <td>
                            <a href="#" class="patient-link" data-patient-id="${s.patientID}">
                                ${s.patientName}
                            </a>
                        </td>
                        <td>${s.serviceName || ''}</td>
                    </tr>`;
                });
                html += '</table>';
                document.getElementById('schedule-list').innerHTML = html;
                attachPatientLinks('#schedule-list');
            });
    }

    function attachPatientLinks(containerSelector) {
        document.querySelectorAll(containerSelector + ' .patient-link').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const patientID = this.getAttribute('data-patient-id');
                fetch('fetch_patient_data.php?patientID=' + patientID)
                    .then(res => res.json())
                    .then(data => {
                        if(data.error){
                            openModal('Patient Details', `<div class="muted">${data.error}</div>`);
                        }else{
                            openModal('Patient Details', `
                                <div>
                                    <img src="${data.avatar}" alt="Avatar" style="width:64px;height:64px;border-radius:50%;margin-bottom:8px;">
                                    <h4>${data.name}</h4>
                                    <div class="muted">Email: ${data.email}</div>
                                    <div class="muted">Phone: ${data.phone}</div>
                                    <div class="muted">DOB: ${data.dob}</div>
                                    <div class="muted">Gender: ${data.gender}</div>
                                    <div class="muted">Address: ${data.address}</div>
                                </div>
                            `);
                        }
                    });
            });
        });
    }
});
</script>
</body>
</html>