<?php
session_start();
include '../db_connect.php';

// Check if doctor is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    header("Location:login.php");
    exit();
}

$doctorUserID = $_SESSION['userID'];

// Fetch doctor info
$doctorQuery = $conn->prepare("SELECT * FROM User u JOIN Doctor d ON u.userID = d.userID WHERE u.userID = ?");
$doctorQuery->bind_param("i", $doctorUserID);
$doctorQuery->execute();
$doctorResult = $doctorQuery->get_result();
$doctor = $doctorResult->fetch_assoc();
$doctorQuery->close();

// Get total patients
$totalPatientsResult = $conn->prepare("
    SELECT COUNT(DISTINCT p.patientID) AS total_patients
    FROM Patient p
    JOIN Appointments a ON p.patientID = a.patientID
    WHERE a.doctorID = ?
");
$totalPatientsResult->bind_param("i", $doctor['doctorID']);
$totalPatientsResult->execute();
$totalPatients = $totalPatientsResult->get_result()->fetch_assoc()['total_patients'] ?? 0;
$totalPatientsResult->close();

// Get today appointments
$today = date('Y-m-d');
$appointmentsQuery = $conn->prepare("
    SELECT a.appointmentTime AS time, a.appointmentID, a.patientID, CONCAT(u.firstName, ' ', u.lastName) AS patientName
    FROM Appointments a
    JOIN Patient p ON a.patientID = p.patientID
    JOIN User u ON p.userID = u.userID
    WHERE a.doctorID = ? AND a.appointmentDate = ?
    ORDER BY a.appointmentTime
");
$appointmentsQuery->bind_param("is", $doctor['doctorID'], $today);
$appointmentsQuery->execute();
$appointments = $appointmentsQuery->get_result();
$todayAppointmentsCount = $appointments->num_rows;

// Weekly appointments
$weekStart = date('Y-m-d', strtotime('monday this week'));
$weekEnd = date('Y-m-d', strtotime('sunday this week'));
$weeklyAppointmentsQuery = $conn->prepare("
    SELECT COUNT(*) AS weekly_appointments
    FROM Appointments
    WHERE doctorID = ? AND appointmentDate BETWEEN ? AND ?
");
$weeklyAppointmentsQuery->bind_param("iss", $doctor['doctorID'], $weekStart, $weekEnd);
$weeklyAppointmentsQuery->execute();
$weeklyAppointments = $weeklyAppointmentsQuery->get_result()->fetch_assoc()['weekly_appointments'] ?? 0;
$weeklyAppointmentsQuery->close();

$pendingTasksQuery = $conn->prepare("
    SELECT COUNT(*) AS pending_tasks
    FROM Appointments
    WHERE doctorID = ? AND (status = 'pending' OR status = 'scheduled') AND appointmentDate >= CURDATE()
");
$pendingTasksQuery->bind_param("i", $doctor['doctorID']);
$pendingTasksQuery->execute();
$pendingTasks = $pendingTasksQuery->get_result()->fetch_assoc()['pending_tasks'] ?? 0;
$pendingTasksQuery->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Dokotela - Doctor Dashboard</title>

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
:root{
    --blue-1: #0f4d92;
    --blue-2: #1CA9C9;
    --pastel: #E6F6FF;
    --bright-red: #ff2d55;
    --muted: #64748b;
    --bg: #f6fbff;
    --card-bg: rgba(255,255,255,0.75);
    --glass-border: rgba(255,255,255,0.35);
    --shadow: 0 6px 18px rgba(16,24,40,0.08);
    --radius: 12px;
    --glass-blur: 8px;
    --text-dark: #0f1724;
    --text-muted: #475569;
    --gap: 1rem;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%}
body{
    font-family: "Segoe UI", system-ui, -apple-system, "Helvetica Neue", Arial;
    background: #f1f8ff;
    background: radial-gradient(circle at top left, #e6f6ff 0%, #f1f8ff 100%);
    color: var(--text-dark);
}

.dashboard-container{
    display:flex;
    min-height:100vh;
    gap:var(--gap);
    transition: all 0.3s ease;
}
.sidebar{
    width:260px;
    background: linear-gradient(180deg, rgba(255,255,255,0.7), rgba(246,249,255,0.55));
    border-radius: calc(var(--radius) + 4px);
    padding:1rem;
    display:flex;
    flex-direction:column;
    gap:0.75rem;
    align-items:stretch;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(6px);
    transition: width 0.28s cubic-bezier(.22,.9,.36,1), transform 0.3s ease;
}
.sidebar.collapsed{ width:72px; padding:0.6rem; align-items:center }
.sidebar.collapsed .sidebar-header h2,
.sidebar.collapsed .nav-text,
.sidebar.collapsed .profile-info { display:none }
.sidebar.collapsed .nav-btn { justify-content:center }
.sidebar-header{
    display:flex;
    align-items:center;
    gap:0.75rem;
    padding:0.6rem 0.6rem;
}
.logo-mark{
    width:44px;height:44px;border-radius:10px;
    display:grid;place-items:center;color:white;
    background: linear-gradient(135deg,var(--blue-1),var(--blue-2));
    box-shadow: 0 6px 18px rgba(15,77,146,0.18);
    font-weight:700;
    font-size:1.05rem;
}
.sidebar-header h2{ color:var(--blue-1); font-size:1.05rem; font-weight:700; }
.sidebar-nav{
    display:flex;flex-direction:column;gap:6px;padding:0.5rem 0;
    width:100%;
}
.nav-btn{
    display:flex;align-items:center;gap:0.75rem;
    background:transparent;border:none;padding:0.6rem 0.8rem;border-radius:10px;
    cursor:pointer;color:var(--text-muted);font-size:0.95rem;transition: all 0.18s ease;
    text-decoration:none;
}
.nav-btn .fa-fw{ width:20px; text-align:center }
.nav-btn:hover{ transform:translateY(-2px); color:var(--blue-1); background: rgba(15,77,146,0.04) }
.nav-btn.active{
    background: linear-gradient(90deg, rgba(15,77,146,0.06), rgba(28,169,201,0.03));
    color:var(--blue-1);
    border-left: 3px solid var(--blue-2);
}
.nav-text{ flex:1 }
.user-profile{
    margin-top:auto;display:flex;align-items:center;gap:0.75rem;padding:0.6rem;border-radius:10px;
    background: linear-gradient(180deg, rgba(255,255,255,0.35), rgba(255,255,255,0.2));
    border: 1px solid rgba(255,255,255,0.25);
    backdrop-filter: blur(4px);
}
.user-profile img{ width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid white; box-shadow: 0 6px 14px rgba(16,24,40,0.06) }
.profile-info h4{ font-size:0.95rem; margin-bottom:2px }
.profile-info span{ font-size:0.82rem; color:var(--text-muted) }
.main-content{
    flex:1;padding:1.5rem;overflow:auto;
}
.topbar{
    display:flex;align-items:center;justify-content:space-between;gap:1rem;margin-bottom:1.25rem;
}
.topbar-left{
    display:flex;align-items:center;gap:1rem;
}
.hamburger{
    background:transparent;border:none;padding:0.5rem;cursor:pointer;color:var(--text-muted);
    border-radius:6px;transition:all 0.2s ease;
}
.hamburger:hover{background:rgba(15,77,146,0.06);color:var(--blue-1);}

.welcome-header{
    background: linear-gradient(135deg, rgba(15,77,146,0.95), rgba(28,169,201,0.95));
    color:white;padding:1.6rem;border-radius:14px;box-shadow: 0 12px 30px rgba(15,77,146,0.12);
    display:flex;flex-direction:column;gap:0.4rem;
}
.welcome-header h1{ font-size:1.6rem; font-weight:700 }
.welcome-header p{ opacity:0.95; font-size:0.95rem }
.grid{
    display:grid;
    grid-template-columns: repeat(12, 1fr);
    gap:1rem;
    margin-top:1rem;
}
.card{
    background: var(--card-bg);
    border-radius: var(--radius);
    padding:1rem;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(var(--glass-blur));
}
.stats-grid{ grid-column: span 12; display:grid; grid-template-columns: repeat(3,1fr); gap:1rem; }
.stat-card{
    padding:0.9rem; display:flex; align-items:center; gap:0.9rem; border-radius:10px;
}
.stat-icon{ font-size:1.75rem; background: linear-gradient(180deg, rgba(255,255,255,0.8), rgba(255,255,255,0.6)); padding:0.6rem; border-radius:10px;}
.stat-info .stat-value{ font-size:1.45rem; color:var(--blue-1); font-weight:700 }
.stat-info .stat-label{ color:var(--text-muted); font-size:0.9rem }
.schedule-card{ grid-column: span 12; padding:1rem }
    
.schedule-list ul{ list-style:none; display:flex; flex-direction:column; gap:0.6rem; margin-top:0.6rem }
.schedule-list li{ padding:0.6rem; border-radius:8px; background: rgba(255,255,255,0.65); display:flex; justify-content:space-between; align-items:center; border-left:4px solid rgba(28,169,201,0.18); }
.patients-grid{ grid-column: span 5; display:grid; gap:0.75rem; grid-auto-rows:min-content }
.patient-card{ padding:0.8rem; border-radius:8px; background: rgba(255,255,255,0.75); display:flex; flex-direction:column; gap:0.4rem; border-left:4px solid rgba(15,77,146,0.08) }
.appointments-table .placeholder{ padding:1rem; color:var(--text-muted) }
.btn{ display:inline-flex; align-items:center; gap:0.5rem; padding:0.55rem 0.9rem; border-radius:10px; border:none; cursor:pointer; font-weight:600; text-decoration:none; }
    
.btn-primary{ background: linear-gradient(90deg,var(--blue-1),var(--blue-2)); color:white }
.btn-ghost{ background:transparent; color:var(--text-dark); border:1px solid rgba(15,77,146,0.06) }
.btn-danger{ background:var(--bright-red); color:white }
.btn-secondary{
    background: linear-gradient(90deg, rgba(28,169,201,0.1), rgba(15,77,146,0.1));
    color: var(--blue-1);
    border: 1px solid rgba(15,77,146,0.2);
}
.btn-consult {
    background-color: #2563eb;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 0.55rem 0.9rem;
    cursor: pointer;
    font-weight: 600;
    transition: background 0.2s, box-shadow 0.2s;
}

.btn-consult:hover {
    background-color: #1e4fd4;
    box-shadow: 0 4px 12px rgba(37, 99, 235, 0.4);
}

.modal{ display:none; position:fixed; inset:0; z-index:1200; background: rgba(2,6,23,0.45); backdrop-filter: blur(4px) }
.modal .modal-content{ background: white; max-width:720px; margin:6% auto; padding:1.4rem; border-radius:12px; box-shadow: 0 20px 50px rgba(2,6,23,0.25) }
.glass-accent{ background: linear-gradient(180deg, rgba(255,255,255,0.6), rgba(255,255,255,0.35)); border-radius:10px; border:1px solid rgba(255,255,255,0.25); backdrop-filter: blur(6px) }

/* Search container */
.search-container {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-left: 1rem;
}

.search-box {
  display: flex;
  align-items: center;
  background: rgba(255, 255, 255, 0.15);
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 12px;
  padding: 6px 10px;
  height: 38px;
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
  transition: border 0.2s ease, background 0.2s ease, box-shadow 0.2s ease;
}

.search-box input {
  border: none;
  outline: none;
  background: transparent;
  width: 180px;
  font-size: 14px;
  color: var(--text-dark);
  backdrop-filter: blur(5px);
}

.search-box button {
  background-color: #2563eb;
  color: white;
  border: none;
  border-radius: 8px;
  padding: 6px 10px;
  cursor: pointer;
  font-size: 14px;
  transition: background 0.2s, box-shadow 0.2s;
  margin-left: 6px;
  box-shadow: 0 4px 15px rgba(37, 99, 235, 0.4);
}

.search-box button:hover {
  background-color: #1e4fd4;
  box-shadow: 0 6px 20px rgba(37, 99, 235, 0.5);
}

/* Weekly Overview */
.weekly-overview {
  background: white;
  border-radius: 10px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
  width: 300px;
  padding: 20px;
  margin-top: 40px;
}

.weekly-overview h3 {
  margin-top: 0;
  font-size: 16px;
  font-weight: 600;
  color: #111827;
}

.days {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 8px;
  margin-top: 10px;
  margin-bottom: 20px;
}

.day {
  background: #f3f4f6;
  border-radius: 8px;
  text-align: center;
  padding: 10px 0;
  font-weight: 500;
  color: #374151;
  transition: all 0.2s;
}

.day.active {
  background-color: #2563eb;
  color: white;
  box-shadow: 0 2px 6px rgba(37, 99, 235, 0.4);
}

@media (max-width: 1000px){
    .stats-grid{ grid-template-columns: repeat(2,1fr) }
    .schedule-card{ grid-column: span 12 }
    .patients-grid{ grid-column: span 12 }
}
@media (max-width: 720px){
    .dashboard-container{ flex-direction:column }
    .sidebar{ width:100%; flex-direction:row; align-items:center; gap:0.6rem; padding:0.6rem; border-radius:10px }
    .sidebar.collapsed{ width:100% }
    .sidebar-header h2{ display:none }
    .nav-btn{ padding:0.55rem; font-size:0.9rem }
    .grid{ grid-template-columns: 1fr; }
    .stats-grid{ grid-template-columns: 1fr }
    .welcome-header h1{ font-size:1.25rem }
    .search-container {
        justify-content: flex-end;
        margin-left: 0;
    }
    .search-box {
        width: 100%;
        max-width: 220px;
    }
    .search-box input {
        width: 100%;
    }
}
.muted { color:var(--text-muted); font-size:0.9rem }
.small { font-size:0.85rem }

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

th, td {
    padding: 0.75rem;
    text-align: left;
    border-bottom: 1px solid #e2e8f0;
}

th {
    background-color: rgba(15, 77, 146, 0.05);
    font-weight: 600;
    color: var(--blue-1);
}

tr:hover {
    background-color: rgba(15, 77, 146, 0.02);
}
    .btn-sm {
    padding: 0.4rem 0.8rem;
    font-size: 0.85rem;
}

/* Analytics Specific Styles */
.analytics-kpi {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.analytics-kpi:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.chart-bar {
    transition: all 0.3s ease;
    cursor: pointer;
}

.chart-bar:hover {
    opacity: 0.8;
    transform: scale(1.05);
}

.performance-metric {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.75rem 0;
    border-bottom: 1px solid #e5e7eb;
    transition: background-color 0.2s ease;
}

.performance-metric:hover {
    background-color: rgba(59, 130, 246, 0.05);
    border-radius: 4px;
    margin: 0 -0.5rem;
    padding: 0.75rem 0.5rem;
}

.recent-patient-item {
    transition: background-color 0.2s ease;
    border-radius: 6px;
    margin: 0 -0.5rem;
    padding: 0.75rem 0.5rem;
}

.recent-patient-item:hover {
    background-color: rgba(16, 185, 129, 0.05);
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

.analytics-loading {
    animation: pulse 2s infinite;
}

/* Responsive analytics adjustments */
@media (max-width: 768px) {
    .grid {
        grid-template-columns: 1fr !important;
    }
    
    #weeklyChart, #monthlyChart {
        height: 200px !important;
    }
    
    .analytics-kpi {
        text-align: center;
    }
}

.medical-record-item {
    transition: all 0.3s ease;
}

.medical-record-item:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

/* Enhanced Profile System Styles */
.avatar-type-btn, .avatar-style-btn {
    padding: 0.5rem 1rem;
    border: 2px solid #ddd;
    background: white;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 0.9rem;
    text-align: center;
}

.avatar-type-btn:hover, .avatar-style-btn:hover {
    border-color: var(--blue-1);
    background: #f0f8ff;
}

.avatar-type-btn.active, .avatar-style-btn.active {
    border-color: var(--blue-1);
    background: var(--blue-1);
    color: white;
}

.avatar-preview-item {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    cursor: pointer;
    border: 2px solid transparent;
    transition: all 0.3s ease;
    object-fit: cover;
}

.avatar-preview-item:hover {
    border-color: var(--blue-1);
    transform: scale(1.1);
}

.avatar-preview-item.selected {
    border-color: var(--green);
    box-shadow: 0 0 0 3px rgba(40, 167, 69, 0.2);
}

.stat-item {
    margin: 0.7rem 0;
    padding: 0.5rem;
    background: rgba(255,255,255,0.7);
    border-radius: 6px;
    border-left: 4px solid var(--blue-1);
}

.field-changed {
    border-color: #ffc107 !important;
    background-color: #fff9e6 !important;
    box-shadow: 0 0 0 2px rgba(255, 193, 7, 0.2) !important;
}

@keyframes pulse {
    0% { opacity: 1; }
    50% { opacity: 0.5; }
    100% { opacity: 1; }
}

.pulse {
    animation: pulse 1s infinite;
}
</style>
</head>
<body>
<div class="dashboard-container">
    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo-mark">D</div>
            <h2>Dokotela</h2>
        </div>

        <nav class="sidebar-nav" id="sidebarNav">
            <button class="nav-btn active" data-section="doctor-overview">
                <i class="fa fa-home fa-fw"></i> <span class="nav-text">Overview</span>
            </button>
            <button class="nav-btn" data-section="doctor-appointments">
                <i class="fa fa-calendar-check fa-fw"></i> <span class="nav-text">Appointments</span>
            </button>
            <button class="nav-btn" data-section="doctor-patients">
                <i class="fa fa-users fa-fw"></i> <span class="nav-text">Patients</span>
            </button>
            <button class="nav-btn" onclick="window.location.href='../bookings/manage_slots.php'">
                <i class="fa fa-clock fa-fw"></i> <span class="nav-text">Schedule</span>
            </button>
           
            <button class="nav-btn" onclick="window.location.href='prescriptions.php'">
                <i class="fa fa-prescription-bottle fa-fw"></i> <span class="nav-text">Prescriptions</span>
            </button>
            <button class="nav-btn" data-section="doctor-profile">
                <i class="fa fa-user-cog fa-fw"></i> <span class="nav-text">settings</span>
            </button>
            
        
            <button class="nav-btn" data-section="doctor-analytics">
                <i class="fa fa-chart-line fa-fw"></i> <span class="nav-text">My Performance and analytics</span>
            </button>
        </nav>

        <div class="user-profile">
            <img src="assets/doctor-avatar.png" alt="Doctor Avatar" id="doctorAvatar" onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIHZpZXdCb3g9IjAgMCA0OCA0OCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMjQiIGN5PSIyNCIgcj0iMjQiIGZpbGw9IiNmM2Y0ZjYiLz4KPHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1zbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTEyIDJDMTMuMSAyIDE0IDIuOSAxNCA0QzE0IDUuMSAxMy4xIDYgMTIgNkMxMC45IDYgMTAgNS4xIDEwIDRDMTAgMi45IDEwLjkgMiAxMiAyWk0yMSAxOUwyMS4yIDE5LjJDMjEuOSAxOSAyMi40IDE4LjQgMjIuNCAxNy43QzIyLjQgMTcuMSAyMS45IDE2LjUgMjEuMiAxNi40TDE5IDE2VjEzLjVDMTkgMTIuNSAxOC42IDExLjYgMTggMTFIMTNWOEMxNS4yIDggMTcgNi4yIDE3IDRDMTcgMS44IDE1LjIgMCAxMyAwSzExQzguOCAwIDcgMS44IDcgNEM3IDYuMiA4LjggOCAxMSA4VjExSDZDNS40IDExLjYgNSAxMi41IDUgMTMuNVYxNkwzIDEzLjRDMi4zIDEzLjUgMS44IDE0LjEgMS44IDE0LjdDMS44IDE1LjQgMi4zIDE2IDMgMTZIMjJDMjIuNyAxNiAyMy4yIDE1LjQgMjMuMiAxNC43QzIzLjIgMTQuMSAyMi43IDEzLjUgMjIgMTMuNFYxOVoiIGZpbGw9IiM2YjdjOGQiLz4KPC9zdmc+Cg=='">
            <div class="profile-info">
                <h4 id="doctorName"><?= htmlspecialchars($doctor['firstName'] . ' ' . $doctor['lastName']) ?></h4>
                <span><?= htmlspecialchars($doctor['specialty'] ?? 'Medical Practitioner') ?></span>
            </div>
        </div>
    </aside>

    <!-- MAIN -->
    <main class="main-content">
        <div class="topbar">
            <div class="topbar-left">
                <button class="hamburger" id="sidebarCollapse" title="Collapse sidebar" aria-label="Collapse sidebar">
                    <i class="fa fa-chevron-left"></i>
                </button>
                <div class="muted small">Welcome back, <strong><?= htmlspecialchars($doctor['firstName']) ?></strong></div>
            </div>

            <div class="search-container">
                <div class="search-box">
                    <input type="text" placeholder="Search patients, appointments..." id="searchInput">
                    <button id="searchBtn"><i class="fa fa-search"></i></button>
                </div>
            </div>

            <div class="topbar-right">
                <button class="btn btn-ghost" id="notifBtn"><i class="fa fa-bell"></i> <span class="small muted">Notifications</span></button>
                <a href="logout.php" class="btn btn-ghost"><i class="fa fa-sign-out-alt"></i> <span class="small muted">Logout</span></a>
            </div>
        </div>

        <!-- Overview Section -->
        <section id="doctor-overview" class="dashboard-section active">
            <div class="welcome-header">
                <h1>Good <span id="timeGreeting">
                    <?php $hour = date('G'); if ($hour < 12) echo "Morning"; elseif ($hour < 17) echo "Afternoon"; else echo "Evening"; ?>
                </span>, <span id="doctorWelcomeName"><?= htmlspecialchars($doctor['firstName']) ?></span></h1>
                <p class="small">You have <strong id="todayAppointments"><?= $todayAppointmentsCount ?></strong> appointments scheduled for today.</p>
            </div>

            <div class="grid">
                <div class="stats-grid card" style="grid-column: span 12;">
                    <div class="stat-card card glass-accent">
                        <div class="stat-icon"><i class="fa fa-user-md fa-lg" style="color:var(--blue-2)"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= $totalPatients ?></div>
                            <div class="stat-label muted">Total Patients</div>
                        </div>
                    </div>

                    <div class="stat-card card glass-accent">
                        <div class="stat-icon"><i class="fa fa-calendar-week fa-lg" style="color:var(--blue-1)"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= $weeklyAppointments ?></div>
                            <div class="stat-label muted">This Week</div>
                        </div>
                    </div>

                    <div class="stat-card card glass-accent" style="cursor: pointer;" onclick="showPendingTasks()">
                        <div class="stat-icon"><i class="fa fa-exclamation-circle fa-lg" style="color:var(--bright-red)"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= $pendingTasks ?></div>
                            <div class="stat-label muted">Pending Tasks</div>
                        </div>
                    </div>
                </div>
                
                <div class="schedule-card card" style="grid-column: span 12;">
                    <h3 style="margin:0 0 0.6rem 0; color:var(--blue-1)">Today's Schedule</h3>
                    <div class="schedule-list" id="todaySchedule">
                        <?php if ($appointments && $appointments->num_rows > 0): ?>
                            <ul>
                            <?php 
                            // Reset the result pointer
                            $appointments->data_seek(0);
                            while ($apt = $appointments->fetch_assoc()): ?>
                                <li class="schedule-card">
                                    <div class="schedule-info">
                                        <strong><?= htmlspecialchars($apt['time']) ?></strong>
                                        <span class="muted">Patient: <?= htmlspecialchars($apt['patientName']) ?></span>
                                    </div>
                                    <div class="schedule-actions">
                                        <button class="btn-consult" onclick="startConsultation(<?= $apt['appointmentID'] ?>)">Join Consultation</button>
                                        <button class="btn-consult" onclick="loadPatientSummary(<?= $apt['patientID'] ?>)">View Patient</button>
                                    </div>
                                </li>
                            <?php endwhile; ?>
                            </ul>
                        <?php else: ?>
                            <p class="muted">No appointments for today.</p>
                        <?php endif; ?>
                    </div>

                    <div style="margin-top:0.9rem;">
                        <button class="btn btn-primary" id="addApptBtn"><i class="fa fa-plus"></i>&nbsp;Add Appointment</button>
                        <button class="btn btn-secondary" id="viewAllBtn" style="margin-left:0.6rem;">View all</button>
                    </div>
                </div>
            </div>
        </section>

        <!-- Appointments Section -->
        <section id="doctor-appointments" class="dashboard-section" style="display:none;">
            <div class="card">
                <h2>Appointments</h2>
                <div id="appointments-list"></div>
            </div>
        </section>

        <!-- Patients Section -->
        <section id="doctor-patients" class="dashboard-section" style="display:none;">
            <div class="card">
                <h2>Patients</h2>
                <div id="patients-list"></div>
            </div>
        </section>

        <!-- Patient Summary Section -->
        <section id="patient-summary" class="dashboard-section" style="display:none;">
            <div class="card">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
                    <h2>Patient Summary</h2>
                    <button class="btn btn-ghost" onclick="goBackToPatients()">← Back to Patients</button>
                </div>
                
                <div id="patient-info" class="card" style="margin-bottom:1rem;">
                    <h3>Patient Information</h3>
                    <div id="patient-details"></div>
                </div>
                
                <div id="appointment-history" class="card" style="margin-bottom:1rem;">
                    <h3>Appointment History</h3>
                    <div id="appointment-history-list"></div>
                </div>
                
                <div id="medical-records" class="card">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
                        <h3>Medical Records</h3>
                        <button class="btn btn-primary" onclick="showAddMedicalRecordModal()">
                            <i class="fa fa-plus"></i> Add Medical Record
                        </button>
                    </div>
                    <div id="medical-records-list"></div>
                </div>
            </div>
        </section>

        <!-- Schedule Section -->
        <section id="doctor-schedule" class="dashboard-section" style="display:none;">
            <div class="card">
                <div style="text-align: center; padding: 3rem;">
                    <div style="margin-bottom: 2rem;">
                        <i class="fa fa-clock fa-3x" style="color: var(--blue-2); margin-bottom: 1rem;"></i>
                        <h2 style="color: var(--blue-1); margin-bottom: 0.5rem;">Schedule Management</h2>
                        <p class="muted" style="margin-bottom: 2rem;">Redirecting to schedule manager...</p>
                    </div>
                    
                    <div style="display: flex; justify-content: center; gap: 1rem;">
                        <div class="pulse">
                            <i class="fa fa-spinner fa-spin fa-2x" style="color: var(--blue-1);"></i>
                        </div>
                    </div>
                    
                    <p class="muted" style="margin-top: 2rem;">
                        If you are not redirected automatically, 
                        <a href="../bookings/manage_slots.php" style="color: var(--blue-1); text-decoration: underline;">click here</a>
                    </p>
                </div>
            </div>
        </section>

        <!-- Analytics Section -->
        <section id="doctor-analytics" class="dashboard-section" style="display:none;">
            <div class="card">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                    <h2><i class="fa fa-chart-line"></i> Analytics & Performance</h2>
                    <div style="display: flex; gap: 1rem; align-items: center;">
                        <button onclick="refreshAnalytics()" class="btn btn-primary">
                            <i class="fa fa-refresh"></i> Refresh
                        </button>
                        <span id="lastUpdated" style="font-size: 0.9rem; color: #666;"></span>
                    </div>
                </div>

                <!-- Loading indicator -->
                <div id="analyticsLoading" style="text-align: center; padding: 2rem;">
                    <i class="fa fa-spinner fa-spin fa-2x" style="color: #007bff;"></i>
                    <p>Loading analytics...</p>
                </div>

                <!-- Analytics Content -->
                <div id="analyticsContent" style="display: none;">
                    
                    <!-- Key Performance Indicators -->
                    <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem; margin-bottom: 2rem;">
                        <div class="card" style="text-align: center; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                            <h3 style="margin: 0; font-size: 1.1rem;">Today's Performance</h3>
                            <div style="margin: 1rem 0;">
                                <div style="font-size: 2.5rem; font-weight: bold;" id="todayPatientsHelped">0</div>
                                <div style="font-size: 0.9rem; opacity: 0.9;">Patients Helped Today</div>
                            </div>
                            <div style="font-size: 0.9rem; opacity: 0.8;">
                                <span id="todayAppointments">0</span> total appointments
                            </div>
                        </div>

                        <div class="card" style="text-align: center; background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white;">
                            <h3 style="margin: 0; font-size: 1.1rem;">This Week</h3>
                            <div style="margin: 1rem 0;">
                                <div style="font-size: 2.5rem; font-weight: bold;" id="weeklyPatientsHelped">0</div>
                                <div style="font-size: 0.9rem; opacity: 0.9;">Patients Helped</div>
                            </div>
                            <div style="font-size: 0.9rem; opacity: 0.8;">
                                <span id="weeklyAppointments">0</span> total appointments
                            </div>
                        </div>

                        <div class="card" style="text-align: center; background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white;">
                            <h3 style="margin: 0; font-size: 1.1rem;">This Month</h3>
                            <div style="margin: 1rem 0;">
                                <div style="font-size: 2.5rem; font-weight: bold;" id="monthlyPatientsHelped">0</div>
                                <div style="font-size: 0.9rem; opacity: 0.9;">Patients Helped</div>
                            </div>
                            <div style="font-size: 0.9rem; opacity: 0.8;">
                                <span id="monthlyAppointments">0</span> total appointments
                            </div>
                        </div>

                        <div class="card" style="text-align: center; background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: white;">
                            <h3 style="margin: 0; font-size: 1.1rem;">Success Rate</h3>
                            <div style="margin: 1rem 0;">
                                <div style="font-size: 2.5rem; font-weight: bold;" id="completionRate">0%</div>
                                <div style="font-size: 0.9rem; opacity: 0.9;">Completion Rate</div>
                            </div>
                            <div style="font-size: 0.9rem; opacity: 0.8;">
                                <span id="totalPatientsHelped">0</span> total patients helped
                            </div>
                        </div>
                    </div>

                    <!-- Charts Row -->
                    <div class="grid" style="grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 2rem;">
                        
                        <!-- Weekly Performance Chart -->
                        <div class="card">
                            <h3 style="margin-bottom: 1rem;">📊 Weekly Performance</h3>
                            <div id="weeklyChart" style="height: 300px; display: flex; justify-content: space-around; align-items: end; border: 1px solid #e5e7eb; border-radius: 8px; padding: 1rem; background: #f8f9fa;">
                                <!-- Dynamic content will be inserted here -->
                            </div>
                            <div style="text-align: center; margin-top: 1rem; color: #666;">
                                <small>Number of patients helped per day this week</small>
                            </div>
                        </div>

                        <!-- Monthly Trend -->
                        <div class="card">
                            <h3 style="margin-bottom: 1rem;">📈 Monthly Trend</h3>
                            <div id="monthlyChart" style="height: 300px; border: 1px solid #e5e7eb; border-radius: 8px; padding: 1rem; background: #f8f9fa; overflow-x: auto;">
                                <!-- Dynamic content will be inserted here -->
                            </div>
                            <div style="text-align: center; margin-top: 1rem; color: #666;">
                                <small>Daily patients helped this month</small>
                            </div>
                        </div>
                    </div>

                    <!-- Additional Statistics -->
                    <div class="grid" style="grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                        
                        <!-- Recent Activity -->
                        <div class="card">
                            <h3 style="margin-bottom: 1rem;">🕒 Recent Patients Helped</h3>
                            <div id="recentPatients" style="max-height: 300px; overflow-y: auto;">
                                <!-- Dynamic content will be inserted here -->
                            </div>
                        </div>

                        <!-- Performance Summary -->
                        <div class="card">
                            <h3 style="margin-bottom: 1rem;">📋 Performance Summary</h3>
                            <div id="performanceSummary">
                                <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid #e5e7eb;">
                                    <span>Total Appointments:</span>
                                    <span id="totalAppointments" style="font-weight: bold;">-</span>
                                </div>
                                <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid #e5e7eb;">
                                    <span>Completed:</span>
                                    <span id="totalCompleted" style="font-weight: bold; color: #10b981;">-</span>
                                </div>
                                <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid #e5e7eb;">
                                    <span>Cancelled:</span>
                                    <span id="totalCancelled" style="font-weight: bold; color: #ef4444;">-</span>
                                </div>
                                <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid #e5e7eb;">
                                    <span>Pending:</span>
                                    <span id="totalPending" style="font-weight: bold; color: #f59e0b;">-</span>
                                </div>
                                <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid #e5e7eb;">
                                    <span>Medical Records Created:</span>
                                    <span id="medicalRecords" style="font-weight: bold; color: #6366f1;">-</span>
                                </div>
                                <div style="display: flex; justify-content: space-between; padding: 0.5rem 0;">
                                    <span>This Week Records:</span>
                                    <span id="weeklyRecords" style="font-weight: bold; color: #8b5cf6;">-</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Profile Settings Section -->
        <section id="doctor-profile" class="dashboard-section" style="display:none;">
            <div class="card">
                <h2><i class="fa fa-user-cog"></i> Interactive Profile Settings</h2>
                
                <div class="grid" style="grid-template-columns: 1fr 2fr; gap: 2rem;">
                    <!-- Avatar & Profile Picture Section -->
                    <div class="card">
                        <h3>🎭 Avatar & Profile</h3>
                        
                        <!-- Current Avatar Display -->
                        <div style="text-align: center; margin-bottom: 2rem;">
                            <div id="currentAvatar" style="position: relative; display: inline-block;">
                                <img id="profileAvatar" src="https://api.dicebear.com/7.x/personas/doctor_default.svg?backgroundColor=b6e3f4" 
                                     alt="Profile Avatar" 
                                     style="width: 120px; height: 120px; border-radius: 50%; object-fit: cover; margin: 1rem 0; border: 3px solid var(--blue-1); background: white;">
                                <div style="position: absolute; bottom: 10px; right: 10px; background: var(--blue-1); color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; cursor: pointer;" 
                                     onclick="openAvatarSelector()">
                                    <i class="fa fa-edit"></i>
                                </div>
                            </div>
                            <p style="margin: 0.5rem 0; font-size: 0.9rem; color: #666;">Click the edit icon to customize your avatar</p>
                        </div>

                        <!-- Avatar Selector Modal (Hidden by default) -->
                        <div id="avatarModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000;">
                            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 2rem; border-radius: 12px; max-width: 600px; width: 90%; max-height: 80vh; overflow-y: auto;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                                    <h3>🎭 Choose Your Avatar</h3>
                                    <button onclick="closeAvatarSelector()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">&times;</button>
                                </div>
                                
                                <!-- Avatar Type Selector -->
                                <div style="margin-bottom: 1.5rem;">
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Avatar Type:</label>
                                    <div id="avatarTypes" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.5rem;">
                                        <button class="avatar-type-btn active" data-type="human">👨‍⚕️ Human</button>
                                        <button class="avatar-type-btn" data-type="animal">🐾 Animal</button>
                                        <button class="avatar-type-btn" data-type="cartoon">🎨 Cartoon</button>
                                        <button class="avatar-type-btn" data-type="abstract">🔮 Abstract</button>
                                    </div>
                                </div>

                                <!-- Avatar Style Selector -->
                                <div style="margin-bottom: 1.5rem;">
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Avatar Style:</label>
                                    <div id="avatarStyles" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.5rem;">
                                        <!-- Will be populated by JavaScript -->
                                    </div>
                                </div>

                                <!-- Avatar Preview Grid -->
                                <div style="margin-bottom: 1.5rem;">
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Choose Avatar:</label>
                                    <div id="avatarPreviewGrid" style="display: grid; grid-template-columns: repeat(6, 1fr); gap: 1rem; max-height: 300px; overflow-y: auto; padding: 1rem; border: 1px solid #ddd; border-radius: 8px;">
                                        <!-- Will be populated by JavaScript -->
                                    </div>
                                    <button onclick="generateMoreAvatars()" class="btn btn-secondary" style="margin-top: 1rem; width: 100%;">
                                        🎲 Generate More Options
                                    </button>
                                </div>

                                <div style="text-align: center;">
                                    <button onclick="saveSelectedAvatar()" class="btn btn-primary" style="margin-right: 1rem;">
                                        ✅ Use This Avatar
                                    </button>
                                    <button onclick="closeAvatarSelector()" class="btn btn-secondary">
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Quick Stats -->
                        <div style="margin-top: 2rem;">
                            <h4>📊 Quick Stats</h4>
                            <div id="doctorStats" style="padding: 1rem; background: linear-gradient(135deg, #f8f9fa, #e9ecef); border-radius: 8px;">
                                <div class="stat-item">👥 Total Patients: <strong id="totalPatientsCount">Loading...</strong></div>
                                <div class="stat-item">📅 This Week: <strong id="weeklyAppointmentsCount">Loading...</strong></div>
                                <div class="stat-item">⭐ Rating: <strong id="doctorRating">Loading...</strong></div>
                                <div class="stat-item">🎓 Experience: <strong id="yearsExperienceDisplay">Loading...</strong></div>
                            </div>
                        </div>
                    </div>

                    <!-- Profile Information Form -->
                    <div class="card">
                        <h3>📋 Personal Information</h3>
                        <form id="profileForm" style="display: grid; gap: 1rem;">
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                                <div>
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">First Name:</label>
                                    <input type="text" id="firstName" 
                                           style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 6px; transition: all 0.3s ease;"
                                           onchange="markFieldAsChanged(this)">
                                </div>
                                <div>
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Last Name:</label>
                                    <input type="text" id="lastName" 
                                           style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 6px; transition: all 0.3s ease;"
                                           onchange="markFieldAsChanged(this)">
                                </div>
                            </div>
                            
                            <div>
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Email:</label>
                                <input type="email" id="email" 
                                       style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 6px; transition: all 0.3s ease;"
                                       onchange="markFieldAsChanged(this)">
                            </div>
                            
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                                <div>
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Specialty:</label>
                                    <select id="specialty" 
                                            style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 6px; transition: all 0.3s ease;"
                                            onchange="markFieldAsChanged(this)">
                                        <option value="General Practitioner">General Practitioner</option>
                                        <option value="Cardiologist">Cardiologist</option>
                                        <option value="Dermatologist">Dermatologist</option>
                                        <option value="Pediatrician">Pediatrician</option>
                                        <option value="Psychiatrist">Psychiatrist</option>
                                        <option value="Surgeon">Surgeon</option>
                                        <option value="Neurologist">Neurologist</option>
                                        <option value="Orthopedic">Orthopedic</option>
                                        <option value="Gynecologist">Gynecologist</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                                <div>
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Years of Experience:</label>
                                    <input type="number" id="yearsExperience" min="0" max="50" 
                                           style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 6px; transition: all 0.3s ease;"
                                           onchange="markFieldAsChanged(this)">
                                </div>
                            </div>
                            
                            <div>
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">📱 Phone Number:</label>
                                <input type="tel" id="phone" placeholder="+27 XX XXX XXXX"
                                       style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 6px; transition: all 0.3s ease;"
                                       onchange="markFieldAsChanged(this)">
                            </div>
                            
                            <div>
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">💰 Consultation Fee (ZAR):</label>
                                <input type="number" id="consultationFee" min="0" step="50" placeholder="500"
                                       style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 6px; transition: all 0.3s ease;"
                                       onchange="markFieldAsChanged(this)">
                            </div>
                            
                            <div>
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">📝 Professional Bio:</label>
                                <textarea id="bio" rows="4" placeholder="Brief description about your practice, expertise, and approach to patient care..." 
                                          style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 6px; resize: vertical; transition: all 0.3s ease;"
                                          onchange="markFieldAsChanged(this)"></textarea>
                            </div>

                            <div>
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">🎓 Education:</label>
                                <textarea id="education" rows="2" placeholder="Medical degree, university, certifications..." 
                                          style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 6px; resize: vertical; transition: all 0.3s ease;"
                                          onchange="markFieldAsChanged(this)"></textarea>
                            </div>
                            
                            <div id="saveButtonContainer" style="display: none;">
                                <button type="submit" class="btn btn-primary" style="position: relative;">
                                    <i class="fa fa-save"></i> Save Changes
                                    <span id="saveIndicator" style="position: absolute; top: -5px; right: -5px; background: #28a745; color: white; border-radius: 50%; width: 20px; height: 20px; font-size: 0.8rem; display: none;">!</span>
                                </button>
                                <small style="color: #666; margin-left: 1rem;">Changes detected - click to save</small>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Availability Settings -->
                <div class="card" style="margin-top: 2rem;">
                    <h3>⏰ Availability Settings</h3>
                    <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1rem;">
                        <div>
                            <h4>Working Hours</h4>
                            <div style="margin: 1rem 0;">
                                <label style="display: block; margin-bottom: 0.5rem;">Start Time:</label>
                                <input type="time" value="09:00" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 6px; width: 100%;">
                            </div>
                            <div style="margin: 1rem 0;">
                                <label style="display: block; margin-bottom: 0.5rem;">End Time:</label>
                                <input type="time" value="17:00" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 6px; width: 100%;">
                            </div>
                        </div>
                        
                        <div>
                            <h4>Working Days</h4>
                            <div style="margin: 1rem 0;">
                                <label style="display: flex; align-items: center; margin: 0.5rem 0;">
                                    <input type="checkbox" checked style="margin-right: 0.5rem;">
                                    Monday to Friday
                                </label>
                                <label style="display: flex; align-items: center; margin: 0.5rem 0;">
                                    <input type="checkbox" style="margin-right: 0.5rem;">
                                    Saturday
                                </label>
                                <label style="display: flex; align-items: center; margin: 0.5rem 0;">
                                    <input type="checkbox" style="margin-right: 0.5rem;">
                                    Sunday
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Weekly Overview -->
        <section class="weekly-overview">
            <h3>Weekly Overview</h3>
            <div class="days">
                <div class="day" id="mon">Mon<br><small>--</small></div>
                <div class="day" id="tue">Tue<br><small>--</small></div>
                <div class="day" id="wed">Wed<br><small>--</small></div>
                <div class="day" id="thu">Thu<br><small>--</small></div>
                <div class="day" id="fri">Fri<br><small>--</small></div>
                <div class="day" id="sat">Sat<br><small>--</small></div>
                <div class="day" id="sun">Sun<br><small>--</small></div>
            </div>
        </section>
    </main>
</div>

<!-- Global Modal -->
<div id="globalModal" class="modal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5);">
    <div class="modal-content" style="background-color: #fefefe; margin: 5% auto; padding: 20px; border: 1px solid #888; border-radius: 12px; width: 90%; max-width: 800px; max-height: 80vh; overflow-y: auto;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; border-bottom: 1px solid #eee; padding-bottom: 1rem;">
            <h2 id="modalTitle" style="margin: 0; color: var(--blue-1);">Modal Title</h2>
            <span id="modalClose" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        </div>
        <div id="modalBody">
            <!-- Modal content will be inserted here -->
        </div>
    </div>
</div>

<!-- Add Medical Record Modal -->
<div id="addMedicalRecordModal" class="modal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5);">
    <div class="modal-content" style="background-color: #fefefe; margin: 5% auto; padding: 20px; border: 1px solid #888; border-radius: 12px; width: 90%; max-width: 600px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; border-bottom: 1px solid #eee; padding-bottom: 1rem;">
            <h3 style="margin: 0; color: var(--blue-1);">Add Medical Record</h3>
            <span onclick="closeAddMedicalRecordModal()" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        </div>
        <form id="addMedicalRecordForm">
            <input type="hidden" id="medicalRecordPatientID" name="patientID" value="">
            
            <div style="margin-bottom: 1rem;">
                <label for="recordDate" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Record Date:</label>
                <input type="date" id="recordDate" name="recordDate" required 
                       value="<?= date('Y-m-d') ?>"
                       style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px;">
            </div>
            
            <div style="margin-bottom: 1rem;">
                <label for="appointmentID" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Appointment ID (Optional):</label>
                <input type="number" id="appointmentID" name="appointmentID" 
                       style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px;"
                       placeholder="Enter appointment ID if applicable">
            </div>
            
            <div style="margin-bottom: 1rem;">
                <label for="serviceID" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Service ID (Optional):</label>
                <input type="number" id="serviceID" name="serviceID" 
                       style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px;"
                       placeholder="Enter service ID if applicable">
            </div>
            
            <div style="margin-bottom: 1rem;">
                <label for="diagnosis" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Diagnosis:</label>
                <input type="text" id="diagnosis" name="diagnosis" required
                       style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px;"
                       placeholder="Enter patient diagnosis">
            </div>
            
            <div style="margin-bottom: 1rem;">
                <label for="symptoms" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Symptoms:</label>
                <textarea id="symptoms" name="symptoms" rows="3" 
                          style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px; resize: vertical;"
                          placeholder="Enter patient symptoms"></textarea>
            </div>
            
            <div style="margin-bottom: 1rem;">
                <label for="treatment" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Treatment:</label>
                <textarea id="treatment" name="treatment" rows="3" 
                          style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px; resize: vertical;"
                          placeholder="Enter treatment plan"></textarea>
            </div>
            
            <div style="margin-bottom: 1rem;">
                <label for="notes" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Additional Notes (Optional):</label>
                <textarea id="medicalNotes" name="notes" rows="3" 
                          style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px; resize: vertical;"
                          placeholder="Enter additional medical notes or observations"></textarea>
            </div>
            
            <div style="display: flex; gap: 1rem; justify-content: flex-end;">
                <button type="button" class="btn btn-ghost" onclick="closeAddMedicalRecordModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i> Save Record
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Add Prescription Modal -->
<div id="addPrescriptionModal" class="modal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5);">
    <div style="background-color: #fff; margin: 5% auto; padding: 0; border-radius: 12px; width: 90%; max-width: 600px; max-height: 90vh; overflow-y: auto;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 1.5rem; border-radius: 12px 12px 0 0;">
            <h3 style="margin: 0; display: flex; align-items: center; gap: 0.5rem;">
                <i class="fa fa-prescription-bottle"></i> Add Prescription to Medical Record
            </h3>
            <span onclick="closePrescriptionModal()" style="color: #fff; float: right; font-size: 28px; font-weight: bold; cursor: pointer; margin-top: -2rem;">&times;</span>
        </div>
        
        <form id="addPrescriptionForm" style="padding: 2rem;">
            <input type="hidden" id="prescriptionRecordID" name="recordID" value="">
            <input type="hidden" id="prescriptionPatientID" name="patientID" value="">
            
            <div style="margin-bottom: 1rem;">
                <label for="prescriptionDate" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Prescription Date:</label>
                <input type="date" id="prescriptionDate" name="prescriptionDate" required 
                       value="<?= date('Y-m-d') ?>"
                       style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px;">
            </div>
            
            <div style="margin-bottom: 1rem;">
                <label for="medication" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Medication:</label>
                <input type="text" id="medication" name="medication" required
                       style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px;"
                       placeholder="Enter medication name">
            </div>
            
            <div style="margin-bottom: 1rem;">
                <label for="dosage" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Dosage:</label>
                <input type="text" id="dosage" name="dosage" required
                       style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px;"
                       placeholder="e.g., 500mg, 2 tablets">
            </div>
            
            <div style="margin-bottom: 1rem;">
                <label for="frequency" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Frequency:</label>
                <select id="frequency" name="frequency" required
                        style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px;">
                    <option value="">Select frequency...</option>
                    <option value="Once daily">Once daily</option>
                    <option value="Twice daily">Twice daily</option>
                    <option value="Three times daily">Three times daily</option>
                    <option value="Four times daily">Four times daily</option>
                    <option value="Every 6 hours">Every 6 hours</option>
                    <option value="Every 8 hours">Every 8 hours</option>
                    <option value="Every 12 hours">Every 12 hours</option>
                    <option value="As needed">As needed</option>
                    <option value="Before meals">Before meals</option>
                    <option value="After meals">After meals</option>
                </select>
            </div>
            
            <div style="margin-bottom: 1rem;">
                <label for="duration" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Duration:</label>
                <input type="text" id="duration" name="duration" required
                       style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px;"
                       placeholder="e.g., 7 days, 2 weeks, 1 month">
            </div>
            
            <div style="margin-bottom: 1rem;">
                <label for="prescriptionInstructions" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Instructions (Optional):</label>
                <textarea id="prescriptionInstructions" name="instructions" rows="3" 
                          style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px; resize: vertical;"
                          placeholder="Additional instructions for the patient..."></textarea>
            </div>
            
            <div style="display: flex; gap: 1rem; justify-content: flex-end;">
                <button type="button" class="btn btn-ghost" onclick="closePrescriptionModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i> Save & Generate PDF
                </button>
            </div>
        </form>
    </div>
</div>


<script>
const sidebar = document.getElementById('sidebar');
const sidebarCollapse = document.getElementById('sidebarCollapse');
const navBtns = document.querySelectorAll('.nav-btn');
const sections = document.querySelectorAll('.dashboard-section');
const modal = document.getElementById('globalModal');
const modalClose = document.getElementById('modalClose');

function setActiveSection(id){
    console.log('Setting active section to:', id);
    const sections = document.querySelectorAll('.dashboard-section');
    const navBtns = document.querySelectorAll('.nav-btn');
    
    sections.forEach(s => {
        if(s.id === id) {
            s.classList.add('active');
            s.style.display = '';
            console.log('Showing section:', s.id);
        } else {
            s.classList.remove('active');
            s.style.display = 'none';
        }
    });
    navBtns.forEach(b => {
        if(b.dataset.section === id) b.classList.add('active'); 
        else b.classList.remove('active');
    });

    // Load data for each section
    if(id === 'doctor-appointments') loadAppointments();
    if(id === 'doctor-patients') loadPatients();
    if(id === 'doctor-schedule') handleScheduleSection();
    if(id === 'doctor-records') loadRecords();
    if(id === 'doctor-profile') loadProfile();
    
    console.log('Active section set to:', id);
}

// Handle schedule section redirection
function handleScheduleSection() {
    const scheduleSection = document.getElementById('doctor-schedule');
    if (scheduleSection && scheduleSection.classList.contains('active')) {
        setTimeout(() => {
            window.location.href = '../bookings/manage_slots.php';
        }, 1500); // Redirect after 1.5 seconds to show the loading state
    }
}

// Collapse for desktop (chevron)
sidebarCollapse?.addEventListener('click', (e) => {
    sidebar.classList.toggle('collapsed');
    const chev = sidebarCollapse.querySelector('i');
    if(chev) {
        chev.classList.toggle('fa-chevron-left');
        chev.classList.toggle('fa-chevron-right');
    }
});

// Nav behavior
navBtns.forEach(btn=>{
    btn.addEventListener('click', (ev)=>{
        const section = btn.dataset.section;
        if(section){
            ev.preventDefault();
            document.querySelector('main').scrollTo({top:0, behavior:'smooth'});
            setActiveSection(section);
        }
    });
});

// View All button functionality
document.getElementById('viewAllBtn')?.addEventListener('click', ()=>{
    setActiveSection('doctor-appointments');
});

// Keyboard accessibility
document.addEventListener('keydown', (e)=>{
    if(e.key === 'Escape'){
        if(sidebar.classList.contains('collapsed')){
            sidebar.classList.remove('collapsed');
        }
        if(modal.style.display === 'block') {
            closeModal();
        }
    }
});

// Pending tasks functionality
function showPendingTasks() {
    fetch('fetch_pending_tasks.php')
        .then(res => res.json())
        .then(data => {
            let html = '<div style="max-height: 400px; overflow-y: auto;">';
            if (data.length === 0) {
                html += '<p class="muted">No pending tasks found.</p>';
            } else {
                html += '<table><tr><th>Date</th><th>Time</th><th>Patient</th><th>Status</th><th>Action</th></tr>';
                data.forEach(task => {
                    html += `<tr>
                        <td>${task.appointmentDate}</td>
                        <td>${task.appointmentTime}</td>
                        <td>${task.patientFirstName} ${task.patientLastName}</td>
                        <td><span style="color: #f59e0b; font-weight: 600;">${task.status}</span></td>
                        <td>
                            <button class="btn btn-primary" onclick="updateAppointmentStatus(${task.appointmentID}, 'confirmed')">Confirm</button>
                        </td>
                    </tr>`;
                });
                html += '</table>';
            }
            html += '</div>';
            
            openModal('Pending Tasks', html);
        })
        .catch(err => {
            console.error('Error loading pending tasks:', err);
            openModal('Pending Tasks', '<p class="muted">Error loading pending tasks.</p>');
        });
}

function updateAppointmentStatus(appointmentID, newStatus) {
    fetch('update_appointment_status.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            appointmentID: appointmentID,
            status: newStatus
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert('✅ Appointment status updated!');
            closeModal();
            location.reload();
        } else {
            alert('❌ Error: ' + data.message);
        }
    })
    .catch(err => {
        console.error('Error updating status:', err);
        alert('❌ Failed to update status.');
    });
}

// Modal functions
function openModal(title, content){
    document.getElementById('modalTitle').innerText = title || 'Modal';
    document.getElementById('modalBody').innerHTML = content || '';
    modal.style.display = 'block';
    modal.setAttribute('aria-hidden', 'false');
}

function closeModal(){
    modal.style.display = 'none';
    modal.setAttribute('aria-hidden', 'true');
}

modalClose?.addEventListener('click', closeModal);
modal.addEventListener('click', (e) => {
    if(e.target === modal) closeModal();
});

// Add Appointment functionality
document.getElementById('addApptBtn')?.addEventListener('click', ()=>{
    showAddAppointmentModal();
});

function showAddAppointmentModal() {
    const modalContent = `
        <form id="addAppointmentForm" style="max-width: 500px;">
            <div style="margin-bottom: 1rem;">
                <label for="patientEmail" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Patient Email:</label>
                <input type="email" id="patientEmail" name="patientEmail" required 
                       placeholder="patient@example.com"
                       style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px; font-size: 0.95rem;">
            </div>
            
            <div style="margin-bottom: 1rem;">
                <label for="appointmentDate" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Appointment Date:</label>
                <input type="date" id="appointmentDate" name="appointmentDate" required
                       min="${new Date().toISOString().split('T')[0]}"
                       style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px; font-size: 0.95rem;">
            </div>
            
            <div style="margin-bottom: 1rem;">
                <label for="appointmentTime" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Appointment Time:</label>
                <input type="time" id="appointmentTime" name="appointmentTime" required
                       style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px; font-size: 0.95rem;">
            </div>
            
            <div style="margin-bottom: 1rem;">
                <label for="consultationType" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Consultation Type:</label>
                <select id="consultationType" name="consultationType"
                        style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px; font-size: 0.95rem;">
                    <option value="video">Video Call</option>
                    <option value="audio">Audio Call</option>
                    <option value="chat">Chat</option>
                    <option value="in-person">In-Person</option>
                </select>
            </div>
            
            <div style="margin-bottom: 1.5rem;">
                <label for="notes" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Notes (Optional):</label>
                <textarea id="notes" name="notes" rows="3" placeholder="Additional notes..."
                          style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px; font-size: 0.95rem; resize: vertical;"></textarea>
            </div>
            
            <div style="display: flex; gap: 1rem; justify-content: flex-end;">
                <button type="button" class="btn btn-ghost" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-plus"></i> Add Appointment
                </button>
            </div>
        </form>
    `;
    
    openModal('Add New Appointment', modalContent);
    
    document.getElementById('addAppointmentForm').addEventListener('submit', handleAddAppointment);
}

function handleAddAppointment(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const submitBtn = e.target.querySelector('button[type="submit"]');
    
    submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Adding...';
    submitBtn.disabled = true;
    
    fetch('add_appointment.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert('✅ Appointment added successfully!');
            closeModal();
            location.reload();
        } else {
            alert('❌ Error: ' + (data.message || 'Failed to add appointment'));
        }
    })
    .catch(err => {
        console.error('Error adding appointment:', err);
        alert('❌ Failed to add appointment. Please try again.');
    })
    .finally(() => {
        submitBtn.innerHTML = '<i class="fa fa-plus"></i> Add Appointment';
        submitBtn.disabled = false;
    });
}

// Data loading functions
function loadAppointments() {
    fetch('fetch_doctor_appointment.php')
        .then(res => res.json())
        .then(data => {
            let html = '<table><tr><th>Date</th><th>Time</th><th>Patient</th><th>Status</th><th>Actions</th></tr>';
            data.forEach(a => {
                html += `<tr>
                    <td>${a.appointmentDate}</td>
                    <td>${a.appointmentTime}</td>
                    <td>${a.patientFirstName} ${a.patientLastName}</td>
                    <td>${a.status}</td>
                    <td>
                        <button class="btn btn-primary" onclick="startConsultation(${a.appointmentID})" style="margin-right: 0.5rem;">Join</button>
                        <button class="btn btn-ghost" onclick="loadPatientSummary(${a.patientID})">View Patient</button>
                    </td>
                </tr>`;
            });
            html += '</table>';
            document.getElementById('appointments-list').innerHTML = html;
        })
        .catch(err => {
            console.error('Error loading appointments:', err);
            document.getElementById('appointments-list').innerHTML = '<p class="muted">Error loading appointments.</p>';
        });
}

function loadPatients() {
    fetch('fetch_doctor_patients.php')
        .then(res => res.json())
        .then(data => {
            let html = '<table><tr><th>Name</th><th>Email</th><th>Action</th></tr>';
            data.forEach(p => {
                html += `<tr>
                    <td>${p.firstName} ${p.lastName}</td>
                    <td>${p.email}</td>
                    <td>
                        <button class="btn btn-primary" onclick="loadPatientSummary(${p.patientID})">View Summary</button>
                    </td>
                </tr>`;
            });
            html += '</table>';
            document.getElementById('patients-list').innerHTML = html;
        })
        .catch(err => {
            console.error('Error loading patients:', err);
            document.getElementById('patients-list').innerHTML = '<p class="muted">Error loading patients.</p>';
        });
}

function loadRecords() {
    fetch('fetch_doctor_records.php')
        .then(res => res.json())
        .then(data => {
            let html = '<table><tr><th>Date</th><th>Patient</th><th>Description</th></tr>';
            data.forEach(r => {
                html += `<tr>
                    <td>${r.recordDate}</td>
                    <td>${r.patientFirstName} ${r.patientLastName}</td>
                    <td>${r.description}</td>
                </tr>`;
            });
            html += '</table>';
            document.getElementById('records-list').innerHTML = html;
        })
        .catch(err => {
            console.error('Error loading records:', err);
            document.getElementById('records-list').innerHTML = '<p class="muted">Error loading records.</p>';
        });
}

// Profile Functions
let currentAvatarData = {
    type: 'human',
    style: 'professional',
    seed: 'doctor_default',
    url: 'https://api.dicebear.com/7.x/personas/doctor_default.svg?backgroundColor=b6e3f4'
};

let hasUnsavedChanges = false;
let selectedAvatar = null;

function loadProfile() {
    console.log('Loading interactive profile settings...');
    
    // Load profile data from API
    fetch('doctor_profile_api.php')
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                populateProfileForm(data.doctor);
                updateProfileStats(data.doctor.stats);
                loadCurrentAvatar(data.doctor);
            } else {
                console.error('Failed to load profile:', data.error);
                showNotification('Failed to load profile data', 'error');
            }
        })
        .catch(err => {
            console.error('Profile loading error:', err);
            showNotification('Network error loading profile', 'error');
        });
}

function populateProfileForm(doctor) {
    document.getElementById('firstName').value = doctor.firstName || '';
    document.getElementById('lastName').value = doctor.lastName || '';
    document.getElementById('email').value = doctor.email || '';
    document.getElementById('specialty').value = doctor.specialty || 'General Practitioner';
    document.getElementById('phone').value = doctor.phone || '';
    document.getElementById('bio').value = doctor.bio || '';
    document.getElementById('yearsExperience').value = doctor.yearsExperience || 0;
    document.getElementById('consultationFee').value = doctor.consultationFee || 500;
    document.getElementById('education').value = doctor.education || '';

    // Update current avatar data
    if (doctor.avatarType && doctor.avatarStyle) {
        currentAvatarData = {
            type: doctor.avatarType,
            style: doctor.avatarStyle,
            seed: doctor.avatarSeed || 'doctor_' + doctor.doctorID,
            url: generateAvatarUrl(doctor.avatarType, doctor.avatarStyle, doctor.avatarSeed || 'doctor_' + doctor.doctorID)
        };
    }
}

function updateProfileStats(stats) {
    document.getElementById('totalPatientsCount').textContent = stats.totalPatients || 0;
    document.getElementById('weeklyAppointmentsCount').textContent = stats.totalAppointments || 0;
    
    const rating = stats.avgRating ? parseFloat(stats.avgRating).toFixed(1) : 'N/A';
    document.getElementById('doctorRating').textContent = rating === 'N/A' ? rating : rating + '/5.0';
    
    const experience = document.getElementById('yearsExperience').value;
    document.getElementById('yearsExperienceDisplay').textContent = experience ? experience + ' years' : 'Not set';
}

function loadCurrentAvatar(doctor) {
    const avatarImg = document.getElementById('profileAvatar');
    const avatarUrl = generateAvatarUrl(
        doctor.avatarType || 'human', 
        doctor.avatarStyle || 'professional', 
        doctor.avatarSeed || 'doctor_default'
    );
    avatarImg.src = avatarUrl;
}

function generateAvatarUrl(type, style, seed) {
    // Generate avatar URL using our avatar generator
    return `avatar_generator.php?action=generate&type=${type}&style=${style}&seed=${seed}`;
}

function markFieldAsChanged(field) {
    hasUnsavedChanges = true;
    field.classList.add('field-changed');
    
    // Show save button
    document.getElementById('saveButtonContainer').style.display = 'block';
    document.getElementById('saveIndicator').style.display = 'inline-block';
    document.getElementById('saveIndicator').classList.add('pulse');
    
    // Update experience display in real-time
    if (field.id === 'yearsExperience') {
        document.getElementById('yearsExperienceDisplay').textContent = field.value ? field.value + ' years' : 'Not set';
    }
}

function openAvatarSelector() {
    document.getElementById('avatarModal').style.display = 'block';
    loadAvatarOptions();
    generateAvatarPreviews();
}

function closeAvatarSelector() {
    document.getElementById('avatarModal').style.display = 'none';
    selectedAvatar = null;
}

function loadAvatarOptions() {
    fetch('avatar_generator.php?action=options')
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                setupAvatarTypeButtons(data.options);
                updateAvatarStyleButtons('human', data.options);
            }
        })
        .catch(err => console.error('Failed to load avatar options:', err));
}

function setupAvatarTypeButtons(options) {
    const container = document.getElementById('avatarTypes');
    container.innerHTML = '';
    
    const typeLabels = {
        human: '👨‍⚕️ Human',
        animal: '🐾 Animal', 
        cartoon: '🎨 Cartoon',
        abstract: '🔮 Abstract'
    };
    
    Object.keys(options).forEach(type => {
        const btn = document.createElement('button');
        btn.className = 'avatar-type-btn';
        btn.dataset.type = type;
        btn.textContent = typeLabels[type] || type;
        btn.onclick = () => selectAvatarType(type, options);
        
        if (type === currentAvatarData.type) {
            btn.classList.add('active');
        }
        
        container.appendChild(btn);
    });
}

function selectAvatarType(type, options) {
    // Update active button
    document.querySelectorAll('.avatar-type-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelector(`[data-type="${type}"]`).classList.add('active');
    
    // Update style options
    updateAvatarStyleButtons(type, options);
    
    // Update current selection
    currentAvatarData.type = type;
    currentAvatarData.style = Object.keys(options[type])[0]; // First style as default
    
    // Regenerate previews
    generateAvatarPreviews();
}

function updateAvatarStyleButtons(type, options) {
    const container = document.getElementById('avatarStyles');
    container.innerHTML = '';
    
    Object.entries(options[type] || {}).forEach(([style, label]) => {
        const btn = document.createElement('button');
        btn.className = 'avatar-style-btn';
        btn.dataset.style = style;
        btn.textContent = label;
        btn.onclick = () => selectAvatarStyle(style);
        
        if (style === currentAvatarData.style) {
            btn.classList.add('active');
        }
        
        container.appendChild(btn);
    });
}

function selectAvatarStyle(style) {
    // Update active button
    document.querySelectorAll('.avatar-style-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelector(`[data-style="${style}"]`).classList.add('active');
    
    // Update current selection
    currentAvatarData.style = style;
    
    // Regenerate previews
    generateAvatarPreviews();
}

function generateAvatarPreviews() {
    const container = document.getElementById('avatarPreviewGrid');
    container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 1rem;">Generating avatars...</div>';
    
    const promises = [];
    for (let i = 0; i < 12; i++) {
        const seed = `doctor_${currentAvatarData.type}_${Date.now()}_${i}`;
        const url = `avatar_generator.php?action=generate&type=${currentAvatarData.type}&style=${currentAvatarData.style}&seed=${seed}`;
        promises.push(fetch(url).then(res => res.json()));
    }
    
    Promise.all(promises)
        .then(results => {
            container.innerHTML = '';
            results.forEach((result, index) => {
                if (result.success) {
                    const img = document.createElement('img');
                    img.src = result.avatarUrl;
                    img.className = 'avatar-preview-item';
                    img.dataset.seed = result.seed;
                    img.dataset.url = result.avatarUrl;
                    img.onclick = () => selectAvatarPreview(img);
                    container.appendChild(img);
                }
            });
        })
        .catch(err => {
            container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; color: red;">Failed to generate avatars</div>';
            console.error('Avatar generation error:', err);
        });
}

function generateMoreAvatars() {
    generateAvatarPreviews();
}

function selectAvatarPreview(img) {
    // Remove previous selection
    document.querySelectorAll('.avatar-preview-item').forEach(item => item.classList.remove('selected'));
    
    // Select new avatar
    img.classList.add('selected');
    selectedAvatar = {
        type: currentAvatarData.type,
        style: currentAvatarData.style,
        seed: img.dataset.seed,
        url: img.dataset.url
    };
}

function saveSelectedAvatar() {
    if (!selectedAvatar) {
        showNotification('Please select an avatar first', 'warning');
        return;
    }
    
    // Update profile avatar
    document.getElementById('profileAvatar').src = selectedAvatar.url;
    currentAvatarData = selectedAvatar;
    
    // Mark as changed
    hasUnsavedChanges = true;
    document.getElementById('saveButtonContainer').style.display = 'block';
    
    closeAvatarSelector();
    showNotification('Avatar updated! Remember to save your changes.', 'success');
}

// Profile form submission
document.getElementById('profileForm').addEventListener('submit', function(e) {
    e.preventDefault();
    saveProfile();
});

function saveProfile() {
    if (!hasUnsavedChanges && !selectedAvatar) {
        showNotification('No changes to save', 'info');
        return;
    }
    
    const profileData = {
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        email: document.getElementById('email').value,
        specialty: document.getElementById('specialty').value,
        phone: document.getElementById('phone').value,
        bio: document.getElementById('bio').value,
        yearsExperience: parseInt(document.getElementById('yearsExperience').value) || 0,
        consultationFee: parseFloat(document.getElementById('consultationFee').value) || 0,
        education: document.getElementById('education').value,
        avatarType: currentAvatarData.type,
        avatarStyle: currentAvatarData.style,
        avatarSeed: currentAvatarData.seed
    };
    
    // Show loading state
    const saveBtn = document.querySelector('#profileForm button[type="submit"]');
    const originalText = saveBtn.innerHTML;
    saveBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Saving...';
    saveBtn.disabled = true;
    
    fetch('doctor_profile_api.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(profileData)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showNotification('Profile saved successfully!', 'success');
            hasUnsavedChanges = false;
            
            // Remove changed styling
            document.querySelectorAll('.field-changed').forEach(field => {
                field.classList.remove('field-changed');
            });
            
            // Hide save button
            document.getElementById('saveButtonContainer').style.display = 'none';
            
            // Update sidebar profile info
            updateSidebarProfile();
        } else {
            showNotification('Failed to save profile: ' + data.error, 'error');
        }
    })
    .catch(err => {
        console.error('Save error:', err);
        showNotification('Network error saving profile', 'error');
    })
    .finally(() => {
        saveBtn.innerHTML = originalText;
        saveBtn.disabled = false;
    });
}

function updateSidebarProfile() {
    // Update sidebar profile name
    const firstName = document.getElementById('firstName').value;
    const lastName = document.getElementById('lastName').value;
    const sidebarName = document.querySelector('.profile-info h4');
    if (sidebarName) {
        sidebarName.textContent = `Dr. ${firstName} ${lastName}`;
    }
    
    // Update sidebar avatar
    const sidebarAvatar = document.querySelector('.user-profile img');
    if (sidebarAvatar) {
        sidebarAvatar.src = currentAvatarData.url;
    }
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 10000;
        max-width: 300px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        animation: slideIn 0.3s ease;
    `;
    
    // Set color based on type
    const colors = {
        success: '#28a745',
        error: '#dc3545', 
        warning: '#ffc107',
        info: '#17a2b8'
    };
    notification.style.backgroundColor = colors[type] || colors.info;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

// Add CSS for notifications
const notificationCSS = document.createElement('style');
notificationCSS.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(notificationCSS);

// Patient summary functions
function loadPatientSummary(patientID) {
    console.log('Loading patient summary for ID:', patientID);
    
    const url = `fetch_patient_summary_minimal.php?patientID=${patientID}`;
    console.log('Fetching from:', url);
    
    fetch(url)
        .then(res => {
            console.log('Response status:', res.status, res.statusText);
            
            if (!res.ok) {
                throw new Error(`HTTP ${res.status}: ${res.statusText}`);
            }
            return res.json();
        })
        .then(data => {
            console.log('Patient summary data received:', data);
            
            if (!data.success) {
                alert('Error: ' + data.error);
                return;
            }
            
            // Render all the data sections
            renderPatientInfo(data.patient);
            renderAppointmentHistory(data.appointments);
            renderMedicalRecords(data.records);
            
            console.log('Setting active section to patient-summary');
            setActiveSection('patient-summary');
        })
        .catch(err => {
            console.error('Error loading patient summary:', err);
            alert('Failed to load patient summary: ' + err.message);
        });
}

function renderPatientInfo(patient) {
    console.log('Rendering patient info:', patient);
    const element = document.getElementById('patient-details');
    
    if (!element) {
        console.error('patient-details element not found!');
        return;
    }
    
    const html = `
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem;">
            <div>
                <strong>Name:</strong> ${patient.firstName} ${patient.lastName}<br>
                <strong>Email:</strong> ${patient.email}<br>
                <strong>Gender:</strong> ${patient.gender || 'N/A'}
            </div>
            <div>
                <strong>Date of Birth:</strong> ${patient.dateOfBirth || 'N/A'}<br>
                <strong>Patient ID:</strong> ${patient.patientID}
            </div>
        </div>
    `;
    
    element.innerHTML = html;
    console.log('Patient info rendered successfully');
}

function renderAppointmentHistory(appointments) {
    console.log('Rendering appointment history:', appointments);
    const element = document.getElementById('appointment-history-list');
    
    if (!element) {
        console.error('appointment-history-list element not found!');
        return;
    }
    
    if (!appointments || appointments.length === 0) {
        element.innerHTML = '<p class="muted">No appointments found.</p>';
        console.log('No appointments to display');
        return;
    }
    
    let html = '<table style="width: 100%; border-collapse: collapse; margin-top: 1rem;">';
    html += '<tr style="background-color: #f8f9fa;">';
    html += '<th style="padding: 0.75rem; border: 1px solid #dee2e6; text-align: left;">Date</th>';
    html += '<th style="padding: 0.75rem; border: 1px solid #dee2e6; text-align: left;">Time</th>';
    html += '<th style="padding: 0.75rem; border: 1px solid #dee2e6; text-align: left;">Status</th>';
    html += '<th style="padding: 0.75rem; border: 1px solid #dee2e6; text-align: left;">Action</th>';
    html += '</tr>';
    
    appointments.forEach(a => {
        html += `<tr>`;
        html += `<td style="padding: 0.75rem; border: 1px solid #dee2e6;">${a.appointmentDate}</td>`;
        html += `<td style="padding: 0.75rem; border: 1px solid #dee2e6;">${a.appointmentTime}</td>`;
        html += `<td style="padding: 0.75rem; border: 1px solid #dee2e6;">
                    <span style="color: ${a.status === 'completed' ? '#28a745' : a.status === 'cancelled' ? '#dc3545' : '#f59e0b'}; font-weight: 600;">
                        ${a.status || 'Pending'}
                    </span>
                 </td>`;
        html += `<td style="padding: 0.75rem; border: 1px solid #dee2e6;">
                    <button class="btn btn-primary" onclick="startConsultation(${a.appointmentID})">Start Consultation</button>
                 </td>`;
        html += `</tr>`;
    });
    html += '</table>';
    
    element.innerHTML = html;
    console.log('Appointment history rendered successfully');
}

function renderMedicalRecords(records) {
    console.log('Rendering medical records:', records);
    const element = document.getElementById('medical-records-list');
    
    if (!element) {
        console.error('medical-records-list element not found!');
        return;
    }
    
    if (!records || records.length === 0) {
        element.innerHTML = '<p class="muted">No medical records found.</p>';
        console.log('No medical records to display');
        return;
    }
    
    let html = '<table style="width: 100%; border-collapse: collapse; margin-top: 1rem;">';
    html += '<tr style="background-color: #f8f9fa;">';
    html += '<th style="padding: 0.75rem; border: 1px solid #dee2e6; text-align: left;">Date</th>';
    html += '<th style="padding: 0.75rem; border: 1px solid #dee2e6; text-align: left;">Diagnosis</th>';
    html += '<th style="padding: 0.75rem; border: 1px solid #dee2e6; text-align: left;">Symptoms</th>';
    html += '<th style="padding: 0.75rem; border: 1px solid #dee2e6; text-align: left;">Treatment</th>';
    html += '<th style="padding: 0.75rem; border: 1px solid #dee2e6; text-align: left;">Notes</th>';
    html += '</tr>';
    
    records.forEach(r => {
        html += `<tr>`;
        html += `<td style="padding: 0.75rem; border: 1px solid #dee2e6;">${r.recordDate || 'N/A'}</td>`;
        html += `<td style="padding: 0.75rem; border: 1px solid #dee2e6;">${r.diagnosis || 'N/A'}</td>`;
        html += `<td style="padding: 0.75rem; border: 1px solid #dee2e6;">${r.symptoms || 'N/A'}</td>`;
        html += `<td style="padding: 0.75rem; border: 1px solid #dee2e6;">${r.treatment || 'N/A'}</td>`;
        html += `<td style="padding: 0.75rem; border: 1px solid #dee2e6;">${r.notes || 'N/A'}</td>`;
        html += `</tr>`;
    });
    html += '</table>';
    
    element.innerHTML = html;
    console.log('Medical records rendered successfully');
}

function goBackToPatients() {
    setActiveSection('doctor-patients');
}

function startConsultation(appointmentID, consultationType = 'video') {
    if (consultationType === 'video') {
        window.open(`video_call.php?appointmentID=${appointmentID}`, '_blank');
    } else if (consultationType === 'audio') {
        window.open(`video_call.php?appointmentID=${appointmentID}&audio=1`, '_blank');
    } else if (consultationType === 'chat') {
        window.open(`chat.php?appointmentID=${appointmentID}`, '_blank');
    } else {
        window.open(`video_call.php?appointmentID=${appointmentID}`, '_blank');
    }
}

// Initialize
window.addEventListener('DOMContentLoaded', ()=>{
    let activeBtn = document.querySelector('.nav-btn.active');
    if(activeBtn && activeBtn.dataset.section){
        setActiveSection(activeBtn.dataset.section);
    }
    
    // Highlight current day
    const days = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
    const today = new Date().getDay();
    document.getElementById(days[today])?.classList.add("active");
    
    // Handle profile form submission
    const profileForm = document.getElementById('profileForm');
    if (profileForm) {
        profileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData();
            formData.append('firstName', document.getElementById('firstName').value);
            formData.append('lastName', document.getElementById('lastName').value);
            formData.append('email', document.getElementById('email').value);
            formData.append('specialty', document.getElementById('specialty').value);
            formData.append('phone', document.getElementById('phone').value);
            formData.append('bio', document.getElementById('bio').value);
            
            // In real implementation, send to backend
            console.log('Saving profile:', Object.fromEntries(formData));
            alert('Profile updated successfully!');
        });
    }
});

// Search functionality
function performSearch() {
    const searchTerm = document.getElementById('searchInput').value.trim();
    
    console.log('Performing search for:', searchTerm); // Debug log
    
    if (!searchTerm) {
        alert('Please enter a search term');
        return;
    }
    
    // Show loading state
    const searchBtn = document.getElementById('searchBtn');
    const originalContent = searchBtn.innerHTML;
    searchBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i>';
    searchBtn.disabled = true;
    
    // Perform search
    fetch('search.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            searchTerm: searchTerm,
            searchType: 'all' // patients, appointments, or all
        })
    })
    .then(res => {
        console.log('Search response status:', res.status); // Debug log
        if (!res.ok) {
            throw new Error('Network response was not ok');
        }
        return res.json();
    })
    .then(data => {
        console.log('Search results:', data); // Debug log
        displaySearchResults(data);
    })
    .catch(err => {
        console.error('Search error:', err);
        alert('Search failed. Please try again. Check console for details.');
    })
    .finally(() => {
        // Reset button state
        searchBtn.innerHTML = originalContent;
        searchBtn.disabled = false;
    });
}

function displaySearchResults(results) {
    console.log('Displaying search results:', results); // Debug log
    
    // Check for errors
    if (results.error) {
        alert('Search error: ' + results.error);
        return;
    }
    
    let html = '<div style="max-height: 500px; overflow-y: auto;">';
    
    if (results.patients && results.patients.length > 0) {
        html += '<h4 style="color: var(--blue-1); margin-bottom: 1rem;">Patients Found (' + results.patients.length + '):</h4>';
        html += '<table style="width: 100%; border-collapse: collapse;"><tr style="background: #f8f9fa;"><th style="padding: 0.5rem; border: 1px solid #dee2e6;">Name</th><th style="padding: 0.5rem; border: 1px solid #dee2e6;">Email</th><th style="padding: 0.5rem; border: 1px solid #dee2e6;">Action</th></tr>';
        results.patients.forEach(p => {
            html += `<tr style="border: 1px solid #dee2e6;">
                <td style="padding: 0.5rem; border: 1px solid #dee2e6;">${p.firstName} ${p.lastName}</td>
                <td style="padding: 0.5rem; border: 1px solid #dee2e6;">${p.email}</td>
                <td style="padding: 0.5rem; border: 1px solid #dee2e6;">
                    <button class="btn btn-primary" onclick="loadPatientSummary(${p.patientID}); closeModal();">View Patient</button>
                </td>
            </tr>`;
        });
        html += '</table><br>';
    }
    
    if (results.appointments && results.appointments.length > 0) {
        html += '<h4 style="color: var(--blue-1); margin-bottom: 1rem;">Appointments Found (' + results.appointments.length + '):</h4>';
        html += '<table style="width: 100%; border-collapse: collapse;"><tr style="background: #f8f9fa;"><th style="padding: 0.5rem; border: 1px solid #dee2e6;">Date</th><th style="padding: 0.5rem; border: 1px solid #dee2e6;">Time</th><th style="padding: 0.5rem; border: 1px solid #dee2e6;">Patient</th><th style="padding: 0.5rem; border: 1px solid #dee2e6;">Status</th><th style="padding: 0.5rem; border: 1px solid #dee2e6;">Action</th></tr>';
        results.appointments.forEach(a => {
            html += `<tr style="border: 1px solid #dee2e6;">
                <td style="padding: 0.5rem; border: 1px solid #dee2e6;">${a.appointmentDate}</td>
                <td style="padding: 0.5rem; border: 1px solid #dee2e6;">${a.appointmentTime}</td>
                <td style="padding: 0.5rem; border: 1px solid #dee2e6;">${a.patientFirstName} ${a.patientLastName}</td>
                <td style="padding: 0.5rem; border: 1px solid #dee2e6;"><span style="color: ${a.status === 'booked' ? '#28a745' : a.status === 'cancelled' ? '#dc3545' : '#6c757d'};">${a.status || 'Pending'}</span></td>
                <td style="padding: 0.5rem; border: 1px solid #dee2e6;">
                    <button class="btn btn-primary" onclick="startConsultation(${a.appointmentID}); closeModal();" style="margin-right: 0.5rem;">Join</button>
                    <button class="btn btn-ghost" onclick="loadPatientSummary(${a.patientID}); closeModal();">View Patient</button>
                </td>
            </tr>`;
        });
        html += '</table>';
    }
    
    if ((!results.patients || results.patients.length === 0) && 
        (!results.appointments || results.appointments.length === 0)) {
        html += '<div style="text-align: center; padding: 2rem;">';
        html += '<p class="muted" style="font-size: 1.1rem;">No results found for your search.</p>';
        html += '<p class="small muted">Try searching for patient names, emails, or appointment dates.</p>';
        html += '</div>';
    }
    
    html += '</div>';
    
    // Force modal to show
    console.log('Opening modal with results...');
    openModal('Search Results', html);
    
    // Ensure modal is visible
    const modal = document.getElementById('globalModal');
    if (modal) {
        modal.style.display = 'block';
        modal.style.zIndex = '9999';
        console.log('Modal should be visible now');
    } else {
        console.error('Modal element not found!');
        // Fallback - show results in alert
        alert('Search found: ' + (results.patients?.length || 0) + ' patients and ' + (results.appointments?.length || 0) + ' appointments');
    }
}

// Real-time search suggestions (optional enhancement)
document.getElementById('searchInput')?.addEventListener('input', function(e) {
    const searchTerm = e.target.value.trim();
    
    if (searchTerm.length >= 2) {
        // Add debouncing to avoid too many requests
        clearTimeout(this.searchTimeout);
        this.searchTimeout = setTimeout(() => {
            showSearchSuggestions(searchTerm);
        }, 300);
    } else {
        hideSearchSuggestions();
    }
});

function showSearchSuggestions(searchTerm) {
    // Create suggestions dropdown if it doesn't exist
    let suggestions = document.getElementById('searchSuggestions');
    if (!suggestions) {
        suggestions = document.createElement('div');
        suggestions.id = 'searchSuggestions';
        suggestions.style.cssText = `
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            max-height: 200px;
            overflow-y: auto;
            z-index: 1000;
            display: none;
        `;
        document.querySelector('.search-box').style.position = 'relative';
        document.querySelector('.search-box').appendChild(suggestions);
    }
    
    fetch('search_suggestions.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ searchTerm })
    })
    .then(res => res.json())
    .then(data => {
        let html = '';
        data.forEach(item => {
            html += `
                <div class="suggestion-item" onclick="selectSuggestion('${item.text}')" 
                     style="padding: 0.5rem; cursor: pointer; border-bottom: 1px solid #f3f4f6;">
                    <i class="fa ${item.type === 'patient' ? 'fa-user' : 'fa-calendar'}" style="margin-right: 0.5rem; color: var(--blue-2);"></i>
                    ${item.text}
                </div>
            `;
        });
        
        if (html) {
            suggestions.innerHTML = html;
            suggestions.style.display = 'block';
        } else {
            hideSearchSuggestions();
        }
    })
    .catch(err => console.error('Suggestions error:', err));
}

function hideSearchSuggestions() {
    const suggestions = document.getElementById('searchSuggestions');
    if (suggestions) {
        suggestions.style.display = 'none';
    }
}

function selectSuggestion(text) {
    document.getElementById('searchInput').value = text;
    hideSearchSuggestions();
    performSearch();
}

// Hide suggestions when clicking outside
document.addEventListener('click', function(e) {
    if (!e.target.closest('.search-box')) {
        hideSearchSuggestions();
    }
});

// Medical Record Modal Functions
function showAddMedicalRecordModal() {
    // Get the current patient ID from the patient summary section
    const patientDetailsDiv = document.getElementById('patient-details');
    if (!patientDetailsDiv) {
        alert('No patient selected. Please select a patient first.');
        return;
    }
    
    // Extract patient ID from the display (this is a simple approach)
    const patientInfo = patientDetailsDiv.innerHTML;
    const patientIDMatch = patientInfo.match(/Patient ID:<\/strong>\s*(\d+)/);
    
    if (!patientIDMatch) {
        alert('Could not determine patient ID. Please try again.');
        return;
    }
    
    const patientID = patientIDMatch[1];
    document.getElementById('medicalRecordPatientID').value = patientID;
    
    // Set today's date as default
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('recordDate').value = today;
    
    document.getElementById('addMedicalRecordModal').style.display = 'block';
}

function closeAddMedicalRecordModal() {
    document.getElementById('addMedicalRecordModal').style.display = 'none';
    document.getElementById('addMedicalRecordForm').reset();
}

// Handle add medical record form submission
document.addEventListener('DOMContentLoaded', function() {
    const addMedicalRecordForm = document.getElementById('addMedicalRecordForm');
    if (addMedicalRecordForm) {
        addMedicalRecordForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const submitBtn = this.querySelector('button[type="submit"]');
            
            submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Saving...';
            submitBtn.disabled = true;
            
            fetch('add_medical_record.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alert('✅ Medical record added successfully!');
                    closeAddMedicalRecordModal();
                    // Reload the patient summary to show the new record
                    const patientID = document.getElementById('medicalRecordPatientID').value;
                    loadPatientSummary(patientID);
                } else {
                    alert('❌ Error: ' + (data.message || 'Failed to add medical record'));
                }
            })
            .catch(err => {
                console.error('Error adding medical record:', err);
                alert('❌ Failed to add medical record. Please try again.');
            })
            .finally(() => {
                submitBtn.innerHTML = '<i class="fa fa-save"></i> Save Record';
                submitBtn.disabled = false;
            });
        });
    }
});

// Prescription Modal Functions
function addPrescriptionToRecord(recordID) {
    // Get patient information from the current context
    const patientDetailsDiv = document.getElementById('patient-details');
    if (!patientDetailsDiv) {
        alert('No patient selected. Please select a patient first.');
        return;
    }
    
    const patientInfo = patientDetailsDiv.innerHTML;
    const patientIDMatch = patientInfo.match(/Patient ID:<\/strong>\s*(\d+)/);
    
    if (!patientIDMatch) {
        alert('Could not determine patient ID. Please try again.');
        return;
    }
    
    const patientID = patientIDMatch[1];
    document.getElementById('prescriptionRecordID').value = recordID;
    document.getElementById('prescriptionPatientID').value = patientID;
    
    // Set today's date as default
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('prescriptionDate').value = today;
    
    document.getElementById('addPrescriptionModal').style.display = 'block';
}

function closePrescriptionModal() {
    document.getElementById('addPrescriptionModal').style.display = 'none';
    document.getElementById('addPrescriptionForm').reset();
}

function downloadPrescription(prescriptionID) {
    window.open(`download_prescription.php?id=${prescriptionID}`, '_blank');
}

function viewPrescription(prescriptionID) {
    // You can implement a view modal or redirect to a view page
    window.open(`view_prescription.php?id=${prescriptionID}`, '_blank');
}

// Prescription form submission
document.addEventListener('DOMContentLoaded', function() {
    const prescriptionForm = document.getElementById('addPrescriptionForm');
    if (prescriptionForm) {
        prescriptionForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const submitBtn = this.querySelector('button[type="submit"]');
            
            submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Creating Prescription...';
            submitBtn.disabled = true;
            
            fetch('add_prescription.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alert('✅ Prescription added successfully!');
                    closePrescriptionModal();
                    
                    // Reload the patient summary to show the updated record
                    const patientID = document.getElementById('prescriptionPatientID').value;
                    loadPatientSummary(patientID);
                    
                    // Optionally auto-download the PDF
                    if (data.prescriptionID) {
                        if (confirm('Would you like to download the prescription PDF now?')) {
                            downloadPrescription(data.prescriptionID);
                        }
                    }
                } else {
                    alert('❌ Error: ' + (data.message || 'Failed to add prescription'));
                }
            })
            .catch(err => {
                console.error('Error adding prescription:', err);
                alert('❌ Failed to add prescription. Please try again.');
            })
            .finally(() => {
                submitBtn.innerHTML = '<i class="fa fa-save"></i> Save & Generate PDF';
                submitBtn.disabled = false;
            });
        });
    }
});

// Analytics Functions
function loadAnalytics() {
    console.log('Loading doctor analytics...');
    
    // Show loading state
    document.getElementById('analyticsLoading').style.display = 'block';
    document.getElementById('analyticsContent').style.display = 'none';
    
    // Create fetch with timeout for InfinityFree compatibility
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000); // 15 second timeout
    
    fetch('fetch_doctor_analytics.php', {
        signal: controller.signal,
        method: 'GET',
        headers: {
            'Cache-Control': 'no-cache',
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
        .then(res => {
            clearTimeout(timeoutId);
            if (!res.ok) {
                throw new Error(`HTTP ${res.status}: ${res.statusText}`);
            }
            return res.json();
        })
        .then(data => {
            console.log('Analytics data received:', data);
            
            if (!data.success) {
                throw new Error(data.error || 'Failed to load analytics');
            }
            
            // Hide loading, show content
            document.getElementById('analyticsLoading').style.display = 'none';
            document.getElementById('analyticsContent').style.display = 'block';
            
            // Update all analytics components
            updateKPIs(data);
            updateWeeklyChart(data.weekly);
            updateMonthlyChart(data.monthly);
            updateRecentPatients(data.recent_patients);
            updatePerformanceSummary(data.overall);
            updateLastUpdated();
            
        })
        .catch(err => {
            console.error('Error loading analytics:', err);
            
            // Enhanced error handling for InfinityFree
            let errorMessage = err.message;
            let retryButton = '<button onclick="loadAnalytics()" class="btn btn-primary">Try Again</button>';
            
            // Check if it's a network/connection error
            if (err.message.includes('Failed to fetch') || err.message.includes('Network')) {
                errorMessage = 'Network connection error. This might be due to InfinityFree server delays.';
                retryButton = '<button onclick="loadAnalytics()" class="btn btn-primary">Retry Connection</button>';
            } else if (err.message.includes('Unauthorized')) {
                errorMessage = 'Please log in again to view analytics.';
                retryButton = '<button onclick="window.location.reload()" class="btn btn-primary">Refresh Page</button>';
            }
            
            document.getElementById('analyticsLoading').innerHTML = 
                '<div style="color: red; text-align: center; padding: 2rem;">' +
                '<i class="fa fa-exclamation-triangle fa-2x"></i>' +
                '<p><strong>Failed to load analytics</strong></p>' +
                '<p>' + errorMessage + '</p>' +
                '<div style="margin-top: 1rem;">' + retryButton + '</div>' +
                '<p style="font-size: 0.8rem; color: #666; margin-top: 1rem;">If issues persist, check your internet connection or try refreshing the page.</p>' +
                '</div>';
        });
}

function updateKPIs(data) {
    // Update Key Performance Indicators
    document.getElementById('todayPatientsHelped').textContent = data.overall.today_patients_helped;
    document.getElementById('todayAppointments').textContent = data.overall.today_appointments;
    
    document.getElementById('weeklyPatientsHelped').textContent = data.weekly.totals.total_patients_helped;
    document.getElementById('weeklyAppointments').textContent = data.weekly.totals.total_appointments;
    
    document.getElementById('monthlyPatientsHelped').textContent = data.monthly.totals.total_patients_helped;
    document.getElementById('monthlyAppointments').textContent = data.monthly.totals.total_appointments;
    
    document.getElementById('completionRate').textContent = data.overall.completion_rate + '%';
    document.getElementById('totalPatientsHelped').textContent = data.overall.total_patients_helped;
}

function updateWeeklyChart(weeklyData) {
    const chartContainer = document.getElementById('weeklyChart');
    chartContainer.innerHTML = '';
    
    // Find max value for scaling
    const maxValue = Math.max(...weeklyData.stats.map(day => day.patients_helped), 1);
    const maxHeight = 250; // Maximum chart height
    
    weeklyData.stats.forEach(day => {
        const barHeight = maxValue > 0 ? (day.patients_helped / maxValue) * maxHeight : 0;
        
        const dayColumn = document.createElement('div');
        dayColumn.style.cssText = 'display: flex; flex-direction: column; align-items: center; flex: 1;';
        
        // Calculate color intensity based on value
        const intensity = maxValue > 0 ? day.patients_helped / maxValue : 0;
        const color = interpolateColor('#e3f2fd', '#1976d2', intensity);
        
        dayColumn.innerHTML = `
            <div style="width: 40px; height: ${barHeight}px; background: ${color}; border-radius: 4px; margin-bottom: 0.5rem; transition: all 0.3s ease; cursor: pointer;" 
                 title="${day.day}: ${day.patients_helped} patients helped, ${day.appointments} appointments"
                 onmouseover="this.style.opacity='0.8'"
                 onmouseout="this.style.opacity='1'">
            </div>
            <span style="font-size: 0.8rem; font-weight: 500;">${day.short}</span>
            <span style="font-size: 0.7rem; color: #666;">${day.patients_helped}</span>
        `;
        
        chartContainer.appendChild(dayColumn);
    });
}

function updateMonthlyChart(monthlyData) {
    const chartContainer = document.getElementById('monthlyChart');
    chartContainer.innerHTML = '';
    
    // Create a scrollable monthly view
    const maxValue = Math.max(...monthlyData.stats.map(day => day.patients_helped), 1);
    const maxHeight = 250;
    
    const chartWrapper = document.createElement('div');
    chartWrapper.style.cssText = 'display: flex; align-items: end; gap: 2px; padding: 1rem; min-width: 800px;';
    
    monthlyData.stats.forEach(day => {
        const barHeight = maxValue > 0 ? (day.patients_helped / maxValue) * maxHeight : 0;
        
        const dayColumn = document.createElement('div');
        dayColumn.style.cssText = 'display: flex; flex-direction: column; align-items: center; min-width: 25px;';
        
        const intensity = maxValue > 0 ? day.patients_helped / maxValue : 0;
        const color = interpolateColor('#f3e5f5', '#7b1fa2', intensity);
        
        dayColumn.innerHTML = `
            <div style="width: 20px; height: ${barHeight || 2}px; background: ${color}; border-radius: 2px; margin-bottom: 0.25rem; cursor: pointer;" 
                 title="Day ${day.day}: ${day.patients_helped} patients helped"
                 onmouseover="this.style.opacity='0.8'"
                 onmouseout="this.style.opacity='1'">
            </div>
            <span style="font-size: 0.6rem; color: #666; writing-mode: vertical-rl;">${day.day}</span>
        `;
        
        chartWrapper.appendChild(dayColumn);
    });
    
    chartContainer.appendChild(chartWrapper);
}

function updateRecentPatients(recentPatients) {
    const container = document.getElementById('recentPatients');
    
    if (recentPatients.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #666; padding: 2rem;">No recent patients</p>';
        return;
    }
    
    let html = '';
    recentPatients.forEach(patient => {
        const date = new Date(patient.date);
        const formattedDate = date.toLocaleDateString();
        const formattedTime = patient.time;
        
        html += `
            <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.75rem; border-bottom: 1px solid #e5e7eb; transition: background-color 0.2s;">
                <div>
                    <div style="font-weight: 500; color: #1f2937;">${patient.name}</div>
                    <div style="font-size: 0.8rem; color: #6b7280;">${formattedDate} at ${formattedTime}</div>
                </div>
                <div style="background: #10b981; color: white; padding: 0.25rem 0.5rem; border-radius: 12px; font-size: 0.7rem;">
                    Helped ✓
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

function updatePerformanceSummary(overallStats) {
    document.getElementById('totalAppointments').textContent = overallStats.total_appointments;
    document.getElementById('totalCompleted').textContent = overallStats.total_patients_helped;
    document.getElementById('totalCancelled').textContent = overallStats.total_cancelled;
    document.getElementById('totalPending').textContent = overallStats.total_pending;
    document.getElementById('medicalRecords').textContent = overallStats.medical_records_created;
    document.getElementById('weeklyRecords').textContent = overallStats.weekly_records;
}

function updateLastUpdated() {
    const now = new Date();
    const timeString = now.toLocaleTimeString();
    document.getElementById('lastUpdated').textContent = `Last updated: ${timeString}`;
}

function refreshAnalytics() {
    loadAnalytics();
}

// Utility function to interpolate between colors
function interpolateColor(color1, color2, factor) {
    const rgb1 = hexToRgb(color1);
    const rgb2 = hexToRgb(color2);
    
    const r = Math.round(rgb1.r + (rgb2.r - rgb1.r) * factor);
    const g = Math.round(rgb1.g + (rgb2.g - rgb1.g) * factor);
    const b = Math.round(rgb1.b + (rgb2.b - rgb1.b) * factor);
    
    return `rgb(${r}, ${g}, ${b})`;
}

function hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

// Auto-refresh analytics every 5 minutes
let analyticsInterval;

function startAnalyticsAutoRefresh() {
    // Clear any existing interval
    if (analyticsInterval) {
        clearInterval(analyticsInterval);
    }
    
    // Set up auto-refresh every 5 minutes (300000 ms)
    analyticsInterval = setInterval(() => {
        // Only refresh if analytics section is visible
        const analyticsSection = document.getElementById('doctor-analytics');
        if (analyticsSection && analyticsSection.classList.contains('active')) {
            console.log('Auto-refreshing analytics...');
            loadAnalytics();
        }
    }, 300000);
}

// Load analytics when the analytics section becomes active
const originalSetActiveSection = setActiveSection;
setActiveSection = function(id) {
    originalSetActiveSection(id);
    
    if (id === 'doctor-analytics') {
        loadAnalytics();
        startAnalyticsAutoRefresh();
    } else {
        // Stop auto-refresh when leaving analytics section
        if (analyticsInterval) {
            clearInterval(analyticsInterval);
        }
    }
};
</script>

<?php
// Close the appointments query after use
$appointmentsQuery->close();
?>
</body>
</html>