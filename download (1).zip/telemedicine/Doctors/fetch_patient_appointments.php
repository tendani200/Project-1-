<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'db_connect.php';
header('Content-Type: application/json');

// Check if user is logged in and is a doctor
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    echo json_encode(['error' => 'Unauthorized access']);
    exit();
}

// Get doctor ID from user ID
$doctorUserID = $_SESSION['userID'];
$doctorQuery = $conn->prepare("SELECT doctorID FROM Doctor WHERE userID = ?");
$doctorQuery->bind_param("i", $doctorUserID);
$doctorQuery->execute();
$doctorResult = $doctorQuery->get_result();
$doctor = $doctorResult->fetch_assoc();
$doctorQuery->close();

if (!$doctor) {
    echo json_encode(['error' => 'Doctor not found']);
    exit();
}

$doctorID = $doctor['doctorID'];

// Get patient ID from request
$patientID = isset($_GET['patientID']) ? (int)$_GET['patientID'] : null;

if (!$patientID) {
    echo json_encode(['error' => 'Patient ID required']);
    exit();
}

try {
    // Fetch patient's appointments with this doctor
    $stmt = $conn->prepare("
        SELECT a.appointmentID, a.appointmentDate, a.appointmentTime, a.status, a.consultationType,
               CONCAT(u.firstName, ' ', u.lastName) AS patientName
        FROM Appointments a
        JOIN Patient p ON a.patientID = p.patientID
        JOIN User u ON p.userID = u.userID
        WHERE a.patientID = ? AND a.doctorID = ?
        ORDER BY a.appointmentDate DESC, a.appointmentTime DESC
    ");
    
    $stmt->bind_param("ii", $patientID, $doctorID);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $appointments = [];
    while ($row = $result->fetch_assoc()) {
        $appointments[] = $row;
    }
    
    $stmt->close();
    
    echo json_encode([
        'success' => true,
        'appointments' => $appointments
    ]);
    
} catch (Exception $e) {
    error_log("Fetch patient appointments error: " . $e->getMessage());
    echo json_encode(['error' => 'Database error occurred']);
}

$conn->close();
?>