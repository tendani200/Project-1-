<?php
include '../db_connect.php';

if(isset($_POST['doctor_id'])){
    $doctorID = intval($_POST['doctor_id']);
    $stmt = $conn->prepare("
        SELECT d.doctorID, u.firstName, u.lastName, d.photo, d.description 
        FROM Doctor d
        JOIN User u ON d.userID = u.userID
        WHERE d.doctorID=?
    ");
    $stmt->bind_param("i", $doctorID);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if($result){
        echo json_encode([
            'firstName' => $result['firstName'],
            'lastName' => $result['lastName'],
            'photo' => $result['photo'],
            'description' => $result['description']
        ]);
    } else {
        echo json_encode(null);
    }
}
?>
