<?php
session_start();
include '../db_connect.php';

header('Content-Type: application/json');

// Debug logging
error_log("Search.php called - Session userID: " . ($_SESSION['userID'] ?? 'not set'));
error_log("Search.php called - Session userType: " . ($_SESSION['userType'] ?? 'not set'));

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    error_log("Search.php - Unauthorized access");
    echo json_encode(['error' => 'Unauthorized - Please log in as a doctor']);
    exit();
}

// Handle both POST (from JavaScript) and GET (direct URL access)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $searchTerm = $input['searchTerm'] ?? '';
    error_log("Search.php - POST search term: " . $searchTerm);
} else {
    $searchTerm = $_GET['term'] ?? '';
    error_log("Search.php - GET search term: " . $searchTerm);
}

$doctorUserID = $_SESSION['userID'];

// Get doctor ID
$doctorQuery = $conn->prepare("SELECT doctorID FROM Doctor WHERE userID = ?");
$doctorQuery->bind_param("i", $doctorUserID);
$doctorQuery->execute();
$doctor = $doctorQuery->get_result()->fetch_assoc();
$doctorQuery->close();

if (!$doctor) {
    error_log("Search.php - Doctor not found for userID: " . $doctorUserID);
    echo json_encode(['error' => 'Doctor not found']);
    exit();
}

error_log("Search.php - Doctor found: " . $doctor['doctorID']);

$results = ['patients' => [], 'appointments' => [], 'debug' => []];

if (!empty($searchTerm)) {
    // Debug: Check if doctor has any patients at all
    $debugQuery = $conn->prepare("
        SELECT COUNT(DISTINCT p.patientID) as total_patients,
               COUNT(DISTINCT a.appointmentID) as total_appointments
        FROM Appointments a
        JOIN Patient p ON a.patientID = p.patientID
        WHERE a.doctorID = ?
    ");
    $debugQuery->bind_param("i", $doctor['doctorID']);
    $debugQuery->execute();
    $debugInfo = $debugQuery->get_result()->fetch_assoc();
    $debugQuery->close();
    
    $results['debug']['doctor_has_patients'] = $debugInfo['total_patients'];
    $results['debug']['doctor_has_appointments'] = $debugInfo['total_appointments'];
    $results['debug']['search_term'] = $searchTerm;
    $results['debug']['doctor_id'] = $doctor['doctorID'];

    // Search patients
    $patientQuery = $conn->prepare("
        SELECT DISTINCT p.patientID, u.firstName, u.lastName, u.email
        FROM Patient p
        JOIN User u ON p.userID = u.userID
        JOIN Appointments a ON p.patientID = a.patientID
        WHERE a.doctorID = ? AND (
            u.firstName LIKE ? OR 
            u.lastName LIKE ? OR 
            u.email LIKE ? OR
            CONCAT(u.firstName, ' ', u.lastName) LIKE ?
        )
        LIMIT 10
    ");
    $searchPattern = "%$searchTerm%";
    $patientQuery->bind_param("issss", $doctor['doctorID'], $searchPattern, $searchPattern, $searchPattern, $searchPattern);
    $patientQuery->execute();
    $results['patients'] = $patientQuery->get_result()->fetch_all(MYSQLI_ASSOC);
    $patientQuery->close();
    
    error_log("Search.php - Found " . count($results['patients']) . " patients");

    // Search appointments
    $appointmentQuery = $conn->prepare("
        SELECT a.appointmentID, a.appointmentDate, a.appointmentTime, a.patientID, a.status,
               u.firstName AS patientFirstName, u.lastName AS patientLastName
        FROM Appointments a
        JOIN Patient p ON a.patientID = p.patientID
        JOIN User u ON p.userID = u.userID
        WHERE a.doctorID = ? AND (
            u.firstName LIKE ? OR 
            u.lastName LIKE ? OR
            CONCAT(u.firstName, ' ', u.lastName) LIKE ? OR
            a.appointmentDate LIKE ?
        )
        ORDER BY a.appointmentDate DESC
        LIMIT 10
    ");
    $appointmentQuery->bind_param("issss", $doctor['doctorID'], $searchPattern, $searchPattern, $searchPattern, $searchPattern);
    $appointmentQuery->execute();
    $results['appointments'] = $appointmentQuery->get_result()->fetch_all(MYSQLI_ASSOC);
    $appointmentQuery->close();
    
    error_log("Search.php - Found " . count($results['appointments']) . " appointments");
} else {
    error_log("Search.php - Empty search term");
}

error_log("Search.php - Returning results: " . json_encode($results));
echo json_encode($results);
?>