<?php
session_start();
include("../db_connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email    = trim($_POST["email"]);
    $password = $_POST["password"];

    $stmt = $conn->prepare("SELECT * FROM User WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user["passwordHash"])) {
            $_SESSION["userID"] = $user["userID"];
            $_SESSION["userType"] = $user["userType"];

            // Redirect by user type
            if ($user["userType"] == "Patient") {
                header("Location: ../patient/patient_dashboard.php");
            } elseif ($user["userType"] == "Doctor") {
                header("Location: ../doctor/doctor-dashboard.php");
            } elseif ($user["userType"] == "Admin") {
                header("Location: ../admin/admin_dashboard.php");
            } else {
                header("Location: ../index.php");
            }
            exit();
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "User not found.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login - Telemedicine</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <h2>Login</h2>
    <?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
    <form method="POST">
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Login</button>
    </form>
    <a href="signup.php">New patient? Sign up here</a>
  </div>
</body>
</html>
