<?php
session_start();
require_once '../db_connect.php';

// Check if doctor is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    http_response_code(401);
    echo "Unauthorized access";
    exit();
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    http_response_code(400);
    echo "Prescription ID required";
    exit();
}

$prescriptionID = (int) $_GET['id'];
$doctorUserID = $_SESSION['userID'];

// Get doctor ID
$doctorQuery = $conn->prepare("SELECT doctorID FROM Doctor WHERE userID = ?");
$doctorQuery->bind_param("i", $doctorUserID);
$doctorQuery->execute();
$doctorResult = $doctorQuery->get_result();
$doctorData = $doctorResult->fetch_assoc();
$doctorQuery->close();

if (!$doctorData) {
    http_response_code(403);
    echo "Doctor not found";
    exit();
}

$doctorID = $doctorData['doctorID'];

try {
    // Get prescription details with security check (only allow doctor's own prescriptions)
    $prescriptionQuery = $conn->prepare("
        SELECT p.*, p.pdfPath,
               u.firstName as patientFirstName, u.lastName as patientLastName,
               d.firstName as doctorFirstName, d.lastName as doctorLastName,
               mr.diagnosis, mr.recordDate
        FROM Prescriptions p
        JOIN Patient pt ON p.aptientID = pt.patientID
        JOIN User u ON pt.userID = u.userID
        JOIN Doctor doc ON p.doctorID = doc.doctorID
        JOIN User d ON doc.userID = d.userID
        LEFT JOIN MedicalRecord mr ON p.recordID = mr.recordID
        WHERE p.prescriptionID = ? AND p.doctorID = ?
    ");
    
    $prescriptionQuery->bind_param("ii", $prescriptionID, $doctorID);
    $prescriptionQuery->execute();
    $result = $prescriptionQuery->get_result();
    $prescription = $result->fetch_assoc();
    $prescriptionQuery->close();
    
    if (!$prescription) {
        http_response_code(404);
        echo "Prescription not found or access denied";
        exit();
    }
    
    // Check if PDF file exists
    $prescriptionsDir = __DIR__ . '/prescriptions';
    $filePath = $prescriptionsDir . '/' . $prescription['pdfPath'];
    
    if (!file_exists($filePath)) {
        // Regenerate the prescription file if it doesn't exist
        $html = generatePrescriptionHTML($prescription);
        file_put_contents($filePath, $html);
    }
    
    // Set headers for file download
    $fileName = "prescription_" . $prescriptionID . "_" . date('Y-m-d') . ".html";
    
    header('Content-Type: text/html');
    header('Content-Disposition: attachment; filename="' . $fileName . '"');
    header('Content-Length: ' . filesize($filePath));
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');
    
    // Output the file
    readfile($filePath);
    
} catch (Exception $e) {
    error_log("Download prescription error: " . $e->getMessage());
    http_response_code(500);
    echo "Error downloading prescription";
}

/**
 * Generate HTML content for prescription
 */
function generatePrescriptionHTML($prescription) {
    $html = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <title>Prescription - {$prescription['prescriptionID']}</title>
        <style>
            body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; line-height: 1.6; }
            .header { text-align: center; border-bottom: 3px solid #2c5282; padding-bottom: 20px; margin-bottom: 30px; }
            .header h1 { color: #2c5282; margin-bottom: 5px; }
            .header h3 { color: #4a5568; margin: 5px 0; }
            .prescription-info { margin-bottom: 25px; }
            .prescription-info h3 { color: #2c5282; border-bottom: 1px solid #e2e8f0; padding-bottom: 5px; }
            .prescription-info table { width: 100%; border-collapse: collapse; margin-top: 10px; }
            .prescription-info td { padding: 12px; border: 1px solid #e2e8f0; vertical-align: top; }
            .prescription-info td:first-child { background-color: #f7fafc; font-weight: bold; width: 30%; color: #2d3748; }
            .medication-highlight { background-color: #fed7d7; font-weight: bold; font-size: 1.1em; }
            .signature { margin-top: 60px; text-align: right; }
            .signature p { margin: 5px 0; }
            .footer { margin-top: 40px; text-align: center; font-size: 12px; color: #718096; border-top: 1px solid #e2e8f0; padding-top: 20px; }
            .warning { background-color: #fef5e7; border: 1px solid #f6e05e; padding: 15px; border-radius: 5px; margin: 20px 0; }
            @media print { body { margin: 0; } .no-print { display: none; } }
        </style>
    </head>
    <body>
        <div class='header'>
            <h1>MEDICAL PRESCRIPTION</h1>
            <h3>Healthcare Center</h3>
            <p><strong>Date Issued:</strong> " . date('F j, Y', strtotime($prescription['prescribdDate'])) . "</p>
            <p><strong>Prescription ID:</strong> {$prescription['prescriptionID']}</p>
        </div>
        
        <div class='prescription-info'>
            <h3>Patient Information</h3>
            <table>
                <tr><td>Patient Name</td><td>{$prescription['patientFirstName']} {$prescription['patientLastName']}</td></tr>
                <tr><td>Patient ID</td><td>{$prescription['aptientID']}</td></tr>
                <tr><td>Date of Prescription</td><td>" . date('F j, Y', strtotime($prescription['prescribdDate'])) . "</td></tr>
            </table>
        </div>
        
        <div class='prescription-info'>
            <h3>Prescription Details</h3>
            <table>
                <tr><td>Medication</td><td class='medication-highlight'>{$prescription['medication']}</td></tr>
                <tr><td>Dosage</td><td><strong>{$prescription['dosage']}</strong></td></tr>
                <tr><td>Instructions</td><td>" . nl2br(htmlspecialchars($prescription['instructions'])) . "</td></tr>
                <tr><td>Status</td><td>" . ucfirst($prescription['status']) . "</td></tr>
            </table>
        </div>
        
        " . (!empty($prescription['diagnosis']) ? "
        <div class='prescription-info'>
            <h3>Medical Diagnosis</h3>
            <div style='background-color: #f0f9ff; padding: 15px; border-radius: 5px; border-left: 4px solid #3182ce;'>
                <p><strong>{$prescription['diagnosis']}</strong></p>
            </div>
        </div>
        " : "") . "
        
        <div class='warning'>
            <p><strong>Important Instructions:</strong></p>
            <ul>
                <li>Take medication exactly as prescribed</li>
                <li>Complete the full course even if you feel better</li>
                <li>Do not share this medication with others</li>
                <li>Contact your doctor if you experience side effects</li>
            </ul>
        </div>
        
        <div class='signature'>
            <p><strong>Prescribed by:</strong></p>
            <p>Dr. {$prescription['doctorFirstName']} {$prescription['doctorLastName']}</p>
            <p>Doctor ID: {$prescription['doctorID']}</p>
            <p style='margin-top: 30px;'>_____________________</p>
            <p>Doctor's Signature</p>
        </div>
        
        <div class='footer'>
            <p><strong>Valid for 30 days from date of issue</strong></p>
            <p>For any questions regarding this prescription, please contact our medical center.</p>
            <p>Generated on: " . date('F j, Y \a\t g:i A') . "</p>
        </div>
    </body>
    </html>";
    
    return $html;
}

$conn->close();
?>