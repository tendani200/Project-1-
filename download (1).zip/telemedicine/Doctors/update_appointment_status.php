<?php
session_start();
include '../db_connect.php';
header('Content-Type: application/json');

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$appointmentID = intval($input['appointmentID'] ?? 0);
$status = $input['status'] ?? '';

if ($appointmentID <= 0 || empty($status)) {
    echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
    exit();
}

// Update appointment status
$updateQuery = $conn->prepare("UPDATE Appointments SET status = ? WHERE appointmentID = ?");
$updateQuery->bind_param("si", $status, $appointmentID);

if ($updateQuery->execute()) {
    echo json_encode(['success' => true, 'message' => 'Status updated successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to update status']);
}

$updateQuery->close();
?>