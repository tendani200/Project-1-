<?php
session_start();
include '../db_connect.php';

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    header("Location:login.php");
    exit();
}

$doctorUserID = $_SESSION['userID'];
$doctorQuery = $conn->prepare("SELECT * FROM User u JOIN Doctor d ON u.userID = d.userID WHERE u.userID = ?");
$doctorQuery->bind_param("i", $doctorUserID);
$doctorQuery->execute();
$doctorResult = $doctorQuery->get_result();
$doctor = $doctorResult->fetch_assoc();
$doctorQuery->close();

$today = date('Y-m-d');
$scheduleStmt = $conn->prepare("
    SELECT a.appointmentDate, a.appointmentTime, s.serviceName,
           CONCAT(u.firstName, ' ', u.lastName) AS patientName
    FROM Appointments a
    LEFT JOIN Service s ON a.serviceID = s.serviceID
    LEFT JOIN User u ON a.patientID = u.userID
    WHERE a.doctorID = ? AND a.appointmentDate >= ?
    ORDER BY a.appointmentDate ASC, a.appointmentTime ASC
");
$scheduleStmt->bind_param("is", $doctor['doctorID'], $today);
$scheduleStmt->execute();
$schedule = $scheduleStmt->get_result();
$scheduleStmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dokotela - Schedule</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
/* Paste your dashboard CSS here for consistency */
</style>
</head>
<body>
<div class="dashboard-container">
    <?php include 'sidebar.php'; ?>
    <main class="main-content">
        <div class="topbar">
            <!-- Paste your topbar HTML here -->
        </div>
        <section id="doctor-schedule" class="dashboard-section active">
            <div class="welcome-header">
                <h1>Schedule</h1>
                <p class="small">Upcoming appointments and schedule.</p>
            </div>
            <div class="grid">
                <div class="card" style="grid-column: span 12;">
                    <table class="rec-table" role="table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Patient</th>
                                <th>Service</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($schedule && $schedule->num_rows > 0): ?>
                            <?php while ($s = $schedule->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($s['appointmentDate']) ?></td>
                                <td><?= htmlspecialchars($s['appointmentTime']) ?></td>
                                <td><?= htmlspecialchars($s['patientName']) ?></td>
                                <td><?= htmlspecialchars($s['serviceName']) ?></td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="4" class="muted">No upcoming appointments.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    </main>
</div>
</body>
</html>