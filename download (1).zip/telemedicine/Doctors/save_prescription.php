<?php
session_start();
require_once '../db_connect.php';

// Set JSON header
header('Content-Type: application/json');

// Check if doctor is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

try {
    // Get the request method
    $method = $_SERVER['REQUEST_METHOD'];
    
    if ($method === 'POST') {
        // Get form data (not JSON for form submissions)
        $input = $_POST;
        
        if (empty($input)) {
            throw new Exception('No form data received');
        }
        
        // Validate required fields
        $required = ['patientName', 'patientId', 'medication', 'dosage'];
        foreach ($required as $field) {
            if (empty($input[$field])) {
                throw new Exception("Missing required field: $field");
            }
        }
        
        // Get doctor ID
        $doctorUserID = $_SESSION['userID'];
        $doctorQuery = $conn->prepare("SELECT doctorID FROM Doctor WHERE userID = ?");
        $doctorQuery->bind_param("i", $doctorUserID);
        $doctorQuery->execute();
        $doctorResult = $doctorQuery->get_result();
        $doctorData = $doctorResult->fetch_assoc();
        $doctorQuery->close();

        if (!$doctorData) {
            throw new Exception('Doctor not found');
        }

        $doctorID = $doctorData['doctorID'];
        
        // Prepare SQL statement for your existing Prescriptions table
        $sql = "INSERT INTO Prescriptions (
            aptientID, doctorID, medication, dosage, instructions, prescribdDate, status
        ) VALUES (?, ?, ?, ?, ?, ?, 'ready')";
        
        $stmt = $conn->prepare($sql);
        
        // Combine instructions
        $instructions = [];
        if (!empty($input['frequency'])) $instructions[] = "Frequency: " . $input['frequency'];
        if (!empty($input['duration'])) $instructions[] = "Duration: " . $input['duration'];
        if (!empty($input['notes'])) $instructions[] = "Notes: " . $input['notes'];
        $combinedInstructions = implode(", ", $instructions);
        
        $prescriptionDate = !empty($input['prescriptionDate']) ? $input['prescriptionDate'] : date('Y-m-d');
        
        // Execute the statement
        $stmt->bind_param("iissss", 
            $input['patientId'],
            $doctorID,
            $input['medication'],
            $input['dosage'],
            $combinedInstructions,
            $prescriptionDate
        );
        
        if ($stmt->execute()) {
            $prescriptionId = $conn->insert_id;
            $stmt->close();
            
            echo json_encode([
                'success' => true,
                'message' => 'Prescription saved successfully!',
                'prescriptionId' => $prescriptionId
            ]);
        } else {
            throw new Exception('Failed to save prescription to database: ' . $stmt->error);
        }
        
    } elseif ($method === 'GET') {
        // Get doctor ID
        $doctorUserID = $_SESSION['userID'];
        $doctorQuery = $conn->prepare("SELECT doctorID FROM Doctor WHERE userID = ?");
        $doctorQuery->bind_param("i", $doctorUserID);
        $doctorQuery->execute();
        $doctorResult = $doctorQuery->get_result();
        $doctorData = $doctorResult->fetch_assoc();
        $doctorQuery->close();

        if (!$doctorData) {
            throw new Exception('Doctor not found');
        }

        $doctorID = $doctorData['doctorID'];
        
        // Get all prescriptions for this doctor
        $stmt = $conn->prepare("
            SELECT p.*, u.firstName, u.lastName 
            FROM Prescriptions p
            JOIN Patient pt ON p.aptientID = pt.patientID
            JOIN User u ON pt.userID = u.userID
            WHERE p.doctorID = ?
            ORDER BY p.prescribdDate DESC
        ");
        $stmt->bind_param("i", $doctorID);
        $stmt->execute();
        $result = $stmt->get_result();
        $prescriptions = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        echo json_encode([
            'success' => true,
            'prescriptions' => $prescriptions
        ]);
        
    } else {
        throw new Exception('Method not allowed');
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}

$conn->close();
?>