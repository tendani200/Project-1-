

<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include '../db_connect.php';

// Fetch all doctors
$stmt = $conn->prepare("SELECT u.userID, u.firstName, u.lastName, u.email, u.phone, 
                               d.doctorID, d.specialty, d.availability, d.photo, d.description
                        FROM User u
                        JOIN Doctor d ON u.userID = d.userID
                        WHERE u.userType = 'Doctor'");
$stmt->execute();
$result = $stmt->get_result();

$doctors = [];
while ($row = $result->fetch_assoc()) {
    $doctors[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Our Doctors - Dokotela</title>

<!-- Google font + FontAwesome -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
    :root{
      --page-bg: #FCEFF4;
      --panel-bg: transparent;
      --soft-1: #E7C6FF;
      --soft-2: #BBCCFF;
      --accent-mid: #567C8D;
      --accent-dark: #2F4156;
      --hint-red: #C23B22;
      --white: #ffffff;
      --muted: #6F8793;
      --shadow-strong: rgba(15,30,60,0.08);
      --shadow-subtle: rgba(15,30,60,0.03);
      --divider: linear-gradient(90deg, rgba(86,124,141,0.06), rgba(86,124,141,0.00));
      --radius: 14px;
    }

    /* base */
    *{box-sizing:border-box}
    html,body{height:100%;margin:0;font-family:'Inter',system-ui,Arial,sans-serif;background:var(--page-bg);color:var(--accent-dark);-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}
    a{color:inherit;text-decoration:none}
    .app-shell{max-width:1300px;margin:26px auto;padding:18px;border-radius:18px;background:transparent;}

/* layout */
    .wrap{display:flex;gap:18px;align-items:flex-start;min-height:calc(100vh - 52px);padding:6px}

/* SIDEBAR - sticky full-height */
    .sidebar{
      width:260px;
      position:sticky;
      top:26px;
      height: calc(100vh - 52px);
      background: linear-gradient(180deg,var(--soft-2),var(--accent-dark));
      color:var(--white);
      border-radius:12px;
      box-shadow: 8px 0 30px var(--shadow-strong);
      overflow:hidden;
      display:flex;
      flex-direction:column;
      transition:width .28s ease;
      flex-shrink:0;
      padding-bottom:18px;
    }
    .sidebar.collapsed{ width:78px; }

    .sidebar .logo{display:flex;align-items:center;gap:12px;height:64px;padding:0 14px;transition:padding 0.3s ease;}
    .logo-mark{width:44px;height:44px;border-radius:10px;background:var(--white);display:flex;align-items:center;justify-content:center;font-weight:700;color:var(--accent-mid);font-size:20px;margin-right:0}
    .logo-text{font-weight:700;font-size:1.02rem;letter-spacing:0.2px;transition:opacity 0.3s ease, width 0.3s ease;overflow:hidden;white-space:nowrap;}

    .sidebar-nav{padding:10px;display:flex;flex-direction:column;gap:8px;flex:1;overflow:auto}
    .sidebar-nav::-webkit-scrollbar{width:8px}
    .sidebar-nav::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.06);border-radius:8px}

    .nav-item{display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:10px;color:var(--white);text-decoration:none;font-size:0.95rem;cursor:pointer;transition:background .14s ease, color .14s ease, padding 0.3s ease, justify-content 0.3s ease;}
    .nav-item .icon{width:36px;text-align:center;font-size:1.05rem}
    .nav-item:hover{background:rgba(255,255,255,0.06)}
    .nav-item.active{background:rgba(255,255,255,0.12);color:var(--white)}
    .label{transition:opacity 0.3s ease, width 0.3s ease;overflow:hidden;white-space:nowrap;}

    .sidebar .bottom-item{margin-top:auto;padding:12px 10px;transition:padding 0.3s ease, justify-content 0.3s ease;}

    /* Sidebar collapsed states */
    .sidebar.collapsed .logo-text,
    .sidebar.collapsed .label,
    .sidebar.collapsed .bottom-item .label {
      opacity: 0;
      width: 0;
    }

    .sidebar.collapsed .logo {
      justify-content: center;
      padding: 0;
    }

    .sidebar.collapsed .nav-item {
      justify-content: center;
      padding: 10px;
    }

    .sidebar.collapsed .sidebar-nav {
      align-items: center;
    }

    .sidebar.collapsed .bottom-item {
      justify-content: center;
      padding: 12px;
    }

/* CENTER content */
    .center{flex:1;display:flex;flex-direction:column;gap:20px;min-width:0;padding-right:6px}

/* GREETING (expanded height) */
    .top-card{
      background: linear-gradient(180deg, #ffff, #fbf8ff);
      backdrop-filter: blur(6px);
      border-radius:18px;
      padding:28px;
      box-shadow: 0 12px 36px var(--shadow-subtle);
      border:1px solid rgba(86,124,141,0.06);
      display:flex;
      justify-content:space-between;
      align-items:center;
      gap:12px;
      min-height:280px; 
      position:relative;
      overflow:visible;
    }

    .greeting{display:flex;flex-direction:column;gap:10px;max-width:62%}
    .greeting h1{margin:0;font-size:1.6rem;line-height:1.05}
    .greeting p{margin:0;color:var(--muted);font-size:0.98rem}

    .patient-summary{display:flex;align-items:center;gap:14px;margin-top:8px}
    .patient-summary .avatar{width:72px;height:72px;border-radius:12px;overflow:hidden;flex-shrink:0;box-shadow:0 6px 18px var(--shadow-subtle)}
    .patient-summary .avatar img{width:100%;height:100%;object-fit:cover}
    .patient-summary .meta{display:flex;flex-direction:column}
    .patient-summary .meta small{color:var(--muted)}

    .top-actions{display:flex;gap:12px;align-items:center}
    .search{display:flex;align-items:center;gap:8px;padding:10px 14px;border-radius:12px;background:rgba(255,255,255,0.9);min-width:280px;box-shadow:0 6px 18px rgba(12,30,45,0.04)}
    .search input{border:0;outline:none;background:transparent;font-size:0.95rem;width:220px}

    .icon-btn{
      width:44px;
      height:44px;
      border-radius:12px;
      display:flex;
      align-items:center;
      justify-content:center;
      background:linear-gradient(180deg,var(--soft-1),var(--soft-2));
      color:var(--accent-dark);
      border:none;
      cursor:pointer;
      box-shadow:0 6px 18px rgba(12,30,45,0.08);
      transition:transform 0.2s ease, box-shadow 0.2s ease;
    }
    .icon-btn:hover{
      transform:translateY(-2px);
      box-shadow:0 8px 22px rgba(12,30,45,0.12);
    }

/* section separators */
    .section-divider{
      height:8px;
      border-radius:8px;
      margin:6px 0 2px 0;
      background: var(--divider);
      box-shadow: 0 6px 18px rgba(12,30,45,0.02);
    }

/* stats blocks */
    .stats-section{display:flex;gap:14px;flex-wrap:wrap}
    .stat{
      flex:1 1 calc(33.333% - 14px);
      min-width:200px;
      background: #ffff;
      border-radius:12px;
      padding:16px;
      display:flex;
      flex-direction:column;
      gap:10px;
      border:1px solid rgba(86,124,141,0.04);
      box-shadow: 0 8px 28px rgba(12,30,45,0.02);
    }
    .stat h3{margin:0;font-size:1rem}
    .stat .value{font-size:1.5rem;font-weight:800;color:var(--accent-mid)}
    .badge-icon{width:46px;height:46px;border-radius:10px;display:flex;align-items:center;justify-content:center;color:var(--white);background: linear-gradient(180deg,var(--soft-1),var(--soft-2))}

/* appointments list */
    .mid-columns{display:grid;grid-template-columns:1fr;gap:16px}
    .card{
      background: #ffff;
      border-radius:12px;
      padding:12px;
      border:1px solid rgba(86,124,141,0.04);
      box-shadow: 0 8px 28px rgba(12,30,45,0.02);
    }

/* Doctor Grid Styles */
.doctor-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 20px;
  margin-top: 20px;
}

.doctor-card {
  position: relative;
  background: #fff;
  border-radius: var(--radius);
  padding: 16px;
  text-align: center;
  box-shadow: 0 8px 28px rgba(12,30,45,0.04);
  border: 1px solid rgba(86,124,141,0.05);
  cursor: pointer;
  overflow: hidden;
  transition: transform .25s ease, box-shadow .25s ease;
}

.doctor-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 36px rgba(12,30,45,0.08);
}

.doctor-card .avatar img {
  width: 100%;
  height: 200px;
  object-fit: cover;
  border-radius: 10px;
}

.doctor-info h3 {
  margin: 12px 0 6px;
  font-size: 1.1rem;
  color: var(--accent-dark);
}

.doctor-info p {
  margin: 0;
  color: var(--muted);
}

.overlay {
  position: absolute;
  top: 0; left: 0;
  width: 100%; height: 100%;
  background: rgba(47,65,86,0.92);
  color: #fff;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  opacity: 0;
  transition: opacity .3s ease;
  padding: 24px;
  border-radius: var(--radius);
  text-align: center;
}

.doctor-card:hover .overlay {
  opacity: 1;
}

.overlay h4 {
  margin-bottom: 10px;
  font-size: 1.2rem;
  font-weight: 700;
}

.detail-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
  width: 100%;
}

.detail-label {
  font-weight: 600;
  color: var(--soft-2);
  font-size: 0.9rem;
  text-align: left;
}

.detail-value {
  color: var(--white);
  font-weight: 500;
  text-align: right;
}

.book-btn {
  background: linear-gradient(180deg, var(--soft-1), var(--soft-2));
  color: var(--accent-dark);
  border: none;
  padding: 10px 20px;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  margin-top: 15px;
  transition: transform 0.2s ease;
}

.book-btn:hover {
  transform: translateY(-2px);
}

/* Responsive design */
@media (max-width: 1100px){
  .wrap{flex-direction:column;padding:12px}
  .sidebar{width:100%;height:auto;position:relative;top:auto;border-radius:12px;margin-bottom:18px}
  .sidebar.collapsed{width:100%;}
  .sidebar.collapsed .logo-text,
  .sidebar.collapsed .label,
  .sidebar.collapsed .bottom-item .label {
    opacity: 1;
    width: auto;
  }
  .sidebar.collapsed .logo{justify-content:flex-start;padding:0 14px;}
  .sidebar.collapsed .nav-item{justify-content:flex-start;padding:10px 12px;}
  .sidebar.collapsed .bottom-item{justify-content:flex-start;padding:12px 10px;}
  .top-card{min-height:200px;flex-direction:column;align-items:flex-start;gap:20px}
  .greeting{max-width:100%}
  .stats-section{flex-direction:row;overflow:auto;padding-bottom:8px}
  .top-actions{width:100%;justify-content:space-between}
  .search{flex:1;min-width:auto}
}

@media (max-width: 768px){
  .app-shell{margin:12px auto;padding:12px;}
  .wrap{padding:0;}
  .top-card{padding:20px;min-height:auto;}
  .greeting h1{font-size:1.4rem;}
  .patient-summary{flex-direction:column;align-items:flex-start;gap:10px;}
  .patient-summary .avatar{width:60px;height:60px;}
  .stats-section{gap:10px;}
  .stat{flex:1 1 100%;min-width:auto;}
  .top-actions{flex-wrap:wrap;gap:8px;}
  .search{min-width:200px;}
  .icon-btn{width:40px;height:40px;}
  .doctor-grid {
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 15px;
  }
}

@media (max-width: 480px){
  .app-shell{padding:8px;}
  .top-card{padding:16px;}
  .greeting h1{font-size:1.3rem;}
  .search{min-width:150px;}
  .search input{width:120px;}
  .top-actions{gap:6px;}
  .icon-btn{width:36px;height:36px;}
  .stats-section{flex-direction:column;}
  .doctor-grid {
    grid-template-columns: 1fr;
    gap: 12px;
  }
}
</style>
</head>

<body>
  <div class="app-shell">
    <div class="wrap">

      <!-- Sidebar -->
      <div class="sidebar">
        <div class="logo">
          <div class="logo-mark"><i class="fa-solid fa-stethoscope"></i></div>
          <div class="logo-text">Dokotela</div>
        </div>
        <div class="sidebar-nav">
          <a href="../dashboard.php" class="nav-item"><i class="fa-solid fa-house icon"></i><span class="label">Dashboard</span></a>
          <a href="doctorinfo.php" class="nav-item active"><i class="fa-solid fa-user-doctor icon"></i><span class="label">Doctors</span></a>
          <a href="../booking/appointments.php" class="nav-item"><i class="fa-solid fa-calendar-check icon"></i><span class="label">Appointments</span></a>
        </div>
        <a href="../logout.php" class="nav-item bottom-item"><i class="fa-solid fa-right-from-bracket icon"></i><span class="label">Logout</span></a>
      </div>

      <!-- Center Content -->
      <div class="center">
        <div class="top-card">
          <div class="greeting">
            <h1>Meet Our Doctors</h1>
            <p>Browse through our team of experienced and compassionate medical professionals ready to care for you.</p>
          </div>
          <div class="top-actions">
            <div class="search">
              <i class="fa-solid fa-search"></i>
              <input type="text" placeholder="Search doctor or specialty..." onkeyup="filterDoctors(this.value)">
            </div>
            <button class="icon-btn" onclick="toggleSidebar()"><i class="fa-solid fa-bars"></i></button>
          </div>
        </div>

        <div class="section-divider"></div>

        <div class="card">
          <div class="doctor-grid" id="doctorGrid">
            <?php foreach ($doctors as $doc): ?>
              <div class="doctor-card" data-doctor-id="<?= $doc['doctorID'] ?>">
                <div class="avatar">
                  <img src="<?= $doc['photo'] ? htmlspecialchars($doc['photo']) : '../assets/default-doctor.png' ?>" alt="Doctor Image" onerror="this.src='../assets/default-doctor.png'">
                </div>
                <div class="doctor-info">
                  <h3>Dr. <?= htmlspecialchars($doc['firstName'] . " " . $doc['lastName']) ?></h3>
                  <p class="muted"><?= htmlspecialchars($doc['specialty']) ?></p>
                </div>

                <div class="overlay">
                  <h4>Dr. <?= htmlspecialchars($doc['firstName'] . " " . $doc['lastName']) ?></h4>
                  <div class="appointment-detail">
                    <div class="detail-row">
                      <span class="detail-label">Specialty:</span>
                      <span class="detail-value"><?= htmlspecialchars($doc['specialty']) ?></span>
                    </div>
                    <div class="detail-row">
                      <span class="detail-label">Availability:</span>
                      <span class="detail-value"><?= htmlspecialchars($doc['availability']) ?></span>
                    </div>
                    <div class="detail-row">
                      <span class="detail-label">Email:</span>
                      <span class="detail-value"><?= htmlspecialchars($doc['email']) ?></span>
                    </div>
                    <div class="detail-row">
                      <span class="detail-label">Phone:</span>
                      <span class="detail-value"><?= htmlspecialchars($doc['phone']) ?></span>
                    </div>
                  </div>
                  <p class="muted"><?= htmlspecialchars($doc['description']) ?></p>
                  <button class="book-btn" onclick="bookAppointment(<?= $doc['doctorID'] ?>)">
                    <i class="fa-solid fa-calendar-plus"></i> Book Appointment
                  </button>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </div>

      </div><!-- end center -->
    </div><!-- end wrap -->
  </div><!-- end app-shell -->

<script>
  // Sidebar toggle
  function toggleSidebar() {
    document.querySelector('.sidebar').classList.toggle('collapsed');
  }

  // Filter doctors
  function filterDoctors(query) {
    const cards = document.querySelectorAll('.doctor-card');
    query = query.toLowerCase();
    cards.forEach(card => {
      const name = card.querySelector('h3').innerText.toLowerCase();
      const spec = card.querySelector('.muted').innerText.toLowerCase();
      card.style.display = (name.includes(query) || spec.includes(query)) ? 'block' : 'none';
    });
  }

  // Book appointment function - FIXED PATH
  function bookAppointment(doctorID) {
    // Redirect to the booking page in the correct location
    window.location.href = `../bookings/book_appointment.php?doctorID=${doctorID}`;
  }

  // Add click event to entire doctor card (except the button)
  document.addEventListener('DOMContentLoaded', function() {
    const doctorCards = document.querySelectorAll('.doctor-card');
    doctorCards.forEach(card => {
      card.addEventListener('click', function(e) {
        // Don't trigger if the click was on the book button
        if (!e.target.closest('.book-btn')) {
          const doctorID = this.getAttribute('data-doctor-id');
          bookAppointment(doctorID);
        }
      });
    });
  });
</script>

</body>
</html>  doctorinfo.php