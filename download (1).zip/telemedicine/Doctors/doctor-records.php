<?php
session_start();
include '../db_connect.php';

// Check if doctor is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    header("Location:login.php");
    exit();
}

$doctorUserID = $_SESSION['userID'];

// Fetch doctor info (same as dashboard)
$doctorQuery = $conn->prepare("SELECT * FROM User u JOIN Doctor d ON u.userID = d.userID WHERE u.userID = ?");
$doctorQuery->bind_param("i", $doctorUserID);
$doctorQuery->execute();
$doctorResult = $doctorQuery->get_result();
$doctor = $doctorResult->fetch_assoc();
$doctorQuery->close();

// Fetch medical records for this doctor (joined to patient name)
$recordsStmt = $conn->prepare("
    SELECT mr.recordID, mr.patientID, mr.appointmentID, mr.notes, mr.recordDate, mr.serviceID,
           CONCAT(u.firstName, ' ', u.lastName) AS patientName
    FROM MedicalRecord mr
    LEFT JOIN Patient p ON mr.patientID = p.patientID
    LEFT JOIN User u ON p.userID = u.userID
    WHERE mr.doctorID = ?
    ORDER BY mr.recordDate DESC
");
$recordsStmt->bind_param("i", $doctor['doctorID']);
$recordsStmt->execute();
$records = $recordsStmt->get_result();
$recordsStmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dokotela - Medical Records</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
/* === dashboard CSS (same as above) === */
:root{
    --blue-1: #0f4d92;
    --blue-2: #1CA9C9;
    --pastel: #E6F6FF;
    --bright-red: #ff2d55;
    --muted: #64748b;
    --bg: #f6fbff;
    --card-bg: rgba(255,255,255,0.75);
    --glass-border: rgba(255,255,255,0.35);
    --shadow: 0 6px 18px rgba(16,24,40,0.08);
    --radius: 12px;
    --glass-blur: 8px;
    --text-dark: #0f1724;
    --text-muted: #475569;
    --gap: 1rem;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%}
body{
    font-family: "Segoe UI", system-ui, -apple-system, "Helvetica Neue", Arial;
    background: linear-gradient(180deg,var(--pastel), #f1f8ff 40%);
    color:var(--text-dark);
    -webkit-font-smoothing:antialiased;
    -moz-osx-font-smoothing:grayscale;
    line-height:1.5;
}
.dashboard-container{ display:flex; min-height:100vh; gap:var(--gap); transition: all 0.3s ease; }
.sidebar{ width:260px; background: linear-gradient(180deg, rgba(255,255,255,0.7), rgba(246,249,255,0.55)); border-radius: calc(var(--radius) + 4px); padding:1rem; display:flex; flex-direction:column; gap:0.75rem; align-items:stretch; box-shadow: var(--shadow); border: 1px solid var(--glass-border); backdrop-filter: blur(6px); transition: width 0.28s cubic-bezier(.22,.9,.36,1), transform 0.3s ease; }
.sidebar.collapsed{ width:72px; padding:0.6rem; align-items:center }
.sidebar-header{ display:flex; align-items:center; gap:0.75rem; padding:0.6rem 0.6rem; }
.logo-mark{ width:44px;height:44px;border-radius:10px; display:grid;place-items:center;color:white; background: linear-gradient(135deg,var(--blue-1),var(--blue-2)); box-shadow: 0 6px 18px rgba(15,77,146,0.18); font-weight:700; font-size:1.05rem; }
.sidebar-header h2{ color:var(--blue-1); font-size:1.05rem; font-weight:700; }
.sidebar-nav{ display:flex;flex-direction:column;gap:6px;padding:0.5rem 0; width:100%; }
.nav-btn{ display:flex;align-items:center;gap:0.75rem; background:transparent;border:none;padding:0.6rem 0.8rem;border-radius:10px; cursor:pointer;color:var(--text-muted);font-size:0.95rem;transition: all 0.18s ease; text-decoration:none; }
.nav-btn .fa-fw{ width:20px; text-align:center }
.nav-btn:hover{ transform:translateY(-2px); color:var(--blue-1); background: rgba(15,77,146,0.04) }
.nav-btn.active{ background: linear-gradient(90deg, rgba(15,77,146,0.06), rgba(28,169,201,0.03)); color:var(--blue-1); border-left: 3px solid var(--blue-2); }
.user-profile{ margin-top:auto;display:flex;align-items:center;gap:0.75rem;padding:0.6rem;border-radius:10px; background: linear-gradient(180deg, rgba(255,255,255,0.35), rgba(255,255,255,0.2)); border: 1px solid rgba(255,255,255,0.25); backdrop-filter: blur(4px); }
.user-profile img{ width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid white; box-shadow: 0 6px 14px rgba(16,24,40,0.06) }
.profile-info h4{ font-size:0.95rem; margin-bottom:2px } .profile-info span{ font-size:0.82rem; color:var(--text-muted) }
.main-content{ flex:1;padding:1.5rem;overflow:auto; }
.hamburger{ display:inline-grid;place-items:center;width:44px;height:44px;border-radius:10px;border:none;background:transparent;cursor:pointer; transition: all 0.18s ease; }
.welcome-header{ background: linear-gradient(135deg, rgba(15,77,146,0.95), rgba(28,169,201,0.95)); color:white;padding:1.6rem;border-radius:14px;box-shadow: 0 12px 30px rgba(15,77,146,0.12); display:flex;flex-direction:column;gap:0.4rem; }
.grid{ display:grid; grid-template-columns: repeat(12, 1fr); gap:1rem; margin-top:1rem; }
.card{ background: var(--card-bg); border-radius: var(--radius); padding:1rem; box-shadow: var(--shadow); border: 1px solid var(--glass-border); backdrop-filter: blur(var(--glass-blur)); }
.btn{ display:inline-flex; align-items:center; gap:0.5rem; padding:0.55rem 0.9rem; border-radius:10px; border:none; cursor:pointer; font-weight:600 }
.btn-primary{ background: linear-gradient(90deg,var(--blue-1),var(--blue-2)); color:white } .btn-ghost{ background:transparent; color:var(--text-dark); border:1px solid rgba(15,77,146,0.06) }
.modal{ display:none; position:fixed; inset:0; z-index:1200; background: rgba(2,6,23,0.45); backdrop-filter: blur(4px) }
.modal .modal-content{ background: white; max-width:720px; margin:6% auto; padding:1.4rem; border-radius:12px; box-shadow: 0 20px 50px rgba(2,6,23,0.25) }
.glass-accent{ background: linear-gradient(180deg, rgba(255,255,255,0.6), rgba(255,255,255,0.35)); border-radius:10px; border:1px solid rgba(255,255,255,0.25); backdrop-filter: blur(6px) }
@media (max-width: 720px){ .dashboard-container{ flex-direction:column } .sidebar{ width:100%; flex-direction:row; align-items:center; gap:0.6rem; padding:0.6rem; border-radius:10px } .sidebar.collapsed{ width:100% } .sidebar-header h2{ display:none } .nav-btn{ padding:0.55rem; font-size:0.9rem } .grid{ grid-template-columns: 1fr; } }
.muted { color:var(--text-muted); font-size:0.9rem } .small { font-size:0.85rem }

/* records table */
.rec-table { width:100%; margin-top:1rem; border-collapse:collapse; }
.rec-table th, .rec-table td { padding:10px; border-bottom:1px solid rgba(15,77,146,0.06); text-align:left; }
.rec-table th { background: rgba(15,77,146,0.03); font-weight:700; }
.rec-table tr:hover { background: rgba(15,77,146,0.02); }
</style>
</head>
<body>
<div class="dashboard-container">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo-mark">D</div>
            <h2>Dokotela</h2>
 
        </div>

       <nav class="sidebar-nav" id="sidebarNav">
    <a class="nav-btn" href="doctor-dashboard.php"><i class="fa fa-home fa-fw"></i> <span class="nav-text">Overview</span></a>
    <a class="nav-btn" href="appointments.php"><i class="fa fa-calendar-check fa-fw"></i> <span class="nav-text">Appointments</span></a>
    <a class="nav-btn" href="patients.php"><i class="fa fa-users fa-fw"></i> <span class="nav-text">Patients</span></a>
    <a class="nav-btn" href="doctor-schedule.php"><i class="fa fa-clock fa-fw"></i> <span class="nav-text">Schedule</span></a>
    <a class="nav-btn active" href="records.php"><i class="fa fa-file-medical fa-fw"></i> <span class="nav-text">Medical Records</span></a>
</nav>

        <div class="user-profile">
            <img src="../assets/doctor-avatar.png" alt="Doctor Avatar" id="doctorAvatar">
            <div class="profile-info">
                <h4 id="doctorName"><?= htmlspecialchars($doctor['firstName'] . ' ' . $doctor['lastName']) ?></h4>
                <span><?= htmlspecialchars($doctor['specialty'] ?? 'Medical Practitioner') ?></span>
            </div>
        </div>
    </aside>

    <main class="main-content">
        <div class="topbar">
            <div class="topbar-left">
               
                <div class="muted small">Welcome back, <strong><?= htmlspecialchars($doctor['firstName']) ?></strong></div>
            </div>
            <div class="topbar-right">
                <button class="btn btn-ghost" id="notifBtn"><i class="fa fa-bell"></i> <span class="small muted">Notifications</span></button>
                <a href="logout.php" class="btn btn-ghost"><i class="fa fa-sign-out-alt"></i> <span class="small muted">Logout</span></a>
            </div>
        </div>

        <section id="doctor-records" class="dashboard-section active">
            <div class="welcome-header">
                <h1>Medical Records</h1>
                <p class="small">Patient records and visit notes.</p>
            </div>

            <div class="grid">
                <div class="card" style="grid-column: span 12;">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <h3 style="margin:0;color:var(--blue-1)">Records</h3>
                        <div>
                            <button class="btn btn-primary" id="addRecordBtn"><i class="fa fa-plus"></i> Add Record</button>
                        </div>
                    </div>

                    <table class="rec-table" role="table">
                        <thead>
                            <tr>
                                <th>Record ID</th>
                                <th>Patient</th>
                                <th>Appointment ID</th>
                                <th>Notes</th>
                                <th>Date</th>
                                <th>Service ID</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($records && $records->num_rows > 0): ?>
                            <?php while ($r = $records->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($r['recordID']) ?></td>
                                <td><?= htmlspecialchars($r['patientName'] ?? $r['patientID']) ?></td>
                                <td><?= htmlspecialchars($r['appointmentID']) ?></td>
                                <td><?= htmlspecialchars($r['notes']) ?></td>
                                <td><?= htmlspecialchars($r['recordDate']) ?></td>
                                <td><?= htmlspecialchars($r['serviceID']) ?></td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="6" class="muted">No records found.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

        <div class="modal" id="globalModal" aria-hidden="true">
            <div class="modal-content">
                <span class="close" id="modalClose" style="position:absolute;right:1rem;top:1rem;cursor:pointer;font-size:1.6rem;color:#b0b8c2">&times;</span>
                <h3 id="modalTitle">Modal</h3>
                <div id="modalBody" class="muted">Content goes here...</div>
            </div>
        </div>
    </main>
</div>

<script>
const sidebar = document.getElementById('sidebar');
const sidebarToggle = document.getElementById('sidebarToggle');
const sidebarCollapse = document.getElementById('sidebarCollapse');
const modal = document.getElementById('globalModal');
const modalClose = document.getElementById('modalClose');

sidebarToggle?.addEventListener('click', ()=> sidebar.classList.toggle('collapsed'));
sidebarCollapse?.addEventListener('click', ()=>{
    sidebar.classList.toggle('collapsed');
    const chev = sidebarCollapse.querySelector('i');
    if(chev) chev.classList.toggle('fa-chevron-left'), chev.classList.toggle('fa-chevron-right');
});

function openModal(title, content){
    document.getElementById('modalTitle').innerText = title || 'Modal';
    document.getElementById('modalBody').innerHTML = content || '';
    modal.style.display = 'block';
    modal.setAttribute('aria-hidden','false');
}
function closeModal(){ modal.style.display = 'none'; modal.setAttribute('aria-hidden','true'); }
modalClose?.addEventListener('click', closeModal);
modal.addEventListener('click', e => { if(e.target === modal) closeModal(); });

document.getElementById('addRecordBtn')?.addEventListener('click', ()=>{
    openModal('Add Medical Record', `
        <form id="addRecordForm">
            <label class="muted">Patient ID</label>
            <input name="patientID" required style="width:100%;padding:8px;margin:6px 0;border-radius:8px;border:1px solid #e6eef8">
            <label class="muted">Appointment ID</label>
            <input name="appointmentID" style="width:100%;padding:8px;margin:6px 0;border-radius:8px;border:1px solid #e6eef8">
            <label class="muted">Notes</label>
            <textarea name="notes" rows="4" style="width:100%;padding:8px;margin:6px 0;border-radius:8px;border:1px solid #e6eef8"></textarea>
            <div style="margin-top:10px;text-align:right">
                <button type="button" class="btn btn-ghost" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    `);
    document.getElementById('addRecordForm')?.addEventListener('submit', e=>{
        e.preventDefault();
        alert('Hook this form to your backend to save the record.');
        closeModal();
    });
});
</script>
</body>
</html>
