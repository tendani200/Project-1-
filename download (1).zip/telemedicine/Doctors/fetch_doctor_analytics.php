<?php
// Prevent any output before JSON
ob_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);

// InfinityFree compatibility
ini_set('max_execution_time', 30);
ini_set('memory_limit', '128M');

session_start();

// Clear any buffered output and set JSON header
ob_clean();
header('Content-Type: application/json');
header('Cache-Control: no-cache');
header('Access-Control-Allow-Origin: *');

try {
    // Use your existing database connection
    require_once '../db_connect.php';
    
    // Check if connection was established
    if (!isset($conn) || $conn->connect_error) {
        throw new Exception('Database connection failed');
    }

    // Check if doctor is logged in
    if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
        throw new Exception('Unauthorized access');
    }

    $doctorUserID = $_SESSION['userID'];

    // Get doctor ID
    $doctorQuery = $conn->prepare("SELECT doctorID FROM Doctor WHERE userID = ?");
    if (!$doctorQuery) {
        throw new Exception('Failed to prepare doctor query: ' . $conn->error);
    }
    
    $doctorQuery->bind_param("i", $doctorUserID);
    if (!$doctorQuery->execute()) {
        throw new Exception('Failed to execute doctor query: ' . $doctorQuery->error);
    }
    
    $doctorResult = $doctorQuery->get_result();
    $doctor = $doctorResult->fetch_assoc();
    $doctorQuery->close();

    if (!$doctor) {
        throw new Exception('Doctor not found');
    }

    $doctorID = $doctor['doctorID'];

    // Get current date for calculations
    $currentDate = date('Y-m-d');
    $startOfWeek = date('Y-m-d', strtotime('monday this week'));
    $endOfWeek = date('Y-m-d', strtotime('sunday this week'));
    $startOfMonth = date('Y-m-01');
    $endOfMonth = date('Y-m-t');

    // 1. WEEKLY PERFORMANCE DATA
    $weeklyQuery = $conn->prepare("
        SELECT 
            DATE(appointmentDate) as date,
            DAYNAME(appointmentDate) as day_name,
            COUNT(*) as appointment_count,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_count
        FROM Appointments 
        WHERE doctorID = ? 
        AND appointmentDate BETWEEN ? AND ?
        GROUP BY DATE(appointmentDate), DAYNAME(appointmentDate)
        ORDER BY appointmentDate
    ");
    
    if (!$weeklyQuery) {
        throw new Exception('Failed to prepare weekly query: ' . $conn->error);
    }
    
    $weeklyQuery->bind_param("iss", $doctorID, $startOfWeek, $endOfWeek);
    if (!$weeklyQuery->execute()) {
        throw new Exception('Failed to execute weekly query: ' . $weeklyQuery->error);
    }
    
    $weeklyResult = $weeklyQuery->get_result();
    
    // Initialize days array
    $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    $weeklyStats = [];
    
    foreach ($days as $day) {
        $weeklyStats[$day] = [
            'day' => $day,
            'short' => substr($day, 0, 3),
            'date' => date('Y-m-d', strtotime($day . ' this week')),
            'appointments' => 0,
            'completed' => 0,
            'cancelled' => 0,
            'patients_helped' => 0
        ];
    }
    
    // Fill in actual data
    while ($row = $weeklyResult->fetch_assoc()) {
        $dayName = $row['day_name'];
        if (isset($weeklyStats[$dayName])) {
            $weeklyStats[$dayName]['appointments'] = (int)$row['appointment_count'];
            $weeklyStats[$dayName]['completed'] = (int)$row['completed_count'];
            $weeklyStats[$dayName]['cancelled'] = (int)$row['cancelled_count'];
            $weeklyStats[$dayName]['patients_helped'] = (int)$row['completed_count'];
        }
    }
    $weeklyQuery->close();

    // 2. MONTHLY PERFORMANCE DATA
    $monthlyQuery = $conn->prepare("
        SELECT 
            DAY(appointmentDate) as day,
            COUNT(*) as appointment_count,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count
        FROM Appointments 
        WHERE doctorID = ? 
        AND appointmentDate BETWEEN ? AND ?
        GROUP BY DAY(appointmentDate)
        ORDER BY DAY(appointmentDate)
    ");
    
    if (!$monthlyQuery) {
        throw new Exception('Failed to prepare monthly query: ' . $conn->error);
    }
    
    $monthlyQuery->bind_param("iss", $doctorID, $startOfMonth, $endOfMonth);
    if (!$monthlyQuery->execute()) {
        throw new Exception('Failed to execute monthly query: ' . $monthlyQuery->error);
    }
    
    $monthlyResult = $monthlyQuery->get_result();
    
    $monthlyStats = [];
    $daysInMonth = (int)date('t');
    
    for ($i = 1; $i <= $daysInMonth; $i++) {
        $monthlyStats[$i] = [
            'day' => $i,
            'date' => date('Y-m-' . sprintf('%02d', $i)),
            'appointments' => 0,
            'patients_helped' => 0
        ];
    }
    
    while ($row = $monthlyResult->fetch_assoc()) {
        $day = (int)$row['day'];
        if (isset($monthlyStats[$day])) {
            $monthlyStats[$day]['appointments'] = (int)$row['appointment_count'];
            $monthlyStats[$day]['patients_helped'] = (int)$row['completed_count'];
        }
    }
    $monthlyQuery->close();

    // 3. OVERALL STATISTICS
    $overallStatsQuery = $conn->prepare("
        SELECT 
            COUNT(*) as total_appointments,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as total_completed,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as total_cancelled,
            SUM(CASE WHEN status = 'booked' THEN 1 ELSE 0 END) as total_pending,
            SUM(CASE WHEN appointmentDate = CURDATE() THEN 1 ELSE 0 END) as today_appointments,
            SUM(CASE WHEN appointmentDate = CURDATE() AND status = 'completed' THEN 1 ELSE 0 END) as today_completed
        FROM Appointments 
        WHERE doctorID = ?
    ");
    
    if (!$overallStatsQuery) {
        throw new Exception('Failed to prepare overall stats query: ' . $conn->error);
    }
    
    $overallStatsQuery->bind_param("i", $doctorID);
    if (!$overallStatsQuery->execute()) {
        throw new Exception('Failed to execute overall stats query: ' . $overallStatsQuery->error);
    }
    
    $overallResult = $overallStatsQuery->get_result();
    $overallStats = $overallResult->fetch_assoc();
    $overallStatsQuery->close();

    // 4. WEEKLY TOTALS
    $weeklyTotals = [
        'total_appointments' => array_sum(array_column($weeklyStats, 'appointments')),
        'total_patients_helped' => array_sum(array_column($weeklyStats, 'patients_helped')),
        'total_cancelled' => array_sum(array_column($weeklyStats, 'cancelled')),
    ];

    // 5. MONTHLY TOTALS
    $monthlyTotals = [
        'total_appointments' => array_sum(array_column($monthlyStats, 'appointments')),
        'total_patients_helped' => array_sum(array_column($monthlyStats, 'patients_helped')),
    ];

    // 6. RECENT PATIENTS HELPED (Last 7 days)
    $recentPatientsQuery = $conn->prepare("
        SELECT 
            u.firstName, u.lastName, a.appointmentDate, a.appointmentTime
        FROM Appointments a
        JOIN Patient p ON a.patientID = p.patientID
        JOIN User u ON p.userID = u.userID
        WHERE a.doctorID = ? 
        AND a.status = 'completed'
        AND a.appointmentDate >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        ORDER BY a.appointmentDate DESC, a.appointmentTime DESC
        LIMIT 10
    ");
    
    if (!$recentPatientsQuery) {
        throw new Exception('Failed to prepare recent patients query: ' . $conn->error);
    }
    
    $recentPatientsQuery->bind_param("i", $doctorID);
    if (!$recentPatientsQuery->execute()) {
        throw new Exception('Failed to execute recent patients query: ' . $recentPatientsQuery->error);
    }
    
    $recentPatientsResult = $recentPatientsQuery->get_result();
    
    $recentPatients = [];
    while ($row = $recentPatientsResult->fetch_assoc()) {
        $recentPatients[] = [
            'name' => $row['firstName'] . ' ' . $row['lastName'],
            'date' => $row['appointmentDate'],
            'time' => $row['appointmentTime']
        ];
    }
    $recentPatientsQuery->close();

    // 7. MEDICAL RECORDS CREATED - Using correct table name 'MedicalRecords'
    $medicalRecordsCount = 0;
    $weeklyRecordsCount = 0;
    $monthlyRecordsCount = 0;
    
    // Check if MedicalRecords table exists
    $tableCheck = $conn->query("SHOW TABLES LIKE 'MedicalRecords'");
    if ($tableCheck && $tableCheck->num_rows > 0) {
        // Total medical records
        $recordsQuery = $conn->prepare("SELECT COUNT(*) as count FROM MedicalRecords WHERE doctorID = ?");
        if ($recordsQuery) {
            $recordsQuery->bind_param("i", $doctorID);
            if ($recordsQuery->execute()) {
                $medicalRecordsCount = $recordsQuery->get_result()->fetch_assoc()['count'];
            }
            $recordsQuery->close();
        }
        
        // Weekly records
        $weeklyRecordsQuery = $conn->prepare("
            SELECT COUNT(*) as count 
            FROM MedicalRecords 
            WHERE doctorID = ? 
            AND recordDate BETWEEN ? AND ?
        ");
        if ($weeklyRecordsQuery) {
            $weeklyRecordsQuery->bind_param("iss", $doctorID, $startOfWeek, $endOfWeek);
            if ($weeklyRecordsQuery->execute()) {
                $weeklyRecordsCount = $weeklyRecordsQuery->get_result()->fetch_assoc()['count'];
            }
            $weeklyRecordsQuery->close();
        }
        
        // Monthly records
        $monthlyRecordsQuery = $conn->prepare("
            SELECT COUNT(*) as count 
            FROM MedicalRecords 
            WHERE doctorID = ? 
            AND recordDate BETWEEN ? AND ?
        ");
        if ($monthlyRecordsQuery) {
            $monthlyRecordsQuery->bind_param("iss", $doctorID, $startOfMonth, $endOfMonth);
            if ($monthlyRecordsQuery->execute()) {
                $monthlyRecordsCount = $monthlyRecordsQuery->get_result()->fetch_assoc()['count'];
            }
            $monthlyRecordsQuery->close();
        }
    }

    // Calculate completion rate
    $completionRate = $overallStats['total_appointments'] > 0 
        ? round(($overallStats['total_completed'] / $overallStats['total_appointments']) * 100, 1)
        : 0;

    // Return comprehensive analytics data
    echo json_encode([
        'success' => true,
        'generated_at' => date('Y-m-d H:i:s'),
        'period' => [
            'current_week' => [
                'start' => $startOfWeek,
                'end' => $endOfWeek
            ],
            'current_month' => [
                'start' => $startOfMonth,
                'end' => $endOfMonth
            ]
        ],
        'weekly' => [
            'stats' => array_values($weeklyStats),
            'totals' => $weeklyTotals
        ],
        'monthly' => [
            'stats' => array_values($monthlyStats),
            'totals' => $monthlyTotals
        ],
        'overall' => [
            'total_appointments' => (int)$overallStats['total_appointments'],
            'total_patients_helped' => (int)$overallStats['total_completed'],
            'total_cancelled' => (int)$overallStats['total_cancelled'],
            'total_pending' => (int)$overallStats['total_pending'],
            'today_appointments' => (int)$overallStats['today_appointments'],
            'today_patients_helped' => (int)$overallStats['today_completed'],
            'completion_rate' => $completionRate,
            'medical_records_created' => (int)$medicalRecordsCount,
            'weekly_records' => (int)$weeklyRecordsCount,
            'monthly_records' => (int)$monthlyRecordsCount
        ],
        'recent_patients' => $recentPatients
    ]);

} catch (Exception $e) {
    error_log("Doctor analytics error: " . $e->getMessage());
    
    // Ensure no output before JSON
    if (ob_get_length()) ob_clean();
    
    echo json_encode([
        'success' => false,
        'error' => 'An error occurred while fetching analytics data'
    ]);
} finally {
    if (isset($conn) && $conn instanceof mysqli) {
        $conn->close();
    }
}
?>