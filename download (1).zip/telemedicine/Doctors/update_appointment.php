<?php
include '../db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $appointmentID = $_POST['appointmentID'] ?? '';

    if ($action === 'reschedule') {
        $newDate = $_POST['newDate'] ?? '';
        $newTime = $_POST['newTime'] ?? '';

        $stmt = $conn->prepare("UPDATE Appointments SET appointmentDate = ?, appointmentTime = ?, status = 'Rescheduled' WHERE appointmentID = ?");
        $stmt->bind_param("ssi", $newDate, $newTime, $appointmentID);
        $stmt->execute();
        echo "Appointment successfully rescheduled.";
    } elseif ($action === 'cancel') {
        $stmt = $conn->prepare("UPDATE Appointments SET status = 'Cancelled' WHERE appointmentID = ?");
        $stmt->bind_param("i", $appointmentID);
        $stmt->execute();
        echo "Appointment successfully cancelled.";
    } else {
        echo "Invalid action.";
    }
}
?>
