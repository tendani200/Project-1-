<?php
session_start();
include '../db_connect.php';

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    error_log("Search.php - Unauthorized access");
    echo json_encode(['error' => 'Unauthorized - Please log in as a doctor']);
    exit();
}

// Fetch prescriptions from database (unchanged)
$query = "SELECT p.prescriptionID, u.firstName AS patientName, p.status, p.prescribedDate, p.medication, p.sentDate 
          FROM Prescription p
          JOIN Patient pa ON p.patientID = pa.patientID
          JOIN User u ON pa.userID = u.userID
          ORDER BY p.prescribedDate DESC";

$result = $conn->query($query);
$prescriptions = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
$prescriptionCount = count($prescriptions);

// Try to get doctor's displayed name from session (frontend-only usage, safe fallback)
$doctorDisplayName = htmlspecialchars($_SESSION['userfirstName'] ?? ($_SESSION['userID'] ?? 'Doctor'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dokotela - Prescriptions</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <style>
    /* --- Theme variables (copied/adapted from dashboard) --- */
    :root{
        --blue-1: #0f4d92;
        --blue-2: #1CA9C9;
        --muted: #64748b;
        --card-bg: rgba(255,255,255,0.75);
        --glass-border: rgba(255,255,255,0.35);
        --shadow: 0 6px 18px rgba(16,24,40,0.08);
        --radius: 12px;
        --glass-blur: 8px;
        --text-dark: #0f1724;
        --text-muted: #475569;
        --gap: 1rem;
    }

    *{box-sizing:border-box;margin:0;padding:0}
    html,body{height:100%}
    body{
        font-family: "Segoe UI", system-ui, -apple-system, "Helvetica Neue", Arial;
        background: radial-gradient(circle at top left, #e6f6ff 0%, #f1f8ff 100%);
        color: var(--text-dark);
        -webkit-font-smoothing:antialiased;
        -moz-osx-font-smoothing:grayscale;
        line-height:1.4;
    }

    /* Layout */
    .dashboard-container{ display:flex; min-height:100vh; gap:var(--gap); }

    /* SIDEBAR */
    .sidebar{
        width:260px;
        background: linear-gradient(180deg, rgba(255,255,255,0.7), rgba(246,249,255,0.55));
        border-radius: calc(var(--radius) + 4px);
        padding:1rem;
        display:flex;
        flex-direction:column;
        gap:0.75rem;
        align-items:stretch;
        box-shadow: var(--shadow);
        border: 1px solid var(--glass-border);
        backdrop-filter: blur(6px);
        transition: width .22s ease, left .22s ease, padding .18s ease;
    }
    .sidebar.collapsed{ width:72px; padding:0.6rem; align-items:center; overflow:hidden; }
    /* When collapsed hide texts */
    .sidebar.collapsed .nav-text,
    .sidebar.collapsed .sidebar-header h2,
    .sidebar.collapsed .profile-info { display:none !important; }

    .sidebar-header{ display:flex; align-items:center; gap:0.75rem; padding:0.6rem 0.6rem; }
    .logo-mark{ width:44px;height:44px;border-radius:10px; display:grid;place-items:center;color:white; background: linear-gradient(135deg,var(--blue-1),var(--blue-2)); font-weight:700; font-size:1.05rem; }
    .sidebar-header h2{ color:var(--blue-1); font-size:1.05rem; font-weight:700; }

    .sidebar-nav{ display:flex;flex-direction:column;gap:6px;padding:0.5rem 0; width:100%; }
    /* Nav items: icon left, text centered in available space */
    .nav-btn{
        display:flex;
        align-items:center;
        gap:0.75rem;
        background:transparent;
        border:none;
        padding:0.6rem 0.8rem;
        border-radius:10px;
        cursor:pointer;
        color:var(--text-muted);
        font-size:0.95rem;
        transition: all 0.18s ease;
        text-decoration:none;
        width:100%;
        text-align:left;
        position:relative;
    }
    .nav-btn .fa-fw{ width:20px; text-align:center; flex:0 0 26px; }
    /* center the text area between icon and right edge */
    .nav-text{ display:inline-block; flex:1 1 auto; text-align:center; margin-right:8px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .nav-btn:hover{ transform:translateY(-2px); color:var(--blue-1); background: rgba(15,77,146,0.04) }
    .nav-btn.active{ background: linear-gradient(90deg, rgba(15,77,146,0.06), rgba(28,169,201,0.03)); color:var(--blue-1); border-left: 3px solid var(--blue-2); }

    .user-profile{ margin-top:auto; display:flex; align-items:center; gap:0.75rem; padding:0.6rem; border-radius:10px; background: linear-gradient(180deg, rgba(255,255,255,0.35), rgba(255,255,255,0.2)); border: 1px solid rgba(255,255,255,0.25); backdrop-filter: blur(4px); }
    .user-profile img{ width:44px;height:44px;border-radius:50%;object-fit:cover;border:2px solid white; box-shadow: 0 6px 14px rgba(16,24,40,0.06) }
    .profile-info h4{ font-size:0.95rem; margin-bottom:2px }
    .profile-info span{ font-size:0.82rem; color:var(--text-muted) }

    /* Main area */
    .main-content{ flex:1; padding:1.25rem; overflow:auto; }

    .topbar{ display:flex;align-items:center;justify-content:space-between;gap:1rem;margin-bottom:1rem; }
    .hamburger{ background:transparent;border:none;padding:0.5rem;cursor:pointer;color:var(--text-muted); border-radius:6px; }
    .welcome-header{ background: linear-gradient(90deg,var(--blue-1),var(--blue-2)); color:white;padding:1rem;border-radius:10px; box-shadow: 0 8px 30px rgba(15,77,146,0.08); margin-bottom:1rem; }
    .welcome-header h1{ font-size:1.1rem; margin:0; }

    /* cards */
    .card{ background: var(--card-bg); border-radius: var(--radius); padding:1rem; box-shadow: var(--shadow); border: 1px solid var(--glass-border); backdrop-filter: blur(var(--glass-blur)); margin-bottom:1rem; }

    /* forms */
    .form-grid{ display:grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; }
    .form-group{ display:flex; flex-direction:column; gap:6px; }
    .form-group input[type="text"], .form-group input[type="date"], .form-group textarea, .form-group select { padding:10px; border-radius:8px; border:1px solid #e6e9ef; font-size:0.95rem; }

    .col-span-3 { grid-column: 1 / -1; }
    .inline-actions{ display:flex; gap:0.6rem; align-items:center; flex-wrap:wrap; }
    .btn{ display:inline-flex; align-items:center; gap:0.5rem; padding:0.6rem 0.9rem; border-radius:10px; border:none; cursor:pointer; font-weight:600; text-decoration:none; }
    .btn-primary{ background: linear-gradient(90deg,var(--blue-1),var(--blue-2)); color:white; }
    .btn-ghost{ background:transparent; color:var(--text-dark); border:1px solid rgba(15,77,146,0.06); }
    .btn-outline{ background: transparent; border:1px solid rgba(15,77,146,0.12); color:var(--blue-1); }
    .btn-success{ background:#10b981; color:#fff; }
    .small{ font-size:0.85rem; padding:0.4rem 0.7rem; border-radius:8px; }

    .med-list{ display:flex; gap:8px; flex-wrap:wrap; margin-top:6px; }
    .med-chip{ background: rgba(28,169,201,0.12); color: var(--blue-1); padding:6px 10px; border-radius:999px; display:flex; gap:6px; align-items:center; font-size:0.9rem; }

    .prescription-list { display:grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap:1rem; margin-top:1rem; }
    .prescription-item{ padding:1rem; border-radius:10px; background: rgba(255,255,255,0.9); border-left: 6px solid rgba(15,77,146,0.08); box-shadow: 0 6px 18px rgba(8,20,40,0.04); }
    .prescription-item h4{ margin:0 0 0.4rem 0; color:var(--blue-1); }
    .meta{ text-align:right; font-size:0.9rem; color:var(--text-muted); }

    /* responsive adjustments */
    @media (max-width: 1000px) {
        .form-grid { grid-template-columns: repeat(2, 1fr); }
    }

    /* Mobile behaviour: make sidebar a hidden drawer and toggle with .open */
    @media (max-width: 900px) {
        .sidebar{
            position:fixed;
            left:-320px;
            top:0;
            bottom:0;
            height:100%;
            z-index:2000;
            width:260px;
            transition:left .25s ease;
        }
        .sidebar.open{ left:0; }
        .main-content{ padding:1rem; }
        .form-grid { grid-template-columns: 1fr; }
        .col-span-3 { grid-column: auto; }
    }

    /* Small helpers for accessibility/visual */
    .muted { color:var(--text-muted); font-size:0.95rem; }
    .small-muted { color:var(--text-muted); font-size:0.85rem; }
  </style>
</head>
<body>
  <div class="dashboard-container">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo-mark">D</div>
            <h2>Dokotela</h2>
        </div>

        <nav class="sidebar-nav" id="sidebarNav">
            <button class="nav-btn" onclick="window.location.href='doctor-dashboard.php'">
                <i class="fa fa-home fa-fw"></i> <span class="nav-text">Overview</span>
            </button>
            <button class="nav-btn" onclick="window.location.href='appointments.php'">
                <i class="fa fa-calendar-check fa-fw"></i> <span class="nav-text">Appointments</span>
            </button>
            <button class="nav-btn" onclick="window.location.href='patients.php'">
                <i class="fa fa-users fa-fw"></i> <span class="nav-text">Patients</span>
            </button>
            <button class="nav-btn" onclick="window.location.href='../bookings/manage_slots.php'">
                <i class="fa fa-clock fa-fw"></i> <span class="nav-text">Schedule</span>
            </button>
            <button class="nav-btn active" onclick="window.location.href='prescriptions.php'">
                <i class="fa fa-file-prescription fa-fw"></i> <span class="nav-text">Prescriptions</span>
            </button>
            <button class="nav-btn" onclick="window.location.href='profile.php'">
                <i class="fa fa-user-cog fa-fw"></i> <span class="nav-text">Settings</span>
            </button>
        </nav>

        <div class="user-profile">
            <img src="/assets/avatar-placeholder.png" alt="Doctor avatar" onerror="this.style.display='none'">
            <div class="profile-info">
                <h4><?= $doctorDisplayName ?></h4>
                <span class="small-muted">Doctor</span>
            </div>
        </div>
    </aside>

    <main class="main-content" id="mainContent">
        <div class="topbar">
            <div style="display:flex; align-items:center; gap:1rem;">
                <!-- Keep only the arrow/collapse control (remove hamburger) -->
                <button class="hamburger" id="sidebarCollapse" title="Collapse sidebar" aria-label="Collapse sidebar">
                    <i class="fa fa-chevron-left"></i>
                </button>
                <div class="muted small">Create & manage prescriptions</div>
            </div>

            <div style="display:flex; align-items:center; gap:0.75rem;">
                <div style="display:flex; gap:8px; align-items:center;">
                    <div style="background: rgba(255,255,255,0.12); padding:6px 10px; border-radius:12px;">
                        <i class="fa fa-user-md" style="color:white; opacity:0.9;"></i>
                    </div>
                    <div class="small-muted"><?= htmlspecialchars($doctorDisplayName) ?></div>
                </div>
            </div>
        </div>

        <!-- Create Prescription -->
        <section class="card" aria-labelledby="create-title">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                <h2 id="create-title" style="margin:0; color:var(--blue-1)"><i class="fa fa-plus-circle"></i> Create New Prescription</h2>
                <div class="inline-actions">
                    <button id="clearFormBtn" class="btn btn-ghost small">Clear Form</button>
                    <button id="saveDraftBtn" class="btn btn-outline small">Save Draft</button>
                    <button id="createDraftBtn" class="btn btn-primary small">Create Prescription</button>
                    <button id="sendPatientBtn" class="btn btn-success small">Send to Patient</button>
                </div>
            </div>

            <form id="create-prescription-form">
                <div class="form-grid">
                    <div class="form-group">
                        <label>Patient Name <span style="color:#d00;">*</span></label>
                        <input type="text" name="patientName" id="patientName" placeholder="Enter patient name" required>
                    </div>

                    <div class="form-group">
                        <label>Date of Birth <span style="color:#d00;">*</span></label>
                        <input type="date" name="dob" id="dob" placeholder="yyyy/mm/dd" required>
                    </div>

                    <div class="form-group">
                        <label>Patient ID <span style="color:#d00;">*</span></label>
                        <input type="text" name="patientID" id="patientID" placeholder="Enter patient ID" required>
                    </div>

                    <div class="form-group">
                        <label>Consultation Date <span style="color:#d00;">*</span></label>
                        <input type="date" name="consultationDate" id="consultationDate" required>
                    </div>

                    <div class="form-group">
                        <label>Diagnosis <span style="color:#d00;">*</span></label>
                        <input type="text" name="diagnosis" id="diagnosis" placeholder="Enter diagnosis" required>
                    </div>

                    <div class="form-group">
                        <label>Allergies</label>
                        <input type="text" name="allergies" id="allergies" placeholder="List any allergies">
                    </div>

                    <div class="form-group col-span-3">
                        <label>Medications <span style="color:#d00;">*</span></label>
                        <div style="display:flex; gap:8px; align-items:center;">
                            <input type="text" id="medicationInput" placeholder="e.g. Paracetamol 500mg - 1 tab 8hrly" style="flex:1; padding:10px; border-radius:8px; border:1px solid #e6e9ef;">
                            <button type="button" id="addMedicationBtn" class="btn btn-outline small">Add Medication</button>
                        </div>
                        <div class="med-list" id="medList" aria-live="polite" style="margin-top:8px;"></div>
                        <textarea name="medications" id="medications" rows="3" style="display:none;"></textarea>
                    </div>

                    <div class="form-group col-span-3">
                        <label>Additional Notes</label>
                        <textarea name="notes" id="notes" rows="3" placeholder="Enter any additional notes or instructions"></textarea>
                    </div>

                    <div class="form-group">
                        <label>Refills Authorized</label>
                        <select name="refillsAuthorized" id="refillsAuthorized">
                            <option value="No Refills">No Refills</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                        </select>
                    </div>

                    <div></div>
                </div>
            </form>
        </section>

        <!-- Existing prescriptions -->
        <section class="card">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                <h3 style="margin:0; color:var(--blue-1)"><i class="fa fa-file-prescription"></i> Your Prescriptions (<?= $prescriptionCount ?>)</h3>
                <div class="small-muted" style="color:var(--text-muted)"><?= date('D, M j, Y') ?></div>
            </div>

            <?php if ($prescriptionCount === 0): ?>
                <div class="muted" style="padding:1.25rem; text-align:center;">No prescriptions yet.</div>
            <?php else: ?>
                <div class="prescription-list" id="existingPrescriptions">
                    <?php foreach ($prescriptions as $prescription): ?>
                        <div class="prescription-item card" data-id="<?= intval($prescription['prescriptionID']) ?>">
                            <div style="display:flex; justify-content:space-between; gap:1rem; align-items:flex-start;">
                                <div>
                                    <h4>RX-<?= str_pad($prescription['prescriptionID'], 6, '0', STR_PAD_LEFT) ?></h4>
                                    <p><strong>Patient:</strong> <?= htmlspecialchars($prescription['patientName']) ?></p>
                                    <p style="margin-top:6px;"><strong>Medications:</strong> <?= htmlspecialchars(strlen($prescription['medication'])>140 ? substr($prescription['medication'],0,140).'...' : $prescription['medication']) ?></p>
                                </div>
                                <div class="meta">
                                    <div style="font-weight:700; color: <?= ($prescription['status'] === 'sent') ? '#16a34a' : '#f59e0b' ?>;"><?= ucfirst(htmlspecialchars($prescription['status'])) ?></div>
                                    <div style="font-size:0.9rem; color:var(--text-muted);"><?= date('M j, Y', strtotime($prescription['prescribedDate'])) ?></div>
                                    <div style="margin-top:8px;">
                                        <button class="btn btn-primary small view-prescription" data-id="<?= intval($prescription['prescriptionID']) ?>"><i class="fa fa-eye"></i></button>
                                        <button class="btn btn-info small edit-prescription" data-id="<?= intval($prescription['prescriptionID']) ?>"><i class="fa fa-edit"></i></button>
                                        <?php if ($prescription['status'] !== 'sent'): ?>
                                            <button class="btn btn-success small send-prescription" data-id="<?= intval($prescription['prescriptionID']) ?>"><i class="fa fa-paper-plane"></i></button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

    </main>
  </div>

  <!-- Modals -->
  <div id="viewModal" class="modal" aria-hidden="true" style="display:none;">
    <div class="modal-content" style="max-width:760px; margin:6% auto; padding:1.25rem; border-radius:12px; box-shadow: 0 20px 50px rgba(2,6,23,0.25); background:#fff;">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
        <h3 style="margin:0;">Prescription Details</h3>
        <button class="close-btn" id="closeView" style="background:none;border:0;font-size:22px;cursor:pointer;">&times;</button>
      </div>
      <div id="viewModalBody"></div>
    </div>
  </div>

  <div id="editModal" class="modal" aria-hidden="true" style="display:none;">
    <div class="modal-content" style="max-width:640px; margin:6% auto; padding:1rem; border-radius:12px; background:#fff;">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
        <h3 style="margin:0;">Edit Prescription</h3>
        <button class="close-btn" id="closeEdit" style="background:none;border:0;font-size:22px;cursor:pointer;">&times;</button>
      </div>

      <form id="edit-prescription-form">
        <input type="hidden" id="edit-prescription-id">
        <div style="display:grid; gap:8px;">
            <label style="font-weight:700;">Diagnosis</label>
            <input id="edit-diagnosis" type="text" style="padding:8px; border-radius:8px; border:1px solid #e6e9ef;">

            <label style="font-weight:700;">Medications</label>
            <textarea id="edit-medications" rows="4" style="padding:8px; border-radius:8px; border:1px solid #e6e9ef;"></textarea>

            <label style="font-weight:700;">Notes</label>
            <textarea id="edit-notes" rows="3" style="padding:8px; border-radius:8px; border:1px solid #e6e9ef;"></textarea>

            <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:6px;">
                <button type="button" class="btn btn-ghost" id="cancelEdit">Cancel</button>
                <button type="button" class="btn btn-primary" id="saveEdit">Save</button>
            </div>
        </div>
      </form>
    </div>
  </div>

<script>
/* Sidebar behaviour */
const sidebar = document.getElementById('sidebar');
const sidebarCollapseBtn = document.getElementById('sidebarCollapse');

/* Collapse arrow flips chevron and hides text (icons remain) */
sidebarCollapseBtn?.addEventListener('click', () => {
    sidebar.classList.toggle('collapsed');
    const i = sidebarCollapseBtn.querySelector('i');
    if (i) i.classList.toggle('fa-chevron-right');
});

/* Mobile drawer: open when screen small and user taps anywhere inside .sidebar (optional)
   If you want a separate button to open on mobile, create one and toggle 'open' class.
*/
document.addEventListener('click', (e) => {
    // Close mobile sidebar when clicking outside
    if (window.innerWidth <= 900) {
        if (!e.target.closest('.sidebar') && !e.target.closest('#sidebarCollapse')) {
            sidebar.classList.remove('open');
        }
    }
});

/* Medications list logic */
const medInput = document.getElementById('medicationInput');
const addMedBtn = document.getElementById('addMedicationBtn');
const medList = document.getElementById('medList');
const medsHidden = document.getElementById('medications');
let medications = [];

function escapeHtml(unsafe) {
    if (!unsafe) return '';
    return unsafe.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}

function renderMedList(){
    medList.innerHTML = '';
    medications.forEach((m, idx) => {
        const chip = document.createElement('div');
        chip.className = 'med-chip';
        chip.innerHTML = `<span>${escapeHtml(m)}</span><button type="button" data-idx="${idx}" class="btn btn-ghost small" style="padding:4px 6px; margin-left:6px;">&times;</button>`;
        medList.appendChild(chip);
    });
    medsHidden.value = medications.join('\n');
}

addMedBtn?.addEventListener('click', ()=> {
    const v = medInput.value.trim();
    if (!v) return alert('Enter a medication description before adding.');
    medications.push(v);
    medInput.value = '';
    renderMedList();
});

medList?.addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    const idx = Number(btn.dataset.idx);
    if (!Number.isNaN(idx)) {
        medications.splice(idx,1);
        renderMedList();
    }
});

/* Form actions */
const form = document.getElementById('create-prescription-form');
document.getElementById('consultationDate').value = new Date().toISOString().split('T')[0];

document.getElementById('clearFormBtn')?.addEventListener('click', (e) => {
    e.preventDefault();
    if (!confirm('Clear the form?')) return;
    form.reset();
    medications = [];
    renderMedList();
    document.getElementById('consultationDate').value = new Date().toISOString().split('T')[0];
});

function collectFormData(){
    return {
        patientName: document.getElementById('patientName').value.trim(),
        dob: document.getElementById('dob').value,
        patientID: document.getElementById('patientID').value.trim(),
        consultationDate: document.getElementById('consultationDate').value,
        diagnosis: document.getElementById('diagnosis').value.trim(),
        allergies: document.getElementById('allergies').value.trim(),
        medications: medications.join('\n'),
        notes: document.getElementById('notes').value.trim(),
        refillsAuthorized: document.getElementById('refillsAuthorized').value
    };
}

function validate(data){
    if (!data.patientName) return 'Patient name is required.';
    if (!data.dob) return 'Date of birth is required.';
    if (!data.patientID) return 'Patient ID is required.';
    if (!data.consultationDate) return 'Consultation date is required.';
    if (!data.diagnosis) return 'Diagnosis is required.';
    if (!data.medications) return 'At least one medication required.';
    return null;
}

function submitPrescription(action = 'create'){
    const data = collectFormData();
    const v = validate(data);
    if (v) { alert(v); return; }

    const isDraft = (action === 'draft');
    const toSend = (action === 'send');

    const parts = [];
    for (const k in data) parts.push(encodeURIComponent(k)+'='+encodeURIComponent(data[k]));
    parts.push('draft=' + (isDraft ? '1' : '0'));
    parts.push('send=' + (toSend ? '1' : '0'));
    const body = parts.join('&');

    fetch('add_prescription.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body
    })
    .then(async (res) => {
        const text = await res.text();
        if (!res.ok) {
            console.error('add_prescription.php responded with status', res.status, text);
            alert('Server error while saving prescription. See console for details.');
            return;
        }
        try {
            const json = JSON.parse(text);
            if (json.success) {
                alert('Prescription ' + (toSend ? 'sent' : (isDraft ? 'saved as draft' : 'created')));
                location.reload();
            } else {
                alert('Error: ' + (json.message || JSON.stringify(json)));
            }
        } catch (err) {
            // backend returned plain text - show as success message and reload
            alert(text || 'Saved (response not JSON).');
            location.reload();
        }
    })
    .catch((err) => {
        console.error('Network error when posting prescription:', err);
        alert('Network error: failed to submit prescription. Check connection and server.');
    });
}

document.getElementById('saveDraftBtn')?.addEventListener('click', (e) => { e.preventDefault(); if (!confirm('Save draft?')) return; submitPrescription('draft'); });
document.getElementById('createDraftBtn')?.addEventListener('click', (e) => { e.preventDefault(); submitPrescription('create'); });
document.getElementById('sendPatientBtn')?.addEventListener('click', (e) => { e.preventDefault(); if (!confirm('Create and send to patient now?')) return; submitPrescription('send'); });

/* --- Existing prescriptions: view/edit/send --- */

/* View prescription with improved error/debug messages */
document.addEventListener('click', (e) => {
    const btn = e.target.closest('.view-prescription');
    if (!btn) return;
    const id = btn.dataset.id;
    if (!id) return alert('No prescription ID found');

    fetch(`get_prescription.php?id=${encodeURIComponent(id)}`, { method: 'GET' })
        .then(async (res) => {
            const text = await res.text(); // always read text for debugging
            if (!res.ok) {
                console.error('get_prescription.php error', res.status, text);
                const excerpt = text ? (text.length > 500 ? text.substring(0,500) + '...' : text) : 'No response body';
                alert(`Failed to fetch prescription (HTTP ${res.status}). Server said: ${excerpt}\nCheck browser console for more details.`);
                return;
            }

            // success: server may return HTML or JSON; render appropriately
            try {
                const parsed = JSON.parse(text);
                if (parsed.html) {
                    document.getElementById('viewModalBody').innerHTML = parsed.html;
                } else {
                    document.getElementById('viewModalBody').innerHTML = '<pre style="white-space:pre-wrap;">' + escapeHtml(JSON.stringify(parsed, null, 2)) + '</pre>';
                }
            } catch (err) {
                // Not JSON -> assume HTML
                document.getElementById('viewModalBody').innerHTML = text;
            }

            document.getElementById('viewModal').style.display = 'block';
        })
        .catch((err) => {
            console.error('Network error fetching prescription:', err);
            alert('Network error: failed to fetch prescription. Check server availability and browser console for details.');
        });
});

document.getElementById('closeView')?.addEventListener('click', ()=> document.getElementById('viewModal').style.display = 'none');

/* Edit flow */
document.addEventListener('click', (e) => {
    const btn = e.target.closest('.edit-prescription');
    if (!btn) return;
    const id = btn.dataset.id;
    fetch(`get_prescription.php?id=${encodeURIComponent(id)}&edit=1`)
        .then(async (res) => {
            if (!res.ok) {
                const txt = await res.text();
                console.error('get_prescription.php (edit) error', res.status, txt);
                alert('Failed to load edit data. See console.');
                return;
            }
            return res.json();
        })
        .then(data => {
            if (!data) return;
            document.getElementById('edit-prescription-id').value = data.prescriptionID || id;
            document.getElementById('edit-diagnosis').value = data.diagnosis || '';
            document.getElementById('edit-medications').value = data.medication || '';
            document.getElementById('edit-notes').value = data.notes || '';
            document.getElementById('editModal').style.display = 'block';
        })
        .catch(err => { console.error(err); alert('Failed to load edit data.'); });
});

document.getElementById('closeEdit')?.addEventListener('click', ()=> document.getElementById('editModal').style.display = 'none');
document.getElementById('cancelEdit')?.addEventListener('click', ()=> document.getElementById('editModal').style.display = 'none');

document.getElementById('saveEdit')?.addEventListener('click', () => {
    const id = document.getElementById('edit-prescription-id').value;
    const diagnosis = document.getElementById('edit-diagnosis').value.trim();
    const medication = document.getElementById('edit-medications').value.trim();
    const notes = document.getElementById('edit-notes').value.trim();

    fetch('update_prescription.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `id=${encodeURIComponent(id)}&diagnosis=${encodeURIComponent(diagnosis)}&medication=${encodeURIComponent(medication)}&notes=${encodeURIComponent(notes)}`
    })
    .then(async (res) => {
        const txt = await res.text();
        if (!res.ok) {
            console.error('update_prescription.php error', res.status, txt);
            alert('Failed to save changes. See console for details.');
            return;
        }
        alert(txt);
        location.reload();
    })
    .catch(err => { console.error(err); alert('Failed to save changes.'); });
});

/* Send from list */
document.addEventListener('click', (e) => {
    const btn = e.target.closest('.send-prescription');
    if (!btn) return;
    const id = btn.dataset.id;
    if (!confirm('Send this prescription to the patient?')) return;
    fetch('send_prescription.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `id=${encodeURIComponent(id)}`
    })
    .then(async (res) => {
        const text = await res.text();
        if (!res.ok) {
            console.error('send_prescription.php error', res.status, text);
            alert('Failed to send. See console for details.');
            return;
        }
        try {
            const json = JSON.parse(text);
            if (json.success) {
                alert('Prescription sent');
                location.reload();
            } else {
                alert('Failed: ' + (json.message || text));
            }
        } catch (err) {
            alert(text || 'Sent (no JSON response).');
            location.reload();
        }
    })
    .catch(err => { console.error('Network error sending prescription:', err); alert('Failed to send prescription.'); });
});

/* Close modals by clicking overlay */
[...document.querySelectorAll('.modal')].forEach(m => {
    m.addEventListener('click', (ev) => {
        if (ev.target === m) m.style.display = 'none';
    });
});

/* Responsive behaviour: ensure mobile drawer closes on resize to desktop */
window.addEventListener('resize', () => {
    if (window.innerWidth > 900) sidebar.classList.remove('open');
});
</script>
</body>
</html>
