<?php
session_start();
include '../db_connect.php';
header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    echo json_encode(['error' => 'Not authenticated as doctor']);
    exit();
}

try {
    $userID = intval($_SESSION['userID']);
    $doctorID = 0;
    
    // Use prepared statement for security
    $stmt = $conn->prepare("SELECT doctorID FROM Doctor WHERE userID = ? LIMIT 1");
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $doctorID = intval($row['doctorID']);
    } else {
        echo json_encode(['error' => 'Doctor profile not found']);
        exit();
    }
    $stmt->close();

    // Get appointments with prepared statement
    $sql = "SELECT a.appointmentID, a.appointmentDate, a.appointmentTime, a.status, 
                s.serviceName, 
                p.patientID,
                u.firstName AS patientFirstName, u.lastName AS patientLastName
            FROM Appointments a
            JOIN Patient p ON a.patientID = p.patientID
            JOIN User u ON p.userID = u.userID
            LEFT JOIN MedicalService s ON a.serviceID = s.serviceID
            WHERE a.doctorID = ?
            ORDER BY a.appointmentDate DESC, a.appointmentTime DESC";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("i", $doctorID);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $appointments = [];
    while ($row = $result->fetch_assoc()) {
        $appointments[] = $row;
    }
    
    echo json_encode($appointments);
    $stmt->close();
    
} catch (Exception $e) {
    error_log("Appointments fetch error: " . $e->getMessage());
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>