<?php
session_start();
include '../db_connect.php';

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    echo json_encode([]);
    exit();
}

$doctorID = $_SESSION['doctorID'] ?? null;
if (!$doctorID) {
    echo json_encode([]);
    exit();
}

$stmt = $conn->prepare("
    SELECT a.appointmentDate, a.appointmentTime, s.serviceName,
           u.firstName AS patientFirstName, u.lastName AS patientLastName
    FROM Appointments a
    JOIN Patient p ON a.patientID = p.patientID
    JOIN User u ON p.userID = u.userID
    LEFT JOIN Services s ON a.serviceID = s.serviceID
    WHERE a.doctorID = ? AND a.status = 'confirmed'
    ORDER BY a.appointmentDate, a.appointmentTime
");
$stmt->bind_param("i", $doctorID);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode($data);
