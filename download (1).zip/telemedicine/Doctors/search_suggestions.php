<?php
// filepath: c:\xampp Files\htdocs\FINAL YEAR END PROJECT\search_suggestions.php
session_start();
include '../db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    echo json_encode([]);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$searchTerm = $input['searchTerm'] ?? '';
$doctorUserID = $_SESSION['userID'];

// Get doctor ID
$doctorQuery = $conn->prepare("SELECT doctorID FROM Doctor WHERE userID = ?");
$doctorQuery->bind_param("i", $doctorUserID);
$doctorQuery->execute();
$doctor = $doctorQuery->get_result()->fetch_assoc();
$doctorQuery->close();

$suggestions = [];

if (!empty($searchTerm) && strlen($searchTerm) >= 2) {
    // Get patient suggestions
    $patientQuery = $conn->prepare("
        SELECT DISTINCT CONCAT(u.firstName, ' ', u.lastName) as name
        FROM Patient p
        JOIN User u ON p.userID = u.userID
        JOIN Appointments a ON p.patientID = a.patientID
        WHERE a.doctorID = ? AND (
            u.firstName LIKE ? OR 
            u.lastName LIKE ? OR
            CONCAT(u.firstName, ' ', u.lastName) LIKE ?
        )
        LIMIT 5
    ");
    $searchPattern = "%$searchTerm%";
    $patientQuery->bind_param("isss", $doctor['doctorID'], $searchPattern, $searchPattern, $searchPattern);
    $patientQuery->execute();
    $patients = $patientQuery->get_result()->fetch_all(MYSQLI_ASSOC);
    $patientQuery->close();
    
    foreach ($patients as $patient) {
        $suggestions[] = ['text' => $patient['name'], 'type' => 'patient'];
    }
}

echo json_encode($suggestions);
?>