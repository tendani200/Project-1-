<?php
session_start();
require_once '../db_connect.php';

// Check if doctor is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    header('Location: login.php');
    exit();
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "Prescription ID required";
    exit();
}

$prescriptionID = (int) $_GET['id'];
$doctorUserID = $_SESSION['userID'];

// Get doctor ID
$doctorQuery = $conn->prepare("SELECT doctorID FROM Doctor WHERE userID = ?");
$doctorQuery->bind_param("i", $doctorUserID);
$doctorQuery->execute();
$doctorResult = $doctorQuery->get_result();
$doctorData = $doctorResult->fetch_assoc();
$doctorQuery->close();

if (!$doctorData) {
    echo "Doctor not found";
    exit();
}

$doctorID = $doctorData['doctorID'];

try {
    // Get prescription details with security check
    $prescriptionQuery = $conn->prepare("
        SELECT p.*, 
               u.firstName as patientFirstName, u.lastName as patientLastName,
               d.firstName as doctorFirstName, d.lastName as doctorLastName,
               mr.diagnosis, mr.symptoms, mr.treatment, mr.recordDate
        FROM Prescriptions p
        JOIN Patient pt ON p.aptientID = pt.patientID
        JOIN User u ON pt.userID = u.userID
        JOIN Doctor doc ON p.doctorID = doc.doctorID
        JOIN User d ON doc.userID = d.userID
        LEFT JOIN MedicalRecord mr ON p.recordID = mr.recordID
        WHERE p.prescriptionID = ? AND p.doctorID = ?
    ");
    
    $prescriptionQuery->bind_param("ii", $prescriptionID, $doctorID);
    $prescriptionQuery->execute();
    $result = $prescriptionQuery->get_result();
    $prescription = $result->fetch_assoc();
    $prescriptionQuery->close();
    
    if (!$prescription) {
        echo "Prescription not found or access denied";
        exit();
    }
    
} catch (Exception $e) {
    echo "Error retrieving prescription: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Prescription - <?= $prescriptionID ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f8fafc;
            line-height: 1.6;
        }
        .container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        .header h1 {
            margin: 0 0 10px 0;
            font-size: 2.5em;
        }
        .header p {
            margin: 5px 0;
            opacity: 0.9;
        }
        .content {
            padding: 30px;
        }
        .info-section {
            margin-bottom: 30px;
        }
        .info-section h3 {
            color: #4a5568;
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 8px;
            margin-bottom: 15px;
            font-size: 1.3em;
        }
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        .info-item {
            background: #f7fafc;
            padding: 15px;
            border-radius: 8px;
            border-left: 4px solid #4299e1;
        }
        .info-item label {
            font-weight: bold;
            color: #2d3748;
            display: block;
            margin-bottom: 5px;
        }
        .info-item .value {
            color: #4a5568;
            font-size: 1.1em;
        }
        .medication-highlight {
            background: linear-gradient(135deg, #fed7d7 0%, #feb2b2 100%);
            border-left-color: #e53e3e;
            font-size: 1.2em;
        }
        .full-width {
            grid-column: 1 / -1;
        }
        .actions {
            background: #f7fafc;
            padding: 20px;
            border-top: 1px solid #e2e8f0;
            text-align: center;
        }
        .btn {
            background: #4299e1;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            text-decoration: none;
            display: inline-block;
            margin: 0 10px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .btn:hover {
            background: #3182ce;
        }
        .btn-download {
            background: #48bb78;
        }
        .btn-download:hover {
            background: #38a169;
        }
        .btn-close {
            background: #718096;
        }
        .btn-close:hover {
            background: #4a5568;
        }
        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: bold;
            text-transform: uppercase;
        }
        .status-ready {
            background: #c6f6d5;
            color: #22543d;
        }
        .status-active {
            background: #bee3f8;
            color: #2a4365;
        }
        .diagnosis-box {
            background: #e6fffa;
            border: 1px solid #81e6d9;
            border-radius: 8px;
            padding: 20px;
            margin: 15px 0;
        }
        @media (max-width: 768px) {
            .info-grid {
                grid-template-columns: 1fr;
            }
            .actions {
                text-align: center;
            }
            .btn {
                display: block;
                margin: 10px auto;
                width: 200px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fa fa-prescription-bottle"></i> Prescription Details</h1>
            <p>Prescription ID: <?= $prescription['prescriptionID'] ?></p>
            <p>Date Issued: <?= date('F j, Y', strtotime($prescription['prescribdDate'])) ?></p>
        </div>
        
        <div class="content">
            <div class="info-section">
                <h3><i class="fa fa-user"></i> Patient Information</h3>
                <div class="info-grid">
                    <div class="info-item">
                        <label>Patient Name</label>
                        <div class="value"><?= htmlspecialchars($prescription['patientFirstName'] . ' ' . $prescription['patientLastName']) ?></div>
                    </div>
                    <div class="info-item">
                        <label>Patient ID</label>
                        <div class="value"><?= $prescription['aptientID'] ?></div>
                    </div>
                </div>
            </div>
            
            <div class="info-section">
                <h3><i class="fa fa-pills"></i> Prescription Details</h3>
                <div class="info-grid">
                    <div class="info-item medication-highlight full-width">
                        <label>Medication</label>
                        <div class="value"><?= htmlspecialchars($prescription['medication']) ?></div>
                    </div>
                    <div class="info-item">
                        <label>Dosage</label>
                        <div class="value"><?= htmlspecialchars($prescription['dosage']) ?></div>
                    </div>
                    <div class="info-item">
                        <label>Status</label>
                        <div class="value">
                            <span class="status-badge status-<?= $prescription['status'] ?>">
                                <?= ucfirst($prescription['status']) ?>
                            </span>
                        </div>
                    </div>
                    <div class="info-item full-width">
                        <label>Instructions</label>
                        <div class="value"><?= nl2br(htmlspecialchars($prescription['instructions'])) ?></div>
                    </div>
                </div>
            </div>
            
            <?php if (!empty($prescription['diagnosis']) || !empty($prescription['symptoms']) || !empty($prescription['treatment'])): ?>
            <div class="info-section">
                <h3><i class="fa fa-stethoscope"></i> Medical Information</h3>
                <?php if (!empty($prescription['diagnosis'])): ?>
                <div class="diagnosis-box">
                    <label><strong>Diagnosis:</strong></label>
                    <p><?= htmlspecialchars($prescription['diagnosis']) ?></p>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($prescription['symptoms']) || !empty($prescription['treatment'])): ?>
                <div class="info-grid">
                    <?php if (!empty($prescription['symptoms'])): ?>
                    <div class="info-item">
                        <label>Symptoms</label>
                        <div class="value"><?= nl2br(htmlspecialchars($prescription['symptoms'])) ?></div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($prescription['treatment'])): ?>
                    <div class="info-item">
                        <label>Treatment</label>
                        <div class="value"><?= nl2br(htmlspecialchars($prescription['treatment'])) ?></div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            
            <div class="info-section">
                <h3><i class="fa fa-user-md"></i> Prescribing Doctor</h3>
                <div class="info-grid">
                    <div class="info-item">
                        <label>Doctor Name</label>
                        <div class="value">Dr. <?= htmlspecialchars($prescription['doctorFirstName'] . ' ' . $prescription['doctorLastName']) ?></div>
                    </div>
                    <div class="info-item">
                        <label>Doctor ID</label>
                        <div class="value"><?= $prescription['doctorID'] ?></div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="actions">
            <a href="download_prescription.php?id=<?= $prescriptionID ?>" class="btn btn-download">
                <i class="fa fa-download"></i> Download PDF
            </a>
            <button onclick="window.print()" class="btn">
                <i class="fa fa-print"></i> Print
            </button>
            <button onclick="window.close()" class="btn btn-close">
                <i class="fa fa-times"></i> Close
            </button>
        </div>
    </div>
</body>
</html>

<?php $conn->close(); ?>