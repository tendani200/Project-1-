<?php

session_start();
if (!isset($_GET['appointmentID'])) {
    die("Invalid appointment.");
}
$room = "dokotela_appointment_" . intval($_GET['appointmentID']);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Online Consultation</title>
    <style>body,html{height:100%;margin:0;padding:0;}</style>
</head>
<body>
    <h2 style="text-align:center;">Online Consultation</h2>
    <div id="jitsi-container" style="width: 100vw; height: 80vh;"></div>
    <script src='https://meet.jit.si/external_api.js'></script>
    <script>
        const domain = "meet.jit.si";
        const options = {
            roomName: "<?= $room ?>",
            width: "100%",
            height: 600,
            parentNode: document.getElementById('jitsi-container'),
            interfaceConfigOverwrite: { DEFAULT_REMOTE_DISPLAY_NAME: 'Guest' }
        };
        const api = new JitsiMeetExternalAPI(domain, options);
    </script>
</body>
</html>