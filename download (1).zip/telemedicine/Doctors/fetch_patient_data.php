<?php
include '../db_connect.php';


$patientID = 291103; 

$sql = "SELECT userID, firstName, lastName, email, avatar 
        FROM User 
        WHERE userID = ? AND role='patient'";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patientID);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows > 0){
    $patient = $result->fetch_assoc();
    echo json_encode([
        "name" => $patient['firstName'] . " " . $patient['lastName'],
        "avatar" => $patient['avatar'] ?: "assets/default-avatar.png",
        "email" => $patient['email']
    ]);
}else{
    echo json_encode(["error" => "Patient not found"]);
}
?>
