<?php
session_start();
include 'db_connect.php';

echo "<h2>Database Debug - Doctor Data Check</h2>";

// Check session
echo "<h3>Session Info:</h3>";
echo "UserID: " . ($_SESSION['userID'] ?? 'NOT SET') . "<br>";
echo "UserType: " . ($_SESSION['userType'] ?? 'NOT SET') . "<br>";

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    echo "<p style='color: red;'>❌ Please log in as a doctor first</p>";
    echo "<p><a href='login.php'>Login here</a></p>";
    exit();
}

$doctorUserID = $_SESSION['userID'];

// Get doctor ID
$doctorQuery = $conn->prepare("SELECT doctorID FROM Doctor WHERE userID = ?");
$doctorQuery->bind_param("i", $doctorUserID);
$doctorQuery->execute();
$doctor = $doctorQuery->get_result()->fetch_assoc();
$doctorQuery->close();

if (!$doctor) {
    echo "<p style='color: red;'>❌ Doctor not found</p>";
    exit();
}

echo "<h3>Doctor Info:</h3>";
echo "Doctor ID: " . $doctor['doctorID'] . "<br>";

// Check appointments for this doctor
$appointmentQuery = $conn->prepare("
    SELECT a.appointmentID, a.appointmentDate, a.appointmentTime, a.patientID, a.status,
           u.firstName AS patientFirstName, u.lastName AS patientLastName, u.email
    FROM Appointments a
    JOIN Patient p ON a.patientID = p.patientID
    JOIN User u ON p.userID = u.userID
    WHERE a.doctorID = ?
    ORDER BY a.appointmentDate DESC
    LIMIT 10
");
$appointmentQuery->bind_param("i", $doctor['doctorID']);
$appointmentQuery->execute();
$appointments = $appointmentQuery->get_result()->fetch_all(MYSQLI_ASSOC);
$appointmentQuery->close();

echo "<h3>Appointments for this Doctor:</h3>";
if (count($appointments) > 0) {
    echo "<p style='color: green;'>✅ Found " . count($appointments) . " appointments</p>";
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>ID</th><th>Date</th><th>Time</th><th>Patient Name</th><th>Email</th><th>Status</th></tr>";
    foreach ($appointments as $apt) {
        echo "<tr>";
        echo "<td>" . $apt['appointmentID'] . "</td>";
        echo "<td>" . $apt['appointmentDate'] . "</td>";
        echo "<td>" . $apt['appointmentTime'] . "</td>";
        echo "<td>" . $apt['patientFirstName'] . " " . $apt['patientLastName'] . "</td>";
        echo "<td>" . $apt['email'] . "</td>";
        echo "<td>" . $apt['status'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>❌ No appointments found for this doctor</p>";
    
    // Check if there are any appointments at all
    $allApptsQuery = $conn->query("SELECT COUNT(*) as total FROM Appointments");
    $totalApts = $allApptsQuery->fetch_assoc()['total'];
    echo "<p>Total appointments in database: " . $totalApts . "</p>";
    
    // Check if there are any patients
    $allPatientsQuery = $conn->query("SELECT COUNT(*) as total FROM Patient");
    $totalPatients = $allPatientsQuery->fetch_assoc()['total'];
    echo "<p>Total patients in database: " . $totalPatients . "</p>";
}

// Test search functionality
echo "<h3>Test Search:</h3>";
echo '<form method="GET" style="margin: 1rem 0;">
    <input type="text" name="search" placeholder="Enter search term (e.g., patient name)" value="' . ($_GET['search'] ?? '') . '" style="padding: 0.5rem; width: 200px;">
    <button type="submit" style="padding: 0.5rem;">Search</button>
</form>';

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchTerm = $_GET['search'];
    $searchPattern = "%$searchTerm%";
    
    echo "<h4>Search Results for: '$searchTerm'</h4>";
    
    // Search patients
    $patientQuery = $conn->prepare("
        SELECT DISTINCT p.patientID, u.firstName, u.lastName, u.email
        FROM Patient p
        JOIN User u ON p.userID = u.userID
        JOIN Appointments a ON p.patientID = a.patientID
        WHERE a.doctorID = ? AND (
            u.firstName LIKE ? OR 
            u.lastName LIKE ? OR 
            u.email LIKE ? OR
            CONCAT(u.firstName, ' ', u.lastName) LIKE ?
        )
        LIMIT 10
    ");
    $patientQuery->bind_param("issss", $doctor['doctorID'], $searchPattern, $searchPattern, $searchPattern, $searchPattern);
    $patientQuery->execute();
    $searchResults = $patientQuery->get_result()->fetch_all(MYSQLI_ASSOC);
    $patientQuery->close();
    
    if (count($searchResults) > 0) {
        echo "<p style='color: green;'>✅ Found " . count($searchResults) . " patients matching '$searchTerm'</p>";
        echo "<ul>";
        foreach ($searchResults as $patient) {
            echo "<li>" . $patient['firstName'] . " " . $patient['lastName'] . " (" . $patient['email'] . ")</li>";
        }
        echo "</ul>";
    } else {
        echo "<p style='color: orange;'>⚠️ No patients found matching '$searchTerm'</p>";
        
        // Try a broader search without the doctor filter
        $broadQuery = $conn->prepare("
            SELECT DISTINCT u.firstName, u.lastName, u.email
            FROM Patient p
            JOIN User u ON p.userID = u.userID
            WHERE u.firstName LIKE ? OR u.lastName LIKE ? OR u.email LIKE ?
            LIMIT 5
        ");
        $broadQuery->bind_param("sss", $searchPattern, $searchPattern, $searchPattern);
        $broadQuery->execute();
        $broadResults = $broadQuery->get_result()->fetch_all(MYSQLI_ASSOC);
        $broadQuery->close();
        
        if (count($broadResults) > 0) {
            echo "<p>But found these patients in the system (not assigned to your appointments):</p>";
            echo "<ul>";
            foreach ($broadResults as $patient) {
                echo "<li>" . $patient['firstName'] . " " . $patient['lastName'] . " (" . $patient['email'] . ")</li>";
            }
            echo "</ul>";
        }
    }
}
?>