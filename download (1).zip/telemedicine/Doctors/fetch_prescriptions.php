<?php
session_start();
include '../db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Patient') {
    echo json_encode([]);
    exit();
}

$patientID = intval($_SESSION['patientID'] ?? 0);

$result = $conn->query("SELECT prescriptionID, medication AS name, status, prescribedDate AS date
    FROM prescriptions
    WHERE patientID = $patientID
    ORDER BY prescribedDate DESC");

$prescriptions = [];
while ($row = $result->fetch_assoc()) {
    $prescriptions[] = $row;
}
echo json_encode($prescriptions);
?>