<?php
session_start();
header('Content-Type: application/json');
require_once '../db_connect.php';


$input = json_decode(file_get_contents('php://input'), true) ?: $_REQUEST;
$action = $input['action'] ?? 'list';


$response = ['success' => false, 'prescriptions' => []];


if (!isset($_SESSION['userID'])) {
echo json_encode($response); exit;
}


$userID = (int) $_SESSION['userID'];
$userType = $_SESSION['userType'] ?? '';


if ($action === 'list_for_doctor' && $userType === 'Doctor') {
$stmt = $conn->prepare("SELECT p.prescriptionID, p.medication, p.dosage, p.prescribedDate, p.status, CONCAT(u.firstName,' ',u.lastName) AS patientName FROM Prescription p JOIN User u ON p.patientID = u.userID WHERE p.doctorID = ? ORDER BY p.prescribedDate DESC LIMIT 50");
$stmt->bind_param('i', $userID);
$stmt->execute();
$res = $stmt->get_result();
$rows = [];
while ($r = $res->fetch_assoc()) {
$rows[] = $r;
}
$stmt->close();
$response['success'] = true;
$response['prescriptions'] = $rows;
}


if ($action === 'list_for_patient' && $userType === 'Patient') {
$stmt = $conn->prepare("SELECT p.prescriptionID, p.medication, p.dosage, p.prescribedDate, p.status, CONCAT(d.firstName,' ',d.lastName) AS doctorName FROM Prescription p JOIN Doctor d ON p.doctorID = d.userID WHERE p.patientID = ? ORDER BY p.prescribedDate DESC LIMIT 50");
$stmt->bind_param('i', $userID);
$stmt->execute();
$res = $stmt->get_result();
$rows = [];
while ($r = $res->fetch_assoc()) {
$rows[] = $r;
}
$stmt->close();
$response['success'] = true;
$response['prescriptions'] = $rows;
}


echo json_encode($response);
exit;