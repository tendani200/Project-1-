<?php
session_start();
include '../db_connect.php';
header('Content-Type: application/json');

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    echo json_encode([]);
    exit();
}

$userID = intval($_SESSION['userID']);

// Get doctor ID
$doctorQuery = $conn->prepare("SELECT doctorID FROM Doctor WHERE userID = ?");
$doctorQuery->bind_param("i", $userID);
$doctorQuery->execute();
$doctorResult = $doctorQuery->get_result();
$doctor = $doctorResult->fetch_assoc();
$doctorQuery->close();

if (!$doctor) {
    echo json_encode([]);
    exit();
}

$doctorID = $doctor['doctorID'];

// Fetch pending/scheduled appointments
$sql = "SELECT a.appointmentID, a.appointmentDate, a.appointmentTime, a.status,
               u.firstName AS patientFirstName, u.lastName AS patientLastName
        FROM Appointments a
        JOIN Patient p ON a.patientID = p.patientID
        JOIN User u ON p.userID = u.userID
        WHERE a.doctorID = ? AND (a.status = 'pending' OR a.status = 'scheduled') 
        AND a.appointmentDate >= CURDATE()
        ORDER BY a.appointmentDate ASC, a.appointmentTime ASC";

$result = $conn->query("PREPARE stmt FROM '$sql'");
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $doctorID);
$stmt->execute();
$result = $stmt->get_result();

$tasks = [];
while ($row = $result->fetch_assoc()) {
    $tasks[] = $row;
}

echo json_encode($tasks);
?>