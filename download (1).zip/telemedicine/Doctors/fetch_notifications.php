<?php
session_start();
include '../db_connect.php';

// Check if user is logged in and is a doctor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'doctor') {
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

$userID = $_SESSION['user_id'];
$res = $conn->query("SELECT doctorID FROM Doctor WHERE userID = $userID LIMIT 1");
$doctorID = intval($row['doctorID']);

$filter = $_GET['filter'] ?? 'all';

// Since notifications table may not exist yet, provide sample data
$notifications = [
    [
        'id' => 1,
        'type' => 'urgent',
        'title' => 'Critical Lab Result',
        'message' => 'Patient Josh Makoana has abnormal blood work requiring immediate attention.',
        'priority' => 'high',
        'is_read' => 0,
        'created_at' => date('Y-m-d H:i:s', strtotime('-2 hours')),
        'patient_name' => 'Josh Makoana'
    ],
    [
        'id' => 2,
        'type' => 'appointment',
        'title' => 'Appointment Reminder',
        'message' => 'Upcoming appointment with Tendani Makhera in 30 minutes.',
        'priority' => 'medium',
        'is_read' => 0,
        'created_at' => date('Y-m-d H:i:s', strtotime('-1 hour')),
        'patient_name' => 'Tendani Makhera'
    ],
    [
        'id' => 3,
        'type' => 'message',
        'title' => 'New Patient Message',
        'message' => 'PP MAKOANA sent you a message about medication side effects.',
        'priority' => 'medium',
        'is_read' => 1,
        'created_at' => date('Y-m-d H:i:s', strtotime('-3 hours')),
        'patient_name' => 'PP MAKOANA'
    ],
    [
        'id' => 4,
        'type' => 'lab',
        'title' => 'Lab Results Available',
        'message' => 'Blood test results are ready for John Smith.',
        'priority' => 'low',
        'is_read' => 1,
        'created_at' => date('Y-m-d H:i:s', strtotime('-1 day')),
        'patient_name' => 'John Smith'
    ],
    [
        'id' => 5,
        'type' => 'appointment',
        'title' => 'Cancelled Appointment',
        'message' => 'Patient Mary Johnson cancelled appointment for tomorrow.',
        'priority' => 'low',
        'is_read' => 1,
        'created_at' => date('Y-m-d H:i:s', strtotime('-2 days')),
        'patient_name' => 'Mary Johnson'
    ]
];

// Filter notifications if needed
if ($filter !== 'all') {
    $notifications = array_filter($notifications, function($notification) use ($filter) {
        return $notification['type'] === $filter;
    });
    $notifications = array_values($notifications); // Re-index array
}

// Count unread notifications
$unreadCount = count(array_filter($notifications, function($notification) {
    return $notification['is_read'] == 0;
}));

echo json_encode([
    'success' => true,
    'notifications' => $notifications,
    'unread_count' => $unreadCount
]);
?>