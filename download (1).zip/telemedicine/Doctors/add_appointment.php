<?php
session_start();
include 'db_connect.php';
header('Content-Type: application/json');

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

$doctorUserID = $_SESSION['userID'];

// Get doctor ID
$doctorQuery = $conn->prepare("SELECT doctorID FROM Doctor WHERE userID = ?");
$doctorQuery->bind_param("i", $doctorUserID);
$doctorQuery->execute();
$doctorResult = $doctorQuery->get_result();
$doctor = $doctorResult->fetch_assoc();
$doctorQuery->close();

if (!$doctor) {
    echo json_encode(['success' => false, 'message' => 'Doctor not found']);
    exit();
}

$doctorID = $doctor['doctorID'];

// Get form data
$patientEmail = trim($_POST['patientEmail'] ?? '');
$appointmentDate = $_POST['appointmentDate'] ?? '';
$appointmentTime = $_POST['appointmentTime'] ?? '';
$consultationType = $_POST['consultationType'] ?? 'video';
$notes = trim($_POST['notes'] ?? '');

// Validate inputs
if (empty($patientEmail) || empty($appointmentDate) || empty($appointmentTime)) {
    echo json_encode(['success' => false, 'message' => 'Patient email, date, and time are required']);
    exit();
}

// Validate email format
if (!filter_var($patientEmail, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Please enter a valid email address']);
    exit();
}

// Check if appointment date is not in the past
if (strtotime($appointmentDate) < strtotime(date('Y-m-d'))) {
    echo json_encode(['success' => false, 'message' => 'Appointment date cannot be in the past']);
    exit();
}

// Find patient by email
$patientQuery = $conn->prepare("
    SELECT p.patientID, u.firstName, u.lastName 
    FROM Patient p 
    JOIN User u ON p.userID = u.userID 
    WHERE u.email = ?
");
$patientQuery->bind_param("s", $patientEmail);
$patientQuery->execute();
$patientResult = $patientQuery->get_result();
$patient = $patientResult->fetch_assoc();
$patientQuery->close();

if (!$patient) {
    echo json_encode(['success' => false, 'message' => 'No patient found with email: ' . $patientEmail]);
    exit();
}

// Check for conflicting appointments (same doctor, date, time)
$conflictQuery = $conn->prepare("
    SELECT appointmentID FROM Appointments 
    WHERE doctorID = ? AND appointmentDate = ? AND appointmentTime = ?
");
$conflictQuery->bind_param("iss", $doctorID, $appointmentDate, $appointmentTime);
$conflictQuery->execute();
$conflictResult = $conflictQuery->get_result();
$conflictQuery->close();

if ($conflictResult->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'You already have an appointment at this time']);
    exit();
}

// Insert appointment (without consultationType and notes if columns don't exist)
$insertQuery = $conn->prepare("
    INSERT INTO Appointments (doctorID, patientID, appointmentDate, appointmentTime, status) 
    VALUES (?, ?, ?, ?, 'scheduled')
");
$insertQuery->bind_param("iiss", $doctorID, $patient['patientID'], $appointmentDate, $appointmentTime);

if ($insertQuery->execute()) {
    echo json_encode([
        'success' => true, 
        'message' => 'Appointment scheduled successfully with ' . $patient['firstName'] . ' ' . $patient['lastName']
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to schedule appointment: ' . $conn->error]);
}

$insertQuery->close();
?>
