<?php
session_start();
include '../db_connect.php';
header('Content-Type: application/json');

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    echo json_encode([]);
    exit();
}

$userID = intval($_SESSION['userID']);
$doctorID = 0;
$res = $conn->query("SELECT doctorID FROM Doctor WHERE userID = $userID LIMIT 1");
if ($row = $res->fetch_assoc()) {
    $doctorID = intval($row['doctorID']);
} else {
    echo json_encode([]);
    exit();
}

// Correct join through Patient table
$sql = "SELECT DISTINCT p.patientID, u.userID, u.firstName, u.lastName, u.email
        FROM Appointments a
        JOIN Patient p ON a.patientID = p.patientID
        JOIN User u ON p.userID = u.userID
        WHERE a.doctorID = $doctorID";
$result = $conn->query($sql);

$patients = [];
while ($row = $result->fetch_assoc()) {
    $patients[] = $row;
}
echo json_encode($patients);
?>