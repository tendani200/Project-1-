<?php
// Prevent any output before JSON
ob_start();
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors to output

session_start();

// Clear any buffered output and set JSON header
ob_clean();
header('Content-Type: application/json');

try {
    require_once '../db_connect.php';

    if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
        throw new Exception('Unauthorized');
    }

    if (!isset($_GET['patientID'])) {
        throw new Exception('Patient ID required');
    }

    $patientID = intval($_GET['patientID']);
    $userID = intval($_SESSION['userID']);

    // Get doctor ID
    $doctorQuery = $conn->prepare("SELECT doctorID FROM Doctor WHERE userID = ?");
    if (!$doctorQuery) {
        throw new Exception('Database prepare failed: ' . $conn->error);
    }
    
    $doctorQuery->bind_param("i", $userID);
    $doctorQuery->execute();
    $doctorResult = $doctorQuery->get_result();
    $doctor = $doctorResult->fetch_assoc();
    $doctorQuery->close();

    if (!$doctor) {
        throw new Exception('Doctor not found');
    }

    $doctorID = $doctor['doctorID'];

    // Get patient basic info (only columns that exist)
    $patientQuery = $conn->prepare("
        SELECT p.patientID, u.firstName, u.lastName, u.email,
               p.dateOfBirth, p.gender
        FROM Patient p
        JOIN User u ON p.userID = u.userID
        WHERE p.patientID = ?
    ");
    
    if (!$patientQuery) {
        throw new Exception('Patient query prepare failed: ' . $conn->error);
    }
    
    $patientQuery->bind_param("i", $patientID);
    $patientQuery->execute();
    $patientResult = $patientQuery->get_result();
    $patient = $patientResult->fetch_assoc();
    $patientQuery->close();

    if (!$patient) {
        throw new Exception('Patient not found');
    }

    // Get appointment history with this doctor
    $appointmentsQuery = $conn->prepare("
        SELECT appointmentID, appointmentDate, appointmentTime, status
        FROM Appointments
        WHERE patientID = ? AND doctorID = ?
        ORDER BY appointmentDate DESC, appointmentTime DESC
    ");
    
    if (!$appointmentsQuery) {
        throw new Exception('Appointments query prepare failed: ' . $conn->error);
    }
    
    $appointmentsQuery->bind_param("ii", $patientID, $doctorID);
    $appointmentsQuery->execute();
    $appointmentsResult = $appointmentsQuery->get_result();
    $appointments = [];
    while ($row = $appointmentsResult->fetch_assoc()) {
        $appointments[] = $row;
    }
    $appointmentsQuery->close();

    // Check if MedicalRecord table exists before querying
    $records = [];
    $tableCheck = $conn->query("SHOW TABLES LIKE 'MedicalRecord'");
    if ($tableCheck && $tableCheck->num_rows > 0) {
        // Get medical records with all fields including prescription info
        $recordsQuery = $conn->prepare("
            SELECT mr.recordID, mr.appointmentID, mr.serviceID, mr.diagnosis, mr.symptoms, mr.treatment, mr.notes, mr.recordDate,
                   p.prescriptionID
            FROM MedicalRecord mr
            LEFT JOIN Prescriptions p ON mr.recordID = p.recordID
            WHERE mr.patientID = ? AND mr.doctorID = ?
            ORDER BY mr.recordDate DESC, mr.recordID DESC
        ");
        
        if (!$recordsQuery) {
            throw new Exception('Records query prepare failed: ' . $conn->error);
        }
        
        $recordsQuery->bind_param("ii", $patientID, $doctorID);
        $recordsQuery->execute();
        $recordsResult = $recordsQuery->get_result();
        while ($row = $recordsResult->fetch_assoc()) {
            $records[] = $row;
        }
        $recordsQuery->close();
    }

    // Return all data
    echo json_encode([
        'success' => true,
        'patient' => $patient,
        'appointments' => $appointments,
        'records' => $records
    ]);

} catch (Exception $e) {
    // Log the error for debugging
    error_log("Fetch patient summary error: " . $e->getMessage());
    
    // Return JSON error response
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
} finally {
    if (isset($conn)) {
        $conn->close();
    }
}