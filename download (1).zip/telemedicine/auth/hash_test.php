<?php
echo password_hash("Makgwale@1935", PASSWORD_DEFAULT);
?>
