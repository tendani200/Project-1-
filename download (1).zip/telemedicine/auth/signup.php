<?php
session_start();
include("../db_connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = trim($_POST["firstName"]);
    $lastName  = trim($_POST["lastName"]);
    $email     = trim($_POST["email"]);
    $password  = $_POST["password"];
    $confirmPassword = $_POST["confirmPassword"];
    $phone     = trim($_POST["phone"]);
    $dob       = $_POST["dob"];
    $gender    = $_POST["gender"];
    $address   = trim($_POST["address"]);

    // Check if passwords match
    if ($password !== $confirmPassword) {
        $error = "Passwords do not match.";
    }
    // Check if 18+
    elseif ($age = (int)((time() - strtotime($dob)) / (365.25 * 24 * 60 * 60)) < 18) {
        $error = "You must be at least 18 years old to register.";
    }
    // Strong password validation
    elseif (!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$/", $password)) {
        $error = "Password must be at least 8 characters long, include uppercase, lowercase, number, and special character.";
    } else {
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        // Check if email exists
        $check = $conn->prepare("SELECT * FROM User WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $result = $check->get_result();

        if ($result->num_rows > 0) {
            $error = "Email already registered!";
        } else {
            // Insert user
            $stmt = $conn->prepare("INSERT INTO User (firstName, lastName, email, passwordHash, phone, userType, createdAt) VALUES (?, ?, ?, ?, ?, 'Patient', NOW())");
            $stmt->bind_param("sssss", $firstName, $lastName, $email, $passwordHash, $phone);

            if ($stmt->execute()) {
                $userID = $stmt->insert_id;

                // Insert into Patient table
                $stmt2 = $conn->prepare("INSERT INTO Patient (userID, dateOfBirth, gender, address) VALUES (?, ?, ?, ?)");
                $stmt2->bind_param("isss", $userID, $dob, $gender, $address);
                $stmt2->execute();

                $_SESSION["userID"] = $userID;
                $_SESSION["userType"] = "Patient";
                header("Location: ../patient/patient_dashboard.php");
                exit();
            } else {
                $error = "Error: " . $stmt->error;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Patient Signup - Dokotela Online</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root{
        --blue-1: #0f4d92;
        --blue-2: #1CA9C9;
        --pastel: #E6F6FF;
        --bright-red: #ff2d55;
        --muted: #64748b;
        --bg: #f6fbff;
        --card-bg: rgba(255,255,255,0.75);
        --glass-border: rgba(255,255,255,0.35);
        --shadow: 0 6px 18px rgba(16,24,40,0.08);
        --radius: 12px;
        --glass-blur: 8px;
        --text-dark: #0f1724;
        --text-muted: #475569;
        --gap: 1rem;
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
        background-color: var(--bg);
        color: var(--text-dark);
        overflow-x: hidden;
    }

    /* Navigation Bar */
    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px 40px;
        flex-wrap: wrap;
        position: fixed;
        top: 0;
        width: 100%;
        background-color: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(var(--glass-blur));
        z-index: 1000;
        transition: all 0.3s ease;
        box-shadow: var(--shadow);
        border-bottom: 1px solid var(--glass-border);
    }

    .header-scrolled {
        padding: 10px 40px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    .logo {
        font-size: 24px;
        font-weight: bold;
        color: var(--bright-red);
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .logo img {
        height: 40px;
        width: auto;
        transition: all 0.3s ease;
    }

    .logo:hover img {
        transform: scale(1.05);
    }

    nav {
        display: flex;
        gap: 25px;
        align-items: center;
        flex-wrap: wrap;
    }

    nav a {
        text-decoration: none;
        color: var(--text-dark);
        font-size: 16px;
        transition: all 0.3s ease;
        position: relative;
        font-weight: 500;
    }

    nav a::after {
        content: '';
        position: absolute;
        bottom: -5px;
        left: 0;
        width: 0;
        height: 2px;
        background-color: var(--blue-2);
        transition: width 0.3s ease;
    }

    nav a:hover::after {
        width: 100%;
    }

    .btn-appointment {
        background-color: var(--blue-1);
        color: white;
        padding: 10px 18px;
        border-radius: 25px;
        text-decoration: none;
        font-size: 14px;
        transition: all 0.3s ease;
        box-shadow: 0 4px 8px rgba(15, 77, 146, 0.2);
        font-weight: 600;
    }

    .btn-appointment:hover {
        background-color: var(--blue-2);
        transform: translateY(-2px);
        box-shadow: 0 6px 12px rgba(15, 77, 146, 0.3);
    }

    .login-link {
        font-size: 14px;
        color: var(--text-dark);
        text-decoration: none;
        transition: all 0.3s ease;
        font-weight: 500;
    }

    .login-link:hover {
        color: var(--blue-1);
    }

    .mobile-menu-toggle {
        display: none;
        flex-direction: column;
        cursor: pointer;
        padding: 5px;
    }

    .mobile-menu-toggle span {
        width: 25px;
        height: 3px;
        background-color: var(--text-dark);
        margin: 3px 0;
        transition: 0.3s;
    }

    /* Main Content */
    .main-content {
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 100px 20px 20px;
        position: relative;
        overflow-x: hidden;
    }

    .main-content::before {
        content: '';
        position: absolute;
        width: 300px;
        height: 300px;
        border-radius: 50%;
        background: rgba(90, 90, 240, 0.05);
        top: -150px;
        right: -150px;
        animation: pulse 8s infinite ease-in-out;
        z-index: -1;
    }

    .main-content::after {
        content: '';
        position: absolute;
        width: 200px;
        height: 200px;
        border-radius: 50%;
        background: rgba(230, 57, 70, 0.05);
        bottom: -100px;
        left: -100px;
        animation: pulse 6s infinite ease-in-out;
        z-index: -1;
    }

    @keyframes pulse {
        0%, 100% { transform: scale(1); opacity: 0.7; }
        50% { transform: scale(1.1); opacity: 0.5; }
    }

    .container {
        background-color: var(--card-bg);
        backdrop-filter: blur(var(--glass-blur));
        border-radius: var(--radius);
        box-shadow: var(--shadow);
        padding: 40px;
        width: 100%;
        max-width: 500px;
        border: 1px solid var(--glass-border);
        position: relative;
        overflow: hidden;
        opacity: 0;
        transform: translateY(20px);
        animation: fadeInUp 0.8s forwards 0.3s;
    }

    @keyframes fadeInUp {
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .container::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 5px;
        background: linear-gradient(to right, var(--bright-red), var(--blue-2));
    }

    h2 {
        text-align: center;
        margin-bottom: 30px;
        color: var(--text-dark);
        font-size: 2rem;
        font-weight: 700;
        position: relative;
        padding-bottom: 15px;
    }

    h2::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 60px;
        height: 3px;
        background: linear-gradient(to right, var(--bright-red), var(--blue-2));
        border-radius: 2px;
    }

    .form-group {
        margin-bottom: 20px;
        position: relative;
    }

    .form-row {
        display: flex;
        gap: 15px;
    }

    .form-row .form-group {
        flex: 1;
    }

    input, select, textarea {
        width: 100%;
        padding: 15px 20px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 16px;
        transition: all 0.3s ease;
        background-color: rgba(255, 255, 255, 0.8);
    }

    input:focus, select:focus, textarea:focus {
        outline: none;
        border-color: var(--blue-2);
        box-shadow: 0 0 0 3px rgba(28, 169, 201, 0.2);
        background-color: white;
    }

    .input-icon {
        position: absolute;
        right: 15px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--muted);
    }

    .password-container {
        position: relative;
    }

    .toggle-password {
        position: absolute;
        right: 15px;
        top: 50%;
        transform: translateY(-50%);
        cursor: pointer;
        color: var(--muted);
        z-index: 2;
    }

    button {
        width: 100%;
        padding: 15px;
        background: linear-gradient(to right, var(--blue-1), var(--blue-2));
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        margin-top: 10px;
        box-shadow: 0 4px 10px rgba(15, 77, 146, 0.3);
    }

    button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(15, 77, 146, 0.4);
    }

    .error-message {
        color: var(--bright-red);
        text-align: center;
        margin-bottom: 20px;
        padding: 10px;
        background-color: rgba(255, 45, 85, 0.05);
        border-radius: 6px;
        font-weight: 500;
    }

    .login-link {
        text-align: center;
        margin-top: 25px;
        color: var(--text-muted);
    }

    .login-link a {
        color: var(--blue-1);
        text-decoration: none;
        font-weight: 600;
        transition: all 0.3s ease;
        position: relative;
    }

    .login-link a::after {
        content: '';
        position: absolute;
        bottom: -2px;
        left: 0;
        width: 0;
        height: 2px;
        background-color: var(--blue-1);
        transition: width 0.3s ease;
    }

    .login-link a:hover::after {
        width: 100%;
    }

    .strength-bar {
        height: 6px;
        border-radius: 5px;
        background: #ddd;
        margin-top: 5px;
        overflow: hidden;
        width: 100%;
    }

    .strength-fill {
        height: 100%;
        width: 0%;
        transition: width 0.3s;
        border-radius: 5px;
    }

    .strength-text {
        font-size: 0.9rem;
        margin-top: 5px;
        font-weight: 500;
    }

    .password-requirements {
        font-size: 0.85rem;
        color: var(--text-muted);
        margin-top: 5px;
        line-height: 1.4;
    }

    .match-status {
        font-size: 0.85rem;
        margin-top: 5px;
        font-weight: 500;
    }

    .match-valid {
        color: green;
    }

    .match-invalid {
        color: var(--bright-red);
    }

    /* Responsive styles */
    @media (max-width: 768px) {
        header {
            padding: 15px 20px;
        }

        .mobile-menu-toggle {
            display: flex;
        }

        nav {
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(var(--glass-blur));
            flex-direction: column;
            gap: 0;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transform: translateY(-10px);
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            padding: 20px 0;
        }

        nav.active {
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }

        nav a {
            padding: 15px 40px;
            border-bottom: 1px solid var(--glass-border);
            width: 100%;
            text-align: left;
        }
        
        .main-content {
            padding: 120px 20px 20px;
        }
        
        .container {
            padding: 30px 20px;
        }
        
        .form-row {
            flex-direction: column;
            gap: 0;
        }
    }
  </style>
</head>
<body>
  <!-- Navigation Bar -->
  <header id="header">
    <div class="logo">
        <img src="dokotelalogo.png" alt="Dokotela Online Logo">
    </div>
    <div class="mobile-menu-toggle" onclick="toggleMobileMenu()">
        <span></span>
        <span></span>
        <span></span>
    </div>
    <nav id="nav">
        <a href="../index.php#home">Home</a>
        <a href="../index.php#services">Services</a>
        <a href="../index.php#mission">About</a>
        <a href="../index.php#booking">Booking</a>
        <a href="../index.php#faq">FAQ</a>
        <a href="login.php" class="btn-appointment">Book Appointment</a>
        <a href="login.php" class="login-link">Login</a>
        <a href="signup.php" class="login-link">Sign Up</a>
    </nav>
  </header>

  <!-- Main Content -->
  <div class="main-content">
    <div class="container">
      <h2>Create Your Account</h2>
      
      <?php if (!empty($error)): ?>
        <div class="error-message">
          <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
        </div>
      <?php endif; ?>
      
      <form method="POST" onsubmit="return validateForm()">
        <div class="form-row">
          <div class="form-group">
            <input type="text" name="firstName" placeholder="First Name" required>
            <i class="fas fa-user input-icon"></i>
          </div>
          
          <div class="form-group">
            <input type="text" name="lastName" placeholder="Last Name" required>
            <i class="fas fa-user input-icon"></i>
          </div>
        </div>
        
        <div class="form-group">
          <input type="email" name="email" placeholder="Email Address" required>
          <i class="fas fa-envelope input-icon"></i>
        </div>
        
        <div class="form-group">
          <div class="password-container">
            <input type="password" name="password" id="password" placeholder="Password" required>
            <span class="toggle-password" onclick="togglePassword('password')">
              <i class="fas fa-eye"></i>
            </span>
          </div>
          
          <div class="strength-bar">
            <div id="strengthFill" class="strength-fill"></div>
          </div>
          <div id="strengthText" class="strength-text"></div>
          <div class="password-requirements">
            Password must have 8+ characters, including uppercase, lowercase, number & symbol.
          </div>
        </div>
        
        <div class="form-group">
          <div class="password-container">
            <input type="password" name="confirmPassword" id="confirmPassword" placeholder="Confirm Password" required>
            <span class="toggle-password" onclick="togglePassword('confirmPassword')">
              <i class="fas fa-eye"></i>
            </span>
          </div>
          <div id="passwordMatch" class="match-status"></div>
        </div>
        
        <div class="form-group">
          <input type="text" name="phone" placeholder="Phone Number" required>
          <i class="fas fa-phone input-icon"></i>
        </div>
        
        <div class="form-group">
          <input type="date" name="dob" id="dob" required onkeydown="return false" max="">
          <i class="fas fa-calendar input-icon"></i>
        </div>
        
        <div class="form-group">
          <select name="gender" required>
            <option value="">Select Gender</option>
            <option>Male</option>
            <option>Female</option>
            <option>Other</option>
          </select>
          <i class="fas fa-venus-mars input-icon"></i>
        </div>
        
        <div class="form-group">
          <textarea name="address" placeholder="Address" rows="3" required></textarea>
          <i class="fas fa-home input-icon" style="top: 25px;"></i>
        </div>
        
        <button type="submit">
          <i class="fas fa-user-plus"></i> Create Account
        </button>
      </form>
      
      <div class="login-link">
        <p>Already have an account? <a href="login.php">Login here</a></p>
      </div>
    </div>
  </div>

  <script>
    // Header scroll effect
    window.addEventListener('scroll', function() {
        const header = document.getElementById('header');
        if (window.scrollY > 50) {
            header.classList.add('header-scrolled');
        } else {
            header.classList.remove('header-scrolled');
        }
    });

    // Mobile menu toggle
    function toggleMobileMenu() {
        const nav = document.getElementById('nav');
        nav.classList.toggle('active');
    }

    // Close mobile menu when clicking on a link
    document.querySelectorAll('nav a').forEach(link => {
        link.addEventListener('click', function() {
            const nav = document.getElementById('nav');
            nav.classList.remove('active');
        });
    });

    // prevent future dates and calculate min DOB
    const dobInput = document.getElementById("dob");
    const today = new Date();
    const maxDate = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());
    dobInput.max = maxDate.toISOString().split("T")[0];

    function togglePassword(fieldId) {
      const passwordField = document.getElementById(fieldId);
      const toggleIcon = passwordField.parentNode.querySelector(".toggle-password i");
      if (passwordField.type === "password") {
        passwordField.type = "text";
        toggleIcon.className = "fas fa-eye-slash";
      } else {
        passwordField.type = "password";
        toggleIcon.className = "fas fa-eye";
      }
    }

    function validateForm() {
      const password = document.getElementById("password").value;
      const confirmPassword = document.getElementById("confirmPassword").value;
      const dob = new Date(document.getElementById("dob").value);
      const age = new Date().getFullYear() - dob.getFullYear();
      const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$/;

      if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return false;
      }
      if (!regex.test(password)) {
        alert("Password must be at least 8 characters long, include uppercase, lowercase, number, and special character.");
        return false;
      }
      if (age < 18) {
        alert("You must be at least 18 years old to sign up.");
        return false;
      }
      return true;
    }

    // Password strength meter
    document.getElementById("password").addEventListener("input", function() {
      const password = this.value;
      const strengthFill = document.getElementById("strengthFill");
      const strengthText = document.getElementById("strengthText");
      let strength = 0;

      if (password.match(/[a-z]/)) strength += 1;
      if (password.match(/[A-Z]/)) strength += 1;
      if (password.match(/[0-9]/)) strength += 1;
      if (password.match(/[@$!%*?&#]/)) strength += 1;
      if (password.length >= 8) strength += 1;

      strengthFill.style.width = (strength * 20) + "%";
      if (strength <= 2) {
        strengthFill.style.background = "var(--bright-red)";
        strengthText.textContent = "Weak Password";
        strengthText.style.color = "var(--bright-red)";
      } else if (strength <= 4) {
        strengthFill.style.background = "orange";
        strengthText.textContent = "Medium Password";
        strengthText.style.color = "orange";
      } else {
        strengthFill.style.background = "green";
        strengthText.textContent = "Strong Password";
        strengthText.style.color = "green";
      }
      
      // Check password match
      checkPasswordMatch();
    });

    // Password match checker
    document.getElementById("confirmPassword").addEventListener("input", checkPasswordMatch);
    
    function checkPasswordMatch() {
      const password = document.getElementById("password").value;
      const confirmPassword = document.getElementById("confirmPassword").value;
      const matchStatus = document.getElementById("passwordMatch");
      
      if (confirmPassword === "") {
        matchStatus.textContent = "";
        matchStatus.className = "match-status";
      } else if (password === confirmPassword) {
        matchStatus.textContent = "✓ Passwords match";
        matchStatus.className = "match-status match-valid";
      } else {
        matchStatus.textContent = "✗ Passwords do not match";
        matchStatus.className = "match-status match-invalid";
      }
    }
  </script>
</body>
</html>