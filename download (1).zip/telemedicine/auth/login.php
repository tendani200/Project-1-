<?php
session_start();
include("../db_connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email    = trim($_POST["email"]);
    $password = $_POST["password"];

    $stmt = $conn->prepare("SELECT * FROM User WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user["passwordHash"])) {
            $_SESSION["userID"] = $user["userID"];
            $_SESSION["userType"] = $user["userType"];

            // Redirect by user type
            if ($user["userType"] == "Patient") {
                header("Location: ../patient/patient_dashboard.php");
            } elseif ($user["userType"] == "Doctor") {
                header("Location: ../Doctors/doctor-dashboard.php");
            } elseif ($user["userType"] == "Admin") {
                header("Location: ../admin/admin_dashboard.php");
            } else {
                header("Location: ../index.php");
            }
            exit();
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "User not found.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Dokotela Online</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root{
            --blue-1: #0f4d92;
            --blue-2: #1CA9C9;
            --pastel: #E6F6FF;
            --bright-red: #ff2d55;
            --muted: #64748b;
            --bg: #f6fbff;
            --card-bg: rgba(255,255,255,0.75);
            --glass-border: rgba(255,255,255,0.35);
            --shadow: 0 6px 18px rgba(16,24,40,0.08);
            --radius: 12px;
            --glass-blur: 8px;
            --text-dark: #0f1724;
            --text-muted: #475569;
            --gap: 1rem;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background-color: var(--bg);
            color: var(--text-dark);
            overflow-x: hidden;
        }

        /* Navigation bar */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 40px;
            flex-wrap: wrap;
            position: fixed;
            top: 0;
            width: 100%;
            background-color: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(var(--glass-blur));
            z-index: 1000;
            transition: all 0.3s ease;
            box-shadow: var(--shadow);
            border-bottom: 1px solid var(--glass-border);
        }

        .header-scrolled {
            padding: 10px 40px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: var(--bright-red);
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .logo img {
            height: 40px;
            width: auto;
            transition: all 0.3s ease;
        }

        .logo:hover img {
            transform: scale(1.05);
        }

        nav {
            display: flex;
            gap: 25px;
            align-items: center;
            flex-wrap: wrap;
        }

        nav a {
            text-decoration: none;
            color: var(--text-dark);
            font-size: 16px;
            transition: all 0.3s ease;
            position: relative;
            font-weight: 500;
        }

        nav a::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 2px;
            background-color: var(--blue-2);
            transition: width 0.3s ease;
        }

        nav a:hover::after {
            width: 100%;
        }

        .btn-appointment {
            background-color: var(--blue-1);
            color: white;
            padding: 10px 18px;
            border-radius: 25px;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 8px rgba(15, 77, 146, 0.2);
            font-weight: 600;
        }

        .btn-appointment:hover {
            background-color: var(--blue-2);
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(15, 77, 146, 0.3);
        }

        .login-link {
            font-size: 14px;
            color: var(--text-dark);
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .login-link:hover {
            color: var(--blue-1);
        }

        /* Login Container */
        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 120px 20px 60px;
            background: linear-gradient(135deg, var(--pastel) 0%, #e9ecef 100%);
        }

        .login-box {
            background-color: var(--card-bg);
            backdrop-filter: blur(var(--glass-blur));
            padding: 50px 40px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 450px;
            text-align: center;
            border: 1px solid var(--glass-border);
            position: relative;
            overflow: hidden;
            opacity: 0;
            transform: translateY(20px);
            animation: fadeInUp 0.8s forwards 0.3s;
        }

        .login-box::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(to right, var(--bright-red), var(--blue-2));
        }

        @keyframes fadeInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-box h2 {
            font-size: 2.2rem;
            margin-bottom: 30px;
            color: var(--text-dark);
            position: relative;
            padding-bottom: 15px;
        }

        .login-box h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 3px;
            background: linear-gradient(to right, var(--bright-red), var(--blue-2));
            border-radius: 2px;
        }

        .login-box form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .login-box input {
            padding: 15px 20px;
            border: 1px solid var(--glass-border);
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background-color: rgba(255, 255, 255, 0.7);
        }

        .login-box input:focus {
            outline: none;
            border-color: var(--blue-2);
            box-shadow: 0 0 0 3px rgba(28, 169, 201, 0.2);
        }

        .login-box button {
            background: linear-gradient(to right, var(--blue-1), var(--blue-2));
            color: white;
            border: none;
            padding: 15px;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }

        .login-box button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(15, 77, 146, 0.3);
        }

        .login-box a {
            color: var(--blue-1);
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-block;
            margin-top: 20px;
            font-weight: 500;
        }

        .login-box a:hover {
            color: var(--blue-2);
            transform: translateX(3px);
        }

        .error-message {
            color: var(--bright-red);
            background-color: rgba(255, 45, 85, 0.1);
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
            border-left: 4px solid var(--bright-red);
        }

        /* Mobile Navigation */
        .mobile-menu-toggle {
            display: none;
            flex-direction: column;
            cursor: pointer;
            padding: 5px;
        }

        .mobile-menu-toggle span {
            width: 25px;
            height: 3px;
            background-color: var(--text-dark);
            margin: 3px 0;
            transition: 0.3s;
        }

        /* Responsive styles */
        @media (max-width: 768px) {
            header {
                padding: 15px 20px;
            }

            .mobile-menu-toggle {
                display: flex;
            }

            nav {
                position: absolute;
                top: 100%;
                left: 0;
                width: 100%;
                background: rgba(255, 255, 255, 0.95);
                backdrop-filter: blur(var(--glass-blur));
                flex-direction: column;
                gap: 0;
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                transform: translateY(-10px);
                opacity: 0;
                visibility: hidden;
                transition: all 0.3s ease;
                padding: 20px 0;
            }

            nav.active {
                transform: translateY(0);
                opacity: 1;
                visibility: visible;
            }

            nav a {
                padding: 15px 40px;
                border-bottom: 1px solid var(--glass-border);
                width: 100%;
                text-align: left;
            }

            .login-container {
                padding: 120px 20px 40px;
            }
            
            .login-box {
                padding: 40px 25px;
            }
        }
    </style>
</head>
<body>
    <header id="header">
        <a href="../index.php" class="logo">
            <img src="../dokotelalogo.png" alt="Dokotela Online Logo">
        </a>
        <div class="mobile-menu-toggle" onclick="toggleMobileMenu()">
            <span></span>
            <span></span>
            <span></span>
        </div>
        <nav id="nav">
            <a href="../index.php#home">Home</a>
            <a href="../index.php#services">Services</a>
            <a href="../index.php#mission">About</a>
            <a href="../index.php#booking">Booking</a>
            <a href="../index.php#faq">FAQ</a>
            <a href="login.php" class="btn-appointment">Book Appointment</a>
            <a href="login.php" class="login-link">Login</a>
            <a href="signup.php" class="login-link">Sign Up</a>
        </nav>
    </header>

    <div class="login-container">
        <div class="login-box">
            <h2>Login</h2>
            <?php if (!empty($error)) echo "<div class='error-message'>$error</div>"; ?>
            <form method="POST">
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Login</button>
            </form>
            <a href="signup.php">New patient? Sign up here</a>
        </div>
    </div>

    <script>
        // Header scroll effect
        window.addEventListener('scroll', function() {
            const header = document.getElementById('header');
            
            if (window.scrollY > 50) {
                header.classList.add('header-scrolled');
            } else {
                header.classList.remove('header-scrolled');
            }
        });

        // Mobile menu toggle
        function toggleMobileMenu() {
            const nav = document.getElementById('nav');
            nav.classList.toggle('active');
        }

        // Close mobile menu when clicking on a link
        document.querySelectorAll('nav a').forEach(link => {
            link.addEventListener('click', function() {
                const nav = document.getElementById('nav');
                nav.classList.remove('active');
            });
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            const nav = document.getElementById('nav');
            const toggle = document.querySelector('.mobile-menu-toggle');
            
            if (!nav.contains(event.target) && !toggle.contains(event.target)) {
                nav.classList.remove('active');
            }
        });
    </script>
</body>
</html>