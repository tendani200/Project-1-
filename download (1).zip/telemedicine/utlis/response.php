<?php
class Response {
    public static function json($data, $status_code = 200) {
        http_response_code($status_code);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    public static function error($message, $status_code = 400) {
        self::json(['error' => $message], $status_code);
    }

    public static function success($data = null, $message = 'Success') {
        $response = ['success' => true, 'message' => $message];
        if ($data) $response['data'] = $data;
        self::json($response);
    }
}
?>