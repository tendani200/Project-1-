<?php
include 'db_connect.php';
echo "✅ Connected successfully to database!";
?>
