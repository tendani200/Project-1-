<?php
// support_tickets.php
session_start();
include '../db_connect.php';

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Patient') {
    header("Location: ../auth/login.php");
    exit();
}

$userID = intval($_SESSION['userID']);

// Fetch patient info
$stmt = $conn->prepare("SELECT u.firstName, u.lastName, p.patientID 
                        FROM User u 
                        JOIN Patient p ON u.userID = p.userID 
                        WHERE u.userID = ?");
$stmt->bind_param("i", $userID);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $patientName = $row['firstName'] . " " . $row['lastName'];
    $patientID = $row['patientID'];
} else {
    session_unset();
    session_destroy();
    header("Location: ../auth/login.php");
    exit();
}

// Fetch all support tickets for the user
$tickets = [];
$stmt = $conn->prepare("
    SELECT ticketID, subject, description, priority, status, admin_response, createdAt, updatedAt
    FROM SupportTickets 
    WHERE userID = ? 
    ORDER BY 
        CASE priority 
            WHEN 'urgent' THEN 1
            WHEN 'high' THEN 2
            WHEN 'normal' THEN 3
            WHEN 'low' THEN 4
        END,
        createdAt DESC
");
$stmt->bind_param("i", $userID);
$stmt->execute();
$result = $stmt->get_result();
while ($ticket = $result->fetch_assoc()) {
    $tickets[] = $ticket;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Support Tickets - Dokotela</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --page-bg: #FCEFF4;
            --panel-bg: transparent;
            --soft-1: #E7C6FF;
            --soft-2: #BBCCFF;
            --accent-mid: #567C8D;
            --accent-dark: #2F4156;
            --hint-red: #C23B22;
            --white: #ffffff;
            --muted: #6F8793;
            --shadow-strong: rgba(15,30,60,0.08);
            --shadow-subtle: rgba(15,30,60,0.03);
        }

        * { box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: var(--page-bg); margin: 0; padding: 20px; color: var(--accent-dark); }
        
        .container { max-width: 1200px; margin: 0 auto; }
        
        .header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            margin-bottom: 30px;
            background: var(--white);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 8px 28px var(--shadow-subtle);
        }
        
        .ticket-card {
            background: var(--white);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 16px;
            box-shadow: 0 8px 28px var(--shadow-subtle);
            border-left: 4px solid var(--accent-mid);
        }
        
        .ticket-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }
        
        .ticket-title {
            font-weight: 700;
            font-size: 1.1rem;
            color: var(--accent-dark);
            margin: 0;
        }
        
        .ticket-meta {
            display: flex;
            gap: 12px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .priority-badge, .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .priority-urgent { background: #FFCDD2; color: #C62828; }
        .priority-high { background: #FFE0B2; color: #EF6C00; }
        .priority-normal { background: #E3F2FD; color: #1565C0; }
        .priority-low { background: #E8F5E8; color: #2E7D32; }
        
        .status-open { background: #E3F2FD; color: #1565C0; }
        .status-in_progress { background: #FFF3E0; color: #EF6C00; }
        .status-resolved { background: #E8F5E8; color: #2E7D32; }
        
        .ticket-description {
            color: var(--muted);
            line-height: 1.5;
            margin-bottom: 16px;
        }
        
        .admin-response {
            background: rgba(86,124,141,0.05);
            padding: 16px;
            border-radius: 8px;
            margin-top: 16px;
            border-left: 3px solid var(--accent-mid);
        }
        
        .response-label {
            font-weight: 600;
            color: var(--accent-mid);
            margin-bottom: 8px;
            display: block;
        }
        
        .btn-primary {
            background: linear-gradient(90deg, var(--soft-1), var(--soft-2));
            color: var(--accent-dark);
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--muted);
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 16px;
            opacity: 0.5;
        }

        /* Back button styles */
        .back-btn {
            background: transparent;
            border: 1px solid rgba(86,124,141,0.2);
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            color: var(--accent-dark);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-right: 12px;
        }

        .back-btn:hover {
            background: rgba(86,124,141,0.05);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <h1 style="margin: 0; color: var(--accent-dark);">Support Tickets</h1>
                <p style="margin: 8px 0 0 0; color: var(--muted);">Manage your support requests and inquiries</p>
            </div>
            <div>
                <a href="patient_dashboard.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
                <button class="btn-primary" onclick="window.location.href='patient_dashboard.php#support'">
                    <i class="fas fa-plus"></i> New Ticket
                </button>
            </div>
        </div>

        <?php if (count($tickets) === 0): ?>
            <div class="empty-state">
                <i class="fas fa-headset"></i>
                <h3>No Support Tickets</h3>
                <p>You haven't submitted any support tickets yet.</p>
                <button class="btn-primary" onclick="window.location.href='patient_dashboard.php#support'">
                    Submit Your First Ticket
                </button>
            </div>
        <?php else: ?>
            <div class="tickets-list">
                <?php foreach ($tickets as $ticket): ?>
                    <div class="ticket-card">
                        <div class="ticket-header">
                            <h3 class="ticket-title"><?php echo htmlspecialchars($ticket['subject']); ?></h3>
                            <div class="ticket-meta">
                                <span class="priority-badge priority-<?php echo $ticket['priority']; ?>">
                                    <?php echo ucfirst($ticket['priority']); ?>
                                </span>
                                <span class="status-badge status-<?php echo $ticket['status']; ?>">
                                    <?php echo str_replace('_', ' ', ucfirst($ticket['status'])); ?>
                                </span>
                                <small style="color: var(--muted);">
                                    <?php echo date('M j, Y g:i A', strtotime($ticket['createdAt'])); ?>
                                </small>
                            </div>
                        </div>
                        
                        <div class="ticket-description">
                            <?php echo nl2br(htmlspecialchars($ticket['description'])); ?>
                        </div>
                        
                        <?php if (!empty($ticket['admin_response'])): ?>
                            <div class="admin-response">
                                <span class="response-label">Admin Response:</span>
                                <div><?php echo nl2br(htmlspecialchars($ticket['admin_response'])); ?></div>
                                <?php if ($ticket['updatedAt'] != $ticket['createdAt']): ?>
                                    <small style="color: var(--muted); margin-top: 8px; display: block;">
                                        Last updated: <?php echo date('M j, Y g:i A', strtotime($ticket['updatedAt'])); ?>
                                    </small>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // Add some interactive functionality
        document.addEventListener('DOMContentLoaded', function() {
            // Add click effect to ticket cards
            const ticketCards = document.querySelectorAll('.ticket-card');
            ticketCards.forEach(card => {
                card.addEventListener('click', function() {
                    this.style.transform = 'translateY(-2px)';
                    this.style.boxShadow = '0 12px 32px rgba(12,30,45,0.1)';
                    setTimeout(() => {
                        this.style.transform = '';
                        this.style.boxShadow = '';
                    }, 150);
                });
            });
        });
    </script>
</body>
</html>