<?php
session_start();
include '../db_connect.php';

// Check if patient is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Patient') {
    header("Location: ../auth/login.php");
    exit();
}

// Prefer patientID from session if available; fallback to lookup by userID
$patientID = isset($_SESSION['patientID']) ? intval($_SESSION['patientID']) : null;
$patientUserID = intval($_SESSION['userID']);

// Try to fetch patientID and name 
if (!$patientID) {
    $pQ = $conn->prepare("SELECT p.patientID, u.firstName, u.lastName FROM Patient p JOIN User u ON p.userID = u.userID WHERE u.userID = ?");
    $pQ->bind_param("i", $patientUserID);
    $pQ->execute();
    $pRes = $pQ->get_result();
    if ($pRow = $pRes->fetch_assoc()) {
        $patientID = intval($pRow['patientID']);
        $patientName = trim($pRow['firstName'] . ' ' . $pRow['lastName']);
    }
    $pQ->close();
} else {
    // Fetch name by patientID
    $pQ = $conn->prepare("SELECT u.firstName, u.lastName FROM Patient p JOIN User u ON p.userID = u.userID WHERE p.patientID = ?");
    $pQ->bind_param("i", $patientID);
    $pQ->execute();
    $pRes = $pQ->get_result();
    if ($pRow = $pRes->fetch_assoc()) {
        $patientName = trim($pRow['firstName'] . ' ' . $pRow['lastName']);
    }
    $pQ->close();
}
if (empty($patientName)) $patientName = 'Patient';

// Handle payment processing
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'process_payment') {
    header('Content-Type: application/json');
    
    $paymentMethod = $_POST['paymentMethod'];
    $totalAmount = floatval($_POST['totalAmount']);
    
    if ($paymentMethod === 'card') {
        // Process card payment through external API
        $paymentResult = processCardPayment($totalAmount);
        
        if ($paymentResult['success']) {
            $conn->begin_transaction();
            try {
                // Update all pending payments to paid
                $updateStmt = $conn->prepare("UPDATE Payments SET status = 'paid', paymentDate = NOW() WHERE patientID = ? AND status = 'pending'");
                $updateStmt->bind_param("i", $patientID);
                $updateStmt->execute();
                
                // If there are outstanding amounts, create settlement records
                $outstandingStmt = $conn->prepare("
                    SELECT appointmentID, service_fee, outstanding_amount 
                    FROM Payments 
                    WHERE patientID = ? AND status = 'paid' AND outstanding_amount > 0
                ");
                $outstandingStmt->bind_param("i", $patientID);
                $outstandingStmt->execute();
                $outstandingResult = $outstandingStmt->get_result();
                
                while ($row = $outstandingResult->fetch_assoc()) {
                    // Create settlement payment record for outstanding amount
                    $settlementStmt = $conn->prepare("
                        INSERT INTO Payments (appointmentID, patientID, serviceID, amount, paymentMethod, status, paymentDate, service_fee, outstanding_amount) 
                        SELECT appointmentID, patientID, serviceID, outstanding_amount, 'card', 'paid', NOW(), service_fee, 0 
                        FROM Payments 
                        WHERE appointmentID = ? AND patientID = ? AND status = 'paid'
                    ");
                    $settlementStmt->bind_param("ii", $row['appointmentID'], $patientID);
                    $settlementStmt->execute();
                    $settlementStmt->close();
                }
                
                $outstandingStmt->close();
                $updateStmt->close();
                $conn->commit();
                
                echo json_encode(['success' => true, 'message' => 'Payment processed successfully', 'transaction_id' => $paymentResult['transaction_id']]);
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => 'Payment processing error: ' . $e->getMessage()]);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Payment failed: ' . $paymentResult['error']]);
        }
    } elseif ($paymentMethod === 'medical_aid') {
        // For medical aid, update payment method and mark as pending verification
        $updateStmt = $conn->prepare("UPDATE Payments SET paymentMethod = 'medical_aid', status = 'pending_verification' WHERE patientID = ? AND status = 'pending'");
        $updateStmt->bind_param("i", $patientID);
        
        if ($updateStmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Medical aid claim submitted. Status will be updated after verification.', 'requires_verification' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update medical aid information']);
        }
        $updateStmt->close();
    }
    exit();
}

// Function to simulate card payment API
function processCardPayment($amount) {
    // Simulate API call to payment gateway
    // In a real application, you would integrate with PayFast, PayGate, etc.
    
    // Simulate API response - 95% success rate for testing
    $success = (rand(0, 19) > 0); // 95% success rate
    
    if ($success) {
        return [
            'success' => true,
            'transaction_id' => 'TXN_' . uniqid(),
            'amount' => $amount,
            'status' => 'completed'
        ];
    } else {
        return [
            'success' => false,
            'error' => 'Payment declined by bank'
        ];
    }
}

// Fetch payment history with service names
$sql = "SELECT p.paymentID, p.appointmentID, p.amount, p.paymentDate, 
               p.paymentMethod, p.status, p.serviceID, p.service_fee, p.outstanding_amount,
               s.serviceName
        FROM Payments p
        LEFT JOIN MedicalService s ON p.serviceID = s.serviceID
        WHERE p.patientID = ?
        ORDER BY p.paymentDate DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patientID);
$stmt->execute();
$result = $stmt->get_result();

// Calculate total pending amount (only booking fees and outstanding amounts)
$pendingAmountQuery = $conn->prepare("
    SELECT SUM(
        CASE 
            WHEN outstanding_amount > 0 THEN outstanding_amount 
            ELSE amount 
        END
    ) as total_pending 
    FROM Payments 
    WHERE patientID = ? AND status IN ('pending', 'pending_verification')
");
$pendingAmountQuery->bind_param("i", $patientID);
$pendingAmountQuery->execute();
$pendingResult = $pendingAmountQuery->get_result();
$pendingData = $pendingResult->fetch_assoc();
$totalPendingAmount = $pendingData['total_pending'] ?? 0;
$pendingAmountQuery->close();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>My Payments — Dokotela</title>

  <!-- Fonts & icons -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <style>
    :root{
      --bg: #F5EFEB;
      --soft-1: #E7C6FF;
      --soft-2: #BBCCFF;
      --accent-mid: #567C8D;
      --accent-dark: #2F4156;
      --hint-red: #C23B22;
      --card: rgba(255,255,255,0.95);
      --muted: rgba(47,65,86,0.6);
      --shadow: rgba(47,65,86,0.08);
      --radius: 12px;
      --success: #28a745;
      --warning: #ffc107;
      --info: #17a2b8;
    }

    *{box-sizing:border-box}
    html,body{height:100%;margin:0;font-family:'Inter',system-ui,Arial,sans-serif;background:var(--bg);color:var(--accent-dark);-webkit-font-smoothing:antialiased}
    a{color:inherit}
    .page{max-width:1200px;margin:20px auto;padding:20px;min-height:calc(100vh - 40px)}

    /* header card */
    .top-card{
      background: linear-gradient(90deg,var(--card), rgba(255,255,255,0.98));
      border-radius:var(--radius);
      padding:18px;
      display:flex;
      justify-content:space-between;
      align-items:center;
      gap:12px;
      box-shadow:0 10px 30px var(--shadow);
      border:1px solid rgba(47,65,86,0.03);
    }
    .page-title{display:flex;gap:12px;align-items:center}
    .page-title h1{margin:0;font-size:1.3rem;font-weight:700}
    .subtitle{color:var(--muted);margin:0;font-size:0.95rem}

    .actions{display:flex;gap:10px;align-items:center}
    .btn{background:linear-gradient(90deg,var(--soft-1),var(--soft-2));color:var(--accent-dark);border:0;padding:8px 12px;border-radius:10px;cursor:pointer;font-weight:600;text-decoration:none;box-shadow:0 6px 18px rgba(12,30,45,0.04)}
    .btn-outline{background:transparent;color:var(--accent-mid);border:1px solid rgba(86,124,141,0.12);padding:8px 12px;border-radius:10px;text-decoration:none;cursor:pointer}
    .btn-success{background:var(--success);color:#fff;border:0;padding:8px 12px;border-radius:10px;cursor:pointer;font-weight:600;text-decoration:none}

    /* layout */
    .content{display:grid;grid-template-columns:1fr;gap:18px;margin-top:18px}

    .card{
      background:var(--card);
      border-radius:var(--radius);
      padding:14px;
      box-shadow:0 10px 30px var(--shadow);
      border:1px solid rgba(47,65,86,0.03);
    }

    .card h2{margin:0;font-size:1.1rem;margin-bottom:12px;color:var(--accent-mid)}
    .card .lead{color:var(--muted);margin-bottom:8px}

    /* pending payment banner */
    .pending-banner {
      background: linear-gradient(90deg, #fff3cd, #ffeaa7);
      border: 1px solid #ffeaa7;
      border-radius: var(--radius);
      padding: 16px;
      margin-bottom: 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .pending-banner.hidden {
      display: none;
    }
    .pending-amount {
      font-size: 1.2rem;
      font-weight: 700;
      color: #856404;
    }

    /* filter section */
    .filter-section {
      display: flex;
      gap: 12px;
      margin-bottom: 16px;
      flex-wrap: wrap;
      align-items: center;
    }
    .filter-group {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }
    .filter-pill {
      background: transparent;
      border: 1px solid rgba(86,124,141,0.2);
      padding: 6px 12px;
      border-radius: 20px;
      cursor: pointer;
      font-size: 0.9rem;
      transition: all 0.2s ease;
    }
    .filter-pill:hover {
      background: rgba(86,124,141,0.05);
    }
    .filter-pill.active {
      background: var(--accent-mid);
      color: white;
      border-color: var(--accent-mid);
    }

    /* table styles */
    .table-wrap{overflow-x:auto;border-radius:8px}
    table{width:100%;border-collapse:collapse;min-width:760px}
    thead th{background:transparent;color:var(--muted);text-align:left;padding:12px 14px;border-bottom:1px solid rgba(15,30,60,0.06);font-weight:600}
    tbody td{padding:12px 14px;border-bottom:1px solid rgba(15,30,60,0.04);vertical-align:middle}
    tbody tr:nth-child(even){background:rgba(12,30,45,0.02)}

    .status-badge{
      display:inline-block;padding:6px 10px;border-radius:999px;font-weight:700;font-size:0.9rem;
      background:rgba(0,0,0,0.03);
    }
    .status-paid{ background: rgba(76,175,80,0.12); color: #2e7d32; }
    .status-pending{ background: rgba(255,193,7,0.12); color: #b36b00; }
    .status-pending_verification{ background: rgba(23,162,184,0.12); color: #0c5460; }
    .status-failed{ background: rgba(244,67,54,0.10); color: #c62828; }

    .invoice-link{ color:var(--accent-mid); text-decoration:none; font-weight:600; }
    .back-btn { display:inline-block; margin-top:1rem; background:var(--accent-mid); color:#fff; padding:0.6rem 1rem; border-radius:8px; text-decoration:none; }

    .no-records{text-align:center;padding:28px;color:var(--muted)}

    /* payment breakdown */
    .payment-breakdown {
      background: rgba(86,124,141,0.05);
      border-radius: 8px;
      padding: 12px;
      margin: 10px 0;
    }
    .breakdown-item {
      display: flex;
      justify-content: space-between;
      padding: 4px 0;
    }
    .breakdown-total {
      border-top: 1px solid rgba(86,124,141,0.2);
      margin-top: 8px;
      padding-top: 8px;
      font-weight: 700;
    }

    /* payment modal */
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
      opacity: 0;
      visibility: hidden;
      transition: all 0.3s ease;
    }
    .modal-overlay.active {
      opacity: 1;
      visibility: visible;
    }
    .modal-content {
      background: var(--card);
      border-radius: var(--radius);
      padding: 24px;
      max-width: 500px;
      width: 90%;
      max-height: 80vh;
      overflow-y: auto;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
      transform: translateY(-20px);
      transition: transform 0.3s ease;
    }
    .modal-overlay.active .modal-content {
      transform: translateY(0);
    }
    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      padding-bottom: 16px;
      border-bottom: 1px solid rgba(86,124,141,0.1);
    }
    .modal-header h2 {
      margin: 0;
      color: var(--accent-dark);
      font-size: 1.4rem;
    }
    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      color: var(--muted);
      cursor: pointer;
      padding: 0;
      width: 32px;
      height: 32px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 8px;
      transition: all 0.2s ease;
    }
    .close-btn:hover {
      background: rgba(86,124,141,0.1);
      color: var(--accent-dark);
    }

    /* payment processing */
    .payment-processing {
      text-align: center;
      padding: 20px;
    }
    .payment-processing .spinner {
      border: 4px solid #f3f3f3;
      border-top: 4px solid var(--accent-mid);
      border-radius: 50%;
      width: 40px;
      height: 40px;
      animation: spin 2s linear infinite;
      margin: 0 auto 20px;
    }
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    /* responsive */
    @media (max-width:800px){
      .top-card{flex-direction:column;align-items:flex-start}
      table{min-width:600px}
      .actions{width:100%;justify-content:space-between}
      .filter-section {
        flex-direction: column;
        align-items: flex-start;
      }
    }
  </style>
</head>
<body>
  <div class="page" role="main">
    <div class="top-card" role="banner">
      <div class="page-title">
        <div style="width:46px;height:46px;border-radius:10px;background:linear-gradient(90deg,var(--soft-1),var(--soft-2));display:flex;align-items:center;justify-content:center;color:var(--accent-dark);font-weight:700">
          <i class="fa-solid fa-wallet" style="font-size:18px"></i>
        </div>
        <div>
          <h1>My Payments</h1>
          <p class="subtitle">Your transactions and invoices — all in one place!</p>
        </div>
      </div>

      <div class="actions" aria-hidden="false">
        <a href="patient_dashboard.php" class="btn-outline"><i class="fa-solid fa-arrow-left" style="margin-right:8px"></i>Dashboard</a>
        <button class="btn" onclick="showPaymentModal()" id="makePaymentBtn" <?php echo $totalPendingAmount == 0 ? 'disabled style="opacity:0.5;cursor:not-allowed"' : ''; ?>>
          <i class="fa-solid fa-credit-card" style="margin-right:8px"></i>Make Payment
        </button>
      </div>
    </div>

    <div class="content">
      <section class="card">
        <!-- Pending Payments Banner -->
        <?php if ($totalPendingAmount > 0): ?>
        <div class="pending-banner" id="pendingBanner">
          <div>
            <strong>Outstanding Balance</strong>
            <div class="pending-amount">R <?php echo number_format($totalPendingAmount, 2); ?></div>
            <small>You have pending payments that need to be settled.</small>
          </div>
          <button class="btn-success" onclick="showPaymentModal()">
            <i class="fa-solid fa-credit-card" style="margin-right:8px"></i>Pay Now
          </button>
        </div>
        <?php endif; ?>

        <h2>Payment History</h2>
        <div class="lead">All your payments are listed below. Click <strong>View</strong> to open an invoice.</div>

        <!-- Filter Section -->
        <div class="filter-section">
          <div class="filter-group">
            <button class="filter-pill active" onclick="filterPayments('all')">All Payments</button>
            <button class="filter-pill" onclick="filterPayments('pending')">Pending</button>
            <button class="filter-pill" onclick="filterPayments('paid')">Paid</button>
            <button class="filter-pill" onclick="filterPayments('failed')">Failed</button>
          </div>
          
          <div style="display:flex;gap:8px;align-items:center;margin-left:auto">
            <div style="background:transparent;border-radius:10px;padding:6px 10px;border:1px solid rgba(15,30,45,0.04);display:flex;align-items:center;gap:8px">
              <i class="fa-solid fa-magnifying-glass" style="opacity:0.6"></i>
              <input id="searchInput" placeholder="Search payment ID, appointment..." oninput="debouncedFilter(this.value)" style="border:0;outline:none;background:transparent;font-size:0.95rem;width:220px" />
            </div>
          </div>
        </div>

        <div style="display:flex;justify-content:space-between;gap:12px;margin-top:12px;align-items:center">
          <div class="muted">Showing payments for <strong><?php echo htmlspecialchars($patientName); ?></strong> — Patient ID: <strong><?php echo htmlspecialchars($patientID); ?></strong></div>
        </div>

        <div class="table-wrap" style="margin-top:12px">
          <?php if ($result->num_rows > 0): ?>
            <table id="paymentsTable" aria-label="Payment history table">
              <thead>
                <tr>
                  <th>Payment ID</th>
                  <th>Date</th>
                  <th>Appointment ID</th>
                  <th>Service</th>
              
                  <th>Service Fee</th>
                  <th>Outstanding</th>
                  <th>Method</th>
                  <th>Status</th>
                  <th>Invoice</th>
                </tr>
              </thead>
              <tbody>
                <?php while ($row = $result->fetch_assoc()):
                  $pid = htmlspecialchars($row['paymentID']);
                  $pdate = htmlspecialchars(date("d M Y", strtotime($row['paymentDate'])));
                  $appid = htmlspecialchars($row['appointmentID']);
                  $serviceName = htmlspecialchars($row['serviceName'] ?? 'Service #' . $row['serviceID']);
                  
                  $serviceFee = isset($row['service_fee']) ? number_format($row['service_fee'], 2) : 'N/A';
                  $outstanding = isset($row['outstanding_amount']) ? number_format($row['outstanding_amount'], 2) : '0.00';
                  $method = htmlspecialchars($row['paymentMethod']);
                  $statusRaw = strtolower(trim($row['status']));
                  $badgeClass = 'status-' . $statusRaw;
                  $statusLabel = htmlspecialchars(ucfirst(str_replace('_', ' ', $row['status'])));
                ?>
                <tr data-status="<?php echo $statusRaw; ?>">
                  <td><?php echo $pid; ?></td>
                  <td><?php echo $pdate; ?></td>
                  <td><?php echo $appid; ?></td>
                  <td><?php echo $serviceName; ?></td>
                
                  <td>R <?php echo $serviceFee; ?></td>
                  <td>R <?php echo $outstanding; ?></td>
                  <td><?php echo $method; ?></td>
                  <td><span class="status-badge <?php echo $badgeClass; ?>"><?php echo $statusLabel; ?></span></td>
                  <td><a href="invoice.php?paymentID=<?php echo $pid; ?>" class="invoice-link">View</a></td>
                </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          <?php else: ?>
            <div class="no-records">
              <div style="font-weight:700;margin-bottom:8px">No payment records found</div>
              <div class="muted">If you recently made a payment, it may take a moment to appear. Contact support if the issue persists.</div>
            </div>
          <?php endif; ?>
        </div>

        <a href="patient_dashboard.php" class="back-btn">⬅ Back to Dashboard</a>
      </section>
    </div>
  </div>

  <!-- Payment Modal -->
  <div class="modal-overlay" id="paymentModal">
    <div class="modal-content">
      <div class="modal-header">
        <h2>Make Payment</h2>
        <button class="close-btn" onclick="closePaymentModal()">&times;</button>
      </div>
      <div id="paymentContent">
        <div style="margin-bottom: 20px;">
          <h3 style="color: var(--accent-dark); margin-bottom: 16px;">Outstanding Balance</h3>
          <div style="background: rgba(86,124,141,0.05); padding: 16px; border-radius: 8px; text-align: center;">
            <div style="font-size: 2rem; font-weight: 700; color: var(--accent-dark);">R <?php echo number_format($totalPendingAmount, 2); ?></div>
            <div style="color: var(--muted); margin-top: 8px;">Total amount due</div>
          </div>
          
          <!-- Payment Breakdown -->
          <div class="payment-breakdown">
            <div class="breakdown-item">
              <span>Booking Fees:</span>
              <span>R <?php 
                $bookingFeesQuery = $conn->prepare("SELECT SUM(amount) as total FROM Payments WHERE patientID = ? AND status IN ('pending', 'pending_verification') AND outstanding_amount = 0");
                $bookingFeesQuery->bind_param("i", $patientID);
                $bookingFeesQuery->execute();
                $bookingResult = $bookingFeesQuery->get_result();
                $bookingData = $bookingResult->fetch_assoc();
                echo number_format($bookingData['total'] ?? 0, 2);
                $bookingFeesQuery->close();
              ?></span>
            </div>
            <div class="breakdown-item">
              <span>Outstanding Amounts:</span>
              <span>R <?php 
                $outstandingQuery = $conn->prepare("SELECT SUM(outstanding_amount) as total FROM Payments WHERE patientID = ? AND status IN ('pending', 'pending_verification') AND outstanding_amount > 0");
                $outstandingQuery->bind_param("i", $patientID);
                $outstandingQuery->execute();
                $outstandingResult = $outstandingQuery->get_result();
                $outstandingData = $outstandingResult->fetch_assoc();
                echo number_format($outstandingData['total'] ?? 0, 2);
                $outstandingQuery->close();
              ?></span>
            </div>
            <div class="breakdown-item breakdown-total">
              <span>Total Due:</span>
              <span>R <?php echo number_format($totalPendingAmount, 2); ?></span>
            </div>
          </div>
        </div>

        <form id="paymentForm">
          <input type="hidden" name="totalAmount" value="<?php echo $totalPendingAmount; ?>">
          
          <div style="margin-bottom: 16px;">
            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--accent-mid);">Payment Method</label>
            <div style="display: flex; gap: 12px; flex-wrap: wrap;">
              <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                <input type="radio" name="paymentMethod" value="card" checked style="accent-color: var(--accent-mid);">
                <span>Credit/Debit Card</span>
              </label>
              <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                <input type="radio" name="paymentMethod" value="medical_aid" style="accent-color: var(--accent-mid);">
                <span>Medical Aid</span>
              </label>
            </div>
          </div>

          <div id="cardDetails" style="margin-bottom: 16px;">
            <div style="margin-bottom: 12px;">
              <label style="display: block; margin-bottom: 6px; font-weight: 600; color: var(--accent-mid);">Card Number</label>
              <input type="text" name="cardNumber" placeholder="1234 5678 9012 3456" style="width: 100%; padding: 10px; border: 1px solid rgba(86,124,141,0.2); border-radius: 6px; font-size: 1rem;" required>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
              <div>
                <label style="display: block; margin-bottom: 6px; font-weight: 600; color: var(--accent-mid);">Expiry Date</label>
                <input type="text" name="expiryDate" placeholder="MM/YY" style="width: 100%; padding: 10px; border: 1px solid rgba(86,124,141,0.2); border-radius: 6px;" required>
              </div>
              <div>
                <label style="display: block; margin-bottom: 6px; font-weight: 600; color: var(--accent-mid);">CVV</label>
                <input type="text" name="cvv" placeholder="123" style="width: 100%; padding: 10px; border: 1px solid rgba(86,124,141,0.2); border-radius: 6px;" required>
              </div>
            </div>
          </div>

          <div id="medicalAidInfo" style="display: none; margin-bottom: 16px;">
            <div style="background: rgba(86,124,141,0.05); padding: 12px; border-radius: 6px;">
              <p style="margin: 0; color: var(--muted); font-size: 0.9rem;">
                <i class="fa-solid fa-info-circle" style="margin-right: 6px;"></i>
                Your medical aid claim will be submitted for verification. Payment status will remain pending until approved by administration.
              </p>
            </div>
          </div>

          <div style="margin-top: 20px; display: flex; gap: 12px; justify-content: flex-end;">
            <button type="button" class="btn-outline" onclick="closePaymentModal()" style="background:transparent;border:1px solid rgba(86,124,141,0.2);padding:10px 20px;border-radius:8px;cursor:pointer">Cancel</button>
            <button type="submit" class="btn-success" style="background:var(--success);color:white;border:0;padding:10px 20px;border-radius:8px;cursor:pointer;font-weight:600">
              <i class="fa-solid fa-lock" style="margin-right:8px"></i>Pay R <?php echo number_format($totalPendingAmount, 2); ?>
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- toast -->
  <div id="toast" style="position:fixed;right:18px;bottom:18px;background:var(--accent-dark);color:var(--white);padding:10px 16px;border-radius:10px;box-shadow:0 8px 30px rgba(47,65,86,0.12);display:none;z-index:60"></div>

  <script>
    // Simple toast
    function showToast(msg, timeout = 1800){
      const t = document.getElementById('toast');
      t.textContent = msg;
      t.style.display = 'block';
      setTimeout(()=> t.style.display = 'none', timeout);
    }

    // Payment Modal Functions
    function showPaymentModal() {
      const modal = document.getElementById('paymentModal');
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }

    function closePaymentModal() {
      const modal = document.getElementById('paymentModal');
      modal.classList.remove('active');
      document.body.style.overflow = 'auto';
    }

    // Filter payments by status
    function filterPayments(status) {
      // Update active filter button
      document.querySelectorAll('.filter-pill').forEach(btn => {
        btn.classList.remove('active');
      });
      event.target.classList.add('active');
      
      const rows = document.querySelectorAll('#paymentsTable tbody tr');
      rows.forEach(row => {
        if (status === 'all') {
          row.style.display = '';
        } else {
          const rowStatus = row.getAttribute('data-status');
          row.style.display = rowStatus === status ? '' : 'none';
        }
      });
    }

    // Client-side debounced filter for the payments table
    let filterTimer;
    function debouncedFilter(q){
      clearTimeout(filterTimer);
      filterTimer = setTimeout(()=> {
        filterTable(q.trim().toLowerCase());
      }, 220);
    }

    function filterTable(q){
      const tbody = document.querySelector('#paymentsTable tbody');
      if(!tbody) return;
      const rows = Array.from(tbody.querySelectorAll('tr'));
      rows.forEach(r => {
        if(!q){ r.style.display=''; return; }
        const text = r.innerText.toLowerCase();
        r.style.display = text.includes(q) ? '' : 'none';
      });
    }

    // Handle payment form submission
    document.getElementById('paymentForm').addEventListener('submit', function(e) {
      e.preventDefault();
      
      const formData = new FormData(this);
      formData.append('action', 'process_payment');
      
      // Show processing state
      const submitBtn = this.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.innerHTML = '<div class="spinner" style="border: 2px solid #f3f3f3; border-top: 2px solid white; border-radius: 50%; width: 16px; height: 16px; animation: spin 1s linear infinite; display: inline-block; margin-right: 8px;"></div> Processing...';
      submitBtn.disabled = true;
      
      // Process payment via AJAX
      fetch(window.location.href, {
          method: 'POST',
          body: formData
      })
      .then(response => response.json())
      .then(data => {
          if (data.success) {
              showToast(data.message);
              closePaymentModal();
              
              // Reload page after successful payment
              setTimeout(() => {
                  window.location.reload();
              }, 1500);
          } else {
              showToast(data.message);
              submitBtn.innerHTML = originalText;
              submitBtn.disabled = false;
          }
      })
      .catch(error => {
          console.error('Error:', error);
          showToast('Payment processing error');
          submitBtn.innerHTML = originalText;
          submitBtn.disabled = false;
      });
    });

    // Toggle payment method details
    document.querySelectorAll('input[name="paymentMethod"]').forEach(radio => {
      radio.addEventListener('change', function() {
        const cardDetails = document.getElementById('cardDetails');
        const medicalAidInfo = document.getElementById('medicalAidInfo');
        
        if (this.value === 'card') {
          cardDetails.style.display = 'block';
          medicalAidInfo.style.display = 'none';
          
          // Make card fields required
          cardDetails.querySelectorAll('input').forEach(input => {
            input.required = true;
          });
        } else {
          cardDetails.style.display = 'none';
          medicalAidInfo.style.display = 'block';
          
          // Remove required from card fields
          cardDetails.querySelectorAll('input').forEach(input => {
            input.required = false;
          });
        }
      });
    });

    // Close modal when clicking outside
    document.getElementById('paymentModal').addEventListener('click', function(e) {
      if (e.target === this) {
        closePaymentModal();
      }
    });

    // Close modal with Escape key
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') {
        closePaymentModal();
      }
    });

    // Format card number input
    document.querySelector('input[name="cardNumber"]')?.addEventListener('input', function(e) {
      let value = e.target.value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
      let matches = value.match(/\d{4,16}/g);
      let match = matches && matches[0] || '';
      let parts = [];
      
      for (let i = 0, len = match.length; i < len; i += 4) {
        parts.push(match.substring(i, i + 4));
      }
      
      if (parts.length) {
        e.target.value = parts.join(' ');
      } else {
        e.target.value = value;
      }
    });

    // Format expiry date input
    document.querySelector('input[name="expiryDate"]')?.addEventListener('input', function(e) {
      let value = e.target.value.replace(/\D/g, '');
      if (value.length >= 2) {
        e.target.value = value.substring(0, 2) + '/' + value.substring(2, 4);
      }
    });
  </script>
</body>
</html>