<?php
// search_patient_data.php
session_start();
include '../db_connect.php';

// Check if patient is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Patient') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $query = $conn->real_escape_string($input['query'] ?? '');
    $category = $input['category'] ?? 'all';
    $patientID = intval($input['patientID']);
    
    $results = [];
    
    // Search appointments
    if ($category === 'all' || $category === 'appointments') {
        $stmt = $conn->prepare("
            SELECT 
                a.appointmentID as id,
                a.appointmentDate as date,
                a.appointmentTime as time,
                a.reason as title,
                a.status,
                CONCAT('Appointment with Dr. ', u.firstName, ' ', u.lastName) as description,
                'appointment' as type,
                a.*
            FROM Appointments a
            LEFT JOIN User u ON a.doctorID = u.userID
            WHERE a.patientID = ? 
            AND (a.reason LIKE ? OR u.firstName LIKE ? OR u.lastName LIKE ? OR a.notes LIKE ?)
            ORDER BY a.appointmentDate DESC, a.appointmentTime DESC
        ");
        $searchTerm = "%$query%";
        $stmt->bind_param("issss", $patientID, $searchTerm, $searchTerm, $searchTerm, $searchTerm);
        $stmt->execute();
        $appointmentResults = $stmt->get_result();
        
        while ($row = $appointmentResults->fetch_assoc()) {
            $results[] = $row;
        }
    }
    
    // Search medical records
    if ($category === 'all' || $category === 'records') {
        $stmt = $conn->prepare("
            SELECT 
                mr.recordID as id,
                mr.recordDate as date,
                mr.recordType as title,
                mr.diagnosis as description,
                'medical_record' as type,
                mr.*
            FROM MedicalRecords mr
            WHERE mr.patientID = ? 
            AND (mr.recordType LIKE ? OR mr.diagnosis LIKE ? OR mr.notes LIKE ? OR mr.treatment LIKE ?)
            ORDER BY mr.recordDate DESC
        ");
        $searchTerm = "%$query%";
        $stmt->bind_param("issss", $patientID, $searchTerm, $searchTerm, $searchTerm, $searchTerm);
        $stmt->execute();
        $recordResults = $stmt->get_result();
        
        while ($row = $recordResults->fetch_assoc()) {
            $results[] = $row;
        }
    }
    
    // Search payments
    if ($category === 'all' || $category === 'payments') {
        $stmt = $conn->prepare("
            SELECT 
                p.paymentID as id,
                p.paymentDate as date,
                p.amount,
                p.status,
                CONCAT('Payment for ', COALESCE(a.reason, 'Service')) as title,
                CONCAT('Amount: $', p.amount, ' - Status: ', p.status) as description,
                'payment' as type,
                p.*
            FROM Payments p
            LEFT JOIN Appointments a ON p.appointmentID = a.appointmentID
            WHERE p.patientID = ? 
            AND (p.status LIKE ? OR a.reason LIKE ? OR p.notes LIKE ?)
            ORDER BY p.paymentDate DESC
        ");
        $searchTerm = "%$query%";
        $stmt->bind_param("isss", $patientID, $searchTerm, $searchTerm, $searchTerm);
        $stmt->execute();
        $paymentResults = $stmt->get_result();
        
        while ($row = $paymentResults->fetch_assoc()) {
            $results[] = $row;
        }
    }
    
    echo json_encode([
        'success' => true,
        'results' => $results,
        'count' => count($results)
    ]);
    
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
