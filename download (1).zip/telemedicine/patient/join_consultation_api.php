<?php
// join_consultation_api.php
session_start();
include '../db_connect.php';

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Patient') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $appointmentId = intval($data['appointmentId']);
    $patientId = intval($data['patientId']);
    
    // Validate appointment belongs to patient
    $stmt = $conn->prepare("SELECT * FROM Appointments WHERE appointmentID = ? AND patientID = ?");
    $stmt->bind_param("ii", $appointmentId, $patientId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Appointment not found']);
        exit();
    }
    
    // In a real implementation, generate or retrieve video consultation URL
    // For demo purposes, we'll return a mock URL
    $consultationUrl = "https://video-consultation.dokotela.com/session/" . bin2hex(random_bytes(16));
    
    // Log the consultation join attempt (optional)
    // $logStmt = $conn->prepare("INSERT INTO ConsultationLogs (appointmentID, patientID, joinTime) VALUES (?, ?, NOW())");
    // $logStmt->bind_param("ii", $appointmentId, $patientId);
    // $logStmt->execute();
    
    echo json_encode([
        'success' => true,
        'consultationUrl' => $consultationUrl,
        'message' => 'Consultation session ready'
    ]);
}
?>