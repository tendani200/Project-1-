<?php
// patient_dashboard.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include '../db_connect.php';

// Check if patient is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Patient') {
    header("Location: ../auth/login.php");
    exit();
}

$userID = intval($_SESSION['userID']);

// Fetch patient info and email
$stmt = $conn->prepare("SELECT u.firstName, u.lastName, u.email, p.patientID 
                        FROM User u 
                        JOIN Patient p ON u.userID = p.userID 
                        WHERE u.userID = ?");
$stmt->bind_param("i", $userID);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $_SESSION['patientID'] = $row['patientID'];
    $patientName = $row['firstName'] . " " . $row['lastName'];
    $patientID = $row['patientID'];
    $patientEmail = $row['email'];
} else {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}

// Fetch dashboard stats
$upcomingAppointments = 0;
$totalRecords = 0;
$activePrescriptions = 0;

// Count upcoming appointments (based on future date/time)
$stmt = $conn->prepare("
    SELECT COUNT(*) as count 
    FROM Appointments 
    WHERE patientID=? 
      AND STR_TO_DATE(CONCAT(appointmentDate, ' ', appointmentTime), '%Y-%m-%d %H:%i') >= NOW()
");
$stmt->bind_param("i", $patientID);
$stmt->execute();
$res = $stmt->get_result();
if ($r = $res->fetch_assoc()) {
    $upcomingAppointments = $r['count'];
}

// Get next 3 upcoming appointments with service and doctor information
$appointmentsList = [];
$stmt2 = $conn->prepare("
    SELECT a.appointmentID, a.appointmentDate, a.appointmentTime, a.status,
           a.doctorID, a.serviceID,
           CONCAT(u.firstName, ' ', u.lastName) AS doctorName,
           u.email AS doctorEmail, u.phone AS doctorPhone,
           ms.serviceName, ms.serviceDescription,
           d.specialty
    FROM Appointments a
    LEFT JOIN Doctor d ON a.doctorID = d.doctorID
    LEFT JOIN User u ON d.userID = u.userID
    LEFT JOIN MedicalService ms ON a.serviceID = ms.serviceID
    WHERE a.patientID=? AND STR_TO_DATE(CONCAT(a.appointmentDate, ' ', a.appointmentTime), '%Y-%m-%d %H:%i') >= NOW()
    ORDER BY STR_TO_DATE(CONCAT(a.appointmentDate, ' ', a.appointmentTime), '%Y-%m-%d %H:%i') ASC
    LIMIT 3
");
$stmt2->bind_param("i", $patientID);
$stmt2->execute();
$res2 = $stmt2->get_result();
while ($ar = $res2->fetch_assoc()) {
    $appointmentsList[] = $ar;
}

// Fetch notifications/announcements for the patient (all patients or all users)
$notifications = [];
$stmt3 = $conn->prepare("
    SELECT a.announcementID, a.title, a.content, a.createdAt, a.isUrgent
    FROM Announcements a 
    WHERE a.targetAudience IN ('all', 'patients')
    ORDER BY a.createdAt DESC
    LIMIT 10
");
$stmt3->execute();
$res3 = $stmt3->get_result();
while ($notification = $res3->fetch_assoc()) {
    $notifications[] = $notification;
}

// Count unread notifications
$unreadNotifications = count($notifications);

// Fetch support tickets for the patient
$supportTickets = [];
$stmt4 = $conn->prepare("
    SELECT ticketID, subject, description, priority, status, admin_response, createdAt, updatedAt
    FROM SupportTickets 
    WHERE userID = ? 
    ORDER BY createdAt DESC
    LIMIT 5
");
$stmt4->bind_param("i", $userID);
$stmt4->execute();
$res4 = $stmt4->get_result();
while ($ticket = $res4->fetch_assoc()) {
    $supportTickets[] = $ticket;
}

// Count open support tickets
$openTickets = 0;
foreach ($supportTickets as $ticket) {
    if ($ticket['status'] === 'open' || $ticket['status'] === 'in_progress') {
        $openTickets++;
    }
}

// Count medical records
$res = $conn->query("SELECT COUNT(*) as count FROM MedicalRecords WHERE patientID=$patientID");
if ($row = $res->fetch_assoc()) {
    $totalRecords = $row['count'];
}

// Count prescriptions
$res = $conn->query("SELECT COUNT(*) as count FROM Prescription WHERE patientID=$patientID");
if ($row = $res->fetch_assoc()) {
    $activePrescriptions = $row['count'];
}

// Handle search functionality
$searchResults = [];
if (isset($_GET['search']) && !empty(trim($_GET['search']))) {
    $searchTerm = $conn->real_escape_string(trim($_GET['search']));
    $patientID = intval($_SESSION['patientID']);
    $searchPattern = "%$searchTerm%";
    
    // Search appointments with enhanced information
    $appointmentQuery = $conn->prepare("
        SELECT 
            a.appointmentID,
            a.appointmentDate,
            a.appointmentTime,
            a.status,
            a.reason,
            a.doctorID,
            CONCAT(u.firstName, ' ', u.lastName) AS doctorName,
            u.email AS doctorEmail,
            u.phone AS doctorPhone,
            ms.serviceName,
            d.specialty,
            CONCAT('Appointment: ', COALESCE(ms.serviceName, a.reason, 'Consultation')) as title,
            CONCAT('With Dr. ', u.firstName, ' ', u.lastName, ' (', d.specialty, ') on ', a.appointmentDate, ' at ', a.appointmentTime) as description,
            'appointment' as type
        FROM Appointments a
        LEFT JOIN Doctor d ON a.doctorID = d.doctorID
        LEFT JOIN User u ON d.userID = u.userID
        LEFT JOIN MedicalService ms ON a.serviceID = ms.serviceID
        WHERE a.patientID = ? 
        AND (
            a.reason LIKE ? 
            OR u.firstName LIKE ? 
            OR u.lastName LIKE ?
            OR a.status LIKE ?
            OR CONCAT(u.firstName, ' ', u.lastName) LIKE ?
            OR ms.serviceName LIKE ?
            OR d.specialty LIKE ?
        )
        ORDER BY a.appointmentDate DESC
    ");
    
    if ($appointmentQuery) {
        $appointmentQuery->bind_param("isssssss", $patientID, $searchPattern, $searchPattern, $searchPattern, $searchPattern, $searchPattern, $searchPattern, $searchPattern);
        $appointmentQuery->execute();
        $appointmentResults = $appointmentQuery->get_result();
        
        while ($row = $appointmentResults->fetch_assoc()) {
            $searchResults[] = $row;
        }
        $appointmentQuery->close();
    }
    
    // Search medical records
    $recordsQuery = $conn->prepare("
        SELECT 
            mr.recordID as id,
            CONCAT('Medical Record: ', DATE(mr.recordDate)) as title,
            CONCAT('Created: ', mr.recordDate, ' - ', COALESCE(LEFT(mr.notes, 100), 'No notes')) as description,
            'Active' as status,
            'record' as type,
            mr.recordDate as date
        FROM MedicalRecords mr
        WHERE mr.patientID = ? 
        AND (
            mr.notes LIKE ?
            OR mr.recordDate LIKE ?
        )
        ORDER BY mr.recordDate DESC
    ");
    
    if ($recordsQuery) {
        $recordsQuery->bind_param("iss", $patientID, $searchPattern, $searchPattern);
        $recordsQuery->execute();
        $recordsResults = $recordsQuery->get_result();
        
        while ($row = $recordsResults->fetch_assoc()) {
            $searchResults[] = $row;
        }
        $recordsQuery->close();
    }
    
    // Search payments - with error handling
    try {
        $paymentsQuery = $conn->prepare("
            SELECT 
                p.paymentID as id,
                CONCAT('Payment: $', p.amount) as title,
                CONCAT('Status: ', p.status, ' - Date: ', p.paymentDate, ' - Method: ', p.paymentMethod) as description,
                p.status,
                'payment' as type,
                p.paymentDate as date
            FROM Payments p
            WHERE p.patientID = ? 
            AND (
                p.status LIKE ?
                OR p.paymentMethod LIKE ?
                OR p.amount LIKE ?
            )
            ORDER BY p.paymentDate DESC
        ");
        
        if ($paymentsQuery) {
            $paymentsQuery->bind_param("isss", $patientID, $searchPattern, $searchPattern, $searchPattern);
            $paymentsQuery->execute();
            $paymentsResults = $paymentsQuery->get_result();
            
            while ($row = $paymentsResults->fetch_assoc()) {
                $searchResults[] = $row;
            }
            $paymentsQuery->close();
        }
    } catch (Exception $e) {
        // If payments table doesn't exist or has issues, continue without payments
        error_log("Payments search error: " . $e->getMessage());
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Dokotela - Patient Dashboard</title>

  <!-- Google font + FontAwesome -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <style>
    :root{
      --page-bg: #FCEFF4;
      --panel-bg: transparent;
      --soft-1: #E7C6FF;
      --soft-2: #BBCCFF;
      --accent-mid: #567C8D;
      --accent-dark: #2F4156;
      --hint-red: #C23B22;
      --white: #ffffff;
      --muted: #6F8793;
      --shadow-strong: rgba(15,30,60,0.08);
      --shadow-subtle: rgba(15,30,60,0.03);
      --divider: linear-gradient(90deg, rgba(86,124,141,0.06), rgba(86,124,141,0.00));
      --radius: 14px;
    }

    /* base */
    *{box-sizing:border-box}
    html,body{height:100%;margin:0;font-family:'Inter',system-ui,Arial,sans-serif;background:var(--page-bg);color:var(--accent-dark);-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}
    a{color:inherit;text-decoration:none}
    .app-shell{max-width:1300px;margin:26px auto;padding:18px;border-radius:18px;background:transparent;}

/* layout */
    .wrap{display:flex;gap:18px;align-items:flex-start;min-height:calc(100vh - 52px);padding:6px}

/* SIDEBAR - sticky full-height */
    .sidebar{
      width:260px;
      position:sticky;
      top:26px;
      height: calc(100vh - 52px); /* ensures it spans full viewport within shell */
      background: linear-gradient(180deg,var(--soft-2),var(--accent-dark));
      color:var(--white);
      border-radius:12px;
      box-shadow: 8px 0 30px var(--shadow-strong);
      overflow:hidden;
      display:flex;
      flex-direction:column;
      transition:width .28s ease;
      flex-shrink:0;
      padding-bottom:18px;
    }
    .sidebar.collapsed{ width:78px; }

    .sidebar .logo{display:flex;align-items:center;gap:12px;height:64px;padding:0 14px;transition:padding 0.3s ease;}
    .logo-mark{width:44px;height:44px;border-radius:10px;background:var(--white);display:flex;align-items:center;justify-content:center;font-weight:700;color:var(--accent-mid);font-size:20px;margin-right:0}
    .logo-text{font-weight:700;font-size:1.02rem;letter-spacing:0.2px;transition:opacity 0.3s ease, width 0.3s ease;overflow:hidden;white-space:nowrap;}

    .sidebar-nav{padding:10px;display:flex;flex-direction:column;gap:8px;flex:1;overflow:auto}
    .sidebar-nav::-webkit-scrollbar{width:8px}
    .sidebar-nav::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.06);border-radius:8px}

    .nav-item{display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:10px;color:var(--white);text-decoration:none;font-size:0.95rem;cursor:pointer;transition:background .14s ease, color .14s ease, padding 0.3s ease, justify-content 0.3s ease;}
    .nav-item .icon{width:36px;text-align:center;font-size:1.05rem}
    .nav-item:hover{background:rgba(255,255,255,0.06)}
    .nav-item.active{background:rgba(255,255,255,0.12);color:var(--white)}
    .label{transition:opacity 0.3s ease, width 0.3s ease;overflow:hidden;white-space:nowrap;}

    .sidebar .bottom-item{margin-top:auto;padding:12px 10px;transition:padding 0.3s ease, justify-content 0.3s ease;}

    /* Sidebar collapsed states */
    .sidebar.collapsed .logo-text,
    .sidebar.collapsed .label,
    .sidebar.collapsed .bottom-item .label {
      opacity: 0;
      width: 0;
    }

    .sidebar.collapsed .logo {
      justify-content: center;
      padding: 0;
    }

    .sidebar.collapsed .nav-item {
      justify-content: center;
      padding: 10px;
    }

    .sidebar.collapsed .sidebar-nav {
      align-items: center;
    }

    .sidebar.collapsed .bottom-item {
      justify-content: center;
      padding: 12px;
    }

/* CENTER content */
    .center{flex:1;display:flex;flex-direction:column;gap:20px;min-width:0;padding-right:6px}

/* GREETING (expanded height) */
    .top-card{
      /* transparent card */
      background: linear-gradient(180deg, #ffff, #fbf8ff);
      backdrop-filter: blur(6px);
      border-radius:18px;
      padding:28px;
      box-shadow: 0 12px 36px var(--shadow-subtle);
      border:1px solid rgba(86,124,141,0.06);
      display:flex;
      justify-content:space-between;
      align-items:center;
      gap:12px;
      min-height:280px; 
      position:relative;
      overflow:visible;
    }

    .greeting{display:flex;flex-direction:column;gap:10px;max-width:62%}
    .greeting h1{margin:0;font-size:1.6rem;line-height:1.05}
    .greeting p{margin:0;color:var(--muted);font-size:0.98rem}

    .patient-summary{display:flex;align-items:center;gap:14px;margin-top:8px}
    .patient-summary .avatar{width:72px;height:72px;border-radius:12px;overflow:hidden;flex-shrink:0;box-shadow:0 6px 18px var(--shadow-subtle)}
    .patient-summary .avatar img{width:100%;height:100%;object-fit:cover}
    .patient-summary .meta{display:flex;flex-direction:column}
    .patient-summary .meta small{color:var(--muted)}

    .top-actions{display:flex;gap:12px;align-items:center}
    .search{display:flex;align-items:center;gap:8px;padding:10px 14px;border-radius:12px;background:rgba(255,255,255,0.9);min-width:280px;box-shadow:0 6px 18px rgba(12,30,45,0.04)}
    .search input{border:0;outline:none;background:transparent;font-size:0.95rem;flex:1;width:100%}

    /* Colored notification and hamburger buttons */
    .icon-btn{
      width:44px;
      height:44px;
      border-radius:12px;
      display:flex;
      align-items:center;
      justify-content:center;
      background:linear-gradient(180deg,var(--soft-1),var(--soft-2));
      color:var(--accent-dark);
      border:none;
      cursor:pointer;
      box-shadow:0 6px 18px rgba(12,30,45,0.08);
      transition:transform 0.2s ease, box-shadow 0.2s ease;
    }
    .icon-btn:hover{
      transform:translateY(-2px);
      box-shadow:0 8px 22px rgba(12,30,45,0.12);
    }

/* section separators (subtle gradient + shadow) */
    .section-divider{
      height:8px;
      border-radius:8px;
      margin:6px 0 2px 0;
      background: var(--divider);
      box-shadow: 0 6px 18px rgba(12,30,45,0.02);
    }

/* stats blocks — now visually separated, no strong white background */
    .stats-section{display:flex;gap:14px;flex-wrap:wrap}
    .stat{
      flex:1 1 calc(33.333% - 14px);
      min-width:200px;
      background: #ffff;
      border-radius:12px;
      padding:16px;
      display:flex;
      flex-direction:column;
      gap:10px;
      border:1px solid rgba(86,124,141,0.04);
      box-shadow: 0 8px 28px rgba(12,30,45,0.02);
    }
    .stat h3{margin:0;font-size:1rem}
    .stat .value{font-size:1.5rem;font-weight:800;color:var(--accent-mid)}
    .badge-icon{width:46px;height:46px;border-radius:10px;display:flex;align-items:center;justify-content:center;color:var(--white);background: linear-gradient(180deg,var(--soft-1),var(--soft-2))}

/* appointments list */
    .mid-columns{display:grid;grid-template-columns:1fr;gap:16px}
    .card{
      background: #ffff;
      border-radius:12px;
      padding:12px;
      border:1px solid rgba(86,124,141,0.04);
      box-shadow: 0 8px 28px rgba(12,30,45,0.02);
    }
    .appointments-list{display:flex;flex-direction:column;gap:12px}
    .appointment-item{background:linear-gradient(180deg, rgba(255,255,255,0.16), rgba(255,255,255,0.08));padding:12px;border-radius:10px;border:1px solid rgba(86,124,141,0.03);display:flex;justify-content:space-between;gap:12px;align-items:center}
    .appointment-meta{display:flex;gap:12px;align-items:center}
    .dot{width:58px;height:58px;border-radius:10px;background:linear-gradient(180deg,var(--soft-2),var(--soft-1));display:flex;align-items:center;justify-content:center;color:var(--accent-mid);font-size:18px}

/* Search Results Styles */
    .search-results-list {
        display: flex;
        flex-direction: column;
        gap: 16px;
    }

    .search-result-item {
        background: linear-gradient(180deg, rgba(255,255,255,0.16), rgba(255,255,255,0.08));
        padding: 20px;
        border-radius: 10px;
        border: 1px solid rgba(86,124,141,0.03);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .search-result-item:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(12,30,45,0.1);
    }

/* helper */
    .muted{color:var(--muted);font-size:0.95rem}
    .view-all-btn{background:transparent;border:1px solid rgba(86,124,141,0.06);padding:8px 10px;border-radius:8px;cursor:pointer;color:var(--accent-mid)}

/* Modal Styles */
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
      opacity: 0;
      visibility: hidden;
      transition: all 0.3s ease;
    }

    .modal-overlay.active {
      opacity: 1;
      visibility: visible;
    }

    .modal-content {
      background: var(--white);
      border-radius: 18px;
      padding: 28px;
      max-width: 500px;
      width: 90%;
      max-height: 80vh;
      overflow-y: auto;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
      transform: translateY(-20px);
      transition: transform 0.3s ease;
    }

    .modal-overlay.active .modal-content {
      transform: translateY(0);
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      padding-bottom: 16px;
      border-bottom: 1px solid rgba(86,124,141,0.1);
    }

    .modal-header h2 {
      margin: 0;
      color: var(--accent-dark);
      font-size: 1.4rem;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      color: var(--muted);
      cursor: pointer;
      padding: 0;
      width: 32px;
      height: 32px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 8px;
      transition: all 0.2s ease;
    }

    .close-btn:hover {
      background: rgba(86,124,141,0.1);
      color: var(--accent-dark);
    }

    .appointment-detail {
      margin-bottom: 16px;
      padding: 12px;
      background: rgba(86,124,141,0.03);
      border-radius: 10px;
    }

    .detail-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
    }

    .detail-label {
      font-weight: 600;
      color: var(--accent-mid);
      font-size: 0.9rem;
    }

    .detail-value {
      color: var(--accent-dark);
      font-weight: 500;
    }

    .status-badge {
      padding: 4px 12px;
      border-radius: 20px;
      font-size: 0.8rem;
      font-weight: 600;
      text-transform: capitalize;
    }

    .status-scheduled { background: var(--soft-2); color: var(--accent-dark); }
    .status-confirmed { background: #C8E6C9; color: #2E7D32; }
    .status-cancelled { background: #FFCDD2; color: #C62828; }
    .status-completed { background: #E0E0E0; color: #424242; }

    /* Form styles */
    input[type="date"], input[type="time"], textarea {
      border: 1px solid rgba(86,124,141,0.2);
      padding: 8px 12px;
      border-radius: 8px;
      font-family: inherit;
      font-size: 0.95rem;
      transition: border-color 0.2s ease;
    }

    input[type="date"]:focus, input[type="time"]:focus, textarea:focus {
      outline: none;
      border-color: var(--accent-mid);
    }

    textarea {
      width: 100%;
      min-height: 80px;
      resize: vertical;
    }

    /* Search form styles */
    .search-form {
      display: contents;
    }

    .clear-search {
      background: none;
      border: none;
      cursor: pointer;
      color: var(--muted);
      padding: 4px;
      margin-left: 4px;
    }

    .clear-search:hover {
      color: var(--accent-dark);
    }

    /* Enhanced appointment details */
    .appointment-service {
        background: rgba(86,124,141,0.05);
        padding: 12px;
        border-radius: 8px;
        margin: 12px 0;
    }

    .service-name {
        font-weight: 600;
        color: var(--accent-dark);
        margin-bottom: 4px;
    }

    .service-description {
        color: var(--muted);
        font-size: 0.9rem;
    }

    /* Notifications Dropdown Styles */
    .notifications-dropdown {
        position: absolute;
        top: 100%;
        right: 0;
        width: 400px;
        max-height: 500px;
        overflow-y: auto;
        background: var(--white);
        border-radius: 12px;
        box-shadow: 0 12px 40px rgba(0,0,0,0.15);
        border: 1px solid rgba(86,124,141,0.1);
        z-index: 1000;
        display: none;
        margin-top: 8px;
    }

    .notifications-dropdown.active {
        display: block;
    }

    .notification-item {
        padding: 16px;
        border-bottom: 1px solid rgba(86,124,141,0.08);
        cursor: pointer;
        transition: background 0.2s ease;
    }

    .notification-item:hover {
        background: rgba(86,124,141,0.03);
    }

    .notification-item:last-child {
        border-bottom: none;
    }

    .notification-title {
        font-weight: 600;
        color: var(--accent-dark);
        margin-bottom: 6px;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .notification-content {
        color: var(--muted);
        font-size: 0.9rem;
        line-height: 1.4;
    }

    .notification-time {
        font-size: 0.8rem;
        color: var(--muted);
        margin-top: 6px;
    }

    .urgent-notification {
        border-left: 4px solid var(--hint-red);
        background: rgba(194,59,34,0.03);
    }

    .notification-badge {
        position: absolute;
        top: -6px;
        right: -6px;
        background: var(--hint-red);
        color: var(--white);
        border-radius: 50%;
        width: 20px;
        height: 20px;
        font-size: 0.7rem;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
    }

    .relative {
        position: relative;
    }

    /* Support Ticket Styles */
    .ticket-form {
        display: flex;
        flex-direction: column;
        gap: 16px;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    .form-group label {
        font-weight: 600;
        color: var(--accent-mid);
        font-size: 0.9rem;
    }

    .form-control {
        border: 1px solid rgba(86,124,141,0.2);
        padding: 10px 12px;
        border-radius: 8px;
        font-family: inherit;
        font-size: 0.95rem;
        transition: border-color 0.2s ease;
    }

    .form-control:focus {
        outline: none;
        border-color: var(--accent-mid);
    }

    .priority-select {
        background: var(--white);
    }

    .btn-primary {
        background: linear-gradient(90deg, var(--soft-1), var(--soft-2));
        color: var(--accent-dark);
        border: none;
        padding: 10px 20px;
        border-radius: 8px;
        cursor: pointer;
        font-weight: 600;
        transition: transform 0.2s ease;
    }

    .btn-primary:hover {
        transform: translateY(-1px);
    }

    .btn-secondary {
        background: transparent;
        border: 1px solid rgba(86,124,141,0.2);
        padding: 10px 20px;
        border-radius: 8px;
        cursor: pointer;
        color: var(--accent-dark);
    }

/* Enhanced responsive design for tablets and phones */
    @media (max-width: 1100px){
      .wrap{flex-direction:column;padding:12px}
      .sidebar{width:100%;height:auto;position:relative;top:auto;border-radius:12px;margin-bottom:18px}
      .sidebar.collapsed{width:100%;}
      .sidebar.collapsed .logo-text,
      .sidebar.collapsed .label,
      .sidebar.collapsed .bottom-item .label {
        opacity: 1;
        width: auto;
      }
      .sidebar.collapsed .logo{justify-content:flex-start;padding:0 14px;}
      .sidebar.collapsed .nav-item{justify-content:flex-start;padding:10px 12px;}
      .sidebar.collapsed .bottom-item{justify-content:flex-start;padding:12px 10px;}
      .top-card{min-height:200px;flex-direction:column;align-items:flex-start;gap:20px}
      .greeting{max-width:100%}
      .stats-section{flex-direction:row;overflow:auto;padding-bottom:8px}
      .top-actions{width:100%;justify-content:space-between}
      .search{flex:1;min-width:auto}
      .notifications-dropdown {
          width: 350px;
          right: -50px;
      }
    }

    @media (max-width: 768px){
      .app-shell{margin:12px auto;padding:12px;}
      .wrap{padding:0;}
      .top-card{padding:20px;min-height:auto;}
      .greeting h1{font-size:1.4rem;}
      .patient-summary{flex-direction:column;align-items:flex-start;gap:10px;}
      .patient-summary .avatar{width:60px;height:60px;}
      .stats-section{gap:10px;}
      .stat{flex:1 1 100%;min-width:auto;}
      .top-actions{flex-wrap:wrap;gap:8px;}
      .search{min-width:200px;}
      .icon-btn{width:40px;height:40px;}
      .modal-content {
        padding: 20px;
        margin: 20px;
      }
      .notifications-dropdown {
          width: 300px;
          right: -30px;
      }
      /* Responsive design for search results */
      .search-result-item {
          padding: 16px;
      }
      
      .search-result-item > div {
          flex-direction: column;
          gap: 12px;
      }
      
      .search-result-item .dot {
          width: 50px;
          height: 50px;
      }
    }

    @media (max-width: 480px){
      .app-shell{padding:8px;}
      .top-card{padding:16px;}
      .greeting h1{font-size:1.3rem;}
      .search{min-width:150px;}
      .search input{width:120px;}
      .top-actions{gap:6px;}
      .icon-btn{width:36px;height:36px;}
      .stats-section{flex-direction:column;}
      .mid-columns{gap:12px;}
      .appointment-item{flex-direction:column;align-items:flex-start;gap:12px;}
      .appointment-item div:last-child{flex-direction:row;width:100%;justify-content:flex-end;}
      .modal-content {
        padding: 16px;
        margin: 10px;
      }
      .modal-header h2 {
        font-size: 1.2rem;
      }
      .detail-row {
        flex-direction: column;
        align-items: flex-start;
        gap: 4px;
      }
      .search-result-item {
          padding: 12px;
      }
      
      .search-result-item > div {
          gap: 8px;
      }
      .notifications-dropdown {
          width: 280px;
          right: -20px;
      }
    }

    @media (max-width: 360px){
      .greeting h1{font-size:1.2rem;}
      .search{min-width:120px;}
      .search input{width:90px;font-size:0.9rem;}
      .top-actions{gap:4px;}
      .notifications-dropdown {
          width: 250px;
          right: -10px;
      }
    }
  </style>
</head>
<body>

<div class="app-shell">
  <div class="wrap">
    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
      <div class="logo">
        <div class="logo-mark">D</div>
        <div class="logo-text">Dokotela</div>
      </div>

      <nav class="sidebar-nav" id="sidebarNav">
        <div class="nav-item active" data-section="overview" onclick="showSection('overview')">
          <div class="icon"><i class="fa-solid fa-house"></i></div>
          <div class="label">Overview</div>
        </div>

        <a class="nav-item" href="appointments.php">
          <div class="icon"><i class="fa-regular fa-calendar-days"></i></div>
          <div class="label">Appointments</div>
        </a>

        <a class="nav-item" href="medical_records.php">
          <div class="icon"><i class="fa-regular fa-file-lines"></i></div>
          <div class="label">Medical Records</div>
        </a>

        <a class="nav-item" href="payments.php">
          <div class="icon"><i class="fa-solid fa-wallet"></i></div>
          <div class="label">Payments</div>
        </a>

        <a class="nav-item" href="support_tickets.php">
          <div class="icon"><i class="fa-solid fa-headset"></i></div>
          <div class="label">Support Tickets</div>
        </a>

        <a class="nav-item bottom-item" href="patient_settings.php" style="margin-top:auto">
          <div class="icon"><i class="fa-solid fa-gear"></i></div>
          <div class="label">Settings</div>
        </a>
      </nav>

      <div style="padding:12px;border-top:1px solid rgba(255,255,255,0.06);">
        <div style="display:flex;gap:10px;align-items:center">
          <div style="width:56px;height:56px;border-radius:10px;overflow:hidden"><img src="../assets/default-avatar.png" alt="avatar" style="width:100%;height:100%;object-fit:cover"></div>
          <div style="flex:1">
            <div style="font-weight:700"><?php echo htmlspecialchars($patientName); ?></div>
            <div class="muted" style="font-size:0.9rem">Patient</div>
            <div style="margin-top:8px"><a href="../auth/logout.php" style="color:var(--white);text-decoration:none;font-size:0.9rem">Logout</a></div>
          </div>
        </div>
      </div>
    </aside>

    <!-- CENTER -->
    <main class="center">
      <!-- GREETING (expanded) -->
      <div class="top-card" role="region" aria-label="Welcome">
        <div class="greeting" role="article">
          <h1>Welcome back, <?php echo htmlspecialchars($patientName); ?>!</h1>
          <p class="muted">You have <?php echo intval($upcomingAppointments); ?> upcoming appointment<?php echo ($upcomingAppointments==1?'':'s'); ?>. Manage your health quickly — view appointments, records and prescriptions from here.</p>

          <div class="patient-summary">
            <div class="avatar"><img src="../assets/default-avatar.png" alt="avatar"></div>
            <div class="meta">
              <div style="font-weight:700"><?php echo htmlspecialchars($patientName); ?></div>
              <small class="muted">Patient ID: <?php echo htmlspecialchars($patientID); ?></small>
            </div>
          </div>
        </div>

        <div class="top-actions" aria-hidden="false">
          <form method="GET" action="" class="search-form" style="display:contents">
            <div class="search" title="Search records, appointments, payments...">
              <i class="fa-solid fa-magnifying-glass" style="opacity:0.7"></i>
              <input 
                id="globalSearch" 
                name="search"
                placeholder="Search appointments, records, payments..." 
                value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>"
                oninput="debouncedSearch(this.value)" 
              />
              <?php if(isset($_GET['search']) && !empty($_GET['search'])): ?>
                <button type="button" onclick="clearSearch()" class="clear-search" style="background:none;border:none;cursor:pointer;color:var(--muted);padding:4px;">
                  <i class="fa-solid fa-times"></i>
                </button>
              <?php endif; ?>
            </div>
          </form>

          <!-- Enhanced Notifications Button -->
          <div class="relative">
            <button class="icon-btn" id="notifBtn" title="Notifications" onclick="toggleNotifications()">
              <i class="fa-solid fa-bell" style="font-size:18px"></i>
              <?php if($unreadNotifications > 0): ?>
                <span class="notification-badge"><?php echo $unreadNotifications; ?></span>
              <?php endif; ?>
            </button>
            <div class="notifications-dropdown" id="notificationsDropdown">
              <div style="padding:16px;border-bottom:1px solid rgba(86,124,141,0.1);">
                <h4 style="margin:0;color:var(--accent-dark);">Notifications</h4>
              </div>
              <?php if(count($notifications) === 0): ?>
                <div class="notification-item">
                  <div class="notification-content">No new notifications</div>
                </div>
              <?php else: ?>
                <?php foreach($notifications as $notification): ?>
                  <div class="notification-item <?php echo $notification['isUrgent'] ? 'urgent-notification' : ''; ?>">
                    <div class="notification-title">
                      <?php if($notification['isUrgent']): ?>
                        <i class="fa-solid fa-circle-exclamation" style="color:var(--hint-red);"></i>
                      <?php endif; ?>
                      <?php echo htmlspecialchars($notification['title']); ?>
                    </div>
                    <div class="notification-content">
                      <?php echo htmlspecialchars($notification['content']); ?>
                    </div>
                    <div class="notification-time">
                      <?php echo date('M j, Y g:i A', strtotime($notification['createdAt'])); ?>
                    </div>
                  </div>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>
          </div>

          <button class="icon-btn" id="toggleSidebarBtn" title="Toggle sidebar" onclick="toggleSidebar()">
            <i class="fa-solid fa-bars" style="font-size:18px"></i>
          </button>
        </div>

        <!-- subtle divider line at bottom of greeting -->
        <div style="position:absolute;left:24px;right:24px;bottom:-12px" aria-hidden="true">
          <div class="section-divider"></div>
        </div>
      </div>

      <!-- Search Results Section -->
      <?php if(isset($_GET['search']) && !empty(trim($_GET['search']))): ?>
      <div class="mid-columns">
          <div class="card" aria-label="search results">
              <div style="display: flex; justify-content: between; align-items: center; margin-bottom: 16px;">
                  <h3 style="margin: 0;">Search Results</h3>
                  <button class="view-all-btn" onclick="clearSearch()" style="background: transparent; border: 1px solid rgba(86,124,141,0.2); padding: 6px 12px; border-radius: 8px; cursor: pointer;">
                      Clear Search
                  </button>
              </div>
              
              <p class="muted" style="margin-bottom: 16px;">
                  Found <?php echo count($searchResults); ?> results for "<?php echo htmlspecialchars($_GET['search']); ?>"
              </p>

              <div class="search-results-list">
                  <?php if(count($searchResults) === 0): ?>
                      <div class="search-result-item" style="background: linear-gradient(180deg, rgba(255,255,255,0.16), rgba(255,255,255,0.08)); padding: 20px; border-radius: 10px; border: 1px solid rgba(86,124,141,0.03); text-align: center;">
                          <div class="appointment-meta">
                              <div class="dot" style="margin: 0 auto 12px auto;"><i class="fa-solid fa-search"></i></div>
                              <div>
                                  <div style="font-weight:600; margin-bottom: 8px;">No results found</div>
                                  <small class="muted">Try searching with different keywords like "appointment", "payment", or doctor names</small>
                              </div>
                          </div>
                      </div>
                  <?php else: ?>
                      <?php foreach($searchResults as $result): ?>
                          <div class="search-result-item">
                              <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 16px;">
                                  <!-- Left side: Icon and content -->
                                  <div style="display: flex; gap: 16px; align-items: flex-start; flex: 1;">
                                      <div class="dot" style="background: <?php 
                                          echo $result['type'] === 'appointment' ? 'linear-gradient(180deg,var(--soft-2),var(--soft-1))' : 
                                              ($result['type'] === 'record' ? 'linear-gradient(180deg,#C8E6C9,#A5D6A7)' : 'linear-gradient(180deg,#FFE0B2,#FFCC80)'); 
                                      ?>; flex-shrink: 0;">
                                          <i class="fa-solid <?php 
                                              echo $result['type'] === 'appointment' ? 'fa-calendar-check' : 
                                                  ($result['type'] === 'record' ? 'fa-file-medical' : 'fa-wallet'); 
                                          ?>"></i>
                                      </div>
                                      
                                      <div style="flex: 1;">
                                          <div style="font-weight: 700; font-size: 1.1rem; margin-bottom: 8px; color: var(--accent-dark);">
                                              <?php echo htmlspecialchars($result['title'] ?? 'Untitled'); ?>
                                          </div>
                                          
                                          <div style="color: var(--muted); margin-bottom: 12px; line-height: 1.4;">
                                              <?php echo htmlspecialchars($result['description'] ?? 'No description available'); ?>
                                          </div>
                                          
                                          <div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
                                              <span class="status-badge <?php echo 'status-' . strtolower($result['status'] ?? 'unknown'); ?>" style="font-size: 0.8rem;">
                                                  <?php echo htmlspecialchars($result['status'] ?? 'Unknown'); ?>
                                              </span>
                                              <span style="color: var(--muted); font-size: 0.8rem; text-transform: capitalize;">
                                                  <i class="fa-solid <?php 
                                                      echo $result['type'] === 'appointment' ? 'fa-calendar' : 
                                                          ($result['type'] === 'record' ? 'fa-file' : 'fa-credit-card'); 
                                                  ?>" style="margin-right: 4px;"></i>
                                                  <?php echo htmlspecialchars($result['type'] ?? 'item'); ?>
                                              </span>
                                              <?php if(isset($result['date'])): ?>
                                                  <span style="color: var(--muted); font-size: 0.8rem;">
                                                      <i class="fa-regular fa-clock" style="margin-right: 4px;"></i>
                                                      <?php echo htmlspecialchars($result['date']); ?>
                                                  </span>
                                              <?php endif; ?>
                                          </div>
                                      </div>
                                  </div>
                                  
                                  <!-- Right side: Action button -->
                                  <div style="flex-shrink: 0;">
                                      <?php if($result['type'] === 'appointment'): ?>
                                          <button class="view-all-btn" onclick="showAppointmentDetails(<?php echo htmlspecialchars(json_encode([
                                              'appointmentID' => $result['appointmentID'],
                                              'appointmentDate' => $result['appointmentDate'],
                                              'appointmentTime' => $result['appointmentTime'],
                                              'status' => $result['status'],
                                              'reason' => $result['reason'] ?? 'Consultation',
                                              'notes' => $result['notes'] ?? '',
                                              'doctorName' => $result['doctorName'] ?? 'Doctor',
                                              'doctorEmail' => $result['doctorEmail'] ?? '',
                                              'doctorPhone' => $result['doctorPhone'] ?? '',
                                              'serviceName' => $result['serviceName'] ?? '',
                                              'serviceDescription' => $result['serviceDescription'] ?? '',
                                              'specialty' => $result['specialty'] ?? ''
                                          ]), ENT_QUOTES, 'UTF-8'); ?>)" style="background: transparent; border: 1px solid rgba(86,124,141,0.2); padding: 8px 16px; border-radius: 8px; cursor: pointer; white-space: nowrap;">
                                              View Details
                                          </button>
                                      <?php elseif($result['type'] === 'record'): ?>
                                          <a href="medical_records.php?record=<?php echo $result['id']; ?>" class="view-all-btn" style="background: transparent; border: 1px solid rgba(86,124,141,0.2); padding: 8px 16px; border-radius: 8px; cursor: pointer; text-decoration: none; white-space: nowrap; display: inline-block;">
                                              View Record
                                          </a>
                                      <?php else: ?>
                                          <a href="payments.php?view=<?php echo $result['id']; ?>" class="view-all-btn" style="background: transparent; border: 1px solid rgba(86,124,141,0.2); padding: 8px 16px; border-radius: 8px; cursor: pointer; text-decoration: none; white-space: nowrap; display: inline-block;">
                                              View Payment
                                          </a>
                                      <?php endif; ?>
                                  </div>
                              </div>
                          </div>
                      <?php endforeach; ?>
                  <?php endif; ?>
              </div>
          </div>
      </div>
      <?php endif; ?>

      <!-- STATS -->
      <section class="stats-section" aria-label="key statistics">
        <div class="stat" id="stat-appointments">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <h3>Upcoming Appointments</h3>
            <div class="badge-icon"><i class="fa-solid fa-calendar-check"></i></div>
          </div>
          <div class="value" data-value="<?php echo $upcomingAppointments; ?>"><?php echo $upcomingAppointments; ?></div>
          <p class="muted">View, reschedule or join telehealth sessions.</p>
          <div style="margin-top:8px"><a class="view-all" href="appointments.php" style="text-decoration:none;color:var(--accent-mid);font-weight:600">View all appointments</a></div>
        </div>

        <div class="stat" id="stat-records">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <h3>Medical Records</h3>
            <div class="badge-icon"><i class="fa-solid fa-file-medical"></i></div>
          </div>
          <div class="value" data-value="<?php echo $totalRecords; ?>"><?php echo $totalRecords; ?></div>
          <p class="muted">All clinical notes and test results are stored chronologically.</p>
          <div style="margin-top:8px"><a class="view-all" href="medical_records.php" style="text-decoration:none;color:var(--accent-mid);font-weight:600">View records</a></div>
        </div>

        <div class="stat" id="stat-prescriptions">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <h3>Active Prescriptions</h3>
            <div class="badge-icon"><i class="fa-solid fa-pills"></i></div>
          </div>
          <div class="value" data-value="<?php echo $activePrescriptions; ?>"><?php echo $activePrescriptions; ?></div>
          <p class="muted">Quick access to your current meds and refill options.</p>
          <div style="margin-top:8px"><a class="view-all" href="prescriptions.php" style="text-decoration:none;color:var(--accent-mid);font-weight:600">Manage prescriptions</a></div>
        </div>

        <div class="stat" id="stat-support">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <h3>Support Tickets</h3>
            <div class="badge-icon"><i class="fa-solid fa-headset"></i></div>
          </div>
          <div class="value" data-value="<?php echo $openTickets; ?>"><?php echo $openTickets; ?></div>
          <p class="muted">Open support requests and inquiries.</p>
          <div style="margin-top:8px">
            <a class="view-all" href="#" onclick="openSupportTicketModal(); return false;" style="text-decoration:none;color:var(--accent-mid);font-weight:600;margin-right:12px">New Ticket</a>
            <a class="view-all" href="support_tickets.php" style="text-decoration:none;color:var(--accent-mid);font-weight:600">View All</a>
          </div>
        </div>
      </section>

      <!-- subtle divider between stats and main -->
      <div class="section-divider" style="margin-top:4px"></div>

      <!-- MAIN MIDDLE: upcoming appointments -->
      <div class="mid-columns">
        <div class="card" aria-label="upcoming appointments">
          <h3 style="margin:0 0 12px 0">Upcoming Appointments</h3>

          <div class="appointments-list">
            <?php if(count($appointmentsList)===0): ?>
              <div class="appointment-item">
                <div class="appointment-meta">
                  <div class="dot"><i class="fa-regular fa-calendar"></i></div>
                  <div>
                    <div style="font-weight:600">No upcoming appointments</div>
                    <small class="muted">You don't have appointments scheduled. Book one when you need it.</small>
                  </div>
                </div>
                <div>
                  <button class="view-all-btn" onclick="bookAppointment()" style="background:linear-gradient(90deg,var(--soft-1),var(--soft-2));color:var(--accent-dark);border:0;padding:8px 10px;border-radius:8px;cursor:pointer">Book</button>
                </div>
              </div>
            <?php else: foreach($appointmentsList as $ap):
              $date = htmlspecialchars($ap['appointmentDate']);
              $time = htmlspecialchars($ap['appointmentTime']);
              $doctor = htmlspecialchars($ap['doctorName'] ?? 'Doctor');
              $serviceName = htmlspecialchars($ap['serviceName'] ?? 'General Consultation');
              $specialty = htmlspecialchars($ap['specialty'] ?? 'General Practitioner');
              $status = htmlspecialchars($ap['status'] ?? 'scheduled');
            ?>
              <div class="appointment-item">
                <div class="appointment-meta">
                  <div class="dot"><i class="fa-solid fa-user-doctor"></i></div>
                  <div class="appointment-details">
                    <div style="font-weight:700"><?php echo $serviceName; ?></div>
                    <small class="muted"><?php echo $doctor; ?> • <?php echo $specialty; ?></small>
                    <small class="muted"><?php echo $date . ' • ' . $time; ?></small>
                  </div>
                </div>

                <div style="display:flex;flex-direction:column;gap:6px;align-items:flex-end">
                  <!-- Join Consultation -->
                  <button
                    class="view-all-btn"
                    style="background:linear-gradient(90deg,var(--soft-1),var(--soft-2));color:var(--accent-dark);border:0;padding:8px 10px;border-radius:8px;cursor:pointer;white-space:nowrap"
                    onclick="joinConsultation(<?php echo $ap['appointmentID']; ?>)"
                  >
                    <i class="fa-solid fa-video" style="margin-right:8px"></i> Join Consultation
                  </button>

                  <!-- View Appointment: open the details modal -->
                  <button
                    class="view-all-btn"
                    style="background:transparent;border:1px solid rgba(86,124,141,0.06);padding:8px 10px;border-radius:8px;cursor:pointer;white-space:nowrap"
                    onclick="showAppointmentDetails(<?php echo htmlspecialchars(json_encode($ap)); ?>)"
                  >
                    <i class="fa-solid fa-eye" style="margin-right:8px"></i> View Appointment
                  </button>
                </div>
              </div>
            <?php endforeach; endif; ?>
          </div>
        </div>
      </div>

    </main>
  </div>
</div>

<!-- Appointment Details Modal -->
<div class="modal-overlay" id="appointmentModal">
  <div class="modal-content">
    <div class="modal-header">
      <h2>Appointment Details</h2>
      <button class="close-btn" onclick="closeModal()">&times;</button>
    </div>
    <div id="appointmentDetailsContent">
      
    </div>
  </div>
</div>

<!-- Support Ticket Modal -->
<div class="modal-overlay" id="supportTicketModal">
  <div class="modal-content">
    <div class="modal-header">
      <h2>Submit Support Ticket</h2>
      <button class="close-btn" onclick="closeSupportTicketModal()">&times;</button>
    </div>
    <div id="supportTicketContent">
      <form id="supportTicketForm" class="ticket-form">
        <input type="hidden" id="ticketUserId" value="<?php echo $userID; ?>">
        
        <div class="form-group">
          <label for="ticketSubject">Subject *</label>
          <input type="text" id="ticketSubject" class="form-control" placeholder="Brief description of your issue" required>
        </div>
        
        <div class="form-group">
          <label for="ticketPriority">Priority *</label>
          <select id="ticketPriority" class="form-control priority-select" required>
            <option value="low">Low</option>
            <option value="normal" selected>Normal</option>
            <option value="high">High</option>
            <option value="urgent">Urgent</option>
          </select>
        </div>
        
        <div class="form-group">
          <label for="ticketDescription">Description *</label>
          <textarea id="ticketDescription" class="form-control" rows="6" placeholder="Please provide detailed information about your issue..." required></textarea>
        </div>
        
        <div style="margin-top: 20px; display: flex; gap: 12px; justify-content: flex-end;">
          <button type="button" class="btn-secondary" onclick="closeSupportTicketModal()">Cancel</button>
          <button type="submit" class="btn-primary">Submit Ticket</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- toast -->
<div id="toast" style="position:fixed;right:18px;bottom:18px;background:var(--accent-dark);color:var(--white);padding:10px 16px;border-radius:10px;box-shadow:0 8px 30px rgba(47,65,86,0.12);display:none;z-index:60"></div>

<script>
  const sidebar = document.getElementById('sidebar');
  let currentAppointmentId = null;
  let currentAppointmentData = null;

  function toggleSidebar(){
    sidebar.classList.toggle('collapsed');
    localStorage.setItem('dok_sidebar_collapsed', sidebar.classList.contains('collapsed'));
  }

  (function(){
    if(localStorage.getItem('dok_sidebar_collapsed') === 'true'){
      sidebar.classList.add('collapsed');
    }
  })();

  function showSection(sectionId){
    document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
    const btn = document.querySelector(`[data-section="${sectionId}"]`);
    if(btn) btn.classList.add('active');
  }

  function showToast(msg, timeout=2200){
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.style.display = 'block';
    setTimeout(()=> t.style.display='none', timeout);
  }

  function animateCounters(){
    document.querySelectorAll('.value').forEach(el=>{
      const target = parseInt(el.getAttribute('data-value')) || 0;
      let cur = 0;
      const step = Math.max(1, Math.floor(target/20));
      const id = setInterval(()=>{
        cur += step;
        if(cur >= target){ el.textContent = target; clearInterval(id); }
        else el.textContent = cur;
      }, 25);
    });
  }

  let searchTimer;
  function debouncedSearch(q){
    clearTimeout(searchTimer);
    searchTimer = setTimeout(()=> {
        if (q.trim()) {
            document.querySelector('.search-form').submit();
        } else {
            window.location.href = window.location.pathname;
        }
    }, 800);
  }

  function clearSearch() {
    window.location.href = window.location.pathname;
  }

  // Enhanced notifications functionality
  function toggleNotifications() {
    const dropdown = document.getElementById('notificationsDropdown');
    dropdown.classList.toggle('active');
  }

  // Close notifications when clicking outside
  document.addEventListener('click', function(e) {
    const notifBtn = document.getElementById('notifBtn');
    const dropdown = document.getElementById('notificationsDropdown');
    if (!notifBtn.contains(e.target) && !dropdown.contains(e.target)) {
      dropdown.classList.remove('active');
    }
  });

  function bookAppointment(){ window.location.href='doctorinfo.php'; }

  // Join Consultation - Redirect to API/Video Call
  function joinConsultation(appointmentId) {
    // Show loading state
    showToast('Connecting to consultation...');
    
    // In a real implementation, this would redirect to your video API
    // For now, we'll simulate the API call
    fetch('join_consultation_api.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            appointmentId: appointmentId,
            patientId: <?php echo $patientID; ?>,
            timestamp: new Date().toISOString()
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success && data.consultationUrl) {
            // Redirect to the consultation URL
            window.open(data.consultationUrl, '_blank');
            showToast('Consultation session started');
        } else {
            showToast('Unable to join consultation: ' + (data.message || 'Please try again'));
        }
    })
    .catch(error => {
        console.error('Error joining consultation:', error);
        showToast('Error connecting to consultation service');
    });
  }

  // Enhanced Appointment Details Modal with Service Information
  function showAppointmentDetails(appointment) {
    const modal = document.getElementById('appointmentModal');
    const content = document.getElementById('appointmentDetailsContent');
    
    // Format date and time for display
    const appointmentDate = new Date(appointment.appointmentDate + 'T' + appointment.appointmentTime);
    const formattedDate = appointmentDate.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
    const formattedTime = appointmentDate.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });

    // Get status class
    const statusClass = `status-${appointment.status.toLowerCase()}`;

    // Service information HTML
    const serviceInfo = appointment.serviceName ? 
      `<div class="appointment-service">
        <div class="service-name">${appointment.serviceName}</div>
        ${appointment.serviceDescription ? `<div class="service-description">${appointment.serviceDescription}</div>` : ''}
      </div>` : '';

    // Populate modal content
    content.innerHTML = 
      `<div class="appointment-detail">
        <div class="detail-row">
          <span class="detail-label">Appointment ID:</span>
          <span class="detail-value">#${appointment.appointmentID}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Date:</span>
          <span class="detail-value">${formattedDate}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Time:</span>
          <span class="detail-value">${formattedTime}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Doctor:</span>
          <span class="detail-value">${appointment.doctorName || 'Not assigned'}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Specialty:</span>
          <span class="detail-value">${appointment.specialty || 'General Practitioner'}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Contact:</span>
          <span class="detail-value">${appointment.doctorEmail || 'N/A'} ${appointment.doctorPhone ? '• ' + appointment.doctorPhone : ''}</span>
        </div>
        ${serviceInfo}
        <div class="detail-row">
          <span class="detail-label">Reason:</span>
          <span class="detail-value">${appointment.reason || 'General Consultation'}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Status:</span>
          <span class="detail-value status-badge ${statusClass}">${appointment.status}</span>
        </div>
        ${appointment.notes ? `
        <div class="detail-row">
          <span class="detail-label">Notes:</span>
          <span class="detail-value">${appointment.notes}</span>
        </div>
        ` : ''}
      </div>
      <div style="margin-top: 20px; display: flex; gap: 12px; justify-content: flex-end;">
        <button class="view-all-btn" onclick="closeModal()" style="background:transparent;border:1px solid rgba(86,124,141,0.2);padding:8px 16px;border-radius:8px;cursor:pointer">Close</button>
        <button class="view-all-btn" onclick="redirectToAppointmentSection(${appointment.appointmentID})" style="background:linear-gradient(90deg,var(--soft-1),var(--soft-2));color:var(--accent-dark);border:0;padding:8px 16px;border-radius:8px;cursor:pointer">View in Appointments</button>
      </div>`;

    // Show modal
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  // Redirect to specific appointment in appointments section
  function redirectToAppointmentSection(appointmentId) {
    closeModal();
    window.location.href = `appointments.php?view=${appointmentId}`;
  }

  function closeModal() {
    const modal = document.getElementById('appointmentModal');
    modal.classList.remove('active');
    document.body.style.overflow = 'auto';
  }

  // Support Ticket functionality
  function openSupportTicketModal() {
    const modal = document.getElementById('supportTicketModal');
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeSupportTicketModal() {
    const modal = document.getElementById('supportTicketModal');
    modal.classList.remove('active');
    document.body.style.overflow = 'auto';
  }

  // Handle support ticket form submission
  document.getElementById('supportTicketForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = {
        userID: document.getElementById('ticketUserId').value,
        subject: document.getElementById('ticketSubject').value,
        priority: document.getElementById('ticketPriority').value,
        description: document.getElementById('ticketDescription').value
    };
    
    // Submit ticket via AJAX
    fetch('submit_support_ticket.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('Support ticket submitted successfully! Ticket ID: ' + data.ticketId);
            closeSupportTicketModal();
            // Reset form
            document.getElementById('supportTicketForm').reset();
            // Reload to update ticket count
            setTimeout(() => location.reload(), 1500);
        } else {
            showToast('Error submitting ticket: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('Error submitting support ticket');
    });
  });

  // Close modals when clicking outside
  document.getElementById('appointmentModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeModal();
    }
  });

  document.getElementById('supportTicketModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeSupportTicketModal();
    }
  });

  // Close modals with Escape key
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      closeModal();
      closeSupportTicketModal();
    }
  });

  (function init(){
    animateCounters();
  })();
</script>
</body>
</html>