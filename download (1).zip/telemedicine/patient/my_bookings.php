<?php
include('../db_connect.php');

$patient_id = $_GET['patient_id'];

$query = "
    SELECT b.booking_id, s.slot_date, s.start_time, s.end_time, d.specialty
    FROM booking_service b
    JOIN appointment_slots s ON b.slot_id = s.slot_id
    JOIN Doctor d ON b.doctor_id = d.doctorID
    WHERE b.patient_id = ?
    ORDER BY s.slot_date, s.start_time
";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();

$bookings = [];
while ($row = $result->fetch_assoc()) {
    $bookings[] = $row;
}

echo json_encode($bookings);
?>
