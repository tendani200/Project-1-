<?php
// reschedule_appointment.php
session_start();
include '../db_connect.php';

header('Content-Type: application/json');

// Check if patient is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Patient') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    $appointmentId = intval($input['appointmentId']);
    $newDate = $conn->real_escape_string(trim($input['newDate']));
    $newTime = $conn->real_escape_string(trim($input['newTime']));
    $reason = $conn->real_escape_string(trim($input['reason'] ?? ''));
    $patientId = $_SESSION['patientID'];

    // Validate date and time
    if (empty($newDate) || empty($newTime)) {
        echo json_encode(['success' => false, 'message' => 'Date and time are required']);
        exit();
    }

    // Check if the new datetime is in the future
    $newDateTime = $newDate . ' ' . $newTime;
    if (strtotime($newDateTime) <= time()) {
        echo json_encode(['success' => false, 'message' => 'Please select a future date and time']);
        exit();
    }

    try {
        // Start transaction
        $conn->begin_transaction();

        // Verify the appointment belongs to the patient and can be rescheduled
        $checkStmt = $conn->prepare("
            SELECT a.appointmentID, a.status, a.appointmentDate, a.appointmentTime, 
                   a.doctorID, CONCAT(u.firstName, ' ', u.lastName) as doctorName,
                   u.email as doctorEmail
            FROM Appointments a 
            LEFT JOIN User u ON a.doctorID = u.userID
            WHERE a.appointmentID = ? AND a.patientID = ? 
            AND a.status NOT IN ('cancelled', 'completed')
        ");
        $checkStmt->bind_param("ii", $appointmentId, $patientId);
        $checkStmt->execute();
        $result = $checkStmt->get_result();
        
        if ($result->num_rows === 0) {
            throw new Exception('Appointment not found or cannot be rescheduled');
        }

        $appointment = $result->fetch_assoc();

        // Check if the new time slot is available for the doctor
        $availabilityStmt = $conn->prepare("
            SELECT appointmentID 
            FROM Appointments 
            WHERE doctorID = ? 
            AND appointmentDate = ? 
            AND appointmentTime = ? 
            AND status NOT IN ('cancelled')
            AND appointmentID != ?
        ");
        $availabilityStmt->bind_param("issi", 
            $appointment['doctorID'], 
            $newDate, 
            $newTime, 
            $appointmentId
        );
        $availabilityStmt->execute();
        $availabilityResult = $availabilityStmt->get_result();
        
        if ($availabilityResult->num_rows > 0) {
            throw new Exception('Selected time slot is not available. Please choose a different time.');
        }

        // Store old appointment details for audit
        $oldDate = $appointment['appointmentDate'];
        $oldTime = $appointment['appointmentTime'];

        // Update appointment with new date/time
        $updateStmt = $conn->prepare("
            UPDATE Appointments 
            SET appointmentDate = ?, 
                appointmentTime = ?,
                status = 'rescheduled',
                rescheduledAt = NOW(),
                rescheduledBy = 'patient',
                rescheduleReason = ?
            WHERE appointmentID = ? AND patientID = ?
        ");
        $updateStmt->bind_param("sssii", $newDate, $newTime, $reason, $appointmentId, $patientId);
        
        if (!$updateStmt->execute()) {
            throw new Exception('Failed to reschedule appointment');
        }

        // Insert into audit log
        $auditStmt = $conn->prepare("
            INSERT INTO AppointmentAuditLog 
            (appointmentID, action, actionBy, oldDate, oldTime, newDate, newTime, reason, createdAt) 
            VALUES (?, 'rescheduled', 'patient', ?, ?, ?, ?, ?, NOW())
        ");
        $auditStmt->bind_param("isssss", $appointmentId, $oldDate, $oldTime, $newDate, $newTime, $reason);
        $auditStmt->execute();

        // Commit transaction
        $conn->commit();

        // Send notification to doctor
        sendRescheduleNotification($appointment, $oldDate, $oldTime, $newDate, $newTime, $reason);

        echo json_encode([
            'success' => true, 
            'message' => 'Appointment rescheduled successfully'
        ]);

    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        error_log("Reschedule appointment error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

function sendRescheduleNotification($appointment, $oldDate, $oldTime, $newDate, $newTime, $reason) {
    // Implement email notification to doctor
    // This is a placeholder - implement your email service here
    /*
    $to = $appointment['doctorEmail'];
    $subject = "Appointment Rescheduled Notification";
    $message = "
        Dear Dr. {$appointment['doctorName']},
        
        Your appointment scheduled for {$oldDate} at {$oldTime} 
        has been rescheduled by the patient.
        
        New appointment time: {$newDate} at {$newTime}
        
        Reason provided: " . ($reason ?: 'Not specified') . "
        
        Appointment details: {$appointment['appointmentReason']}
        
        Please update your schedule accordingly.
        
        Best regards,
        Dokotela System
    ";
    
    // mail($to, $subject, $message);
    */
}
?>