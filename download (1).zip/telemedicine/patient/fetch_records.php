<?php
session_start();
include '../db_connect.php';

$patientID = $_SESSION['patientID'] ?? 0;
if(!$patientID) { echo json_encode([]); exit; }

$result = $conn->query("
    SELECT r.recordID, r.notes, r.recordDate,
           u.firstName AS doctorFirst, u.lastName AS doctorLast
    FROM MedicalRecords r
    LEFT JOIN Doctor d ON r.doctorID = d.doctorID
    LEFT JOIN User u ON d.userID = u.userID
    WHERE r.patientID = $patientID
    ORDER BY r.date DESC
");

$records = [];
while($row = $result->fetch_assoc()) {
    $records[] = $row;
}

echo json_encode($records);
