<?php
// cancel_appointment.php
session_start();
include '../db_connect.php';

header('Content-Type: application/json');

// Check if patient is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Patient') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    $appointmentId = intval($input['appointmentId']);
    $reason = $conn->real_escape_string(trim($input['reason']));
    $patientId = $_SESSION['patientID'];

    if (empty($reason)) {
        echo json_encode(['success' => false, 'message' => 'Cancellation reason is required']);
        exit();
    }

    try {
        // Start transaction
        $conn->begin_transaction();

        // Verify the appointment belongs to the patient and is not already cancelled/completed
        $checkStmt = $conn->prepare("
            SELECT a.appointmentID, a.status, a.appointmentDate, a.appointmentTime, 
                   CONCAT(u.firstName, ' ', u.lastName) as doctorName,
                   u.email as doctorEmail
            FROM Appointments a 
            LEFT JOIN User u ON a.doctorID = u.userID
            WHERE a.appointmentID = ? AND a.patientID = ? 
            AND a.status NOT IN ('cancelled', 'completed')
        ");
        $checkStmt->bind_param("ii", $appointmentId, $patientId);
        $checkStmt->execute();
        $result = $checkStmt->get_result();
        
        if ($result->num_rows === 0) {
            throw new Exception('Appointment not found or cannot be cancelled');
        }

        $appointment = $result->fetch_assoc();

        // Update appointment status to cancelled
        $updateStmt = $conn->prepare("
            UPDATE Appointments 
            SET status = 'cancelled', 
                cancellationReason = ?,
                cancelledAt = NOW(),
                cancelledBy = 'patient'
            WHERE appointmentID = ? AND patientID = ?
        ");
        $updateStmt->bind_param("sii", $reason, $appointmentId, $patientId);
        
        if (!$updateStmt->execute()) {
            throw new Exception('Failed to cancel appointment');
        }

        // Insert into audit log
        $auditStmt = $conn->prepare("
            INSERT INTO AppointmentAuditLog 
            (appointmentID, action, actionBy, reason, createdAt) 
            VALUES (?, 'cancelled', 'patient', ?, NOW())
        ");
        $auditStmt->bind_param("is", $appointmentId, $reason);
        $auditStmt->execute();

        // Commit transaction
        $conn->commit();

        // Send notification to doctor (you can implement email/SMS here)
        sendCancellationNotification($appointment, $reason);

        echo json_encode([
            'success' => true, 
            'message' => 'Appointment cancelled successfully'
        ]);

    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        error_log("Cancel appointment error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

function sendCancellationNotification($appointment, $reason) {
    // Implement email notification to doctor
    // This is a placeholder - implement your email service here
    /*
    $to = $appointment['doctorEmail'];
    $subject = "Appointment Cancellation Notification";
    $message = "
        Dear Dr. {$appointment['doctorName']},
        
        Your appointment scheduled for {$appointment['appointmentDate']} at {$appointment['appointmentTime']} 
        has been cancelled by the patient.
        
        Reason provided: $reason
        
        Please check your dashboard for details.
        
        Best regards,
        Dokotela System
    ";
    
    // mail($to, $subject, $message);
    */
}
?>