<?php
// submit_support_ticket.php
session_start();
include '../db_connect.php';

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Patient') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $userID = intval($data['userID']);
    $subject = $conn->real_escape_string($data['subject']);
    $priority = $conn->real_escape_string($data['priority']);
    $description = $conn->real_escape_string($data['description']);
    
    // Insert the support ticket using your existing table structure
    $stmt = $conn->prepare("INSERT INTO SupportTickets (userID, subject, description, priority) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $userID, $subject, $description, $priority);
    
    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Support ticket submitted successfully',
            'ticketId' => $conn->insert_id
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Error submitting support ticket: ' . $conn->error
        ]);
    }
    
    $stmt->close();
}

$conn->close();
?>