<?php
session_start();
include '../db_connect.php';

// Check if patient is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Patient') {
    header("Location: ../auth/login.php");
    exit();
}

$patientID = intval($_SESSION['patientID']);

// Check if this is a PDF download request
if (isset($_POST['download_type'])) {
    generatePDF();
    exit;
}

// Fetch medical records with proper doctor info through appointments
$sql = "SELECT 
            mr.recordID, 
            mr.notes, 
            mr.recordDate, 
            mr.appointmentID,
            ms.serviceName, 
            ms.serviceDescription,
            a.doctorID,
            du.firstName AS doctorFirst, 
            du.lastName AS doctorLast,
            p.prescriptionID, 
            p.medication AS medication_name, 
            p.dosage, 
            p.instructions, 
            p.prescribedDate AS prescribed_date
        FROM MedicalRecords mr
        LEFT JOIN Appointments a ON mr.appointmentID = a.appointmentID
        LEFT JOIN Doctor d ON a.doctorID = d.doctorID
        LEFT JOIN User du ON d.userID = du.userID
        LEFT JOIN MedicalService ms ON mr.serviceID = ms.serviceID
        LEFT JOIN Prescription p ON mr.recordID = p.recordID
        WHERE mr.patientID = ?
        ORDER BY mr.recordDate DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patientID);
$stmt->execute();
$result = $stmt->get_result();

// Store all records with their prescriptions
$medicalRecords = [];
while ($row = $result->fetch_assoc()) {
    $recordID = $row['recordID'];
    
    if (!isset($medicalRecords[$recordID])) {
        // Initialize the record
        $medicalRecords[$recordID] = [
            'recordID' => $row['recordID'],
            'notes' => $row['notes'],
            'recordDate' => $row['recordDate'],
            'serviceName' => $row['serviceName'],
            'serviceDescription' => $row['serviceDescription'],
            'appointmentID' => $row['appointmentID'],
            'doctorID' => $row['doctorID'],
            'doctorFirst' => $row['doctorFirst'],
            'doctorLast' => $row['doctorLast'],
            'prescriptions' => []
        ];
    }
    
    // Add prescription if it exists
    if (!empty($row['prescriptionID'])) {
        $medicalRecords[$recordID]['prescriptions'][] = [
            'prescriptionID' => $row['prescriptionID'],
            'medication_name' => $row['medication_name'],
            'dosage' => $row['dosage'],
            'instructions' => $row['instructions'],
            'prescribed_date' => $row['prescribed_date']
        ];
    }
}

function generatePDF() {
    global $conn, $patientID;
    
    $type = $_POST['download_type'] ?? '';
    $id = $_POST['id'] ?? null;

    // Fetch patient info
    $patient_sql = "SELECT u.firstName, u.lastName, u.email, p.dateOfBirth, p.gender, p.address 
                    FROM User u 
                    JOIN Patient p ON u.userID = p.userID 
                    WHERE p.patientID = ?";
    $patient_stmt = $conn->prepare($patient_sql);
    $patient_stmt->bind_param("i", $patientID);
    $patient_stmt->execute();
    $patient_result = $patient_stmt->get_result();
    $patient = $patient_result->fetch_assoc();

    // Include TCPDF library
    require_once('../tcpdf/tcpdf.php');

    // Generate PDF based on type
    switch($type) {
        case 'record':
            generateRecordPDF($id, $patient, $conn);
            break;
        case 'prescription':
            generatePrescriptionPDF($id, $patient, $conn);
            break;
        case 'all_records':
            generateAllRecordsPDF($patientID, $patient, $conn);
            break;
        case 'all_prescriptions':
            generateAllPrescriptionsPDF($patientID, $patient, $conn);
            break;
        default:
            echo "Invalid download type";
            exit;
    }
}

function generateRecordPDF($recordID, $patient, $conn) {
    // Fetch record with proper doctor info through appointments
    $sql = "SELECT 
                mr.recordID, 
                mr.notes, 
                mr.recordDate, 
                mr.appointmentID,
                ms.serviceName, 
                ms.serviceDescription,
                a.doctorID,
                du.firstName AS doctorFirst, 
                du.lastName AS doctorLast,
                p.prescriptionID, 
                p.medication, 
                p.dosage, 
                p.instructions, 
                p.prescribedDate
            FROM MedicalRecords mr
            LEFT JOIN Appointments a ON mr.appointmentID = a.appointmentID
            LEFT JOIN Doctor d ON a.doctorID = d.doctorID
            LEFT JOIN User du ON d.userID = du.userID
            LEFT JOIN MedicalService ms ON mr.serviceID = ms.serviceID
            LEFT JOIN Prescription p ON mr.recordID = p.recordID
            WHERE mr.recordID = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $recordID);
    $stmt->execute();
    $result = $stmt->get_result();
    $record = $result->fetch_assoc();
    
    // Create new PDF document
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    
    // Set document information
    $pdf->SetCreator('Dokotela Online');
    $pdf->SetAuthor('Dokotela Online');
    $pdf->SetTitle("Medical Record #{$recordID}");
    $pdf->SetSubject('Medical Record');
    
    // Set margins
    $pdf->SetMargins(15, 25, 15);
    $pdf->SetHeaderMargin(10);
    $pdf->SetFooterMargin(10);
    
    // Remove default header/footer
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);
    
    // Add a page
    $pdf->AddPage();
    
    // Add header with logo placeholder
    $pdf->SetFont('helvetica', 'B', 16);
    $pdf->Cell(0, 10, 'DOKOTELA ONLINE', 0, 1, 'C');
    $pdf->SetFont('helvetica', '', 12);
    $pdf->Cell(0, 10, 'MEDICAL RECORD', 0, 1, 'C');
    $pdf->Ln(5);
    
    // Patient information
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(0, 10, 'PATIENT INFORMATION', 0, 1);
    $pdf->SetFont('helvetica', '', 10);
    
    $patientInfo = "Name: {$patient['firstName']} {$patient['lastName']}\n";
    $patientInfo .= "Email: {$patient['email']}\n";
    $patientInfo .= "Date of Birth: " . ($patient['dateOfBirth'] ?: 'Not provided') . "\n";
    $patientInfo .= "Gender: " . ($patient['gender'] ?: 'Not provided') . "\n";
    $patientInfo .= "Address: " . ($patient['address'] ?: 'Not provided') . "\n";
    $patientInfo .= "Document Generated: " . date('F j, Y \a\t g:i A');
    
    $pdf->MultiCell(0, 8, $patientInfo, 0, 'L');
    $pdf->Ln(5);
    
    // Record details
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(0, 10, 'APPOINTMENT DETAILS', 0, 1);
    $pdf->SetFont('helvetica', '', 10);
    
    $doctorName = $record['doctorFirst'] && $record['doctorLast'] ? "Dr. {$record['doctorFirst']} {$record['doctorLast']}" : "Not specified";
    $recordDate = $record['recordDate'] ? date('F j, Y', strtotime($record['recordDate'])) : 'Not specified';
    
    $recordDetails = "Record ID: {$record['recordID']}\n";
    $recordDetails .= "Date: {$recordDate}\n";
    $recordDetails .= "Appointment ID: " . ($record['appointmentID'] ?: 'Not specified') . "\n";
    $recordDetails .= "Service: " . ($record['serviceName'] ?: 'Not specified') . "\n";
    $recordDetails .= "Doctor: {$doctorName}\n";
    
    if ($record['serviceDescription']) {
        $recordDetails .= "Service Description: {$record['serviceDescription']}\n";
    }
    
    $pdf->MultiCell(0, 8, $recordDetails, 0, 'L');
    $pdf->Ln(5);
    
    // Clinical notes
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(0, 10, 'CLINICAL NOTES', 0, 1);
    $pdf->SetFont('helvetica', '', 10);
    
    $notes = $record['notes'] ?: 'No clinical notes available for this record.';
    $pdf->MultiCell(0, 8, $notes, 0, 'L');
    
    // Add signature placeholder at the bottom
    $pdf->SetY(-40);
    $pdf->SetFont('helvetica', '', 10);
    $pdf->Cell(0, 8, "Doctor's Signature: _________________________", 0, 1);
    $pdf->Cell(0, 8, "Date: " . date('Y-m-d'), 0, 1);
    
    // Output PDF
    $pdf->Output("medical_record_{$recordID}.pdf", 'D');
    exit;
}

function generatePrescriptionPDF($prescriptionID, $patient, $conn) {
    // Fetch prescription with proper doctor info through appointments
    $sql = "SELECT 
                p.*,
                mr.recordDate, 
                mr.appointmentID, 
                ms.serviceName,
                a.doctorID,
                du.firstName AS doctorFirst, 
                du.lastName AS doctorLast
            FROM Prescription p
            LEFT JOIN MedicalRecords mr ON p.recordID = mr.recordID
            LEFT JOIN Appointments a ON mr.appointmentID = a.appointmentID
            LEFT JOIN Doctor d ON a.doctorID = d.doctorID
            LEFT JOIN User du ON d.userID = du.userID
            LEFT JOIN MedicalService ms ON mr.serviceID = ms.serviceID
            WHERE p.prescriptionID = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $prescriptionID);
    $stmt->execute();
    $result = $stmt->get_result();
    $prescription = $result->fetch_assoc();
    
    // Create new PDF document
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    
    // Set document information
    $pdf->SetCreator('Dokotela Online');
    $pdf->SetAuthor('Dokotela Online');
    $pdf->SetTitle("Prescription #{$prescriptionID}");
    $pdf->SetSubject('Prescription');
    
    // Set margins
    $pdf->SetMargins(15, 25, 15);
    $pdf->SetHeaderMargin(10);
    $pdf->SetFooterMargin(10);
    
    // Remove default header/footer
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);
    
    // Add a page
    $pdf->AddPage();
    
    // Add header with logo placeholder
    $pdf->SetFont('helvetica', 'B', 16);
    $pdf->Cell(0, 10, 'DOKOTELA ONLINE', 0, 1, 'C');
    $pdf->SetFont('helvetica', '', 12);
    $pdf->Cell(0, 10, 'PRESCRIPTION', 0, 1, 'C');
    $pdf->Ln(5);
    
    // Patient information
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(0, 10, 'PATIENT INFORMATION', 0, 1);
    $pdf->SetFont('helvetica', '', 10);
    
    $patientInfo = "Name: {$patient['firstName']} {$patient['lastName']}\n";
    $patientInfo .= "Date of Birth: " . ($patient['dateOfBirth'] ?: 'Not provided') . "\n";
    $patientInfo .= "Document Generated: " . date('F j, Y \a\t g:i A');
    
    $pdf->MultiCell(0, 8, $patientInfo, 0, 'L');
    $pdf->Ln(5);
    
    // Prescription details
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(0, 10, 'PRESCRIPTION DETAILS', 0, 1);
    $pdf->SetFont('helvetica', '', 10);
    
    $doctorName = $prescription['doctorFirst'] && $prescription['doctorLast'] ? "Dr. {$prescription['doctorFirst']} {$prescription['doctorLast']}" : "Not specified";
    $prescribedDate = $prescription['prescribedDate'] ? date('F j, Y', strtotime($prescription['prescribedDate'])) : 'Not specified';
    $recordDate = $prescription['recordDate'] ? date('F j, Y', strtotime($prescription['recordDate'])) : 'Not specified';
    
    $prescriptionDetails = "Prescription ID: {$prescription['prescriptionID']}\n";
    $prescriptionDetails .= "Medication: " . ($prescription['medication'] ?: 'Not specified') . "\n";
    $prescriptionDetails .= "Dosage: " . ($prescription['dosage'] ?: 'Not specified') . "\n";
    $prescriptionDetails .= "Prescribed Date: {$prescribedDate}\n";
    $prescriptionDetails .= "Prescribing Doctor: {$doctorName}\n";
    $prescriptionDetails .= "Related Appointment: {$recordDate} - " . ($prescription['serviceName'] ?: 'Not specified') . "\n";
    
    if ($prescription['instructions']) {
        $prescriptionDetails .= "\nInstructions:\n" . $prescription['instructions'];
    }
    
    $pdf->MultiCell(0, 8, $prescriptionDetails, 0, 'L');
    
    // Add signature placeholder at the bottom
    $pdf->SetY(-40);
    $pdf->SetFont('helvetica', '', 10);
    $pdf->Cell(0, 8, "Doctor's Signature: _________________________", 0, 1);
    $pdf->Cell(0, 8, "Date: " . date('Y-m-d'), 0, 1);
    $pdf->Cell(0, 8, "Medical License Number: [PLACEHOLDER]", 0, 1);
    
    // Output PDF
    $pdf->Output("prescription_{$prescriptionID}.pdf", 'D');
    exit;
}

function generateAllRecordsPDF($patientID, $patient, $conn) {
    // Fetch all records with proper doctor info through appointments
    $sql = "SELECT 
                mr.recordID, 
                mr.notes, 
                mr.recordDate, 
                mr.appointmentID,
                ms.serviceName, 
                ms.serviceDescription,
                a.doctorID,
                du.firstName AS doctorFirst, 
                du.lastName AS doctorLast
            FROM MedicalRecords mr
            LEFT JOIN Appointments a ON mr.appointmentID = a.appointmentID
            LEFT JOIN Doctor d ON a.doctorID = d.doctorID
            LEFT JOIN User du ON d.userID = du.userID
            LEFT JOIN MedicalService ms ON mr.serviceID = ms.serviceID
            WHERE mr.patientID = ?
            ORDER BY mr.recordDate DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $patientID);
    $stmt->execute();
    $result = $stmt->get_result();
    $records = $result->fetch_all(MYSQLI_ASSOC);
    
    // Create new PDF document
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    
    // Set document information
    $pdf->SetCreator('Dokotela Online');
    $pdf->SetAuthor('Dokotela Online');
    $pdf->SetTitle("Complete Medical Records");
    $pdf->SetSubject('Medical Records');
    
    // Set margins
    $pdf->SetMargins(15, 25, 15);
    $pdf->SetHeaderMargin(10);
    $pdf->SetFooterMargin(10);
    
    // Remove default header/footer
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);
    
    // Add a page
    $pdf->AddPage();
    
    // Add header with logo placeholder
    $pdf->SetFont('helvetica', 'B', 16);
    $pdf->Cell(0, 10, 'DOKOTELA ONLINE', 0, 1, 'C');
    $pdf->SetFont('helvetica', '', 12);
    $pdf->Cell(0, 10, 'COMPLETE MEDICAL RECORDS', 0, 1, 'C');
    $pdf->Ln(5);
    
    // Patient information
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(0, 10, 'PATIENT INFORMATION', 0, 1);
    $pdf->SetFont('helvetica', '', 10);
    
    $patientInfo = "Name: {$patient['firstName']} {$patient['lastName']}\n";
    $patientInfo .= "Email: {$patient['email']}\n";
    $patientInfo .= "Date of Birth: " . ($patient['dateOfBirth'] ?: 'Not provided') . "\n";
    $patientInfo .= "Gender: " . ($patient['gender'] ?: 'Not provided') . "\n";
    $patientInfo .= "Address: " . ($patient['address'] ?: 'Not provided') . "\n";
    $patientInfo .= "Document Generated: " . date('F j, Y \a\t g:i A');
    
    $pdf->MultiCell(0, 8, $patientInfo, 0, 'L');
    $pdf->Ln(10);
    
    if (empty($records)) {
        $pdf->SetFont('helvetica', '', 10);
        $pdf->Cell(0, 10, 'No medical records found.', 0, 1);
    } else {
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->Cell(0, 10, 'MEDICAL RECORDS HISTORY', 0, 1);
        $pdf->Ln(5);
        
        foreach($records as $index => $record) {
            if ($index > 0) {
                $pdf->AddPage();
            }
            
            $pdf->SetFont('helvetica', 'B', 11);
            $pdf->Cell(0, 10, "Record #{$record['recordID']}", 0, 1);
            $pdf->SetFont('helvetica', '', 10);
            
            $doctorName = $record['doctorFirst'] && $record['doctorLast'] ? "Dr. {$record['doctorFirst']} {$record['doctorLast']}" : "Not specified";
            $recordDate = $record['recordDate'] ? date('F j, Y', strtotime($record['recordDate'])) : 'Not specified';
            
            $recordDetails = "Date: {$recordDate}\n";
            $recordDetails .= "Appointment ID: " . ($record['appointmentID'] ?: 'Not specified') . "\n";
            $recordDetails .= "Service: " . ($record['serviceName'] ?: 'Not specified') . "\n";
            $recordDetails .= "Doctor: {$doctorName}\n";
            
            if ($record['serviceDescription']) {
                $recordDetails .= "Service Description: {$record['serviceDescription']}\n";
            }
            
            $pdf->MultiCell(0, 8, $recordDetails, 0, 'L');
            $pdf->Ln(3);
            
            $pdf->SetFont('helvetica', 'B', 10);
            $pdf->Cell(0, 8, 'Clinical Notes:', 0, 1);
            $pdf->SetFont('helvetica', '', 9);
            
            $notes = $record['notes'] ?: 'No clinical notes available for this record.';
            $pdf->MultiCell(0, 6, $notes, 0, 'L');
            
            if ($index < count($records) - 1) {
                $pdf->Ln(5);
                $pdf->SetDrawColor(200, 200, 200);
                $pdf->Line(15, $pdf->GetY(), 195, $pdf->GetY());
                $pdf->Ln(5);
            }
        }
    }
    
    // Output PDF
    $pdf->Output("all_medical_records.pdf", 'D');
    exit;
}

function generateAllPrescriptionsPDF($patientID, $patient, $conn) {
    // Fetch all prescriptions with proper doctor info through appointments
    $sql = "SELECT 
                p.*,
                mr.recordDate, 
                mr.appointmentID, 
                ms.serviceName,
                a.doctorID,
                du.firstName AS doctorFirst, 
                du.lastName AS doctorLast
            FROM Prescription p
            LEFT JOIN MedicalRecords mr ON p.recordID = mr.recordID
            LEFT JOIN Appointments a ON mr.appointmentID = a.appointmentID
            LEFT JOIN Doctor d ON a.doctorID = d.doctorID
            LEFT JOIN User du ON d.userID = du.userID
            LEFT JOIN MedicalService ms ON mr.serviceID = ms.serviceID
            WHERE p.patientID = ?
            ORDER BY p.prescribedDate DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $patientID);
    $stmt->execute();
    $result = $stmt->get_result();
    $prescriptions = $result->fetch_all(MYSQLI_ASSOC);
    
    // Create new PDF document
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    
    // Set document information
    $pdf->SetCreator('Dokotela Online');
    $pdf->SetAuthor('Dokotela Online');
    $pdf->SetTitle("All Prescriptions");
    $pdf->SetSubject('Prescriptions');
    
    // Set margins
    $pdf->SetMargins(15, 25, 15);
    $pdf->SetHeaderMargin(10);
    $pdf->SetFooterMargin(10);
    
    // Remove default header/footer
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);
    
    // Add a page
    $pdf->AddPage();
    
    // Add header with logo placeholder
    $pdf->SetFont('helvetica', 'B', 16);
    $pdf->Cell(0, 10, 'DOKOTELA ONLINE', 0, 1, 'C');
    $pdf->SetFont('helvetica', '', 12);
    $pdf->Cell(0, 10, 'ALL PRESCRIPTIONS', 0, 1, 'C');
    $pdf->Ln(5);
    
    // Patient information
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(0, 10, 'PATIENT INFORMATION', 0, 1);
    $pdf->SetFont('helvetica', '', 10);
    
    $patientInfo = "Name: {$patient['firstName']} {$patient['lastName']}\n";
    $patientInfo .= "Date of Birth: " . ($patient['dateOfBirth'] ?: 'Not provided') . "\n";
    $patientInfo .= "Document Generated: " . date('F j, Y \a\t g:i A');
    
    $pdf->MultiCell(0, 8, $patientInfo, 0, 'L');
    $pdf->Ln(10);
    
    if (empty($prescriptions)) {
        $pdf->SetFont('helvetica', '', 10);
        $pdf->Cell(0, 10, 'No prescriptions found.', 0, 1);
    } else {
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->Cell(0, 10, 'PRESCRIPTION HISTORY', 0, 1);
        $pdf->Ln(5);
        
        foreach($prescriptions as $index => $prescription) {
            if ($index > 0) {
                $pdf->AddPage();
            }
            
            $pdf->SetFont('helvetica', 'B', 11);
            $pdf->Cell(0, 10, "Prescription #{$prescription['prescriptionID']}", 0, 1);
            $pdf->SetFont('helvetica', '', 10);
            
            $doctorName = $prescription['doctorFirst'] && $prescription['doctorLast'] ? "Dr. {$prescription['doctorFirst']} {$prescription['doctorLast']}" : "Not specified";
            $prescribedDate = $prescription['prescribedDate'] ? date('F j, Y', strtotime($prescription['prescribedDate'])) : 'Not specified';
            $recordDate = $prescription['recordDate'] ? date('F j, Y', strtotime($prescription['recordDate'])) : 'Not specified';
            
            $prescriptionDetails = "Medication: " . ($prescription['medication'] ?: 'Not specified') . "\n";
            $prescriptionDetails .= "Dosage: " . ($prescription['dosage'] ?: 'Not specified') . "\n";
            $prescriptionDetails .= "Prescribed Date: {$prescribedDate}\n";
            $prescriptionDetails .= "Prescribing Doctor: {$doctorName}\n";
            $prescriptionDetails .= "Related Appointment: {$recordDate} - " . ($prescription['serviceName'] ?: 'Not specified') . "\n";
            
            if ($prescription['instructions']) {
                $prescriptionDetails .= "\nInstructions:\n" . $prescription['instructions'];
            }
            
            $pdf->MultiCell(0, 8, $prescriptionDetails, 0, 'L');
            
            // Add signature placeholder
            $pdf->SetY(-40);
            $pdf->SetFont('helvetica', '', 9);
            $pdf->Cell(0, 6, "Doctor's Signature: _________________________", 0, 1);
            $pdf->Cell(0, 6, "Date: " . date('Y-m-d'), 0, 1);
            $pdf->Cell(0, 6, "Medical License Number: [PLACEHOLDER]", 0, 1);
            
            if ($index < count($prescriptions) - 1) {
                $pdf->AddPage();
            }
        }
    }
    
    // Output PDF
    $pdf->Output("all_prescriptions.pdf", 'D');
    exit;
}
?>

<!-- The HTML part remains exactly the same as in the previous code -->
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>My Medical Records</title>

  <!-- Fonts + FontAwesome -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <style>
    /* All the CSS styles remain exactly the same as in the previous code */
    :root{
      --bg: #F5EFEB;          /* page background */
      --soft-1: #E7C6FF;
      --soft-2: #BBCCFF;
      --accent-mid: #567C8D;  /* main accent */
      --accent-dark: #2F4156; /* text */
      --hint-red: #C23B22;
      --card: rgba(255,255,255,0.95);
      --muted: rgba(47,65,86,0.6);
      --shadow: rgba(47,65,86,0.08);
      --radius: 12px;
    }

    /* Reset & base */
    *{box-sizing:border-box}
    html,body{height:100%;margin:0;font-family:'Inter',system-ui,Arial,sans-serif;-webkit-font-smoothing:antialiased;background:var(--bg);color:var(--accent-dark)}
    a{color:inherit}
    img{max-width:100%;display:block}

    /* Page container */
    .page {
      max-width:1200px;
      margin:20px auto;
      padding:20px;
      min-height:calc(100vh - 40px);
    }

    /* Header / breadcrumb */
    .top-card {
      background: linear-gradient(90deg,var(--card), rgba(255,255,255,0.98));
      border-radius:var(--radius);
      padding:18px;
      display:flex;
      justify-content:space-between;
      align-items:center;
      gap:12px;
      box-shadow:0 10px 30px var(--shadow);
      border:1px solid rgba(47,65,86,0.03);
    }
    .page-title{
      display:flex;gap:12px;align-items:center;
    }
    .page-title h1{
      margin:0;font-size:1.3rem;font-weight:700;
    }
    .subtitle { color:var(--muted); font-size:0.95rem; margin:0; }

    .actions { display:flex; gap:10px; align-items:center; }
    .btn {
      background:linear-gradient(90deg,var(--soft-1),var(--soft-2));
      color:var(--accent-dark);
      border:0;padding:8px 12px;border-radius:10px;
      cursor:pointer;text-decoration:none;font-weight:600;
      box-shadow: 0 6px 18px rgba(12,30,45,0.04);
    }
    .btn-outline {
      background:transparent;color:var(--accent-mid);border:1px solid rgba(86,124,141,0.12);padding:8px 12px;border-radius:10px;cursor:pointer;
    }

    /* Content layout */
    .content {
      display:grid;
      grid-template-columns: 1fr 340px;
      gap:18px;
      margin-top:18px;
    }

    /* left column: records table/card */
    .records-card{
      background:var(--card);
      border-radius:var(--radius);
      padding:14px;
      box-shadow:0 10px 30px var(--shadow);
      border:1px solid rgba(47,65,86,0.03);
    }

    /* responsive table that becomes cards on small screens */
    .records-table {
      width:100%;
      border-collapse:collapse;
      margin-top:8px;
      font-size:0.95rem;
    }
    .records-table thead th {
      text-align:left;
      padding:12px;
      background:linear-gradient(90deg,var(--accent-mid),var(--soft-2));
      color:#fff;
      border:0;
      font-weight:600;
      font-size:0.95rem;
    }
    .records-table tbody td {
      padding:12px;
      border-bottom:1px solid rgba(47,65,86,0.06);
      vertical-align:top;
    }
    .records-table tbody tr:nth-child(even){ background: rgba(0,0,0,0.02); }

    .no-records { text-align:center; padding:28px 12px; color:var(--muted); font-size:1rem; }

    /* small card view for mobile */
    @media (max-width:900px){
      .content{ grid-template-columns:1fr; }
      .records-table thead { display:none; }
      .records-table tbody td { display:block; width:100%; }
      .records-table tbody tr { display:block; margin-bottom:12px; background:var(--card); padding:12px; border-radius:10px; box-shadow:0 6px 18px var(--shadow); }
      .records-table tbody td .label { display:block; font-weight:700; color:var(--accent-mid); margin-bottom:6px; }
    }

    /* right column: small info & tips */
    .side-card{
      background:linear-gradient(90deg,var(--card), rgba(255,255,255,0.98));
      border-radius:var(--radius);
      padding:14px;
      box-shadow:0 8px 20px var(--shadow);
      border:1px solid rgba(47,65,86,0.03);
      height:max-content;
    }
    .side-card h4{ margin:0 0 8px 0; font-size:1rem }
    .hint { font-size:0.95rem; color:var(--muted); margin-bottom:8px; line-height:1.45 }

    /* small meta badges */
    .meta-row{ display:flex; gap:8px; flex-wrap:wrap; margin-top:8px }
    .meta-pill{ background:linear-gradient(90deg,var(--soft-2),var(--soft-1)); padding:8px 10px;border-radius:999px;font-weight:600;color:var(--accent-dark);font-size:0.9rem; }

    /* utility */
    .small { font-size:0.9rem; color:var(--muted) }
    .muted { color:var(--muted) }

    /* spacing for paragraphs */
    p, li { line-height:1.45; margin:0 0 8px 0; }

    /* back link */
    .back { display:inline-flex; gap:8px; align-items:center; text-decoration:none; color:var(--accent-mid); font-weight:600; padding:8px 10px; border-radius:8px; border:1px solid rgba(86,124,141,0.08); background:transparent; }

    /* Modal styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0,0,0,0.5);
    }

    .modal-content {
      background-color: var(--card);
      margin: 5% auto;
      padding: 20px;
      border-radius: var(--radius);
      width: 90%;
      max-width: 700px;
      box-shadow: 0 20px 40px rgba(0,0,0,0.2);
      max-height: 80vh;
      overflow-y: auto;
    }

    .close {
      color: var(--accent-mid);
      float: right;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
      line-height: 1;
    }

    .close:hover {
      color: var(--accent-dark);
    }

    .prescription-item {
      background: rgba(86,124,141,0.05);
      padding: 12px;
      border-radius: 8px;
      margin-bottom: 12px;
      border-left: 4px solid var(--accent-mid);
    }

    .prescription-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
    }

    .prescription-title {
      font-weight: 600;
      color: var(--accent-dark);
      margin: 0;
    }

    .prescription-meta {
      font-size: 0.9rem;
      color: var(--muted);
    }

    .download-btns {
      display: flex;
      gap: 10px;
      margin-top: 15px;
      flex-wrap: wrap;
    }

    .view-record-btn {
      background: linear-gradient(90deg, var(--soft-2), var(--soft-1));
      border: none;
      padding: 6px 10px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 0.85rem;
      font-weight: 600;
    }

    .has-prescription {
      position: relative;
    }

    .has-prescription::after {
      content: "💊";
      position: absolute;
      top: 8px;
      right: 8px;
      font-size: 0.8rem;
    }

    .record-section {
      margin-bottom: 20px;
      padding-bottom: 15px;
      border-bottom: 1px solid rgba(86,124,141,0.1);
    }

    .record-section:last-child {
      border-bottom: none;
    }

  </style>
</head>
<body>
  <div class="page">
    <div class="top-card" role="banner">
      <div class="page-title">
        <div style="width:46px;height:46px;border-radius:10px;background:linear-gradient(90deg,var(--soft-1),var(--soft-2));display:flex;align-items:center;justify-content:center;color:var(--accent-dark);font-weight:700">
          <i class="fa-solid fa-file-medical" style="font-size:18px"></i>
        </div>
        <div>
          <h1>My Medical Records</h1>
          <p class="subtitle">All consultations and clinical notes — organized chronologically.</p>
        </div>
      </div>

      <div class="actions">
        <a href="patient_dashboard.php" class="btn-outline"><i class="fa-solid fa-arrow-left" style="margin-right:8px"></i>Back to Dashboard</a>
        <a href="appointments.php" class="btn"><i class="fa-regular fa-calendar-days" style="margin-right:8px"></i>My Appointments</a>
      </div>
    </div>

    <div class="content" aria-live="polite">
      <section class="records-card" aria-label="Medical records">
        <?php if (!empty($medicalRecords)): ?>
          <table class="records-table" role="table" aria-label="Medical records table">
            <thead>
              <tr>
                <th>Record ID</th>
                <th>Date</th>
                <th>Doctor</th>
                <th>Service</th>
                <th>Notes Preview</th>
                <th>Appointment ID</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($medicalRecords as $record): ?>
                <tr role="row" class="<?php echo !empty($record['prescriptions']) ? 'has-prescription' : ''; ?>">
                  <td role="cell"><?php echo htmlspecialchars($record['recordID']); ?></td>
                  <td role="cell"><?php echo htmlspecialchars(date("d M Y", strtotime($record['recordDate']))); ?></td>
                  <td role="cell"><?php 
                      $doc = trim($record['doctorFirst'] . ' ' . $record['doctorLast']);
                      echo htmlspecialchars($doc ?: '—');
                  ?></td>
                  <td role="cell"><?php echo htmlspecialchars($record['serviceName'] ?: '—'); ?></td>
                  <td role="cell" style="white-space:pre-wrap;word-break:break-word;">
                    <?php 
                      $notes = $record['notes'];
                      if (strlen($notes) > 100) {
                        echo htmlspecialchars(substr($notes, 0, 100)) . '...';
                      } else {
                        echo htmlspecialchars($notes);
                      }
                    ?>
                  </td>
                  <td role="cell"><?php echo htmlspecialchars($record['appointmentID']); ?></td>
                  <td role="cell">
                    <button onclick="viewFullRecord(<?php echo htmlspecialchars(json_encode($record)); ?>)" class="view-record-btn" title="View full record">
                      <i class="fa-solid fa-eye" style="margin-right:4px"></i>View Full
                    </button>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php else: ?>
          <div class="no-records">
            <div style="font-size:1.1rem;font-weight:700;margin-bottom:8px">No medical records found</div>
            <div class="muted">If you recently had an appointment, records may take a short time to appear.</div>
            <div style="margin-top:12px">
              <a href="appointments.php" class="btn">View Appointments</a>
            </div>
          </div>
        <?php endif; ?>
      </section>

      <aside class="side-card" aria-label="Help and tips">
        <h4>Quick Tips</h4>
        <p class="hint">Use the search in the dashboard to quickly find notes and appointment details. If something looks off, contact your clinic.</p>

        <div style="margin-top:8px">
          <div class="small">Useful links</div>
          <div class="meta-row" style="margin-top:8px">
            <a class="meta-pill" href="medical_records.php?filter=recent">Recent</a>
            <a class="meta-pill" href="medical_records.php?filter=lab">Lab Results</a>
            <a class="meta-pill" href="medical_records.php?filter=prescriptions">Prescriptions</a>
          </div>
        </div>

        <div style="margin-top:14px">
          <h4 style="margin-bottom:8px">Download Options</h4>
          <p class="small muted">Download your complete medical history or individual records for your personal files.</p>
          <div class="download-btns">
            <button onclick="downloadAllRecords()" class="btn"><i class="fa-solid fa-download" style="margin-right:8px"></i>All Records</button>
            <button onclick="downloadAllPrescriptions()" class="btn-outline"><i class="fa-solid fa-prescription-bottle" style="margin-right:8px"></i>All Prescriptions</button>
          </div>
        </div>

        <div style="margin-top:14px">
          <h4 style="margin-bottom:8px">Need help?</h4>
          <p class="small muted">Contact the clinic reception or use the help link on your dashboard for urgent corrections.</p>
          <div style="margin-top:12px">
            <a href="../auth/logout.php" class="btn-outline"><i class="fa-solid fa-right-from-bracket" style="margin-right:8px"></i>Logout</a>
          </div>
        </div>
      </aside>
    </div>
  </div>

  <!-- Medical Record Modal -->
  <div id="recordModal" class="modal">
    <div class="modal-content">
      <span class="close" onclick="closeRecordModal()">&times;</span>
      <div id="modalContent"></div>
    </div>
  </div>

  <script>
    // Modal functions
    function viewFullRecord(record) {
      let modalContent = document.getElementById('modalContent');
      let content = `
        <h2 style="margin-top:0;color:var(--accent-dark);border-bottom:2px solid var(--soft-2);padding-bottom:10px;">
          Medical Record #${record.recordID}
        </h2>
        
        <div class="record-section">
          <h3 style="color:var(--accent-mid);margin-bottom:10px;">Appointment Details</h3>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:15px;">
            <div>
              <strong>Date:</strong> ${new Date(record.recordDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}
            </div>
            <div>
              <strong>Appointment ID:</strong> ${record.appointmentID || '—'}
            </div>
            <div>
              <strong>Service:</strong> ${record.serviceName || '—'}
            </div>
            <div>
              <strong>Doctor:</strong> ${record.doctorFirst ? 'Dr. ' + record.doctorFirst + ' ' + record.doctorLast : '—'}
            </div>
          </div>
          ${record.serviceDescription ? `<div style="margin-top:10px;"><strong>Service Description:</strong> ${record.serviceDescription}</div>` : ''}
        </div>

        <div class="record-section">
          <h3 style="color:var(--accent-mid);margin-bottom:10px;">Clinical Notes</h3>
          <div style="background:rgba(86,124,141,0.05);padding:15px;border-radius:8px;white-space:pre-wrap;line-height:1.5;">
            ${record.notes || 'No notes available for this record.'}
          </div>
        </div>
      `;

      // Add prescriptions section if they exist
      if (record.prescriptions && record.prescriptions.length > 0) {
        content += `
          <div class="record-section">
            <h3 style="color:var(--accent-mid);margin-bottom:10px;">Prescriptions</h3>
            ${record.prescriptions.map(prescription => `
              <div class="prescription-item">
                <div class="prescription-header">
                  <div class="prescription-title">${prescription.medication_name || 'Unnamed Medication'}</div>
                  <div class="prescription-meta">${prescription.prescribed_date ? new Date(prescription.prescribed_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : 'No date'}</div>
                </div>
                <div class="prescription-meta">
                  <strong>Dosage:</strong> ${prescription.dosage || '—'}
                </div>
                ${prescription.instructions ? `
                  <div class="prescription-meta"><strong>Instructions:</strong> ${prescription.instructions}</div>
                ` : ''}
                <button onclick="downloadPrescription(${prescription.prescriptionID})" class="view-record-btn" style="margin-top:8px">
                  <i class="fa-solid fa-download" style="margin-right:4px"></i>Download Prescription
                </button>
              </div>
            `).join('')}
          </div>
        `;
      }

      content += `
        <div class="download-btns" style="margin-top:20px;border-top:1px solid rgba(86,124,141,0.1);padding-top:15px;">
          <button onclick="downloadRecord(${record.recordID})" class="btn">
            <i class="fa-solid fa-download" style="margin-right:8px"></i>Download Full Record
          </button>
        </div>
      `;

      modalContent.innerHTML = content;
      document.getElementById('recordModal').style.display = 'block';
    }

    function closeRecordModal() {
      document.getElementById('recordModal').style.display = 'none';
    }

    // Close modal when clicking outside
    window.onclick = function(event) {
      const modal = document.getElementById('recordModal');
      if (event.target == modal) {
        modal.style.display = 'none';
      }
    }

    // Download functions
    function downloadRecord(recordId) {
      generatePDF('record', recordId);
    }

    function downloadPrescription(prescriptionId) {
      generatePDF('prescription', prescriptionId);
    }

    function downloadAllRecords() {
      generatePDF('all_records');
    }

    function downloadAllPrescriptions() {
      generatePDF('all_prescriptions');
    }

    function generatePDF(type, id = null) {
      // Create a form and submit it to generate PDF
      const form = document.createElement('form');
      form.method = 'POST';
      form.action = window.location.href;
      
      const typeInput = document.createElement('input');
      typeInput.type = 'hidden';
      typeInput.name = 'download_type';
      typeInput.value = type;
      form.appendChild(typeInput);
      
      if (id) {
        const idInput = document.createElement('input');
        idInput.type = 'hidden';
        idInput.name = 'id';
        idInput.value = id;
        form.appendChild(idInput);
      }
      
      document.body.appendChild(form);
      form.submit();
      document.body.removeChild(form);
    }

    // small accessible enhancement: allow clicking rows to copy record id (optional)
    document.querySelectorAll('.records-table tbody tr').forEach(tr=>{
      tr.addEventListener('click', ()=> {
        const id = tr.querySelector('td')?.textContent?.trim();
        if(!id) return;
        navigator.clipboard?.writeText(id).then(()=> {
          // quick toast (light)
          const el = document.createElement('div');
          el.textContent = 'Record ID ' + id + ' copied';
          el.style.position='fixed';el.style.right='18px';el.style.bottom='18px';
          el.style.background='var(--accent-mid)';el.style.color='#fff';el.style.padding='8px 12px';
          el.style.borderRadius='8px';el.style.boxShadow='0 8px 20px rgba(0,0,0,0.12)';el.style.zIndex=9999;
          document.body.appendChild(el);
          setTimeout(()=> el.remove(),1500);
        }).catch(()=>{});
      });
    });
  </script>
</body>
</html>