<?php
session_start();
include '../db_connect.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if patient is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Patient') {
    header("Location: ../auth/login.php");
    exit();
}

$userID = $_SESSION['userID'];
$errors = [];
$success = "";

// Fetch patient data
$stmt = $conn->prepare("
    SELECT u.*, p.patientID, p.dateOfBirth, p.gender, p.address 
    FROM User u 
    JOIN Patient p ON u.userID = p.userID 
    WHERE u.userID = ?
");
$stmt->bind_param("i", $userID);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    header("Location: login.php");
    exit();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        // Update profile information
        $firstName = trim($_POST['firstName']);
        $lastName = trim($_POST['lastName']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $dateOfBirth = $_POST['dateOfBirth'];
        $gender = $_POST['gender'];
        $address = trim($_POST['address']);

        // Validation
        if (empty($firstName) || empty($lastName) || empty($email)) {
            $errors[] = "First name, last name, and email are required.";
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Please enter a valid email address.";
        }

        // Check if email already exists (excluding current user)
        $checkEmail = $conn->prepare("SELECT userID FROM User WHERE email = ? AND userID != ?");
        $checkEmail->bind_param("si", $email, $userID);
        $checkEmail->execute();
        if ($checkEmail->get_result()->num_rows > 0) {
            $errors[] = "This email is already registered.";
        }
        $checkEmail->close();

        if (empty($errors)) {
            $conn->begin_transaction();
            try {
                // Update User table
                $updateUser = $conn->prepare("
                    UPDATE User 
                    SET firstName = ?, lastName = ?, email = ?, phone = ? 
                    WHERE userID = ?
                ");
                $updateUser->bind_param("ssssi", $firstName, $lastName, $email, $phone, $userID);
                $updateUser->execute();
                $updateUser->close();

                // Update Patient table
                $updatePatient = $conn->prepare("
                    UPDATE Patient 
                    SET dateOfBirth = ?, gender = ?, address = ? 
                    WHERE userID = ?
                ");
                $updatePatient->bind_param("sssi", $dateOfBirth, $gender, $address, $userID);
                $updatePatient->execute();
                $updatePatient->close();

                $conn->commit();
                $success = "Profile updated successfully!";
                
                // Refresh user data
                $stmt = $conn->prepare("SELECT u.*, p.patientID, p.dateOfBirth, p.gender, p.address FROM User u JOIN Patient p ON u.userID = p.userID WHERE u.userID = ?");
                $stmt->bind_param("i", $userID);
                $stmt->execute();
                $result = $stmt->get_result();
                $user = $result->fetch_assoc();
                $stmt->close();
                
            } catch (Exception $e) {
                $conn->rollback();
                $errors[] = "Error updating profile: " . $e->getMessage();
            }
        }
    }

    if (isset($_POST['change_password'])) {
        // Change password
        $currentPassword = $_POST['currentPassword'];
        $newPassword = $_POST['newPassword'];
        $confirmPassword = $_POST['confirmPassword'];

        // Verify current password
        if (!password_verify($currentPassword, $user['passwordHash'])) {
            $errors[] = "Current password is incorrect.";
        }

        if ($newPassword !== $confirmPassword) {
            $errors[] = "New passwords do not match.";
        }

        if (strlen($newPassword) < 8) {
            $errors[] = "New password must be at least 8 characters long.";
        }

        if (empty($errors)) {
            $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);
            $updatePassword = $conn->prepare("UPDATE User SET passwordHash = ? WHERE userID = ?");
            $updatePassword->bind_param("si", $newPasswordHash, $userID);
            
            if ($updatePassword->execute()) {
                $success = "Password changed successfully!";
            } else {
                $errors[] = "Error changing password.";
            }
            $updatePassword->close();
        }
    }

    if (isset($_POST['delete_account'])) {
        // Delete account confirmation
        $confirmDelete = $_POST['confirmDelete'];
        
        if ($confirmDelete !== 'DELETE') {
            $errors[] = "Please type 'DELETE' to confirm account deletion.";
        } else {
            // In a real application, you might want to soft delete or archive the account
            // For demonstration, we'll show a message
            $success = "Account deletion requested. Please contact support for further assistance.";
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Account Settings - Dokotela</title>

  <!-- Fonts + Icons -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <style>
    :root{
      --bg: #F5EFEB;
      --card: rgba(255,255,255,0.98);
      --soft-1: #E7C6FF;
      --soft-2: #BBCCFF;
      --accent-mid: #567C8D;
      --accent-dark: #2F4156;
      --muted: rgba(47,65,86,0.6);
      --hint-red: #C23B22;
      --shadow: rgba(47,65,86,0.08);
      --radius: 12px;
      --gap: 18px;
    }

    *{ box-sizing: border-box; }
    html,body{ height:100%; margin:0; font-family:'Inter',system-ui,Arial,sans-serif; -webkit-font-smoothing:antialiased; background:var(--bg); color:var(--accent-dark); }

    .page { max-width:1200px; margin:20px auto; padding:20px; min-height:calc(100vh - 40px); }

    /* Top card matches medical records style */
    .top-card {
      background: linear-gradient(90deg,var(--card), rgba(255,255,255,0.98));
      border-radius:var(--radius);
      padding:18px;
      display:flex;
      justify-content:space-between;
      align-items:center;
      gap:12px;
      box-shadow:0 10px 30px var(--shadow);
      border:1px solid rgba(47,65,86,0.03);
    }

    .page-title { display:flex; gap:12px; align-items:center; }
    .page-title h1{ margin:0; font-size:1.25rem; font-weight:700; }
    .page-title p { margin:0; color:var(--muted); font-size:0.95rem; }

    .actions { display:flex; gap:10px; align-items:center; }

    .btn {
      background: linear-gradient(90deg,var(--soft-1),var(--soft-2));
      color: var(--accent-dark);
      border: 0;
      padding: 8px 12px;
      border-radius: 10px;
      cursor: pointer;
      text-decoration: none;
      font-weight:600;
      box-shadow: 0 6px 18px rgba(12,30,45,0.04);
    }
    .btn-outline {
      background:transparent;
      color:var(--accent-mid);
      border:1px solid rgba(86,124,141,0.12);
      padding:8px 12px;
      border-radius:10px;
      text-decoration:none;
      display:inline-flex;
      align-items:center;
      gap:8px;
      font-weight:600;
    }

    /* layout */
    .content { display:grid; grid-template-columns: 1fr 340px; gap:var(--gap); margin-top:18px; align-items:start; }

    /* left column */
    .card {
      background: var(--card);
      border-radius: var(--radius);
      padding:20px;
      box-shadow:0 10px 30px var(--shadow);
      border:1px solid rgba(47,65,86,0.03);
    }

    .section-title {
      font-size:1.1rem;
      font-weight:600;
      margin-bottom:14px;
      color:var(--accent-dark);
      border-bottom:2px solid var(--soft-2);
      padding-bottom:10px;
    }

    .form-grid { display:grid; grid-template-columns: 1fr 1fr; gap:12px; }

    .form-group { margin-bottom:12px; }
    label { display:block; margin-bottom:6px; color:var(--accent-mid); font-weight:500; }
    input, select, textarea {
      width:100%;
      padding:10px 12px;
      border-radius:8px;
      border:1px solid rgba(86,124,141,0.15);
      font-size:0.95rem;
      font-family:inherit;
    }
    input:focus, select:focus, textarea:focus { outline:none; border-color:var(--accent-mid); box-shadow:0 4px 18px rgba(86,124,141,0.06); }

    .muted { color:var(--muted); font-size:0.95rem; }

    /* right column (sidebar) */
    .side-card {
      background: linear-gradient(90deg,var(--card), rgba(255,255,255,0.98));
      border-radius:var(--radius);
      padding:16px;
      box-shadow:0 8px 20px var(--shadow);
      border:1px solid rgba(47,65,86,0.03);
      height:fit-content;
    }
    .side-card h4 { margin:0 0 8px 0; font-size:1rem; }
    .side-card p { margin:0 0 10px 0; color:var(--muted); }

    /* nav list */
    .settings-nav { display:flex; flex-direction:column; gap:8px; margin-top:8px; }
    .settings-nav a {
      display:flex; gap:10px; align-items:center; padding:10px; border-radius:8px; text-decoration:none; color:var(--accent-dark);
    }
    .settings-nav a.active, .settings-nav a:hover {
      background: linear-gradient(90deg,var(--soft-1),var(--soft-2));
    }

    /* danger zone style */
    .danger-zone {
      border: 2px solid var(--hint-red);
      border-radius: var(--radius);
      padding: 16px;
      background: rgba(194, 59, 34, 0.04);
    }
    .danger-zone .section-title { color:var(--hint-red); border-bottom-color:var(--hint-red); }

    /* PRIVACY OPTIONS - compact aligned list (ADDED) */
    .privacy-options {
      display: grid;
      gap: 10px;
      margin-top: 8px;
    }

    .privacy-option {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 10px 12px;
      border-radius: 8px;
      border: 1px solid rgba(47,65,86,0.06);
      background: transparent;
      transition: background 0.15s ease, transform 0.12s ease;
    }

    .privacy-option input[type="checkbox"] {
      width: 18px;
      height: 18px;
      flex-shrink: 0;
      margin: 0;
      accent-color: #00b4d8;
    }

    .privacy-option .label-block {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .privacy-option .label-title {
      font-weight: 600;
      color: var(--accent-dark);
      font-size: 0.97rem;
    }

    .privacy-option .label-desc {
      color: var(--muted);
      font-size: 0.88rem;
      line-height: 1.25;
    }

    .privacy-option:hover,
    .privacy-option:focus-within {
      background: linear-gradient(90deg, rgba(183,145,255,0.06), rgba(187,204,255,0.03));
      transform: translateY(-1px);
    }

    .privacy-actions {
      display:flex;
      justify-content:flex-end;
      gap:10px;
      margin-top:12px;
    }

    @media (max-width: 900px) {
      .content { grid-template-columns: 1fr; }
      .side-card { order: 2; }
    }

    /* small helpers */
    .row-right { display:flex; justify-content:flex-end; gap:8px; align-items:center; }
    .input-inline { display:flex; gap:8px; align-items:center; }
    .avatar {
      width:72px; height:72px; border-radius:12px; background:linear-gradient(90deg,var(--soft-1),var(--soft-2));
      display:flex;align-items:center;justify-content:center;color:var(--accent-dark);font-size:1.6rem;font-weight:700;
    }

    .alert { padding:12px 14px; border-radius:8px; margin-bottom:12px; }
    .alert-success { background:#d4edda; color:#155724; border:1px solid #c3e6cb; }
    .alert-error { background:#f8d7da; color:#721c24; border:1px solid #f5c6cb; }

    /* toast (light) */
    .toast {
      position: fixed;
      right: 18px;
      bottom: 18px;
      background: var(--accent-dark);
      color: #fff;
      padding: 10px 14px;
      border-radius: 8px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.12);
      z-index: 9999;
      opacity: 0;
      transform: translateY(10px);
      transition: all 220ms ease;
      pointer-events: none;
    }
    .toast.show { opacity: 1; transform: translateY(0); pointer-events: auto; }

  </style>
</head>
<body>
  <div class="page">
    <div class="top-card" role="banner">
      <div class="page-title">
        <div style="width:46px;height:46px;border-radius:10px;background:linear-gradient(90deg,var(--soft-1),var(--soft-2));display:flex;align-items:center;justify-content:center;color:var(--accent-dark);font-weight:700">
          <i class="fa-solid fa-gear" style="font-size:18px"></i>
        </div>
        <div>
          <h1>Account Settings</h1>
          <p class="muted">Manage your personal information, password, privacy preferences and account actions.</p>
        </div>
      </div>

      <div class="actions">
        <a href="patient_dashboard.php" class="btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a>
        <a href="appointments.php" class="btn"><i class="fa-regular fa-calendar-days"></i> Appointments</a>
      </div>
    </div>

    <?php if ($success): ?>
      <div style="max-width:1200px;margin:12px auto 0;">
        <div class="alert alert-success"><i class="fa-solid fa-check-circle"></i> <?php echo $success; ?></div>
      </div>
    <?php endif; ?>

    <?php if (!empty($errors)): ?>
      <div style="max-width:1200px;margin:12px auto 0;">
        <div class="alert alert-error">
          <i class="fa-solid fa-exclamation-triangle"></i>
          <?php foreach ($errors as $error): ?>
            <div><?php echo htmlspecialchars($error); ?></div>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endif; ?>

    <div class="content" aria-live="polite">
      <!-- LEFT: main settings content -->
      <div class="card" role="main" aria-label="Account settings">

        <!-- PROFILE SECTION -->
        <section id="profile-section" class="section">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:12px;">
            <div style="display:flex;gap:12px;align-items:center;">
              <div class="avatar"><?php echo strtoupper(substr($user['firstName'],0,1)); ?></div>
              <div>
                <div style="font-weight:700;font-size:1.05rem;"><?php echo htmlspecialchars($user['firstName'] . ' ' . $user['lastName']); ?></div>
                <div class="muted">Patient since <?php echo date('F Y', strtotime($user['createdAt'] ?? 'now')); ?></div>
              </div>
            </div>
            <div class="row-right">
              <a href="#" class="btn-outline" onclick="showSection('privacy'); return false;"><i class="fa-solid fa-shield-halved"></i> Privacy</a>
              <a href="#" class="btn" onclick="showSection('password'); return false;"><i class="fa-solid fa-lock"></i> Change Password</a>
            </div>
          </div>

          <form method="POST" novalidate>
            <input type="hidden" name="update_profile" value="1">

            <div class="section-title">Personal Information</div>

            <div class="form-grid" style="margin-top:8px;">
              <div class="form-group">
                <label for="firstName">First Name *</label>
                <input type="text" id="firstName" name="firstName" value="<?php echo htmlspecialchars($user['firstName']); ?>" required>
              </div>

              <div class="form-group">
                <label for="lastName">Last Name *</label>
                <input type="text" id="lastName" name="lastName" value="<?php echo htmlspecialchars($user['lastName']); ?>" required>
              </div>
            </div>

            <div class="form-group">
              <label for="email">Email Address *</label>
              <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>

            <div class="form-grid">
              <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
              </div>

              <div class="form-group">
                <label for="dateOfBirth">Date of Birth</label>
                <input type="date" id="dateOfBirth" name="dateOfBirth" value="<?php echo htmlspecialchars($user['dateOfBirth'] ?? ''); ?>">
              </div>
            </div>

            <div class="form-grid">
              <div class="form-group">
                <label for="gender">Gender</label>
                <select id="gender" name="gender">
                  <option value="">Select Gender</option>
                  <option value="Male" <?php echo ($user['gender'] ?? '') === 'Male' ? 'selected' : ''; ?>>Male</option>
                  <option value="Female" <?php echo ($user['gender'] ?? '') === 'Female' ? 'selected' : ''; ?>>Female</option>
                  <option value="Other" <?php echo ($user['gender'] ?? '') === 'Other' ? 'selected' : ''; ?>>Other</option>
                  <option value="Prefer not to say" <?php echo ($user['gender'] ?? '') === 'Prefer not to say' ? 'selected' : ''; ?>>Prefer not to say</option>
                </select>
              </div>

              <div class="form-group">
                <label for="address">Address</label>
                <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($user['address'] ?? ''); ?>">
              </div>
            </div>

            <div style="margin-top:12px; display:flex; justify-content:flex-end; gap:10px;">
              <button type="submit" class="btn">Update Profile</button>
              <a href="patient_dashboard.php" class="btn-outline">Cancel</a>
            </div>
          </form>
        </section>

        <!-- PASSWORD SECTION -->
        <section id="password-section" class="section" style="display:none; margin-top:22px;">
          <div class="section-title">Change Password</div>

          <form method="POST" novalidate>
            <input type="hidden" name="change_password" value="1">
            <div class="form-group">
              <label for="currentPassword">Current Password *</label>
              <input type="password" id="currentPassword" name="currentPassword" required>
            </div>

            <div class="form-group">
              <label for="newPassword">New Password *</label>
              <input type="password" id="newPassword" name="newPassword" required>
              <div class="muted" style="margin-top:6px;">Password must be at least 8 characters long.</div>
            </div>

            <div class="form-group">
              <label for="confirmPassword">Confirm New Password *</label>
              <input type="password" id="confirmPassword" name="confirmPassword" required>
            </div>

            <div style="margin-top:12px; display:flex; justify-content:flex-end; gap:10px;">
              <button type="submit" class="btn">Change Password</button>
              <a href="#" class="btn-outline" onclick="showSection('profile'); return false;">Back</a>
            </div>
          </form>
        </section>

        <!-- PRIVACY SECTION (REPLACED: compact aligned options) -->
        <section id="privacy-section" class="section" style="display:none; margin-top:22px;">
          <div class="section-title">Privacy & Security</div>

          <div class="privacy-options" role="group" aria-label="Privacy preferences">
            <label class="privacy-option">
              <input type="checkbox" name="notify_reminders" checked>
              <div class="label-block">
                <span class="label-title">Email me about appointment reminders</span>
                <span class="label-desc">Receive email reminders 24 hours before scheduled appointments.</span>
              </div>
            </label>

            <label class="privacy-option">
              <input type="checkbox" name="notify_features" checked>
              <div class="label-block">
                <span class="label-title">Email me about new features and updates</span>
                <span class="label-desc">Keep me informed about improvements and new functionality.</span>
              </div>
            </label>

            <label class="privacy-option">
              <input type="checkbox" name="share_usage" >
              <div class="label-block">
                <span class="label-title">Share anonymous usage data</span>
                <span class="label-desc">Help improve the service by sharing anonymized analytics.</span>
              </div>
            </label>
          </div>

          <div class="privacy-actions">
            <!-- front-end only save confirmation (no backend changes) -->
            <button type="button" class="btn" onclick="savePrivacyPreferences()">Save Preferences</button>
            <a href="#" class="btn-outline" onclick="showSection('profile'); return false;">Back</a>
          </div>
        </section>

        <!-- DANGER SECTION -->
        <section id="danger-section" class="section" style="display:none; margin-top:22px;">
          <div class="danger-zone">
            <div class="section-title">Danger Zone</div>

            <p style="margin-bottom:12px; color:var(--hint-red);">
              <i class="fa-solid fa-exclamation-triangle"></i> These actions are irreversible. Please proceed with caution.
            </p>

            <div style="margin-bottom:16px;">
              <h4 style="margin-bottom:8px;">Delete All Data</h4>
              <p class="muted">Permanently delete all your personal data, medical records, and appointment history.</p>
              <button class="btn-outline" onclick="showDeleteModal()">Delete My Data</button>
            </div>

            <div>
              <h4 style="margin-bottom:8px;">Delete Account</h4>
              <p class="muted">Permanently delete your account and all associated data. This action cannot be undone.</p>

              <form method="POST" onsubmit="return confirmAccountDeletion()">
                <input type="hidden" name="delete_account" value="1">
                <div class="form-group">
                  <label for="confirmDelete">Type "DELETE" to confirm account deletion:</label>
                  <input type="text" id="confirmDelete" name="confirmDelete" placeholder="DELETE" style="border-color: var(--hint-red);">
                </div>
                <div style="display:flex;justify-content:flex-end;gap:10px;">
                  <button type="submit" class="btn btn-danger"><i class="fa-solid fa-trash"></i> Delete Account</button>
                  <a href="#" class="btn-outline" onclick="showSection('profile'); return false;">Back</a>
                </div>
              </form>
            </div>
          </div>
        </section>

      </div>

      <!-- RIGHT: sidebar with quick links & help -->
      <aside class="side-card" role="complementary" aria-label="Settings navigation and help">
        <h4>Navigation</h4>
        <div class="settings-nav" role="navigation" aria-label="Settings sections">
          <a href="#" id="nav-profile" class="active" onclick="showSection('profile'); return false;"><i class="fa-solid fa-user"></i> Profile Information</a>
          <a href="#" id="nav-password" onclick="showSection('password'); return false;"><i class="fa-solid fa-lock"></i> Change Password</a>
          <a href="#" id="nav-privacy" onclick="showSection('privacy'); return false;"><i class="fa-solid fa-shield-halved"></i> Privacy & Security</a>
          <a href="#" id="nav-danger" onclick="showSection('danger'); return false;"><i class="fa-solid fa-exclamation-triangle"></i> Danger Zone</a>
        </div>

        <hr style="margin:14px 0;border:none;border-top:1px solid rgba(47,65,86,0.06)">

        <h4>Help</h4>
        <p class="muted">If you need assistance updating your account or handling sensitive actions, contact clinic support.</p>
        <div style="margin-top:10px;">
          <a href="#" class="btn-outline" onclick="window.location.href='mailto:support@clinic.example'"><i class="fa-solid fa-envelope"></i> Contact Support</a>
        </div>

        <hr style="margin:14px 0;border:none;border-top:1px solid rgba(47,65,86,0.06)">

        <h4>Quick actions</h4>
        <div style="display:flex;flex-direction:column;gap:8px;margin-top:8px;">
          <a href="patient_dashboard.php" class="btn-outline"><i class="fa-solid fa-house"></i> Back to Dashboard</a>
          <a href="appointments.php" class="btn"><i class="fa-regular fa-calendar-days"></i> My Appointments</a>
        </div>
      </aside>
    </div>
  </div>

  <!-- lightweight toast element -->
  <div id="toast" class="toast" role="status" aria-live="polite"></div>

  <script>
    function showSection(section) {
      // Hide all sections
      document.querySelectorAll('.card .section').forEach(sec => sec.style.display = 'none');

      // Show selected section
      const sel = document.getElementById(section + '-section');
      if (sel) sel.style.display = 'block';

      // Update nav active state (right column)
      document.querySelectorAll('.settings-nav a').forEach(a => a.classList.remove('active'));
      const map = {
        'profile': 'nav-profile',
        'password': 'nav-password',
        'privacy': 'nav-privacy',
        'danger': 'nav-danger'
      };
      const nav = document.getElementById(map[section]);
      if (nav) nav.classList.add('active');

      return false;
    }

    function showDeleteModal() {
      if (confirm('Are you sure you want to delete all your data? This action cannot be undone.')) {
        alert('Data deletion requested. Please contact support for further assistance.');
      }
    }

    function confirmAccountDeletion() {
      return confirm('WARNING: This will permanently delete your account and all associated data. This action cannot be undone. Are you absolutely sure?');
    }

    // Toast helper (front-end confirmation)
    function showToast(message, duration = 2200) {
      const t = document.getElementById('toast');
      t.textContent = message;
      t.classList.add('show');
      clearTimeout(t._hideTimer);
      t._hideTimer = setTimeout(() => t.classList.remove('show'), duration);
    }

    // Save privacy preferences (front-end feedback only — no server change)
    function savePrivacyPreferences() {
      // Gather values (you can later send via AJAX if desired)
      const prefs = {
        notify_reminders: !!document.querySelector('input[name="notify_reminders"]')?.checked,
        notify_features: !!document.querySelector('input[name="notify_features"]')?.checked,
        share_usage: !!document.querySelector('input[name="share_usage"]')?.checked
      };
      // For now, give visual confirmation
      showToast('Privacy preferences saved');
      // console.log('Privacy prefs (front-end):', prefs);
    }

    // Set initial visible section
    document.addEventListener('DOMContentLoaded', function() {
      showSection('profile');
    });
  </script>
</body>
</html>
