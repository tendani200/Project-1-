<?php
session_start();
include '../db_connect.php';

// Check if patient is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Patient') {
    header("Location: login.php");
    exit();
}

$patientUserID = $_SESSION['userID'];

// Handle AJAX request for available slots
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'get_available_slots') {
    header('Content-Type: application/json');
    
    $doctorId = intval($_POST['doctorId']);
    $date = $conn->real_escape_string($_POST['date']);
    $currentAppointmentId = isset($_POST['currentAppointmentId']) ? intval($_POST['currentAppointmentId']) : 0;
    
    // Get available slots for the doctor on the selected date
    $query = "
        SELECT 
            slot_id,
            start_time,
            end_time,
            is_booked,
            CASE 
                WHEN is_booked = 0 THEN 1
                ELSE 0
            END as is_available
        FROM appointment_slots 
        WHERE doctor_id = ? 
          AND slot_date = ? 
          AND slot_date >= CURDATE()
        ORDER BY start_time
    ";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("is", $doctorId, $date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $slots = [];
    while ($row = $result->fetch_assoc()) {
        $slots[] = $row;
    }
    
    $stmt->close();
    
    if (empty($slots)) {
        echo json_encode([
            'success' => false, 
            'message' => 'No slots available for this date'
        ]);
    } else {
        echo json_encode([
            'success' => true, 
            'slots' => $slots
        ]);
    }
    exit();
}

// Fetch patient info
$patientQuery = $conn->prepare("
    SELECT p.patientID, u.firstName, u.lastName, u.email
    FROM Patient p
    JOIN User u ON p.userID = u.userID
    WHERE u.userID = ?
");
$patientQuery->bind_param("i", $patientUserID);
$patientQuery->execute();
$patientResult = $patientQuery->get_result();
$patient = $patientResult->fetch_assoc();
$patientID = $patient['patientID'];
$patientQuery->close();

// Fetch appointments for this patient
$apptStmt = $conn->prepare("
    SELECT 
        a.appointmentID,
        a.appointmentDate,
        a.appointmentTime,
        a.status,
        a.doctorID,
        a.reason,
        d.specialty,
        du.firstName AS docFirst,
        du.lastName  AS docLast,
        du.email AS docEmail,
        du.phone AS docPhone,
        a.serviceID
    FROM Appointments a
    JOIN Doctor d ON a.doctorID = d.doctorID
    JOIN User du   ON d.userID = du.userID
    WHERE a.patientID = ?
    ORDER BY a.appointmentDate DESC, a.appointmentTime DESC
");

$apptStmt->bind_param("i", $patientID);
$apptStmt->execute();
$appointments = $apptStmt->get_result();
$apptStmt->close();

// Convert appointments to array for JavaScript
$appointmentsArray = [];
while($row = $appointments->fetch_assoc()) {
    $appointmentsArray[] = $row;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>My Appointments</title>

  <!-- Fonts + FontAwesome -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <style>
    :root{
      --bg: #F5EFEB;
      --soft-1: #E7C6FF;
      --soft-2: #BBCCFF;
      --accent-mid: #567C8D;
      --accent-dark: #2F4156;
      --hint-red: #C23B22;
      --card: rgba(255,255,255,0.95);
      --muted: rgba(47,65,86,0.6);
      --shadow: rgba(47,65,86,0.08);
      --radius: 12px;
    }

    *{box-sizing:border-box}
    html,body{height:100%;margin:0;font-family:'Inter',system-ui,Arial,sans-serif;background:var(--bg);color:var(--accent-dark);-webkit-font-smoothing:antialiased}
    a{color:inherit}
    .page{max-width:1200px;margin:20px auto;padding:20px;min-height:calc(100vh - 40px)}
    
    /* header card */
    .top-card{
      background: linear-gradient(90deg,var(--card), rgba(255,255,255,0.98));
      border-radius:var(--radius);
      padding:18px;
      display:flex;
      justify-content:space-between;
      align-items:center;
      gap:12px;
      box-shadow:0 10px 30px var(--shadow);
      border:1px solid rgba(47,65,86,0.03);
    }
    .page-title{display:flex;gap:12px;align-items:center}
    .page-title h1{margin:0;font-size:1.3rem;font-weight:700}
    .subtitle{color:var(--muted);margin:0;font-size:0.95rem}

    .actions{display:flex;gap:10px;align-items:center}
    .btn{background:linear-gradient(90deg,var(--soft-1),var(--soft-2));color:var(--accent-dark);border:0;padding:8px 12px;border-radius:10px;cursor:pointer;font-weight:600;text-decoration:none;box-shadow:0 6px 18px rgba(12,30,45,0.04)}
    .btn-outline{background:transparent;color:var(--accent-mid);border:1px solid rgba(86,124,141,0.12);padding:8px 12px;border-radius:10px;text-decoration:none;cursor:pointer}
    .view-all-btn{background:transparent;border:1px solid rgba(86,124,141,0.06);padding:8px 10px;border-radius:8px;cursor:pointer;color:var(--accent-mid)}

    /* layout */
    .content{display:grid;grid-template-columns:1fr 340px;gap:18px;margin-top:18px}

    .card{
      background:var(--card);
      border-radius:var(--radius);
      padding:14px;
      box-shadow:0 10px 30px var(--shadow);
      border:1px solid rgba(47,65,86,0.03);
    }

    /* appointments list */
    .appt-list{display:flex;flex-direction:column;gap:12px}
    .appt-item{
      display:flex;
      justify-content:space-between;
      gap:12px;
      align-items:center;
      padding:12px;
      border-radius:10px;
      border:1px solid rgba(47,65,86,0.03);
      background:linear-gradient(180deg,rgba(255,255,255,0.98),rgba(255,255,255,0.99));
    }
    .appt-left{display:flex;gap:12px;align-items:center;min-width:0}
    .avatar{width:56px;height:56px;border-radius:10px;background:linear-gradient(90deg,var(--soft-2),var(--soft-1));display:flex;align-items:center;justify-content:center;color:var(--accent-dark);font-weight:700}
    .appt-meta{min-width:0}
    .appt-meta .title{font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .appt-meta .muted{color:var(--muted);font-size:0.92rem}

    .appt-actions{display:flex;flex-direction:column;gap:8px;align-items:flex-end}
    .small-btn{background:transparent;border:1px solid rgba(86,124,141,0.08);padding:6px 10px;border-radius:8px;cursor:pointer;color:var(--accent-mid)}
    .danger-btn{background:var(--hint-red);color:#fff;border:0;padding:6px 10px;border-radius:8px;cursor:pointer}

    /* right column: filters / tips */
    .side-card h4{margin:0 0 8px 0}
    .filter-group{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}
    .filter-pill{background:linear-gradient(90deg,var(--soft-2),var(--soft-1));padding:8px 10px;border-radius:999px;font-weight:600;color:var(--accent-dark);cursor:pointer}
    .filter-pill.active{background:var(--accent-mid);color:white}

    /* empty state */
    .no-records{text-align:center;padding:28px;color:var(--muted)}

    /* Modal Styles */
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
      opacity: 0;
      visibility: hidden;
      transition: all 0.3s ease;
    }

    .modal-overlay.active {
      opacity: 1;
      visibility: visible;
    }

    .modal-content {
      background: var(--card);
      border-radius: var(--radius);
      padding: 24px;
      max-width: 500px;
      width: 90%;
      max-height: 80vh;
      overflow-y: auto;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
      transform: translateY(-20px);
      transition: transform 0.3s ease;
    }

    .modal-overlay.active .modal-content {
      transform: translateY(0);
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      padding-bottom: 16px;
      border-bottom: 1px solid rgba(86,124,141,0.1);
    }

    .modal-header h2 {
      margin: 0;
      color: var(--accent-dark);
      font-size: 1.4rem;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      color: var(--muted);
      cursor: pointer;
      padding: 0;
      width: 32px;
      height: 32px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 8px;
      transition: all 0.2s ease;
    }

    .close-btn:hover {
      background: rgba(86,124,141,0.1);
      color: var(--accent-dark);
    }

    .appointment-detail {
      margin-bottom: 16px;
      padding: 12px;
      background: rgba(86,124,141,0.03);
      border-radius: 10px;
    }

    .detail-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
    }

    .detail-label {
      font-weight: 600;
      color: var(--accent-mid);
      font-size: 0.9rem;
    }

    .detail-value {
      color: var(--accent-dark);
      font-weight: 500;
    }

    /* Form styles */
    input[type="date"], select, textarea {
      border: 1px solid rgba(86,124,141,0.2);
      padding: 8px 12px;
      border-radius: 8px;
      font-family: inherit;
      font-size: 0.95rem;
      transition: border-color 0.2s ease;
      width: 100%;
    }

    input[type="date"]:focus, select:focus, textarea:focus {
      outline: none;
      border-color: var(--accent-mid);
    }

    textarea {
      min-height: 80px;
      resize: vertical;
    }

    /* Time slots grid */
    .time-slots-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
      gap: 8px;
      margin-top: 12px;
      max-height: 200px;
      overflow-y: auto;
      padding: 8px;
      border: 1px solid rgba(86,124,141,0.1);
      border-radius: 8px;
    }

    .time-slot {
      padding: 8px;
      border: 1px solid rgba(86,124,141,0.2);
      border-radius: 6px;
      text-align: center;
      cursor: pointer;
      transition: all 0.2s ease;
      font-size: 0.9rem;
    }

    .time-slot:hover {
      background: rgba(86,124,141,0.05);
    }

    .time-slot.selected {
      background: linear-gradient(90deg, var(--soft-1), var(--soft-2));
      color: var(--accent-dark);
      border-color: var(--accent-mid);
      font-weight: 600;
    }

    .time-slot.unavailable {
      background: rgba(195,59,34,0.1);
      color: var(--muted);
      cursor: not-allowed;
      text-decoration: line-through;
    }

    .loading {
      text-align: center;
      padding: 20px;
      color: var(--muted);
    }

    /* small screens: stacked cards */
    @media (max-width:1000px){
      .content{grid-template-columns:1fr}
      .side-card{order:2}
    }
    @media (max-width:700px){
      .page{padding:12px}
      .top-card { flex-direction:column; align-items:flex-start; gap:12px }
      .actions{width:100%;justify-content:space-between}
      .appt-item{flex-direction:column;align-items:flex-start}
      .appt-actions{flex-direction:row;width:100%;justify-content:space-between}
      .modal-content {
        padding: 16px;
        margin: 10px;
      }
      .time-slots-grid {
        grid-template-columns: repeat(auto-fill, minmax(80px, 1fr));
      }
    }

    /* status badges */
    .status-badge{padding:6px 10px;border-radius:999px;font-weight:700;font-size:0.9rem}
    .status-badge.scheduled{background:linear-gradient(90deg,var(--soft-2),#e6fff7);color:var(--accent-mid)}
    .status-badge.completed{background:linear-gradient(90deg,#e8fff6,#dff7f1);color:green}
    .status-badge.cancelled{background:#ffecec;color:var(--hint-red)}
    .status-badge.pending{background:linear-gradient(90deg,#fff3db,#ffedd6);color:orange}
    .status-badge.rescheduled{background:linear-gradient(90deg,#e0f7fa,#b2ebf2);color:#006064}

    .muted{color:var(--muted);}
  </style>
</head>
<body>
  <div class="page">
    <div class="top-card" role="banner">
      <div class="page-title">
        <div style="width:46px;height:46px;border-radius:10px;background:linear-gradient(90deg,var(--soft-1),var(--soft-2));display:flex;align-items:center;justify-content:center;color:var(--accent-dark);font-weight:700">
          <i class="fa-regular fa-calendar-days" style="font-size:18px"></i>
        </div>
        <div>
          <h1>My Appointments</h1>
          <p class="subtitle">All your upcoming and past appointments — keep track, view details, or reschedule.</p>
        </div>
      </div>

      <div class="actions">
        <a href="patient_dashboard.php" class="btn-outline"><i class="fa-solid fa-arrow-left" style="margin-right:8px"></i>Dashboard</a>
        <a href="/telemedicine/doctor/doctorinfo.php" class="btn"><i class="fa-solid fa-plus" style="margin-right:8px"></i>Book Appointment</a>
      </div>
    </div>

    <div class="content" role="main">
      <section class="card">
        <h3 style="margin:0 0 12px 0">Appointments (<?= count($appointmentsArray) ?>)</h3>

        <?php if (count($appointmentsArray) > 0): ?>
          <div class="appt-list" aria-live="polite">
            <?php foreach($appointmentsArray as $a): 
                $status = strtolower(trim($a['status']));
                $statusClass = in_array($status, ['completed','cancelled','pending','scheduled','rescheduled']) ? $status : 'scheduled';
                $doctorName = htmlspecialchars($a['docFirst'].' '.$a['docLast']);
                $date = htmlspecialchars($a['appointmentDate']);
                $time = htmlspecialchars($a['appointmentTime']);
                $specialty = htmlspecialchars($a['specialty'] ?? '');
                $reason = htmlspecialchars($a['reason'] ?? 'General Consultation');
                $notes = htmlspecialchars($a['notes'] ?? '');
            ?>
              <article class="appt-item" data-id="<?php echo htmlspecialchars($a['appointmentID']); ?>" data-status="<?php echo $statusClass; ?>">
                <div class="appt-left">
                  <div class="avatar"><i class="fa-solid fa-user-doctor"></i></div>
                  <div class="appt-meta">
                    <div class="title"><?php echo $doctorName; ?> <span class="muted">• <?php echo $specialty; ?></span></div>
                    <div class="muted" style="margin-top:6px"><?php echo $date; ?> • <?php echo $time; ?></div>
                    <?php if($reason): ?><div class="muted" style="margin-top:6px"><?php echo $reason; ?></div><?php endif; ?>
                    <?php if($notes): ?><div class="muted" style="margin-top:6px;white-space:pre-wrap;"><?php echo $notes; ?></div><?php endif; ?>
                  </div>
                </div>

                <div class="appt-actions" aria-hidden="false">
                  <div><span class="status-badge <?php echo $statusClass; ?>"><?php echo htmlspecialchars(ucfirst($status)); ?></span></div>
                  <div style="display:flex;gap:6px;">
                 <button class="small-btn" onclick="showAppointmentDetails(<?php echo $a['appointmentID']; ?>)">
  <i class="fa-solid fa-eye" style="margin-right:8px"></i>Details
</button>
                  </div>
                </div>
              </article>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <div class="no-records">
            <div style="font-weight:700;margin-bottom:8px">No appointments found</div>
            <div class="muted">Book an appointment or check back later.</div>
            <div style="margin-top:12px"><a href="/telemedicine/doctor/doctorinfo.php" class="btn">Book Appointment</a></div>
          </div>
        <?php endif; ?>
      </section>

      <aside class="card side-card" aria-label="Help & filters">
        <h4>Filters & Quick Actions</h4>

        <div style="margin-top:8px">
          <div class="muted">Filter by status</div>
          <div class="filter-group">
            <button class="filter-pill active" onclick="filterStatus('')">All</button>
            <button class="filter-pill" onclick="filterStatus('scheduled')">Scheduled</button>
            <button class="filter-pill" onclick="filterStatus('completed')">Completed</button>
            <button class="filter-pill" onclick="filterStatus('cancelled')">Cancelled</button>
            <button class="filter-pill" onclick="filterStatus('pending')">Pending</button>
            <button class="filter-pill" onclick="filterStatus('rescheduled')">Rescheduled</button>
          </div>
        </div>

        <div style="margin-top:12px">
          <h4 style="margin-bottom:8px">Tips</h4>
          <p class="muted">Click "Details" on any appointment to view or reschedule. Contact reception for urgent cancellations.</p>
        </div>

        <div style="margin-top:12px">
          <h4 style="margin-bottom:8px">Need help?</h4>
          <p class="muted">If you notice incorrect details, contact the clinic or use the dashboard help link.</p>
          <div style="margin-top:12px">
            <a href="../auth/logout.php" class="btn-outline"><i class="fa-solid fa-right-from-bracket" style="margin-right:8px"></i>Logout</a>
          </div>
        </div>
      </aside>
    </div>
  </div>

  <!-- Appointment Details Modal -->
  <div class="modal-overlay" id="appointmentModal">
    <div class="modal-content">
      <div class="modal-header">
        <h2>Appointment Details</h2>
        <button class="close-btn" onclick="closeModal()">&times;</button>
      </div>
      <div id="appointmentDetailsContent">
        <!-- Content will be populated by JavaScript -->
      </div>
    </div>
  </div>

  <!-- Reschedule Modal -->
  <div class="modal-overlay" id="rescheduleModal">
    <div class="modal-content">
      <div class="modal-header">
        <h2>Reschedule Appointment</h2>
        <button class="close-btn" onclick="closeRescheduleModal()">&times;</button>
      </div>
      <div id="rescheduleContent">
        <form id="rescheduleForm">
          <input type="hidden" id="rescheduleAppointmentId">
          <input type="hidden" id="rescheduleDoctorId">
          <div class="appointment-detail">
            <div class="detail-row">
              <span class="detail-label">Current Date:</span>
              <span class="detail-value" id="currentDate"></span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Current Time:</span>
              <span class="detail-value" id="currentTime"></span>
            </div>
            <div class="detail-row">
              <label class="detail-label" for="newDate">New Date:</label>
              <input type="date" id="newDate" class="detail-value" style="border:1px solid rgba(86,124,141,0.2);padding:6px;border-radius:6px;min-width:120px" required onchange="fetchAvailableSlots()">
            </div>
            <div class="detail-row">
              <span class="detail-label">Available Time Slots:</span>
              <div class="detail-value">
                <div id="timeSlotsContainer" class="time-slots-grid">
                  <div class="loading">Select a date to see available slots</div>
                </div>
                <input type="hidden" id="selectedSlotTime" required>
              </div>
            </div>
            <div class="detail-row">
              <label class="detail-label" for="rescheduleReason">Reason for change:</label>
              <textarea id="rescheduleReason" class="detail-value" style="border:1px solid rgba(86,124,141,0.2);padding:6px;border-radius:6px;width:100%;min-height:60px;resize:vertical" placeholder="Optional reason for rescheduling..."></textarea>
            </div>
          </div>
          <div style="margin-top: 20px; display: flex; gap: 12px; justify-content: flex-end;">
            <button type="button" class="view-all-btn" onclick="closeRescheduleModal()" style="background:transparent;border:1px solid rgba(86,124,141,0.2);padding:8px 16px;border-radius:8px;cursor:pointer">Cancel</button>
            <button type="submit" class="view-all-btn" style="background:linear-gradient(90deg,var(--soft-1),var(--soft-2));color:var(--accent-dark);border:0;padding:8px 16px;border-radius:8px;cursor:pointer">Confirm Reschedule</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Cancel Confirmation Modal -->
  <div class="modal-overlay" id="cancelModal">
    <div class="modal-content">
      <div class="modal-header">
        <h2>Cancel Appointment</h2>
        <button class="close-btn" onclick="closeCancelModal()">&times;</button>
      </div>
      <div id="cancelContent">
        <div class="appointment-detail">
          <p style="margin:0 0 16px 0;color:var(--accent-dark);">Are you sure you want to cancel this appointment?</p>
          <div class="detail-row">
            <span class="detail-label">Appointment ID:</span>
            <span class="detail-value" id="cancelAppointmentId"></span>
          </div>
          <div class="detail-row">
            <span class="detail-label">Date & Time:</span>
            <span class="detail-value" id="cancelDateTime"></span>
          </div>
          <div class="detail-row">
            <span class="detail-label">Doctor:</span>
            <span class="detail-value" id="cancelDoctor"></span>
          </div>
          <div class="detail-row">
            <label class="detail-label" for="cancelReason">Reason for cancellation:</label>
            <textarea id="cancelReason" class="detail-value" style="border:1px solid rgba(86,124,141,0.2);padding:6px;border-radius:6px;width:100%;min-height:60px;resize:vertical" placeholder="Please provide a reason for cancellation..." required></textarea>
          </div>
        </div>
        <div style="margin-top: 20px; display: flex; gap: 12px; justify-content: flex-end;">
          <button type="button" class="view-all-btn" onclick="closeCancelModal()" style="background:transparent;border:1px solid rgba(86,124,141,0.2);padding:8px 16px;border-radius:8px;cursor:pointer">Keep Appointment</button>
          <button type="button" class="view-all-btn" onclick="confirmCancel()" style="background:var(--hint-red);color:var(--white);border:0;padding:8px 16px;border-radius:8px;cursor:pointer">Confirm Cancellation</button>
        </div>
      </div>
    </div>
  </div>

  <!-- toast -->
  <div id="toast" style="position:fixed;right:18px;bottom:18px;background:var(--accent-dark);color:var(--white);padding:10px 16px;border-radius:10px;box-shadow:0 8px 30px rgba(47,65,86,0.12);display:none;z-index:60"></div>

  <script>
    // Store appointments data for JavaScript
const appointmentsData = <?php echo json_encode($appointmentsArray); ?>;
let currentAppointmentId = null;
let currentAppointmentData = null;

// Appointment Details Modal
function showAppointmentDetails(appointmentId) {
  // Find the appointment data from the stored array
  const appointment = appointmentsData.find(a => parseInt(a.appointmentID) === parseInt(appointmentId));
  
  if (!appointment) {
    showToast('Appointment not found');
    return;
  }

  const modal = document.getElementById('appointmentModal');
  const content = document.getElementById('appointmentDetailsContent');
  
  // Format date and time for display
  const appointmentDate = new Date(appointment.appointmentDate + 'T' + appointment.appointmentTime);
  const formattedDate = appointmentDate.toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
  const formattedTime = appointmentDate.toLocaleTimeString('en-US', { 
    hour: '2-digit', 
    minute: '2-digit' 
  });

  // Get status class
  const statusClass = `status-${appointment.status.toLowerCase()}`;
  const canModify = (appointment.status === 'booked' || appointment.status === 'pending');

  // Populate modal content
  content.innerHTML = `
    <div class="appointment-detail">
      <div class="detail-row">
        <span class="detail-label">Appointment ID:</span>
        <span class="detail-value">#${appointment.appointmentID}</span>
      </div>
      <div class="detail-row">
        <span class="detail-label">Date:</span>
        <span class="detail-value">${formattedDate}</span>
      </div>
      <div class="detail-row">
        <span class="detail-label">Time:</span>
        <span class="detail-value">${formattedTime}</span>
      </div>
      <div class="detail-row">
        <span class="detail-label">Doctor:</span>
        <span class="detail-value">${appointment.docFirst} ${appointment.docLast}</span>
      </div>
      <div class="detail-row">
        <span class="detail-label">Specialty:</span>
        <span class="detail-value">${appointment.specialty || 'General'}</span>
      </div>
      <div class="detail-row">
        <span class="detail-label">Contact:</span>
        <span class="detail-value">${appointment.docEmail || 'N/A'} ${appointment.docPhone ? '• ' + appointment.docPhone : ''}</span>
      </div>
      <div class="detail-row">
        <span class="detail-label">Reason:</span>
        <span class="detail-value">${appointment.reason || 'General Consultation'}</span>
      </div>
      <div class="detail-row">
        <span class="detail-label">Status:</span>
        <span class="detail-value status-badge ${statusClass}">${appointment.status}</span>
      </div>
      ${appointment.notes ? `
      <div class="detail-row">
        <span class="detail-label">Notes:</span>
        <span class="detail-value">${appointment.notes}</span>
      </div>
      ` : ''}
    </div>
    <div style="margin-top: 20px; display: flex; gap: 12px; justify-content: flex-end;">
      <button class="view-all-btn" onclick="closeModal()" style="background:transparent;border:1px solid rgba(86,124,141,0.2);padding:8px 16px;border-radius:8px;cursor:pointer">Close</button>
      ${canModify ? `
        <button class="view-all-btn" onclick="cancelAppointment(${appointment.appointmentID})" style="background:var(--hint-red);color:var(--white);border:0;padding:8px 16px;border-radius:8px;cursor:pointer">Cancel Appointment</button>
        <button class="view-all-btn" onclick="rescheduleAppointment(${appointment.appointmentID})" style="background:linear-gradient(90deg,var(--soft-1),var(--soft-2));color:var(--accent-dark);border:0;padding:8px 16px;border-radius:8px;cursor:pointer">Reschedule</button>
      ` : ''}
    </div>
  `;

  // Show modal
  modal.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  const modal = document.getElementById('appointmentModal');
  modal.classList.remove('active');
  document.body.style.overflow = 'auto';
}

// Reschedule functionality
function rescheduleAppointment(appointmentId) {
  // Find the appointment data
  const appointment = appointmentsData.find(a => parseInt(a.appointmentID) === parseInt(appointmentId));
  if (!appointment) {
    showToast('Appointment not found');
    return;
  }

  // Close details modal first
  closeModal();
  
  // Open reschedule modal after a short delay
  setTimeout(() => {
    currentAppointmentId = appointmentId;
    currentAppointmentData = appointment;
    const modal = document.getElementById('rescheduleModal');
    
    // Populate current appointment details
    document.getElementById('currentDate').textContent = new Date(appointment.appointmentDate).toLocaleDateString();
    document.getElementById('currentTime').textContent = appointment.appointmentTime;
    document.getElementById('rescheduleAppointmentId').value = appointmentId;
    document.getElementById('rescheduleDoctorId').value = appointment.doctorID;
    
    // Set minimum date to today and default to current date
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('newDate').min = today;
    document.getElementById('newDate').value = appointment.appointmentDate;
    
    // Clear time slots initially
    document.getElementById('timeSlotsContainer').innerHTML = '<div class="loading">Select a date to see available slots</div>';
    document.getElementById('selectedSlotTime').value = '';
    
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }, 300);
}

function closeRescheduleModal() {
  const modal = document.getElementById('rescheduleModal');
  modal.classList.remove('active');
  document.body.style.overflow = 'auto';
  currentAppointmentId = null;
  currentAppointmentData = null;
}

// Fetch available time slots for the selected date
function fetchAvailableSlots() {
  const selectedDate = document.getElementById('newDate').value;
  const doctorId = document.getElementById('rescheduleDoctorId').value;
  
  if (!selectedDate) {
    document.getElementById('timeSlotsContainer').innerHTML = '<div class="loading">Please select a date</div>';
    return;
  }
  
  // Show loading state
  document.getElementById('timeSlotsContainer').innerHTML = '<div class="loading">Loading available slots...</div>';
  document.getElementById('selectedSlotTime').value = '';
  
  // Fetch available slots from the same file using form data
  const formData = new FormData();
  formData.append('action', 'get_available_slots');
  formData.append('doctorId', doctorId);
  formData.append('date', selectedDate);
  formData.append('currentAppointmentId', currentAppointmentId);
  
  fetch(window.location.href, {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      displayTimeSlots(data.slots);
    } else {
      document.getElementById('timeSlotsContainer').innerHTML = '<div class="loading">' + data.message + '</div>';
    }
  })
  .catch(error => {
    console.error('Error:', error);
    document.getElementById('timeSlotsContainer').innerHTML = '<div class="loading">Error loading slots</div>';
  });
}

// Display available time slots in a grid
function displayTimeSlots(slots) {
  const container = document.getElementById('timeSlotsContainer');
  
  if (!slots || slots.length === 0) {
    container.innerHTML = '<div class="loading">No available slots for this date</div>';
    return;
  }
  
  let html = '';
  slots.forEach(slot => {
    const isAvailable = slot.is_available;
    const timeDisplay = formatTimeForDisplay(slot.start_time);
    html += `
      <div class="time-slot ${isAvailable ? 'available' : 'unavailable'}" 
           onclick="${isAvailable ? `selectTimeSlot('${slot.start_time}', this)` : ''}">
        ${timeDisplay}
      </div>
    `;
  });
  
  container.innerHTML = html;
}

// Select a time slot
function selectTimeSlot(time, element) {
  // Remove selected class from all slots
  document.querySelectorAll('.time-slot').forEach(slot => {
    slot.classList.remove('selected');
  });
  
  // Add selected class to clicked slot
  element.classList.add('selected');
  
  // Store selected time
  document.getElementById('selectedSlotTime').value = time;
}

// Format time for display (e.g., "8:00 AM", "2:30 PM")
function formatTimeForDisplay(timeString) {
  const [hours, minutes] = timeString.split(':');
  const hour = parseInt(hours);
  const minute = parseInt(minutes);
  const period = hour >= 12 ? 'PM' : 'AM';
  const displayHour = hour % 12 || 12; // Convert 0, 12, 13, etc. to 12, 1, 2, etc.
  return `${displayHour}:${minute.toString().padStart(2, '0')} ${period}`;
}

// Cancel functionality
function cancelAppointment(appointmentId) {
  // Find the appointment data
  const appointment = appointmentsData.find(a => parseInt(a.appointmentID) === parseInt(appointmentId));
  if (!appointment) {
    showToast('Appointment not found');
    return;
  }

  // Close details modal first
  closeModal();
  
  // Open cancel modal after a short delay
  setTimeout(() => {
    currentAppointmentId = appointmentId;
    currentAppointmentData = appointment;
    const modal = document.getElementById('cancelModal');
    
    // Populate cancellation details
    document.getElementById('cancelAppointmentId').textContent = '#' + appointmentId;
    document.getElementById('cancelDateTime').textContent = 
        new Date(appointment.appointmentDate).toLocaleDateString() + ' at ' + appointment.appointmentTime;
    document.getElementById('cancelDoctor').textContent = appointment.docFirst + ' ' + appointment.docLast;
    document.getElementById('cancelReason').value = '';
    
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }, 300);
}

function closeCancelModal() {
  const modal = document.getElementById('cancelModal');
  modal.classList.remove('active');
  document.body.style.overflow = 'auto';
  currentAppointmentId = null;
  currentAppointmentData = null;
}

function confirmCancel() {
  const reason = document.getElementById('cancelReason').value;
  if (!reason.trim()) {
    showToast('Please provide a reason for cancellation');
    return;
  }
  
  // AJAX call to cancel appointment
  fetch('cancel_appointment.php', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
      },
      body: JSON.stringify({
          appointmentId: currentAppointmentId,
          reason: reason
      })
  })
  .then(response => response.json())
  .then(data => {
      if (data.success) {
          showToast('Appointment cancelled successfully');
          closeCancelModal();
          // Reload the page to update the list
          setTimeout(() => location.reload(), 1000);
      } else {
          showToast('Error: ' + data.message);
      }
  })
  .catch(error => {
      console.error('Error:', error);
      showToast('Error cancelling appointment');
  });
}

// Form submission for rescheduling
document.getElementById('rescheduleForm').addEventListener('submit', function(e) {
  e.preventDefault();
  
  const newDate = document.getElementById('newDate').value;
  const newTime = document.getElementById('selectedSlotTime').value;
  const reason = document.getElementById('rescheduleReason').value;
  const doctorId = document.getElementById('rescheduleDoctorId').value;
  
  if (!newDate || !newTime) {
    showToast('Please select both date and time slot');
    return;
  }
  
  // Validate that new date is in the future
  const newDateTime = new Date(newDate + 'T' + newTime);
  if (newDateTime <= new Date()) {
    showToast('Please select a future date and time');
    return;
  }
  
  // AJAX call to reschedule appointment
  fetch('reschedule_appointment.php', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
      },
      body: JSON.stringify({
          appointmentId: currentAppointmentId,
          newDate: newDate,
          newTime: newTime,
          reason: reason,
          doctorId: doctorId
      })
  })
  .then(response => response.json())
  .then(data => {
      if (data.success) {
          showToast('Appointment rescheduled successfully');
          closeRescheduleModal();
          // Reload the page to update the list
          setTimeout(() => location.reload(), 1000);
      } else {
          showToast('Error: ' + data.message);
      }
  })
  .catch(error => {
      console.error('Error:', error);
      showToast('Error rescheduling appointment');
  });
});
    // Filter functionality
    function filterStatus(status) {
      // Update active filter button
      document.querySelectorAll('.filter-pill').forEach(btn => {
        btn.classList.remove('active');
      });
      event.target.classList.add('active');
      
      // Filter appointments
      document.querySelectorAll('.appt-item').forEach(item => {
        if (!status) {
          item.style.display = 'flex';
          return;
        }
        const itemStatus = item.getAttribute('data-status');
        if (itemStatus === status) {
          item.style.display = 'flex';
        } else {
          item.style.display = 'none';
        }
      });
    }

    // Toast notification
    function showToast(msg, timeout = 2200) {
      const t = document.getElementById('toast');
      t.textContent = msg;
      t.style.display = 'block';
      setTimeout(() => t.style.display = 'none', timeout);
    }

    // Close modals when clicking outside
    document.getElementById('appointmentModal').addEventListener('click', function(e) {
      if (e.target === this) {
          closeModal();
      }
    });

    document.getElementById('rescheduleModal').addEventListener('click', function(e) {
      if (e.target === this) {
          closeRescheduleModal();
      }
    });

    document.getElementById('cancelModal').addEventListener('click', function(e) {
      if (e.target === this) {
          closeCancelModal();
      }
    });

    // Close modals with Escape key
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') {
        closeModal();
        closeRescheduleModal();
        closeCancelModal();
      }
    });

    // Make each appt-item clickable (copy id or open)
    document.querySelectorAll('.appt-item').forEach(it => {
      it.addEventListener('dblclick', () => {
        const id = it.getAttribute('data-id');
        if (!id) return;
        // on double-click copy id to clipboard (useful for support)
        navigator.clipboard?.writeText(id).then(() => {
          showToast('Appointment ID ' + id + ' copied');
        }).catch(() => {});
      });
    });
  </script>
</body>
</html>