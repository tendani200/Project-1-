<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - Dokotela Online</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background-color: #f8f9fa;
            color: #333;
            line-height: 1.6;
        }

        /* Header */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 40px;
            background-color: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: #e63946;
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .logo i {
            font-size: 28px;
        }

        .back-to-home {
            color: #5a5af0;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .back-to-home:hover {
            color: #4a4acf;
            transform: translateX(-3px);
        }

        /* Privacy Policy Content */
        .privacy-container {
            max-width: 1000px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .privacy-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .privacy-header h1 {
            font-size: 2.5rem;
            color: #333;
            margin-bottom: 15px;
            position: relative;
            padding-bottom: 15px;
        }

        .privacy-header h1::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: linear-gradient(to right, #e63946, #5a5af0);
            border-radius: 2px;
        }

        .privacy-header p {
            font-size: 1.1rem;
            color: #666;
            max-width: 800px;
            margin: 0 auto;
        }

        .privacy-content {
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            padding: 40px;
        }

        .policy-section {
            margin-bottom: 40px;
        }

        .policy-section h2 {
            font-size: 1.5rem;
            color: #333;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }

        .policy-section p {
            margin-bottom: 15px;
            color: #555;
        }

        .policy-section ul {
            margin-left: 20px;
            margin-bottom: 15px;
        }

        .policy-section li {
            margin-bottom: 10px;
            color: #555;
        }

        .highlight-box {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid #5a5af0;
            margin: 20px 0;
        }

        .contact-info {
            margin-top: 40px;
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        .contact-info h3 {
            margin-bottom: 15px;
            color: #333;
        }

        .contact-info p {
            margin-bottom: 10px;
            color: #666;
        }

        /* Footer */
        footer {
            margin-top: 80px;
            background: linear-gradient(to right, #2c3e50, #34495e);
            color: #fff;
            padding: 40px 20px 20px;
            text-align: center;
        }

        .footer-links {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }

        .footer-links a {
            color: #ccc;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .footer-links a:hover {
            color: #5a5af0;
        }

        .copyright {
            font-size: 14px;
            color: #999;
            padding-top: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }

        /* Responsive styles */
        @media (max-width: 768px) {
            header {
                padding: 15px 20px;
            }
            
            .privacy-container {
                margin: 20px auto;
            }
            
            .privacy-header h1 {
                font-size: 2rem;
            }
            
            .privacy-content {
                padding: 25px;
            }
            
            .footer-links {
                flex-direction: column;
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <a href="index.php" class="logo">
            <i class="fas fa-stethoscope"></i> Dokotela Online
        </a>
        <a href="index.php" class="back-to-home">
            <i class="fas fa-arrow-left"></i> Back to Home
        </a>
    </header>

    <!-- Privacy Policy Content -->
    <div class="privacy-container">
        <div class="privacy-header">
            <h1>Privacy Policy</h1>
            <p>Last updated: January 2023</p>
        </div>
        
        <div class="privacy-content">
            <div class="policy-section">
                <p>At Dokotela Online, we value and respect your right to privacy. This Privacy Policy explains how we collect, use, store, and protect your personal information in accordance with the Protection of Personal Information Act (POPIA), Act No. 4 of 2013 and other applicable South African laws.</p>
            </div>
            
            <div class="policy-section">
                <h2>1. Information We Collect</h2>
                <p>When you use our platform, we may collect the following information:</p>
                <ul>
                    <li>Personal details such as your name, contact number, email address, and ID number</li>
                    <li>Medical history and health information necessary for your online consultation</li>
                    <li>Payment and billing information</li>
                    <li>Technical information (such as IP address and device type) to enhance security and user experience</li>
                </ul>
            </div>
            
            <div class="policy-section">
                <h2>2. How We Use Your Information</h2>
                <p>Your personal information is collected solely for legitimate healthcare and operational purposes, including:</p>
                <ul>
                    <li>Booking and managing consultations</li>
                    <li>Providing accurate medical advice and follow-up care</li>
                    <li>Processing payments and generating invoices</li>
                    <li>Communicating with you regarding appointments, updates, and support</li>
                    <li>Ensuring compliance with medical, ethical, and legal standards</li>
                </ul>
                <div class="highlight-box">
                    <p><strong>We do not sell, rent, or trade your information to third parties.</strong></p>
                </div>
            </div>
            
            <div class="policy-section">
                <h2>3. Data Storage and Security</h2>
                <p>We take every reasonable measure to ensure that your personal and medical information is stored securely. This includes:</p>
                <ul>
                    <li>Encryption of sensitive data</li>
                    <li>Secure servers and password protection</li>
                    <li>Limited access to authorized personnel only</li>
                </ul>
                <p>If there is ever a data breach, we will notify you and the Information Regulator of South Africa as required by law.</p>
            </div>
            
            <div class="policy-section">
                <h2>4. Sharing of Information</h2>
                <p>We may share limited information only with:</p>
                <ul>
                    <li>Registered healthcare professionals involved in your consultation</li>
                    <li>Authorized third-party service providers (such as payment processors) who comply with POPIA</li>
                    <li>Legal or regulatory authorities when required by law</li>
                </ul>
                <p>All third parties are required to maintain confidentiality and data protection standards.</p>
            </div>
            
            <div class="policy-section">
                <h2>5. Your Rights</h2>
                <p>Under POPIA, you have the right to:</p>
                <ul>
                    <li>Access and request a copy of your personal information</li>
                    <li>Request correction or deletion of inaccurate data</li>
                    <li>Withdraw consent to processing (where applicable)</li>
                    <li>Lodge a complaint with the Information Regulator (South Africa) if you believe your data has been mishandled</li>
                </ul>
            </div>
            
            <div class="policy-section">
                <h2>6. Retention of Information</h2>
                <p>We retain your medical and personal information only as long as necessary to provide healthcare services, meet legal obligations, and maintain accurate medical records.</p>
            </div>
            
            <div class="policy-section">
                <h2>7. Updates to This Policy</h2>
                <p>This Privacy Policy may be updated periodically to reflect changes in our practices or legal requirements. Updates will be posted on our website, and your continued use of our platform will signify acceptance of the revised policy.</p>
            </div>
            
            <div class="contact-info">
                <h3>Contact Us</h3>
                <p>If you have any questions about this Privacy Policy, please contact us:</p>
                <p>Email: aphiwe.meyiwa@dokotela-online.com</p>
                <p>Phone: +27 67 566 9355</p>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-links">
            <a href="index.php">Home</a>
            <a href="index.php#services">Services</a>
            <a href="index.php#mission">About Us</a>
            <a href="privacy-policy.php">Privacy Policy</a>
            <a href="#">Terms of Service</a>
        </div>
        <div class="copyright">
            &copy; 2023 Dokotela Online. All rights reserved.
        </div>
    </footer>
</body>
</html>
                                        