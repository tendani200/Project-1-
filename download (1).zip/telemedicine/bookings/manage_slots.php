<?php
session_start();
include '../db_connect.php';

// ✅ Check if doctor is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Doctor') {
    header("Location: ../login.php");
    exit();
}

$doctorUserID = intval($_SESSION['userID']);

// ✅ Fetch doctor info & doctorID using JOIN
$doctorQuery = $conn->prepare("
    SELECT d.doctorID, u.firstName, u.lastName, u.email
    FROM User u 
    JOIN Doctor d ON u.userID = d.userID 
    WHERE u.userID = ?
");
$doctorQuery->bind_param("i", $doctorUserID);
$doctorQuery->execute();
$doctorResult = $doctorQuery->get_result();

if ($doctorResult && $doctorResult->num_rows > 0) {
    $doctor = $doctorResult->fetch_assoc();
    $doctorID = intval($doctor['doctorID']);
} else {
    header("Location: ../login.php");
    exit();
}
$doctorQuery->close();

// ✅ Selected date - Fixed to use South Africa timezone
$timezone = new DateTimeZone('Africa/Johannesburg');
$currentDate = new DateTime('now', $timezone);
$selected_date = isset($_GET['date']) ? $_GET['date'] : $currentDate->format('Y-m-d');

// ✅ Add single slot
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_slot'])) {
    $date = $_POST['slot_date'];
    $start = $_POST['start_time'];
    $end = $_POST['end_time'];

    $stmt = $conn->prepare("
        INSERT INTO appointment_slots (doctor_id, slot_date, start_time, end_time, is_booked)
        SELECT ?, ?, ?, ?, 0 FROM DUAL
        WHERE NOT EXISTS (
            SELECT 1 FROM appointment_slots
            WHERE doctor_id=? AND slot_date=? AND start_time=? AND end_time=?
        )
    ");
    $stmt->bind_param("isssisss", $doctorID, $date, $start, $end, $doctorID, $date, $start, $end);
    $stmt->execute();
    $stmt->close();

    header("Location: manage_slots.php?date=" . urlencode($date));
    exit;
}

// ✅ Generate bulk slots
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_bulk'])) {
    $date = $_POST['bulk_date'];
    $start_hour = intval($_POST['bulk_start']);
    $end_hour = intval($_POST['bulk_end']);
    $skipped = [];

    for ($hour = $start_hour; $hour < $end_hour; $hour++) {
        $slot_start = sprintf("%02d:00", $hour);
        $slot_end = sprintf("%02d:00", $hour + 1);

        $exists = $conn->query("
            SELECT 1 FROM appointment_slots 
            WHERE doctor_id=$doctorID 
            AND slot_date='$date' 
            AND start_time='$slot_start' 
            AND end_time='$slot_end'
        ")->num_rows;

        if ($exists) {
            $skipped[] = $slot_start;
            continue;
        }

        $stmt = $conn->prepare("
            INSERT INTO appointment_slots (doctor_id, slot_date, start_time, end_time, is_booked)
            SELECT ?, ?, ?, ?, 0 FROM DUAL
            WHERE NOT EXISTS (
                SELECT 1 FROM appointment_slots
                WHERE doctor_id=? AND slot_date=? AND start_time=? AND end_time=?
            )
        ");
        $stmt->bind_param("isssisss", $doctorID, $date, $slot_start, $slot_end, $doctorID, $date, $slot_start, $slot_end);
        $stmt->execute();
        $stmt->close();
    }

    if (!empty($skipped)) {
        $_SESSION['message'] = 'Skipped hours (already exist): ' . implode(", ", $skipped);
    }

    header("Location: manage_slots.php?date=" . urlencode($date));
    exit;
}

// ✅ Delete single slot
if (isset($_GET['delete_slot'])) {
    $slot_id = intval($_GET['delete_slot']);
    $slot = $conn->query("
        SELECT slot_date 
        FROM appointment_slots 
        WHERE slot_id=$slot_id AND doctor_id=$doctorID
    ")->fetch_assoc();
    $date = $slot ? $slot['slot_date'] : $selected_date;

    $conn->query("
        DELETE FROM appointment_slots 
        WHERE slot_id=$slot_id AND doctor_id=$doctorID AND is_booked=0
    ");
    header("Location: manage_slots.php?date=" . urlencode($date));
    exit;
}

// ✅ Cancel appointment
if (isset($_GET['cancel_appointment'])) {
    $appointment_id = intval($_GET['cancel_appointment']);
    $app = $conn->query("
        SELECT * FROM Appointments 
        WHERE appointmentID=$appointment_id AND doctorID=$doctorID
    ")->fetch_assoc();
    if ($app) {
        $conn->query("
            UPDATE appointment_slots 
            SET is_booked=0 
            WHERE doctor_id={$app['doctorID']} 
            AND slot_date='{$app['appointmentDate']}' 
            AND start_time='{$app['appointmentTime']}'
        ");

        $conn->query("
            UPDATE Appointments 
            SET status='cancelled', cancelledAt=NOW(), cancelledBy='doctor' 
            WHERE appointmentID=$appointment_id
        ");
    }
    header("Location: manage_slots.php?date=" . urlencode($selected_date));
    exit;
}

// ✅ Delete all available slots for a day
if (isset($_POST['delete_all_day'])) {
    $day = $_POST['delete_day'];
    $stmt = $conn->prepare("
        DELETE FROM appointment_slots 
        WHERE doctor_id=? AND slot_date=? AND is_booked=0
    ");
    $stmt->bind_param("is", $doctorID, $day);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_slots.php?date=" . urlencode($day));
    exit;
}

// ✅ Delete available slots in range
if (isset($_POST['delete_range'])) {
    $from = $_POST['from_date'];
    $to   = $_POST['to_date'];
    $stmt = $conn->prepare("
        DELETE FROM appointment_slots 
        WHERE doctor_id=? AND slot_date BETWEEN ? AND ? AND is_booked=0
    ");
    $stmt->bind_param("iss", $doctorID, $from, $to);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_slots.php?date=" . urlencode($selected_date));
    exit;
}

// ✅ Fetch slots and appointments
$available_slots = $conn->query("
    SELECT * FROM appointment_slots 
    WHERE doctor_id=$doctorID AND slot_date='$selected_date' AND is_booked=0 
    ORDER BY start_time
");

$appointments = $conn->query("
    SELECT a.*, u.firstName, u.lastName 
    FROM Appointments a 
    JOIN Patient p ON a.patientID = p.patientID 
    JOIN User u ON p.userID = u.userID 
    WHERE a.doctorID=$doctorID AND a.appointmentDate='$selected_date' AND a.status='booked' 
    ORDER BY a.appointmentTime
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dokotela — Manage Slots & Appointments</title>

    <!-- keep bootstrap for some components (forms, table) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- datepicker style (you already use) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-datepicker@1.10.0/dist/css/bootstrap-datepicker.min.css">

    <style>
    /* === Theme variables (match doctor dashboard) === */
    :root{
        --blue-1: #0f4d92;
        --blue-2: #1CA9C9;
        --pastel: #E6F6FF;
        --muted: #64748b;
        --bg: #f6fbff;
        --card-bg: rgba(255,255,255,0.75);
        --glass-border: rgba(255,255,255,0.35);
        --shadow: 0 6px 18px rgba(16,24,40,0.08);
        --radius: 12px;
        --glass-blur: 8px;
        --text-dark: #0f1724;
        --text-muted: #475569;
        --gap: 1rem;
    }

    /* Reset */
    *{box-sizing:border-box;margin:0;padding:0}
    html,body{height:100%}
    body{
        font-family: "Segoe UI", system-ui, -apple-system, "Helvetica Neue", Arial;
        background: radial-gradient(circle at top left, #e6f6ff 0%, #f1f8ff 100%);
        color: var(--text-dark);
        -webkit-font-smoothing:antialiased;
        -moz-osx-font-smoothing:grayscale;
        line-height:1.45;
    }

    /* Layout */
    .dashboard-container{ display:flex; min-height:100vh; gap:var(--gap); }

    /* Sidebar */
    .sidebar{
        width:260px;
        background: linear-gradient(180deg, rgba(255,255,255,0.7), rgba(246,249,255,0.55));
        border-radius: calc(var(--radius) + 4px);
        padding:1rem;
        display:flex;
        flex-direction:column;
        gap:0.75rem;
        align-items:stretch;
        box-shadow: var(--shadow);
        border: 1px solid var(--glass-border);
        backdrop-filter: blur(6px);
        transition: width 0.28s cubic-bezier(.22,.9,.36,1), transform .25s ease;
    }
    .sidebar.collapsed{ width:72px; padding:0.6rem; align-items:center; }
    /* hide text when collapsed */
    .sidebar.collapsed .sidebar-header h2,
    .sidebar.collapsed .nav-text,
    .sidebar.collapsed .profile-info { display:none !important; }

    .sidebar-header{ display:flex; align-items:center; gap:0.75rem; padding:0.6rem 0.6rem; }
    .logo-mark{ width:44px;height:44px;border-radius:10px; display:grid;place-items:center;color:white; background: linear-gradient(135deg,var(--blue-1),var(--blue-2)); box-shadow: 0 6px 18px rgba(15,77,146,0.18); font-weight:700; font-size:1.05rem; }
    .sidebar-header h2{ color:var(--blue-1); font-size:1.05rem; font-weight:700; }

    .sidebar-nav{ display:flex;flex-direction:column;gap:6px;padding:0.5rem 0; width:100%; }
    .nav-btn{ display:flex;align-items:center;gap:0.75rem; background:transparent;border:none;padding:0.6rem 0.8rem;border-radius:10px; cursor:pointer;color:var(--text-muted);font-size:0.95rem;transition: all 0.18s ease; text-decoration:none; width:100%; }
    .nav-btn .fa-fw{ width:20px; text-align:center }
    .nav-btn:hover{ transform:translateY(-2px); color:var(--blue-1); background: rgba(15,77,146,0.04) }
    .nav-btn.active{ background: linear-gradient(90deg, rgba(15,77,146,0.06), rgba(28,169,201,0.03)); color:var(--blue-1); border-left: 3px solid var(--blue-2); }

    .user-profile{ margin-top:auto; display:flex; align-items:center; gap:0.75rem; padding:0.6rem; border-radius:10px; background: linear-gradient(180deg, rgba(255,255,255,0.35), rgba(255,255,255,0.2)); border: 1px solid rgba(255,255,255,0.25); backdrop-filter: blur(4px); }
    .user-profile img{ width:44px;height:44px;border-radius:50%;object-fit:cover;border:2px solid white; box-shadow: 0 6px 14px rgba(16,24,40,0.06) }
    .profile-info h4{ font-size:0.95rem; margin-bottom:2px }
    .profile-info span{ font-size:0.82rem; color:var(--text-muted) }

    /* Main */
    .main-content{ flex:1; padding:1.25rem; overflow:auto; }

    .topbar{ display:flex;align-items:center;justify-content:space-between;gap:1rem;margin-bottom:1.25rem; }
    .hamburger{ background:transparent;border:none;padding:0.5rem;cursor:pointer;color:var(--text-muted); border-radius:6px; }
    .welcome-header{ background: linear-gradient(135deg, rgba(15,77,146,0.95), rgba(28,169,201,0.95)); color:white;padding:1.2rem;border-radius:14px; box-shadow: 0 12px 30px rgba(15,77,146,0.12); margin-bottom:1rem; }
    .welcome-header h1{ font-size:1.25rem; margin:0; }

    /* Cards */
    .card{
        background: var(--card-bg);
        border-radius: var(--radius);
        padding:1rem;
        box-shadow: var(--shadow);
        border: 1px solid var(--glass-border);
        backdrop-filter: blur(var(--glass-blur));
        margin-bottom:1rem;
    }
    .card-header {
        display:flex;
        justify-content:space-between;
        align-items:center;
        gap:1rem;
        padding:0.8rem 1rem;
        border-radius:8px;
        background: linear-gradient(90deg, rgba(15,77,146,0.06), rgba(28,169,201,0.02));
        color: var(--blue-1);
        font-weight:700;
        margin-bottom:0.75rem;
    }
    .card-body { padding:0.75rem 1rem; }

    /* Forms */
    .form-grid{ display:grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; }
    .form-group{ display:flex; flex-direction:column; gap:6px; }
    .form-control, .form-select { padding:10px; border-radius:8px; border:1px solid #e6e9ef; }

    .col-span-4 { grid-column: 1 / -1; }
    .inline-actions{ display:flex; gap:0.6rem; align-items:center; flex-wrap:wrap; }
    .btn { display:inline-flex; align-items:center; gap:0.5rem; padding:0.6rem 0.9rem; border-radius:10px; border:none; cursor:pointer; font-weight:600; text-decoration:none; }
    .btn-primary{ background: linear-gradient(90deg,var(--blue-1),var(--blue-2)); color:white; }
    .btn-ghost{ background:transparent; color:var(--text-dark); border:1px solid rgba(15,77,146,0.06); }
    .btn-outline{ background: transparent; border:1px solid rgba(15,77,146,0.12); color:var(--blue-1); }
    .btn-success{ background: #10b981; color: white; }
    .small{ font-size:0.85rem; padding:0.4rem 0.7rem; border-radius:8px; }

    .med-list{ display:flex; gap:8px; flex-wrap:wrap; margin-top:6px; }
    .med-chip{ background: rgba(28,169,201,0.12); color: var(--blue-1); padding:6px 10px; border-radius:999px; display:flex; gap:6px; align-items:center; font-size:0.9rem; }

    .prescription-list { display:grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap:1rem; margin-top:1rem; }
    .slot-item, .appointment-item { padding:0.9rem; border-radius:8px; }

    /* responsive adjustments */
    @media (max-width: 1100px) {
        .form-grid { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 720px) {
        .dashboard-container{ flex-direction:column; }
        .sidebar { display:none; } /* we'll use hamburger drawer on small screens */
        .form-grid { grid-template-columns: 1fr; }
        .col-span-4 { grid-column: auto; }
    }

    /* Mobile sidebar drawer */
    @media (max-width: 900px) {
        .sidebar{ position: fixed; left:-320px; top:0; bottom:0; height:100%; z-index:2000; width:260px; transition:left .25s ease; }
        .sidebar.open{ left:0; }
        .main-content{ padding:1rem; }
    }

    /* small helpers */
    .muted { color:var(--text-muted); }
    .small-text { font-size:0.85rem; color:var(--text-muted); }

    </style>
</head>
<body>
  <div class="dashboard-container">
    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo-mark">D</div>
            <h2>Dokotela</h2>
        </div>

        <nav class="sidebar-nav" id="sidebarNav">
            <button class="nav-btn" onclick="window.location.href='../Doctors/doctor-dashboard.php'">
                <i class="fa fa-home fa-fw"></i> <span class="nav-text">Overview</span>
            </button>
            <button class="nav-btn" onclick="window.location.href='../Doctors/doctor-appointments.php'">
                <i class="fa fa-calendar-check fa-fw"></i> <span class="nav-text">Appointments</span>
            </button>
            <button class="nav-btn" onclick="window.location.href='../Doctors/doctor-patients.php'">
                <i class="fa fa-users fa-fw"></i> <span class="nav-text">Patients</span>
            </button>
            <button class="nav-btn active" onclick="window.location.href='manage_slots.php'">
                <i class="fa fa-clock fa-fw"></i> <span class="nav-text">Schedule</span>
            </button>
            <button class="nav-btn" onclick="window.location.href='../Doctors/prescriptions.php'">
                <i class="fa fa-file-prescription fa-fw"></i> <span class="nav-text">Prescriptions</span>
            </button>
            <button class="nav-btn" onclick="window.location.href='../Doctors/profile.php'">
                <i class="fa fa-user-cog fa-fw"></i> <span class="nav-text">Settings</span>
            </button>
        </nav>

        <div class="user-profile">
            <img src="/assets/avatar-placeholder.png" alt="Doctor avatar" onerror="this.style.display='none'">
            <div class="profile-info">
                <h4><?= htmlspecialchars($doctor['firstName'] . ' ' . $doctor['lastName']) ?></h4>
                <span class="small muted">Doctor</span>
            </div>
        </div>
    </aside>

    <!-- MAIN -->
    <main class="main-content">
        <div class="topbar">
            <div style="display:flex; align-items:center; gap:1rem;">
                <button class="hamburger" id="sidebarToggle" title="Toggle sidebar" aria-label="Toggle sidebar">
                    <i class="fa fa-bars"></i>
                </button>
                <button class="hamburger" id="sidebarCollapse" title="Collapse sidebar" aria-label="Collapse sidebar">
                    <i class="fa fa-chevron-left"></i>
                </button>
                <div class="muted small-text">Manage appointment slots & bookings</div>
            </div>

            <div style="display:flex; align-items:center; gap:0.75rem;">
                <div style="display:flex; align-items:center; gap:0.6rem;">
                    <div style="background: rgba(255,255,255,0.12); padding:6px 10px; border-radius:12px;">
                        <i class="fa fa-calendar-alt" style="color:white; opacity:0.9;"></i>
                    </div>
                    <div class="small-text"><?= htmlspecialchars($doctor['firstName'] . ' ' . $doctor['lastName']) ?></div>
                </div>
            </div>
        </div>

        <div class="welcome-header">
            <h1>Manage Slots & Appointments</h1>
            <p class="small-text" style="margin-top:6px;">Create available slots, view booked appointments and manage cancellations.</p>
        </div>

        <?php if(isset($_SESSION['message'])): ?>
            <div class="card">
                <div class="alert alert-info d-flex align-items-center gap-2">
                    <i class="fas fa-info-circle"></i>
                    <div><?= $_SESSION['message'] ?></div>
                    <button type="button" class="btn-close ms-auto" onclick="this.parentElement.style.display='none'"></button>
                </div>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <!-- Date Picker -->
        <div class="card">
            <div class="card-header">
                <div style="display:flex; align-items:center; gap:0.75rem;">
                    <i class="fa fa-calendar-day"></i>
                    <strong>Select Date</strong>
                </div>
                <div class="small-text"><?= date('l, F j, Y', strtotime($selected_date)) ?></div>
            </div>
            <div class="card-body">
                <div class="date-picker-container" style="align-items:center; gap:1rem;">
                    <input type="text" id="datepicker" class="form-control w-auto" value="<?= htmlspecialchars($selected_date) ?>" autocomplete="off" style="max-width:160px;">
                    <div class="small-text muted">Choose a date to manage slots and appointments</div>
                </div>
            </div>
        </div>

        <!-- Slot Generator -->
        <div class="card">
            <div class="card-header">
                <div style="display:flex; align-items:center; gap:0.75rem;">
                    <i class="fa fa-plus-circle"></i>
                    <strong>Generate Appointment Slots</strong>
                </div>
                <div class="small-text muted">Create single or bulk hourly slots quickly</div>
            </div>

            <div class="card-body">
                <div style="display:flex; gap:0.5rem; margin-bottom:1rem;">
                    <button class="btn btn-ghost small mode-btn active" id="singleModeBtn">Single Slot</button>
                    <button class="btn btn-ghost small mode-btn" id="bulkModeBtn">Bulk Generate</button>
                </div>

                <!-- Single Slot Form -->
                <form class="single-section" id="singleForm" method="post" novalidate>
                    <div class="form-grid">
                        <div class="form-group">
                            <label class="form-label">Date</label>
                            <input type="date" class="form-control" name="slot_date" value="<?= htmlspecialchars($selected_date) ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Start Time</label>
                            <select class="form-select" name="start_time" id="startTime" required>
                                <option value="">Select hour</option>
                                <?php for ($h=0;$h<24;$h++):
                                    $t = sprintf("%02d:00",$h); ?>
                                    <option value="<?= $t ?>"><?= $t ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">End Time (Auto +1h)</label>
                            <input type="time" class="form-control" name="end_time" id="endTime" readonly required>
                        </div>
                        <div class="form-group" style="align-self:end;">
                            <button type="submit" name="add_slot" class="btn btn-primary w-100">
                                <i class="fa fa-plus me-1"></i> Add Slot
                            </button>
                        </div>
                    </div>
                </form>

                <!-- Bulk Generate Form -->
                <form class="bulk-section hidden" id="bulkForm" method="post" novalidate>
                    <div class="form-grid">
                        <div class="form-group">
                            <label class="form-label">Date</label>
                            <input type="date" class="form-control" name="bulk_date" value="<?= htmlspecialchars($selected_date) ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">From Hour</label>
                            <select class="form-select" name="bulk_start" required>
                                <?php for ($h=0;$h<24;$h++): ?>
                                    <option value="<?= $h ?>"><?= sprintf("%02d:00",$h) ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">To Hour</label>
                            <select class="form-select" name="bulk_end" required>
                                <?php for ($h=1;$h<=24;$h++): ?>
                                    <option value="<?= $h ?>"><?= sprintf("%02d:00",$h) ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="form-group" style="align-self:end;">
                            <button type="submit" name="generate_bulk" class="btn btn-success w-100">
                                <i class="fa fa-bolt me-1"></i> Generate Slots
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Available Slots -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div style="display:flex; align-items:center; gap:0.75rem;">
                    <i class="fa fa-clock"></i>
                    <strong>Available Slots</strong>
                    <div class="small-text muted">for <?= htmlspecialchars($selected_date) ?></div>
                </div>
                <div class="small-text"><span class="badge bg-primary"><?= $available_slots->num_rows ?> slots</span></div>
            </div>

            <div class="card-body p-0">
                <?php if($available_slots->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Start</th>
                                    <th>End</th>
                                    <th>Duration</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($s = $available_slots->fetch_assoc()): ?>
                                    <tr class="slot-item">
                                        <td><?= htmlspecialchars($s['start_time']) ?></td>
                                        <td><?= htmlspecialchars($s['end_time']) ?></td>
                                        <td>1 hour</td>
                                        <td>
                                            <a href="manage_slots.php?delete_slot=<?= $s['slot_id'] ?>&date=<?= urlencode($selected_date) ?>" 
                                               class="btn btn-sm btn-danger" 
                                               onclick="return confirm('Delete this available slot?')">
                                                <i class="fa fa-trash"></i> Delete
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state" style="padding:1.5rem;">
                        <i class="fa fa-calendar-times" style="font-size:3rem;color:var(--blue-2);"></i>
                        <h5 style="margin-top:8px;">No available slots for this day</h5>
                        <p class="text-muted">Use the form above to create new appointment slots.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Booked Appointments -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div style="display:flex; align-items:center; gap:0.75rem;">
                    <i class="fa fa-list-alt"></i>
                    <strong>Booked Appointments</strong>
                    <div class="small-text muted">(<?= htmlspecialchars($selected_date) ?>)</div>
                </div>
                <div class="small-text"><span class="badge bg-primary"><?= $appointments->num_rows ?> appointments</span></div>
            </div>

            <div class="card-body p-0">
                <?php if($appointments->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Time</th>
                                    <th>Patient Name</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($a = $appointments->fetch_assoc()): ?>
                                    <tr class="appointment-item">
                                        <td><?= htmlspecialchars($a['appointmentTime']) ?></td>
                                        <td><?= htmlspecialchars($a['firstName'] . ' ' . $a['lastName']) ?></td>
                                        <td>
                                            <span class="badge bg-success"><?= ucfirst(htmlspecialchars($a['status'])) ?></span>
                                        </td>
                                        <td>
                                            <a href="manage_slots.php?cancel_appointment=<?= $a['appointmentID'] ?>&date=<?= urlencode($selected_date) ?>" 
                                               class="btn btn-sm btn-warning"
                                               onclick="return confirm('Cancel this appointment? The time slot will become available again.')">
                                                <i class="fa fa-times"></i> Cancel
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state" style="padding:1.5rem;">
                        <i class="fa fa-calendar-check" style="font-size:3rem;color:var(--blue-2);"></i>
                        <h5 style="margin-top:8px;">No booked appointments today</h5>
                        <p class="text-muted">All your slots are available for booking.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </main>
  </div>

  <!-- Keep the same external scripts you used -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap-datepicker@1.10.0/dist/js/bootstrap-datepicker.min.js"></script>

  <script>
    // Sidebar collapse + mobile drawer
    const sidebar = document.getElementById('sidebar');
    const sidebarCollapseBtn = document.getElementById('sidebarCollapse');
    const sidebarToggleBtn = document.getElementById('sidebarToggle');

    sidebarCollapseBtn?.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
        // flip chevron
        const i = sidebarCollapseBtn.querySelector('i');
        if (i) i.classList.toggle('fa-chevron-right');
    });

    sidebarToggleBtn?.addEventListener('click', () => {
        if (window.innerWidth <= 900) {
            sidebar.classList.toggle('open');
        } else {
            sidebar.classList.toggle('collapsed');
        }
    });

    // Close mobile sidebar when clicking outside
    document.addEventListener('click', (e) => {
        if (window.innerWidth <= 900) {
            if (!e.target.closest('.sidebar') && !e.target.closest('#sidebarToggle')) {
                sidebar.classList.remove('open');
            }
        }
    });

    // Datepicker initialization
    $('#datepicker').datepicker({
        format: 'yyyy-mm-dd',
        autoclose: true,
        todayHighlight: true
    }).on('changeDate', function(e) {
        window.location.href = 'manage_slots.php?date=' + encodeURIComponent(e.format(0, 'yyyy-mm-dd'));
    });

    // Start time change handler
    $('#startTime').on('change', function() {
        const val = $(this).val();
        if (!val) return;
        const [h,m] = val.split(':').map(Number);
        const endH = (h + 1) % 24;
        $('#endTime').val(String(endH).padStart(2,'0') + ':00');
    });

    // Mode toggle
    $('#singleModeBtn').on('click', function() {
        $(this).addClass('active');
        $('#bulkModeBtn').removeClass('active');
        $('#singleForm').removeClass('hidden');
        $('#bulkForm').addClass('hidden');
    });
    $('#bulkModeBtn').on('click', function() {
        $(this).addClass('active');
        $('#singleModeBtn').removeClass('active');
        $('#bulkForm').removeClass('hidden');
        $('#singleForm').addClass('hidden');
    });

    // subtle animation delays
    document.querySelectorAll('.card').forEach((el, idx) => {
        el.style.animation = 'fadeIn .45s ease ' + (idx * 0.06) + 's both';
    });

    // ensure mobile drawer closed on resize to desktop
    window.addEventListener('resize', () => {
        if (window.innerWidth > 900) sidebar.classList.remove('open');
    });
  </script>
</body>
</html>
