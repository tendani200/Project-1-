<?php
session_start();
require '../db_connect.php';

$patient_id = $_SESSION['patient_id'] ?? 3;

if (isset($_GET['id'])) {
    $appointment_id = intval($_GET['id']);
    $appointment = $conn->query("SELECT * FROM Appointments WHERE appointmentID=$appointment_id AND patientID=$patient_id")->fetch_assoc();
    if ($appointment) {
        // Free the slot
        $conn->query("UPDATE appointment_slots SET is_booked=0 WHERE doctor_id={$appointment['doctorID']} AND slot_date='{$appointment['appointmentDate']}' AND start_time='{$appointment['appointmentTime']}'");
        // Cancel appointment
        $conn->query("UPDATE Appointments SET status='cancelled', cancelledAt=NOW(), cancelledBy='patient' WHERE appointmentID=$appointment_id");
    }
    header("Location: appointments_list.php");
    exit;
}
