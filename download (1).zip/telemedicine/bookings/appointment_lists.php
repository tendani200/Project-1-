<?php
session_start();
require 'db_connect.php';

// Simple: show all appointments
$appointments = $conn->query("SELECT a.*, s.start_time, s.end_time 
                              FROM Appointments a 
                              JOIN appointment_slots s 
                              ON a.doctorID=s.doctor_id 
                              AND a.appointmentDate=s.slot_date 
                              AND a.appointmentTime=s.start_time 
                              ORDER BY a.appointmentDate, a.appointmentTime");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Appointments List</title>
    <link rel="stylesheet" href="assets/bootstrap.min.css">
</head>
<body class="p-4">
<div class="container">
    <h2>All Appointments</h2>
    <table class="table table-bordered">
        <thead class="table-light">
            <tr><th>ID</th><th>Patient</th><th>Doctor</th><th>Date</th><th>Time</th><th>Status</th><th>Action</th></tr>
        </thead>
        <tbody>
        <?php while($a = $appointments->fetch_assoc()): ?>
            <tr>
                <td><?= $a['appointmentID'] ?></td>
                <td><?= $a['patientID'] ?></td>
                <td><?= $a['doctorID'] ?></td>
                <td><?= $a['appointmentDate'] ?></td>
                <td><?= $a['appointmentTime'] ?></td>
                <td><?= ucfirst($a['status']) ?></td>
                <td>
                    <?php if($a['status']=='booked'): ?>
                        <a href="cancel_appointment.php?id=<?= $a['appointmentID'] ?>" class="btn btn-sm btn-danger">Cancel</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>
