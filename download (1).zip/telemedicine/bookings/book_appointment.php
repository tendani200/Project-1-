<?php
session_start();
require '../db_connect.php';

// Check if patient is logged in
$patient_id = isset($_SESSION['patientID']) ? intval($_SESSION['patientID']) : 0;
if (!$patient_id) {
    header("Location: ../login.php");
    exit();
}

// Pre-selected doctor from URL - accept both doctor_id and doctorID
$doctor_id = isset($_GET['doctor_id']) ? intval($_GET['doctor_id']) : 
             (isset($_GET['doctorID']) ? intval($_GET['doctorID']) : 0);

// Debug: Check what parameters are received
error_log("Received doctor_id: " . ($_GET['doctor_id'] ?? 'not set'));
error_log("Received doctorID: " . ($_GET['doctorID'] ?? 'not set'));
error_log("Final doctor_id: " . $doctor_id);

// Validate doctor ID
if (!$doctor_id) {
    die("Doctor ID is required. Please select a doctor first.");
}

// Get patient info with error handling - FIXED QUERY
$patient_result = $conn->query("
    SELECT u.firstName, u.lastName, u.email, u.phone, u.userType, p.dateOfBirth, p.gender, p.address 
    FROM Patient p 
    JOIN User u ON p.userID = u.userID 
    WHERE p.patientID = $patient_id
");

if ($patient_result && $patient_result->num_rows > 0) {
    $patient = $patient_result->fetch_assoc();
} else {
    // Patient not found, create a default structure
    $patient = [
        'firstName' => 'Patient',
        'lastName' => '#' . $patient_id,
        'email' => 'email@example.com',
        'phone' => '',
        'dateOfBirth' => '',
        'gender' => '',
        'address' => ''
    ];
    error_log("Patient not found with ID: " . $patient_id);
}

// Get doctor info
$doctor = $conn->query("SELECT d.*, u.firstName, u.lastName 
                       FROM Doctor d 
                       JOIN User u ON d.userID = u.userID 
                       WHERE d.doctorID = $doctor_id")->fetch_assoc();

if (!$doctor) {
    die("Doctor not found");
}

// Get services for this doctor
$services = $conn->query("SELECT * FROM MedicalService WHERE doctorID = $doctor_id");

// Get patient's medical aid info
$medical_aid = $conn->query("SELECT * FROM MedicalAid WHERE patientID = $patient_id")->fetch_assoc();

$current_step = $_GET['step'] ?? 1;
$selected_service = $_SESSION['selected_service'] ?? null;
$selected_slot = $_SESSION['selected_slot'] ?? null;
$selected_date = $_SESSION['selected_date'] ?? null;
$payment_method = $_SESSION['payment_method'] ?? null;
$medical_aid_details = $_SESSION['medical_aid_details'] ?? null;

// Define booking fee
$booking_fee = 100.00;

// Handle step navigation and form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['slot_id'])) {
        // Step 1: Slot selection
        $_SESSION['selected_slot'] = intval($_POST['slot_id']);
        $_SESSION['selected_date'] = $_POST['appointment_date'] ?? date('Y-m-d');
        header("Location: ?doctor_id=$doctor_id&step=2");
        exit;
    }
    elseif (isset($_POST['service_id'])) {
        // Step 2: Service selection
        $_SESSION['selected_service'] = intval($_POST['service_id']);
        header("Location: ?doctor_id=$doctor_id&step=3");
        exit;
    }
    elseif (isset($_POST['payment_method'])) {
        // Step 3: Payment method selection
        $_SESSION['payment_method'] = $_POST['payment_method'];
        
        if ($_POST['payment_method'] === 'medical_aid') {
            // Save medical aid details
            $_SESSION['medical_aid_details'] = [
                'medicalAidName' => $_POST['medicalAidName'],
                'medicalAidNumber' => $_POST['medicalAidNumber'],
                'planType' => $_POST['planType'],
                'primaryMember' => isset($_POST['primaryMember']) ? 1 : 0
            ];
            
            // Save to database if not exists
            if (!$medical_aid) {
                $stmt = $conn->prepare("
                    INSERT INTO MedicalAid (patientID, medicalAidName, medicalAidNumber, planType, primaryMember)
                    VALUES (?, ?, ?, ?, ?)
                ");
                
                if ($stmt) {
                    $primary_member = isset($_POST['primaryMember']) ? 1 : 0;
                    $stmt->bind_param("isssi", $patient_id, $_POST['medicalAidName'], $_POST['medicalAidNumber'], $_POST['planType'], $primary_member);
                    $stmt->execute();
                    $stmt->close();
                } else {
                    error_log("Failed to prepare medical aid statement: " . $conn->error);
                }
            }
        }
        
        header("Location: ?doctor_id=$doctor_id&step=4");
        exit;
    }
    elseif (isset($_POST['confirm_booking'])) {
        // Step 4: Final confirmation and booking
        $conn->begin_transaction();
        
        try {
            // Get selected service and slot details
            $service = $conn->query("SELECT * FROM MedicalService WHERE serviceID = " . $_SESSION['selected_service'])->fetch_assoc();
            $slot = $conn->query("SELECT * FROM appointment_slots WHERE slot_id = " . $_SESSION['selected_slot'])->fetch_assoc();
            
            // Calculate amounts
            $service_fee = floatval($service['serviceFee']);
            $outstanding_amount = $service_fee - $booking_fee;
            
            // Update slot as booked
            $conn->query("UPDATE appointment_slots SET is_booked=1 WHERE slot_id=" . $_SESSION['selected_slot']);
            
            // Create appointment
            $stmt = $conn->prepare("INSERT INTO Appointments (patientID, doctorID, serviceID, appointmentDate, appointmentTime, status) VALUES (?, ?, ?, ?, ?, 'booked')");
            $stmt->bind_param("iiiss", $patient_id, $doctor_id, $_SESSION['selected_service'], $slot['slot_date'], $slot['start_time']);
            $stmt->execute();
            $appointment_id = $conn->insert_id;
            
            // Create payment record - store both booking fee and service fee details
            $payment_status = 'pending';
            $amount = $booking_fee; // Only charge booking fee initially

            // Prepare the payment statement - FIXED: Added service_fee and outstanding_amount columns
            $stmt = $conn->prepare("
                INSERT INTO Payments (appointmentID, patientID, serviceID, amount, paymentMethod, status, medicalAidID, service_fee, outstanding_amount) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            if ($stmt) {
                $service_id = (int)$_SESSION['selected_service'];
                $payment_method_val = $_SESSION['payment_method'];
                
                // Set medicalAidID to NULL for card payments
                $medical_aid_id = null;
                if ($_SESSION['payment_method'] === 'medical_aid' && $medical_aid) {
                    $medical_aid_id = $medical_aid['medicalAidID'];
                }
                
                // Bind parameters including service_fee and outstanding_amount
                $stmt->bind_param("iiidssidd", $appointment_id, $patient_id, $service_id, $amount, $payment_method_val, $payment_status, $medical_aid_id, $service_fee, $outstanding_amount);
                $stmt->execute();
                $stmt->close();
            } else {
                error_log("Failed to prepare payment statement: " . $conn->error);
                throw new Exception("Payment record creation failed");
            }
            
            // Create audit log
            $stmt = $conn->prepare("INSERT INTO AppointmentAuditLog (appointmentID, action, actionBy, newDate, newTime) VALUES (?, 'created', 'patient', ?, ?)");
            $stmt->bind_param("iss", $appointment_id, $slot['slot_date'], $slot['start_time']);
            $stmt->execute();
            
            $conn->commit();

            // Store payment method and service fee for display before clearing
            $_SESSION['payment_method_display'] = ($_SESSION['payment_method'] === 'medical_aid') ? 'Medical Aid' : 'Credit/Debit Card';
            $_SESSION['service_fee'] = $service_fee;
            $_SESSION['outstanding_amount'] = $outstanding_amount;

            // Store medical aid details for display
            if ($_SESSION['payment_method'] === 'medical_aid') {
                if ($medical_aid) {
                    $_SESSION['medical_aid_display'] = [
                        'name' => $medical_aid['medicalAidName'],
                        'number' => $medical_aid['medicalAidNumber'],
                        'plan' => $medical_aid['planType']
                    ];
                } elseif (isset($_SESSION['medical_aid_details'])) {
                    $_SESSION['medical_aid_display'] = [
                        'name' => $_SESSION['medical_aid_details']['medicalAidName'],
                        'number' => $_SESSION['medical_aid_details']['medicalAidNumber'],
                        'plan' => $_SESSION['medical_aid_details']['planType']
                    ];
                }
            }

            // Store booking success data
            $_SESSION['booking_success'] = true;
            $_SESSION['appointment_id'] = $appointment_id;

            // Clear session data (but keep what we need for display)
            unset($_SESSION['selected_service'], $_SESSION['selected_slot'], $_SESSION['selected_date'], $_SESSION['payment_method'], $_SESSION['medical_aid_details']);

            header("Location: ?doctor_id=$doctor_id&step=confirmation");
            exit;
        } catch (Exception $e) {
            $conn->rollback();
            $error = "Booking failed: " . $e->getMessage();
        }
    }
}

// Handle back navigation
if (isset($_GET['back'])) {
    $back_step = max(1, $current_step - 1);
    header("Location: ?doctor_id=$doctor_id&step=$back_step");
    exit;
}

// Get available slots
$slots = $conn->query("SELECT * FROM appointment_slots WHERE doctor_id=$doctor_id AND is_booked=0 AND slot_date >= CURDATE() ORDER BY slot_date, start_time");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Book Appointment - Dr. <?= $doctor['firstName'] . ' ' . $doctor['lastName'] ?></title>
    <link rel="stylesheet" href="assets/bootstrap.min.css">
    <style>
        /* Patient-dashboard continuation color scheme + polished UI
           Only CSS changed — backend and HTML structure preserved */
        :root{
            --bg: #F5EFEB;            /* page background */
            --card: rgba(255,255,255,0.98);
            --muted: rgba(47,65,86,0.6);
            --shadow: rgba(47,65,86,0.08);
            --accent-mid: #567C8D;    /* accent mid (links, highlights) */
            --accent-dark: #2F4156;   /* primary text color */
            --soft-1: #E7C6FF;        /* gradient start */
            --soft-2: #BBCCFF;        /* gradient end */
            --success: #28a745;
            --danger: #C23B22;
            --radius: 12px;
            --container-max: 1100px;
        }

        html,body{height:100%;margin:0;font-family:'Inter',system-ui,Arial,sans-serif;background:var(--bg);color:var(--accent-dark);-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}
        .container{max-width:var(--container-max);margin:20px auto;padding:18px}

        /* Top left back button styled to match patient dashboard */
        .top-header {
            display:flex;
            align-items:center;
            gap:12px;
            margin-bottom:14px;
        }
        .back-btn {
            background: transparent;
            border: 1px solid rgba(86,124,141,0.18);
            color: var(--accent-mid);
            padding: 10px 14px;
            border-radius: 10px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
        }

        h2 { margin: 0 0 8px 0; font-weight:700; }

        .step-progress {
            display: flex;
            justify-content: space-between;
            margin-bottom: 26px;
        }
        .step {
            text-align: center;
            flex: 1;
        }
        .step-number {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e9ecef;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
            font-weight: bold;
            color: var(--accent-dark);
        }
        .step.active .step-number {
            background: linear-gradient(90deg,var(--soft-1),var(--soft-2));
            color: var(--accent-dark);
            box-shadow: 0 6px 18px var(--shadow);
        }
        .step.completed .step-number {
            background: var(--success);
            color: white;
        }
        .step div { font-weight:600; color:var(--muted); }

        .service-card, .slot-card {
            border: 2px solid rgba(86,124,141,0.04);
            border-radius: 12px;
            padding: 18px;
            margin-bottom: 15px;
            cursor: pointer;
            transition: transform 0.18s ease, box-shadow 0.18s ease, border-color 0.18s ease, background 0.18s ease;
            background: var(--card);
            box-shadow: 0 8px 28px rgba(12,30,45,0.02);
        }
        .service-card:hover, .slot-card:hover {
            transform: translateY(-4px);
            border-color: rgba(86,124,141,0.12);
            box-shadow: 0 12px 36px rgba(12,30,45,0.04);
        }
        .service-card.selected, .slot-card.selected {
            border-color: var(--accent-mid);
            background: linear-gradient(180deg, rgba(231,198,255,0.12), rgba(187,204,255,0.06));
            box-shadow: 0 12px 36px rgba(12,30,45,0.05);
        }

        .payment-method {
            border: 2px solid rgba(86,124,141,0.04);
            border-radius: 12px;
            padding: 18px;
            margin-bottom: 15px;
            cursor: pointer;
            background: var(--card);
            transition: all 0.18s ease;
        }
        .payment-method.selected {
            border-color: var(--accent-mid);
            background: linear-gradient(180deg, rgba(231,198,255,0.10), rgba(187,204,255,0.06));
            box-shadow: 0 12px 28px rgba(12,30,45,0.04);
        }

        .confirmation-details {
            background: linear-gradient(180deg, #ffffff, #fbfbff);
            border-radius: 12px;
            padding: 20px;
            border: 1px solid rgba(86,124,141,0.04);
            box-shadow: 0 10px 30px rgba(12,30,45,0.03);
        }

        .badge {
            display:inline-block;
            padding:6px 10px;
            border-radius: 8px;
            background: linear-gradient(90deg,var(--soft-1),var(--soft-2));
            color: var(--accent-dark);
            font-weight:700;
            box-shadow:0 6px 18px rgba(12,30,45,0.04);
        }

        .btn-primary {
            background: linear-gradient(90deg,var(--soft-1),var(--soft-2));
            border: none;
            color: var(--accent-dark);
            padding: 10px 18px;
            border-radius: 10px;
            font-weight:700;
            box-shadow: 0 8px 20px rgba(12,30,45,0.05);
        }
        .btn-secondary {
            background: transparent;
            border: 1px solid rgba(86,124,141,0.12);
            color: var(--accent-mid);
            padding: 10px 18px;
            border-radius: 10px;
            font-weight:700;
        }
        .btn-success {
            background: var(--success);
            color: #fff;
            border: none;
            padding: 10px 18px;
            border-radius: 10px;
            font-weight:700;
        }

        .outstanding-amount {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 15px;
            margin: 15px 0;
        }

        /* small responsive tweaks */
        @media (max-width: 768px){
            .step-progress { flex-direction: column; gap:10px; }
            .step { display:flex; align-items:center; gap:12px; }
            .step-number { margin:0; }
        }
    </style>
</head>
<body class="p-4">
<div class="container">

    <!-- Top header: Back to dashboard (top-left) -->
    <div class="top-header">
        <a href="/telemedicine/patient/patient_dashboard.php" class="back-btn">
            <i class="fa-solid fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>

    <h2>Book Appointment with Dr. <?= $doctor['firstName'] . ' ' . $doctor['lastName'] ?></h2>
    
    <!-- Progress Steps -->
    <div class="step-progress">
        <div class="step <?= $current_step >= 1 ? 'completed' : '' ?> <?= $current_step == 1 ? 'active' : '' ?>">
            <div class="step-number">1</div>
            <div>Date & Time</div>
        </div>
        <div class="step <?= $current_step >= 2 ? 'completed' : '' ?> <?= $current_step == 2 ? 'active' : '' ?>">
            <div class="step-number">2</div>
            <div>Service</div>
        </div>
        <div class="step <?= $current_step >= 3 ? 'completed' : '' ?> <?= $current_step == 3 ? 'active' : '' ?>">
            <div class="step-number">3</div>
            <div>Payment</div>
        </div>
        <div class="step <?= $current_step >= 4 ? 'completed' : '' ?> <?= $current_step == 4 ? 'active' : '' ?>">
            <div class="step-number">4</div>
            <div>Confirmation</div>
        </div>
    </div>

    <?php if(isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <!-- Step 1: Date & Time Selection -->
    <?php if($current_step == 1): ?>
    <?php 
    // Handle selected date
    $selected_date = $_SESSION['selected_date'] ?? date('Y-m-d');

    // If form submitted with new date, update session
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['appointment_date'])) {
        $selected_date = $_POST['appointment_date'];
        $_SESSION['selected_date'] = $selected_date;
    }

    // Get available slots for selected date
    $slots = $conn->query("
        SELECT * FROM appointment_slots 
        WHERE doctor_id=$doctor_id 
          AND is_booked=0 
          AND slot_date='$selected_date' 
        ORDER BY start_time
    ");
    ?>
    <form method="post">
        <h3>Select Date & Time</h3>
        <p class="text-muted">Choose your preferred appointment date and time</p>

        <!-- Date Picker -->
        <h5>Select Date</h5>
        <div class="mb-4">
            <input type="date" id="appointment_date" name="appointment_date" class="form-control" 
                   value="<?= $selected_date ?>" min="<?= date('Y-m-d') ?>" required onchange="submitDateChange()">
        </div>

        <!-- Available Slots -->
        <h5>Available Time Slots</h5>
        <div class="row">
            <?php if($slots->num_rows > 0): ?>
                <?php while($slot = $slots->fetch_assoc()): ?>
                <div class="col-md-4 mb-3">
                    <div class="slot-card" onclick="selectSlot(<?= $slot['slot_id'] ?>)">
                        <input type="radio" name="slot_id" value="<?= $slot['slot_id'] ?>" id="slot_<?= $slot['slot_id'] ?>" style="display: none;" required>
                        <h6><?= date('D, M j', strtotime($slot['slot_date'])) ?></h6>
                        <p class="mb-1"><?= date('g:i A', strtotime($slot['start_time'])) ?> - <?= date('g:i A', strtotime($slot['end_time'])) ?></p>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="text-muted">No slots available for this date. Please select another date.</p>
            <?php endif; ?>
        </div>
        
        <div class="mt-4">
            <button type="submit" class="btn-primary">Continue to Service Selection</button>
        </div>
    </form>

    <script>
    function submitDateChange() {
        // Submit only the date change
        const form = document.createElement('form');
        form.method = 'post';
        form.action = '';

        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'appointment_date';
        input.value = document.getElementById('appointment_date').value;
        form.appendChild(input);

        document.body.appendChild(form);
        form.submit();
    }

    // Auto-select previously chosen slot
    <?php if($current_step == 1 && $selected_slot): ?>
    document.addEventListener('DOMContentLoaded', function() {
        selectSlot(<?= $selected_slot ?>);
    });
    <?php endif; ?>
    </script>
    <?php endif; ?>

    <!-- Step 2: Service Selection -->
    <?php if($current_step == 2 && $selected_slot): ?>
    <?php 
    $slot_details = $conn->query("SELECT * FROM appointment_slots WHERE slot_id = $selected_slot")->fetch_assoc();
    ?>
    <form method="post">
        <h3>Select Service</h3>
        <p class="text-muted">Choose the medical service you require</p>
        
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5>Selected Appointment</h5>
                        <p><strong>Date:</strong> <?= date('D, M j, Y', strtotime($slot_details['slot_date'])) ?></p>
                        <p><strong>Time:</strong> <?= date('g:i A', strtotime($slot_details['start_time'])) ?> - <?= date('g:i A', strtotime($slot_details['end_time'])) ?></p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <?php while($service = $services->fetch_assoc()): ?>
            <div class="col-md-6">
                <div class="service-card" onclick="selectService(<?= $service['serviceID'] ?>)">
                    <input type="radio" name="service_id" value="<?= $service['serviceID'] ?>" id="service_<?= $service['serviceID'] ?>" style="display: none;" required>
                    <h5><?= $service['serviceName'] ?></h5>
                    <p class="text-muted"><?= $service['serviceDescription'] ?></p>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="badge"><?= $service['serviceDuration'] ?> mins</span>
                        <span class="text-success"><strong>R <?= number_format($service['serviceFee'], 2) ?></strong></span>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
        
        <div class="mt-4 d-flex justify-content-between">
            <a href="?doctor_id=<?= $doctor_id ?>&step=1" class="btn-secondary">Back</a>
            <button type="submit" class="btn-primary">Continue to Payment</button>
        </div>
    </form>
    <?php endif; ?>

    <!-- Step 3: Payment Method -->
    <?php if($current_step == 3 && $selected_service && $selected_slot): ?>
    <?php 
    $service_details = $conn->query("SELECT * FROM MedicalService WHERE serviceID = $selected_service")->fetch_assoc();
    $slot_details = $conn->query("SELECT * FROM appointment_slots WHERE slot_id = $selected_slot")->fetch_assoc();
    $outstanding_amount = $service_details['serviceFee'] - $booking_fee;
    ?>
    <form method="post">
        <h3>Payment</h3>
        
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="confirmation-details">
                    <h5>Appointment Summary</h5>
                    <p><strong>Service:</strong> <?= $service_details['serviceName'] ?></p>
                    <p><strong>Date:</strong> <?= date('D, M j, Y', strtotime($slot_details['slot_date'])) ?></p>
                    <p><strong>Time:</strong> <?= date('g:i A', strtotime($slot_details['start_time'])) ?> - <?= date('g:i A', strtotime($slot_details['end_time'])) ?></p>
                    <p><strong>Service Fee:</strong> R <?= number_format($service_details['serviceFee'], 2) ?></p>
                    <p><strong>Booking Fee:</strong> R <?= number_format($booking_fee, 2) ?></p>
                    <p><strong>Outstanding Amount:</strong> R <?= number_format($outstanding_amount, 2) ?></p>
                </div>
            </div>
        </div>

        <h5>Pay Booking Fee</h5>
        <p class="text-muted">Pay R<?= number_format($booking_fee, 2) ?> now to secure your appointment. The remaining R<?= number_format($outstanding_amount, 2) ?> will be settled after your appointment.</p>
        
        <div class="row">
            <!-- Medical Aid Option -->
            <div class="col-md-6">
                <div class="payment-method" onclick="selectPayment('medical_aid')">
                    <input type="radio" name="payment_method" value="medical_aid" id="medical_aid" style="display: none;">
                    <h6>Medical Aid</h6>
                    <p class="text-muted">Pay using your medical aid</p>
                </div>
                
                <div id="medicalAidDetails" style="display: none;">
                    <div class="card mt-3">
                        <div class="card-body">
                            <h6>Medical Aid Details</h6>

                            <?php if($medical_aid): ?>
                                <p>Using saved medical aid: <?= $medical_aid['medicalAidName'] ?> (<?= $medical_aid['medicalAidNumber'] ?>)</p>
                                <button type="button" class="btn btn-sm btn-outline-primary mb-2" onclick="showNewMedicalAid()">Use New Medical Aid</button>
                            <?php endif; ?>

                            <div id="newMedicalAidForm" style="display: <?= $medical_aid ? 'none' : 'block' ?>;">
                                <div class="mb-3">
                                    <label class="form-label">Medical Aid Name</label>
                                    <input type="text" name="medicalAidName" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Medical Aid Number</label>
                                    <input type="text" name="medicalAidNumber" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Plan Type</label>
                                    <input type="text" name="planType" class="form-control">
                                </div>
                                <div class="form-check">
                                    <input type="checkbox" name="primaryMember" class="form-check-input" checked>
                                    <label class="form-check-label">Primary Member</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card Option -->
            <div class="col-md-6">
                <div class="payment-method" onclick="selectPayment('card')">
                    <input type="radio" name="payment_method" value="card" id="card" style="display: none;">
                    <h6>Credit/Debit Card</h6>
                    <p class="text-muted">Pay securely with your card</p>
                </div>
            </div>
        </div>

        <div class="mt-4 d-flex justify-content-between">
            <a href="?doctor_id=<?= $doctor_id ?>&step=2" class="btn-secondary">Back</a>
            <button type="submit" class="btn-primary">Continue to Confirmation</button>
        </div>
    </form>

    <script>
    function selectPayment(method) {
        document.querySelectorAll('.payment-method').forEach(card => card.classList.remove('selected'));
        const card = document.querySelector(`.payment-method[onclick="selectPayment('${method}')"]`);
        card.classList.add('selected');
        document.getElementById(method).checked = true;

        const medicalAidDetails = document.getElementById('medicalAidDetails');
        if(method === 'medical_aid') {
            medicalAidDetails.style.display = 'block';
            // Enable inputs only if visible
            document.querySelectorAll('#newMedicalAidForm input').forEach(input => input.disabled = false);
        } else {
            medicalAidDetails.style.display = 'none';
            // Disable inputs when hidden
            document.querySelectorAll('#newMedicalAidForm input').forEach(input => input.disabled = true);
        }
    }

    function showNewMedicalAid() {
        const form = document.getElementById('newMedicalAidForm');
        form.style.display = 'block';
        // Enable inputs so form can be submitted
        form.querySelectorAll('input').forEach(input => input.disabled = false);
    }

    // Disable hidden inputs on page load
    document.querySelectorAll('#newMedicalAidForm input').forEach(input => {
        if(input.closest('#newMedicalAidForm').style.display === 'none') input.disabled = true;
    });

    // Auto-select previously chosen payment method
    <?php if($payment_method): ?>
    document.addEventListener('DOMContentLoaded', function() {
        selectPayment('<?= $payment_method ?>');
    });
    <?php endif; ?>
    </script>
    <?php endif; ?>

    <!-- Step 4: Confirmation -->
    <?php if($current_step == 4 && $selected_service && $selected_slot && $payment_method): ?>
    <?php 
    $service_details = $conn->query("SELECT * FROM MedicalService WHERE serviceID = $selected_service")->fetch_assoc();
    $slot_details = $conn->query("SELECT * FROM appointment_slots WHERE slot_id = $selected_slot")->fetch_assoc();
    $outstanding_amount = $service_details['serviceFee'] - $booking_fee;
    
    // Get medical aid details for display
    $medical_aid_display = null;
    if ($payment_method === 'medical_aid') {
        if ($medical_aid) {
            $medical_aid_display = [
                'name' => $medical_aid['medicalAidName'],
                'number' => $medical_aid['medicalAidNumber'],
                'plan' => $medical_aid['planType']
            ];
        } elseif (isset($medical_aid_details)) {
            $medical_aid_display = [
                'name' => $medical_aid_details['medicalAidName'],
                'number' => $medical_aid_details['medicalAidNumber'],
                'plan' => $medical_aid_details['planType']
            ];
        }
    }
    ?>
    <form method="post">
        <div class="confirmation-details">
            <h3>Confirm Your Appointment</h3>
            <p class="text-muted">Please review your appointment details before confirming</p>
            
            <div class="row mt-4">
                <div class="col-md-6">
                    <h6>Patient Details</h6>
                    <p><strong>Name:</strong> <?= htmlspecialchars($patient['firstName'] . ' ' . $patient['lastName']) ?></p>
                    <p><strong>Email:</strong> <?= htmlspecialchars($patient['email']) ?></p>
                </div>
                
                <div class="col-md-6">
                    <h6>Service Details</h6>
                    <p><strong>Service:</strong> <?= $service_details['serviceName'] ?></p>
                    <p><strong>Description:</strong> <?= $service_details['serviceDescription'] ?></p>
                    <p><strong>Duration:</strong> <?= $service_details['serviceDuration'] ?> minutes</p>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-md-6">
                    <h6>Appointment Details</h6>
                    <p><strong>Date:</strong> <?= date('l, F j, Y', strtotime($slot_details['slot_date'])) ?></p>
                    <p><strong>Time:</strong> <?= date('g:i A', strtotime($slot_details['start_time'])) ?> - <?= date('g:i A', strtotime($slot_details['end_time'])) ?></p>
                    <p><strong>Doctor:</strong> Dr. <?= $doctor['firstName'] . ' ' . $doctor['lastName'] ?></p>
                </div>
                
                <div class="col-md-6">
                    <h6>Payment Details</h6>
                    <p><strong>Payment Method:</strong> <?= $payment_method === 'medical_aid' ? 'Medical Aid' : 'Credit/Debit Card' ?></p>
                    <p><strong>Booking Fee:</strong> R <?= number_format($booking_fee, 2) ?></p>
                    <p><strong>Service Fee:</strong> R <?= number_format($service_details['serviceFee'], 2) ?></p>
                    <div class="outstanding-amount">
                        <strong>Outstanding Amount:</strong> R <?= number_format($outstanding_amount, 2) ?>
                        <small class="d-block text-muted">To be settled after your appointment</small>
                    </div>
                    <?php if($payment_method === 'medical_aid' && $medical_aid_display): ?>
                        <p><strong>Medical Aid:</strong> <?= $medical_aid_display['name'] ?> (<?= $medical_aid_display['number'] ?>) - <?= $medical_aid_display['plan'] ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="mt-4 d-flex justify-content-between">
                <a href="?doctor_id=<?= $doctor_id ?>&step=3" class="btn-secondary">Back</a>
                <button type="submit" name="confirm_booking" class="btn-success btn-lg">
                    <i class="fa fa-check-circle"></i> Confirm Booking & Pay R<?= number_format($booking_fee, 2) ?>
                </button>
            </div>
        </div>
    </form>
    <?php endif; ?>

    <!-- Success Confirmation Page -->
    <?php if($current_step == 'confirmation' && isset($_SESSION['booking_success'])): ?>
    <?php
    // Get the appointment details for confirmation page
    $appointment_id = $_SESSION['appointment_id'] ?? 0;
    $payment_method_display = $_SESSION['payment_method_display'] ?? 'Credit/Debit Card';
    $service_fee = $_SESSION['service_fee'] ?? 0;
    $outstanding_amount = $_SESSION['outstanding_amount'] ?? 0;
    $medical_aid_display = $_SESSION['medical_aid_display'] ?? null;

    if ($appointment_id) {
        $appointment_details = $conn->query("
            SELECT a.*, s.serviceName, s.serviceDuration, s.serviceFee,
                   d.doctorID, u.firstName as doctorFirstName, u.lastName as doctorLastName,
                   sl.slot_date, sl.start_time, sl.end_time
            FROM Appointments a
            LEFT JOIN MedicalService s ON a.serviceID = s.serviceID
            LEFT JOIN Doctor d ON a.doctorID = d.doctorID  
            LEFT JOIN User u ON d.userID = u.userID
            LEFT JOIN appointment_slots sl ON a.appointmentDate = sl.slot_date AND a.appointmentTime = sl.start_time
            WHERE a.appointmentID = $appointment_id
        ")->fetch_assoc();
    }

    // Get fresh patient data for confirmation - FIXED QUERY
    $patient_data = $conn->query("
        SELECT u.firstName, u.lastName, u.email, u.phone, u.userType, 
               p.dateOfBirth, p.gender, p.address 
        FROM Patient p 
        JOIN User u ON p.userID = u.userID 
        WHERE p.patientID = $patient_id
    ")->fetch_assoc();
    ?>
    <div class="confirmation-details">
        <h3>Appointment Confirmed! ✅</h3>
        <div class="alert alert-success">
            <h4>Your appointment has been successfully booked!</h4>
            <p class="mb-0">Appointment ID: #<?= $appointment_id ?></p>
            <p class="mb-0">A confirmation email has been sent to <?= htmlspecialchars($patient_data['email'] ?? $patient['email']) ?></p>
        </div>
        
        <div class="row mt-4">
            <div class="col-md-6">
                <h6>Patient Details</h6>
                <p><strong>Name:</strong> <?= htmlspecialchars($patient_data['firstName'] ?? $patient['firstName']) ?> <?= htmlspecialchars($patient_data['lastName'] ?? $patient['lastName']) ?></p>
                <p><strong>Email:</strong> <?= htmlspecialchars($patient_data['email'] ?? $patient['email']) ?></p>
                <?php if(!empty($patient_data['phone'])): ?>
                    <p><strong>Phone:</strong> <?= htmlspecialchars($patient_data['phone']) ?></p>
                <?php endif; ?>
                <?php if(!empty($patient_data['dateOfBirth'])): ?>
                    <p><strong>Date of Birth:</strong> <?= date('F j, Y', strtotime($patient_data['dateOfBirth'])) ?></p>
                <?php endif; ?>
                <?php if(!empty($patient_data['gender'])): ?>
                    <p><strong>Gender:</strong> <?= htmlspecialchars($patient_data['gender']) ?></p>
                <?php endif; ?>
            </div>
            
            <div class="col-md-6">
                <h6>Service Details</h6>
                <p><strong>Service:</strong> <?= $appointment_details['serviceName'] ?? 'Medical Service' ?></p>
                <p><strong>Duration:</strong> <?= $appointment_details['serviceDuration'] ?? '30' ?> minutes</p>
                <p><strong>Service Fee:</strong> R <?= number_format($service_fee, 2) ?></p>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
                <h6>Appointment Details</h6>
                <p><strong>Date:</strong> <?= date('l, F j, Y', strtotime($appointment_details['slot_date'] ?? $appointment_details['appointmentDate'] ?? '')) ?></p>
                <p><strong>Time:</strong> <?= date('g:i A', strtotime($appointment_details['start_time'] ?? $appointment_details['appointmentTime'] ?? '')) ?></p>
                <p><strong>Doctor:</strong> Dr. <?= $appointment_details['doctorFirstName'] ?? $doctor['firstName'] ?> <?= $appointment_details['doctorLastName'] ?? $doctor['lastName'] ?></p>
            </div>
            
            <div class="col-md-6">
                <h6>Payment Details</h6>
                <p><strong>Payment Method:</strong> <?= $payment_method_display ?></p>
                <p><strong>Booking Fee Paid:</strong> R <?= number_format($booking_fee, 2) ?></p>
                <div class="outstanding-amount">
                    <strong>Outstanding Amount:</strong> R <?= number_format($outstanding_amount, 2) ?>
                    <small class="d-block text-muted">To be settled after your appointment</small>
                </div>
                <?php if($medical_aid_display): ?>
                    <p><strong>Medical Aid:</strong> <?= $medical_aid_display['name'] ?> (<?= $medical_aid_display['number'] ?>) - <?= $medical_aid_display['plan'] ?></p>
                <?php endif; ?>
                <p><strong>Payment Status:</strong> <span class="badge bg-warning">Pending</span></p>
                <p><strong>Reference:</strong> APPT-<?= $appointment_id ?></p>
            </div>
        </div>

        <div class="mt-4 text-center">
            <div class="alert alert-info">
                <i class="fa fa-info-circle"></i> 
                You will be redirected to your dashboard shortly, or 
                <a href="/telemedicine/patient/patient_dashboard.php" class="alert-link">click here</a> to go now.
            </div>
        </div>
    </div>

    <script>
    // Redirect to dashboard after 8 seconds
    setTimeout(function() {
        window.location.href = "/telemedicine/patient/patient_dashboard.php";
    }, 8000);
    </script>
    <?php 
    // Clear the success flags after displaying
    unset($_SESSION['booking_success'], $_SESSION['appointment_id'], $_SESSION['payment_method_display'], $_SESSION['service_fee'], $_SESSION['outstanding_amount'], $_SESSION['medical_aid_display']);
    ?>
    <?php endif; ?>

</div>

<script>
function selectService(serviceId) {
    document.querySelectorAll('.service-card').forEach(card => {
        card.classList.remove('selected');
    });
    document.querySelector(`.service-card[onclick="selectService(${serviceId})"]`).classList.add('selected');
    document.getElementById(`service_${serviceId}`).checked = true;
}

function selectSlot(slotId) {
    document.querySelectorAll('.slot-card').forEach(card => {
        card.classList.remove('selected');
    });
    document.querySelector(`.slot-card[onclick="selectSlot(${slotId})"]`).classList.add('selected');
    document.getElementById(`slot_${slotId}`).checked = true;
}

function selectPayment(method) {
    document.querySelectorAll('.payment-method').forEach(card => {
        card.classList.remove('selected');
    });
    document.querySelector(`.payment-method[onclick="selectPayment('${method}')"]`).classList.add('selected');
    document.getElementById(method).checked = true;
    
    // Show/hide medical aid details
    const medicalAidDetails = document.getElementById('medicalAidDetails');
    if (method === 'medical_aid') {
        medicalAidDetails.style.display = 'block';
    } else {
        medicalAidDetails.style.display = 'none';
    }
}

// Auto-select if coming back to step
<?php if($current_step == 2 && $selected_service): ?>
document.addEventListener('DOMContentLoaded', function() {
    selectService(<?= $selected_service ?>);
});
<?php endif; ?>

<?php if($current_step == 1 && $selected_slot): ?>
document.addEventListener('DOMContentLoaded', function() {
    selectSlot(<?= $selected_slot ?>);
});
<?php endif; ?>

<?php if($current_step == 3 && $payment_method): ?>
document.addEventListener('DOMContentLoaded', function() {
    selectPayment('<?= $payment_method ?>');
});
<?php endif; ?>
</script>
</body>
</html>