<?php
// admin_announcements.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if admin is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

$userID = intval($_SESSION['userID']);

// Create database connection
try {
    $host = 'sql206.byetcluster.com';
    $dbname = 'if0_40031860_dok';
    $username = 'if0_40031860';
    $password = "qzJkHEejybefK";  
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Handle announcement actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_announcement'])) {
        $title = $_POST['title'];
        $content = $_POST['content'];
        $target_audience = $_POST['target_audience'];
        $is_urgent = isset($_POST['is_urgent']) ? 1 : 0;
        
        try {
            $stmt = $pdo->prepare("INSERT INTO Announcements (title, content, targetAudience, isUrgent, createdBy) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$title, $content, $target_audience, $is_urgent, $userID]);
            
            $_SESSION['message'] = "Announcement created successfully!";
        } catch (PDOException $e) {
            $_SESSION['error'] = "Error creating announcement: " . $e->getMessage();
        }
        header("Location: admin_announcements.php");
        exit();
    }
    
    if (isset($_POST['delete_announcement'])) {
        $announcement_id = $_POST['announcement_id'];
        
        try {
            $stmt = $pdo->prepare("DELETE FROM Announcements WHERE announcementID = ?");
            $stmt->execute([$announcement_id]);
            $_SESSION['message'] = "Announcement deleted successfully!";
        } catch (PDOException $e) {
            $_SESSION['error'] = "Error deleting announcement: " . $e->getMessage();
        }
        header("Location: admin_announcements.php");
        exit();
    }
}

// Get announcements with filters
try {
    $audience_filter = $_GET['audience'] ?? 'all';
    $urgent_filter = $_GET['urgent'] ?? 'all';
    $search_query = $_GET['search'] ?? '';
    
    $query = "SELECT a.*, u.firstName, u.lastName 
              FROM Announcements a 
              JOIN User u ON a.createdBy = u.userID 
              WHERE 1=1";
    
    $params = [];
    
    if ($audience_filter !== 'all') {
        $query .= " AND a.targetAudience = ?";
        $params[] = $audience_filter;
    }
    
    if ($urgent_filter !== 'all') {
        $query .= " AND a.isUrgent = ?";
        $params[] = ($urgent_filter === 'urgent') ? 1 : 0;
    }
    
    if (!empty($search_query)) {
        $query .= " AND (a.title LIKE ? OR a.content LIKE ?)";
        $search_term = "%$search_query%";
        $params[] = $search_term;
        $params[] = $search_term;
    }
    
    $query .= " ORDER BY a.isUrgent DESC, a.createdAt DESC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $announcements = $stmt->fetchAll();
    
    // Get announcement statistics
    $total_announcements = $pdo->query("SELECT COUNT(*) FROM Announcements")->fetchColumn();
    $urgent_announcements = $pdo->query("SELECT COUNT(*) FROM Announcements WHERE isUrgent = 1")->fetchColumn();
    $today_announcements = $pdo->query("SELECT COUNT(*) FROM Announcements WHERE DATE(createdAt) = CURDATE()")->fetchColumn();
    $all_audience = $pdo->query("SELECT COUNT(*) FROM Announcements WHERE targetAudience = 'all'")->fetchColumn();
    $doctors_audience = $pdo->query("SELECT COUNT(*) FROM Announcements WHERE targetAudience = 'doctors'")->fetchColumn();
    $patients_audience = $pdo->query("SELECT COUNT(*) FROM Announcements WHERE targetAudience = 'patients'")->fetchColumn();
    
} catch (PDOException $e) {
    $error = "Error loading announcements: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcements - Dokotela Admin</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
:root{
    --blue-1: #0f4d92;
    --blue-2: #1CA9C9;
    --pastel: #E6F6FF;
    --bright-red: #ff2d55;
    --muted: #64748b;
    --bg: #f6fbff;
    --card-bg: rgba(255,255,255,0.75);
    --glass-border: rgba(255,255,255,0.35);
    --shadow: 0 6px 18px rgba(16,24,40,0.08);
    --radius: 12px;
    --glass-blur: 8px;
    --text-dark: #0f1724;
    --text-muted: #475569;
    --gap: 1rem;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%}
body{
    font-family: "Segoe UI", system-ui, -apple-system, "Helvetica Neue", Arial;
    background: #f1f8ff;
    background: radial-gradient(circle at top left, #e6f6ff 0%, #f1f8ff 100%);
    color: var(--text-dark);
}

.dashboard-container{
    display:flex;
    min-height:100vh;
    gap:var(--gap);
    transition: all 0.3s ease;
}
.sidebar{
    width:260px;
    background: linear-gradient(180deg, rgba(255,255,255,0.7), rgba(246,249,255,0.55));
    border-radius: calc(var(--radius) + 4px);
    padding:1rem;
    display:flex;
    flex-direction:column;
    gap:0.75rem;
    align-items:stretch;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(6px);
    transition: width 0.28s cubic-bezier(.22,.9,.36,1), transform 0.3s ease;
}
.sidebar.collapsed{ width:72px; padding:0.6rem; align-items:center }
.sidebar.collapsed .sidebar-header h2,
.sidebar.collapsed .nav-text,
.sidebar.collapsed .profile-info { display:none }
.sidebar.collapsed .nav-btn { justify-content:center }
.sidebar-header{
    display:flex;
    align-items:center;
    gap:0.75rem;
    padding:0.6rem 0.6rem;
}
.logo-mark{
    width:44px;height:44px;border-radius:10px;
    display:grid;place-items:center;color:white;
    background: linear-gradient(135deg,var(--blue-1),var(--blue-2));
    box-shadow: 0 6px 18px rgba(15,77,146,0.18);
    font-weight:700;
    font-size:1.05rem;
}
.sidebar-header h2{ color:var(--blue-1); font-size:1.05rem; font-weight:700; }
.sidebar-nav{
    display:flex;flex-direction:column;gap:6px;padding:0.5rem 0;
    width:100%;
}
.nav-btn{
    display:flex;align-items:center;gap:0.75rem;
    background:transparent;border:none;padding:0.6rem 0.8rem;border-radius:10px;
    cursor:pointer;color:var(--text-muted);font-size:0.95rem;transition: all 0.18s ease;
    text-decoration:none;
}
.nav-btn .fa-fw{ width:20px; text-align:center }
.nav-btn:hover{ transform:translateY(-2px); color:var(--blue-1); background: rgba(15,77,146,0.04) }
.nav-btn.active{
    background: linear-gradient(90deg, rgba(15,77,146,0.06), rgba(28,169,201,0.03));
    color:var(--blue-1);
    border-left: 3px solid var(--blue-2);
}
.nav-text{ flex:1 }
.user-profile{
    margin-top:auto;display:flex;align-items:center;gap:0.75rem;padding:0.6rem;border-radius:10px;
    background: linear-gradient(180deg, rgba(255,255,255,0.35), rgba(255,255,255,0.2));
    border: 1px solid rgba(255,255,255,0.25);
    backdrop-filter: blur(4px);
}
.user-profile img{ width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid white; box-shadow: 0 6px 14px rgba(16,24,40,0.06) }
.profile-info h4{ font-size:0.95rem; margin-bottom:2px }
.profile-info span{ font-size:0.82rem; color:var(--text-muted) }
.main-content{
    flex:1;padding:1.5rem;overflow:auto;
}
.topbar{
    display:flex;align-items:center;justify-content:space-between;gap:1rem;margin-bottom:1.25rem;
}
.topbar-left{
    display:flex;align-items:center;gap:1rem;
}
.hamburger{
    background:transparent;border:none;padding:0.5rem;cursor:pointer;color:var(--text-muted);
    border-radius:6px;transition:all 0.2s ease;
}
.hamburger:hover{background:rgba(15,77,146,0.06);color:var(--blue-1);}

.stats-grid{ display:grid; grid-template-columns: repeat(6,1fr); gap:1rem; margin-bottom: 1.5rem; }
.stat-card{
    padding:1.5rem; 
    background: linear-gradient(135deg, rgba(255,255,255,0.8), rgba(255,255,255,0.6));
    border-radius: 12px;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(8px);
    transition: all 0.3s ease;
    text-align: center;
}
.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 30px rgba(15,77,146,0.15);
}
.stat-icon{ 
    font-size: 2rem; 
    background: linear-gradient(135deg, var(--blue-1), var(--blue-2));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 0.5rem;
}
.stat-value{ 
    font-size: 2rem; 
    font-weight: 700; 
    margin-bottom: 0.5rem;
    display: block;
}
.stat-label{ 
    color: var(--text-muted); 
    font-size: 0.9rem; 
    font-weight: 500;
}
.stat-card.total .stat-value { color: var(--blue-1); }
.stat-card.urgent .stat-value { color: #ef4444; }
.stat-card.today .stat-value { color: #f59e0b; }
.stat-card.all .stat-value { color: #3b82f6; }
.stat-card.doctors .stat-value { color: #10b981; }
.stat-card.patients .stat-value { color: #8b5cf6; }
    
.btn{ display:inline-flex; align-items:center; gap:0.5rem; padding:0.55rem 0.9rem; border-radius:10px; border:none; cursor:pointer; font-weight:600; text-decoration:none; transition: all 0.2s ease; }
    
.btn-primary{ background: linear-gradient(90deg,var(--blue-1),var(--blue-2)); color:white }
.btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(15,77,146,0.3); }
.btn-ghost{ background:transparent; color:var(--text-dark); border:1px solid rgba(15,77,146,0.06) }
.btn-ghost:hover { background: rgba(15,77,146,0.04); }
.btn-danger{ background:var(--bright-red); color:white }
.btn-danger:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(255,45,85,0.3); }
.btn-secondary{
    background: linear-gradient(90deg, rgba(28,169,201,0.1), rgba(15,77,146,0.1));
    color: var(--blue-1);
    border: 1px solid rgba(15,77,146,0.2);
}
.btn-secondary:hover { background: linear-gradient(90deg, rgba(28,169,201,0.15), rgba(15,77,146,0.15)); }
.btn-sm {
    padding: 0.4rem 0.8rem;
    font-size: 0.85rem;
}

/* Filter and Search Styles */
.filters-container {
    background: var(--card-bg);
    border-radius: var(--radius);
    padding: 1.5rem;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(var(--glass-blur));
    margin-bottom: 1.5rem;
}

.filter-group {
    display: flex;
    gap: 1rem;
    align-items: center;
    flex-wrap: wrap;
}

.search-box {
    display: flex;
    align-items: center;
    background: rgba(255, 255, 255, 0.7);
    border: 1px solid rgba(15, 77, 146, 0.2);
    border-radius: 10px;
    padding: 0.5rem 1rem;
    flex: 1;
    max-width: 300px;
}

.search-box input {
    border: none;
    outline: none;
    background: transparent;
    width: 100%;
    font-size: 0.95rem;
    color: var(--text-dark);
}

.search-box button {
    background: none;
    border: none;
    color: var(--blue-1);
    cursor: pointer;
}

.filter-buttons {
    display: flex;
    gap: 0.5rem;
    flex-wrap: wrap;
}

.filter-btn {
    padding: 0.5rem 1rem;
    border: 1px solid rgba(15, 77, 146, 0.2);
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.7);
    color: var(--text-dark);
    text-decoration: none;
    font-size: 0.9rem;
    transition: all 0.2s ease;
}

.filter-btn:hover, .filter-btn.active {
    background: linear-gradient(90deg, var(--blue-1), var(--blue-2));
    color: white;
    border-color: transparent;
}

/* Announcement Styles */
.announcement-card {
    background: var(--card-bg);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(var(--glass-blur));
    margin-bottom: 1rem;
    border-left: 4px solid;
    transition: all 0.3s ease;
}

.announcement-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(16,24,40,0.12);
}

.announcement-urgent { border-left-color: #ef4444; background: linear-gradient(135deg, rgba(255,255,255,0.9), rgba(254,226,226,0.3)); }
.announcement-normal { border-left-color: var(--blue-2); }

.announcement-header {
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid rgba(15, 77, 146, 0.1);
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
}

.announcement-body {
    padding: 1.5rem;
}

.announcement-actions {
    padding: 1rem 1.5rem;
    border-top: 1px solid rgba(15, 77, 146, 0.1);
    background: rgba(15, 77, 146, 0.02);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.badge {
    padding: 0.35rem 0.65rem;
    border-radius: 6px;
    font-size: 0.75rem;
    font-weight: 600;
}

.badge-urgent { background-color: rgba(239, 68, 68, 0.1); color: #ef4444; }
.badge-audience { background-color: rgba(15, 77, 146, 0.1); color: var(--blue-1); }

.alert {
    padding: 0.75rem 1rem;
    border-radius: 8px;
    margin-bottom: 1rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.alert-success {
    background-color: rgba(16, 185, 129, 0.1);
    color: #059669;
    border: 1px solid rgba(16, 185, 129, 0.2);
}

.alert-error {
    background-color: rgba(239, 68, 68, 0.1);
    color: #dc2626;
    border: 1px solid rgba(239, 68, 68, 0.2);
}

.alert-dismissible .btn-close {
    background: transparent;
    border: none;
    font-size: 1.25rem;
    cursor: pointer;
    color: inherit;
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    color: var(--text-dark);
}

.form-control, .form-select {
    width: 100%;
    padding: 0.75rem 1rem;
    border: 1px solid rgba(15, 77, 146, 0.2);
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.7);
    transition: all 0.2s ease;
    font-size: 0.95rem;
}

.form-control:focus, .form-select:focus {
    outline: none;
    border-color: var(--blue-2);
    box-shadow: 0 0 0 3px rgba(28, 169, 201, 0.1);
    background: white;
}

.form-check {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.form-check-input {
    width: 18px;
    height: 18px;
    border-radius: 4px;
    border: 2px solid rgba(15, 77, 146, 0.3);
}

.form-check-label {
    font-weight: 500;
    color: var(--text-dark);
}

.user-info {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin-bottom: 0.5rem;
}

.user-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--blue-1), var(--blue-2));
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: 600;
    font-size: 0.9rem;
}

.user-details h6 {
    margin: 0;
    color: var(--text-dark);
}

.user-details small {
    color: var(--text-muted);
}

.announcement-meta {
    display: flex;
    gap: 1rem;
    margin-top: 1rem;
    padding-top: 1rem;
    border-top: 1px solid rgba(15, 77, 146, 0.1);
}

.meta-item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: var(--text-muted);
    font-size: 0.85rem;
}

.meta-item i {
    color: var(--blue-1);
}

.empty-state {
    text-align: center;
    padding: 3rem;
    color: var(--text-muted);
}

.empty-state i {
    font-size: 3rem;
    margin-bottom: 1rem;
    color: var(--blue-2);
}

.create-announcement-card {
    background: var(--card-bg);
    border-radius: var(--radius);
    padding: 1.5rem;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(var(--glass-blur));
    margin-bottom: 1.5rem;
}

.create-announcement-card .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid rgba(15, 77, 146, 0.1);
}

.create-announcement-card .card-header h5 {
    margin: 0;
    color: var(--blue-1);
    font-size: 1.2rem;
}

.create-announcement-card .card-header h5 i {
    margin-right: 0.5rem;
}

.grid {
    display: grid;
    grid-template-columns: repeat(12, 1fr);
    gap: 1.5rem;
}

@media (max-width: 1000px){
    .stats-grid{ grid-template-columns: repeat(3,1fr) }
}
@media (max-width: 720px){
    .dashboard-container{ flex-direction:column }
    .sidebar{ width:100%; flex-direction:row; align-items:center; gap:0.6rem; padding:0.6rem; border-radius:10px }
    .sidebar.collapsed{ width:100% }
    .sidebar-header h2{ display:none }
    .nav-btn{ padding:0.55rem; font-size:0.9rem }
    .stats-grid{ grid-template-columns: repeat(2,1fr) }
    .filter-group { flex-direction: column; align-items: stretch; }
    .search-box { max-width: none; }
    .grid { grid-template-columns: 1fr; }
}
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="logo-mark">D</div>
                <h2>Dokotela</h2>
            </div>
            
            <div class="sidebar-nav">
                <a href="admin_dashboard.php" class="nav-btn">
                    <i class="fas fa-tachometer-alt fa-fw"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
                <a href="admin_users.php" class="nav-btn">
                    <i class="fas fa-users fa-fw"></i>
                    <span class="nav-text">User Management</span>
                </a>
                <a href="admin_appointments.php" class="nav-btn">
                    <i class="fas fa-calendar-alt fa-fw"></i>
                    <span class="nav-text">Appointments</span>
                </a>
                <a href="admin_doctors.php" class="nav-btn">
                    <i class="fas fa-user-md fa-fw"></i>
                    <span class="nav-text">Doctors</span>
                </a>
                <a href="admin_payments.php" class="nav-btn">
                    <i class="fas fa-money-bill-wave fa-fw"></i>
                    <span class="nav-text">Payments</span>
                </a>
                <a href="admin_services.php" class="nav-btn">
                    <i class="fas fa-concierge-bell fa-fw"></i>
                    <span class="nav-text">Services</span>
                </a>
                <a href="admin_notifications.php" class="nav-btn">
                    <i class="fas fa-bell fa-fw"></i>
                    <span class="nav-text">Notifications</span>
                </a>
                <a href="admin_support.php" class="nav-btn">
                    <i class="fas fa-headset fa-fw"></i>
                    <span class="nav-text">Support Tickets</span>
                </a>
                <a href="admin_announcements.php" class="nav-btn active">
                    <i class="fas fa-bullhorn fa-fw"></i>
                    <span class="nav-text">Announcements</span>
                </a>
                <a href="admin_settings.php" class="nav-btn">
                    <i class="fas fa-cogs fa-fw"></i>
                    <span class="nav-text">Settings</span>
                </a>
                <a href="../auth/logout.php" class="nav-btn">
                    <i class="fas fa-sign-out-alt fa-fw"></i>
                    <span class="nav-text">Logout</span>
                </a>
            </div>
            
            <div class="user-profile">
                <img src="https://ui-avatars.com/api/?name=Admin+User&background=0f4d92&color=fff" alt="Admin User">
                <div class="profile-info">
                    <h4>Admin User</h4>
                    <span>Administrator</span>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="topbar">
                <div class="topbar-left">
                    <button class="hamburger">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h1>Announcements</h1>
                </div>
            </div>

            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-success alert-dismissible">
                    <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
                    <button type="button" class="btn-close">&times;</button>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-error alert-dismissible">
                    <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close">&times;</button>
                </div>
            <?php endif; ?>

            <!-- Announcement Statistics -->
            <div class="stats-grid">
                <div class="stat-card total">
                    <div class="stat-icon">
                        <i class="fas fa-bullhorn"></i>
                    </div>
                    <div class="stat-value"><?php echo $total_announcements; ?></div>
                    <div class="stat-label">Total Announcements</div>
                </div>
                <div class="stat-card urgent">
                    <div class="stat-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="stat-value"><?php echo $urgent_announcements; ?></div>
                    <div class="stat-label">Urgent</div>
                </div>
                <div class="stat-card today">
                    <div class="stat-icon">
                        <i class="fas fa-calendar-day"></i>
                    </div>
                    <div class="stat-value"><?php echo $today_announcements; ?></div>
                    <div class="stat-label">Today</div>
                </div>
                <div class="stat-card all">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-value"><?php echo $all_audience; ?></div>
                    <div class="stat-label">All Users</div>
                </div>
                <div class="stat-card doctors">
                    <div class="stat-icon">
                        <i class="fas fa-user-md"></i>
                    </div>
                    <div class="stat-value"><?php echo $doctors_audience; ?></div>
                    <div class="stat-label">Doctors</div>
                </div>
                <div class="stat-card patients">
                    <div class="stat-icon">
                        <i class="fas fa-user-injured"></i>
                    </div>
                    <div class="stat-value"><?php echo $patients_audience; ?></div>
                    <div class="stat-label">Patients</div>
                </div>
            </div>

            <!-- Filters -->
            <div class="filters-container">
                <form method="GET" class="filter-group">
                    <div class="search-box">
                        <input type="text" name="search" placeholder="Search announcements..." value="<?php echo htmlspecialchars($search_query); ?>">
                        <button type="submit"><i class="fas fa-search"></i></button>
                    </div>
                    <div class="filter-buttons">
                        <a href="?audience=all&urgent=all" class="filter-btn <?php echo $audience_filter === 'all' && $urgent_filter === 'all' ? 'active' : ''; ?>">All</a>
                        <a href="?audience=all&urgent=urgent" class="filter-btn <?php echo $urgent_filter === 'urgent' ? 'active' : ''; ?>">Urgent</a>
                    </div>
                    <div class="filter-buttons">
                        <a href="?audience=all&urgent=<?php echo $urgent_filter; ?>" class="filter-btn <?php echo $audience_filter === 'all' ? 'active' : ''; ?>">All Users</a>
                        <a href="?audience=doctors&urgent=<?php echo $urgent_filter; ?>" class="filter-btn <?php echo $audience_filter === 'doctors' ? 'active' : ''; ?>">Doctors</a>
                        <a href="?audience=patients&urgent=<?php echo $urgent_filter; ?>" class="filter-btn <?php echo $audience_filter === 'patients' ? 'active' : ''; ?>">Patients</a>
                    </div>
                </form>
            </div>

            <div class="grid">
                <!-- Create Announcement -->
                <div style="grid-column: span 6;">
                    <div class="create-announcement-card">
                        <div class="card-header">
                            <h5><i class="fas fa-plus-circle"></i> Create New Announcement</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="create_announcement" value="1">
                                <div class="form-group">
                                    <label for="title" class="form-label">Title</label>
                                    <input type="text" class="form-control" id="title" name="title" required placeholder="Enter announcement title">
                                </div>
                                <div class="form-group">
                                    <label for="content" class="form-label">Content</label>
                                    <textarea class="form-control" id="content" name="content" rows="5" required placeholder="Enter announcement content..."></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="target_audience" class="form-label">Target Audience</label>
                                    <select class="form-select" id="target_audience" name="target_audience" required>
                                        <option value="all">All Users</option>
                                        <option value="doctors">Doctors Only</option>
                                        <option value="patients">Patients Only</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="is_urgent" name="is_urgent">
                                        <label class="form-check-label" for="is_urgent">
                                            <i class="fas fa-exclamation-triangle me-1"></i>Mark as Urgent
                                        </label>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane me-2"></i>Create Announcement
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Announcement History -->
                <div style="grid-column: span 6;">
                    <div class="create-announcement-card">
                        <div class="card-header">
                            <h5><i class="fas fa-history"></i> Recent Announcements</h5>
                        </div>
                        <div class="card-body" style="max-height: 600px; overflow-y: auto;">
                            <?php if (empty($announcements)): ?>
                                <div class="empty-state">
                                    <i class="fas fa-bullhorn"></i>
                                    <h3>No announcements found</h3>
                                    <p>There are no announcements matching your current filters.</p>
                                </div>
                            <?php else: ?>
                                <?php foreach ($announcements as $announcement): ?>
                                <div class="announcement-card <?php echo $announcement['isUrgent'] ? 'announcement-urgent' : 'announcement-normal'; ?>">
                                    <div class="announcement-header">
                                        <div>
                                            <h4><?php echo htmlspecialchars($announcement['title']); ?></h4>
                                            <div class="user-info">
                                                <div class="user-avatar">
                                                    <?php echo strtoupper(substr($announcement['firstName'], 0, 1) . substr($announcement['lastName'], 0, 1)); ?>
                                                </div>
                                                <div class="user-details">
                                                    <h6><?php echo htmlspecialchars($announcement['firstName'] . ' ' . $announcement['lastName']); ?></h6>
                                                    <small><?php echo date('M j, Y g:i A', strtotime($announcement['createdAt'])); ?></small>
                                                </div>
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 0.5rem; align-items: flex-start;">
                                            <?php if ($announcement['isUrgent']): ?>
                                                <span class="badge badge-urgent">
                                                    <i class="fas fa-exclamation-triangle"></i> Urgent
                                                </span>
                                            <?php endif; ?>
                                            <span class="badge badge-audience">
                                                <?php echo ucfirst($announcement['targetAudience']); ?>
                                            </span>
                                        </div>
                                    </div>
                                    
                                    <div class="announcement-body">
                                        <p><?php echo nl2br(htmlspecialchars($announcement['content'])); ?></p>
                                        
                                        <div class="announcement-meta">
                                            <div class="meta-item">
                                                <i class="fas fa-user-tag"></i>
                                                <span>Target: <?php echo ucfirst($announcement['targetAudience']); ?></span>
                                            </div>
                                            <?php if (!empty($announcement['updatedAt']) && $announcement['updatedAt'] !== $announcement['createdAt']): ?>
                                            <div class="meta-item">
                                                <i class="fas fa-sync"></i>
                                                <span>Updated: <?php echo date('M j, Y g:i A', strtotime($announcement['updatedAt'])); ?></span>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    
                                    <div class="announcement-actions">
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="announcement_id" value="<?php echo $announcement['announcementID']; ?>">
                                            <button type="submit" name="delete_announcement" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this announcement?')">
                                                <i class="fas fa-trash"></i> Delete
                                            </button>
                                        </form>
                                        <small class="text-muted">
                                            ID: <?php echo $announcement['announcementID']; ?>
                                        </small>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Toggle sidebar
        document.querySelector('.hamburger').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('collapsed');
        });

        // Alert dismiss functionality
        document.querySelectorAll('.btn-close').forEach(button => {
            button.addEventListener('click', function() {
                this.closest('.alert').style.display = 'none';
            });
        });

        // Auto-expand textarea on focus
        document.getElementById('content').addEventListener('focus', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });

        // Form validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const title = document.getElementById('title');
            const content = document.getElementById('content');
            
            if (!title.value.trim() || !content.value.trim()) {
                e.preventDefault();
                if (!title.value.trim()) {
                    title.style.borderColor = 'var(--bright-red)';
                }
                if (!content.value.trim()) {
                    content.style.borderColor = 'var(--bright-red)';
                }
                alert('Please fill all required fields.');
            }
        });
    </script>
</body>
</html>