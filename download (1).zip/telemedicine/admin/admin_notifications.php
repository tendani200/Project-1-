<?php
// admin_notifications.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if admin is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

$userID = intval($_SESSION['userID']);

// Create database connection
try {
    $host = 'sql206.byetcluster.com';
    $dbname = 'if0_40031860_dok';
    $username = 'if0_40031860';
    $password = "qzJkHEejybefK";
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['send_notification'])) {
        $message = $_POST['message'];
        $type = $_POST['type'];
        $recipient_type = $_POST['recipient_type'];
        $specific_recipient = $_POST['specific_recipient'] ?? null;
        
        try {
            // Determine recipients based on type
            $recipients = [];
            if ($recipient_type === 'all') {
                $recipients = getAllUsers();
            } elseif ($recipient_type === 'doctors') {
                $recipients = getDoctors();
            } elseif ($recipient_type === 'patients') {
                $recipients = getPatients();
            } elseif ($recipient_type === 'specific' && $specific_recipient) {
                // Get user ID from email
                $stmt = $pdo->prepare("SELECT userID FROM User WHERE email = ?");
                $stmt->execute([$specific_recipient]);
                $user = $stmt->fetch();
                if ($user) {
                    $recipients = [$user['userID']];
                } else {
                    $_SESSION['error'] = "User with email '$specific_recipient' not found.";
                }
            }
            
            // Send notifications
            if (!empty($recipients) && !isset($_SESSION['error'])) {
                foreach ($recipients as $recipientID) {
                    $stmt = $pdo->prepare("INSERT INTO NotificationService (message, type, recipientID, status) VALUES (?, ?, ?, 'Sent')");
                    $stmt->execute([$message, $type, $recipientID]);
                    
                    // Here you would add actual email/SMS sending logic
                    sendNotification($recipientID, $message, $type);
                }
                
                $_SESSION['message'] = "Notification sent successfully to " . count($recipients) . " recipients!";
            }
        } catch (PDOException $e) {
            $_SESSION['error'] = "Error sending notification: " . $e->getMessage();
        }
        header("Location: admin_notifications.php");
        exit();
    }
}

// Get notification history
try {
    $stmt = $pdo->query("SELECT n.*, u.firstName, u.lastName, u.email 
                         FROM NotificationService n 
                         LEFT JOIN User u ON n.recipientID = u.userID 
                         ORDER BY n.sentDate DESC 
                         LIMIT 50");
    $notifications = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Error loading notifications: " . $e->getMessage();
}

// Get stats for dashboard
try {
    $totalUsers = $pdo->query("SELECT COUNT(*) FROM User")->fetchColumn();
    $totalDoctors = $pdo->query("SELECT COUNT(*) FROM Doctor")->fetchColumn();
    $totalPatients = $pdo->query("SELECT COUNT(*) FROM Patient")->fetchColumn();
    $totalNotifications = $pdo->query("SELECT COUNT(*) FROM NotificationService")->fetchColumn();
    $sentToday = $pdo->query("SELECT COUNT(*) FROM NotificationService WHERE DATE(sentDate) = CURDATE()")->fetchColumn();
} catch (PDOException $e) {
    // Continue without stats if there's an error
    $totalUsers = $totalDoctors = $totalPatients = $totalNotifications = $sentToday = 0;
}

function getAllUsers() {
    global $pdo;
    $stmt = $pdo->query("SELECT userID FROM User");
    $users = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
    return $users;
}

function getDoctors() {
    global $pdo;
    $stmt = $pdo->query("SELECT u.userID FROM User u JOIN Doctor d ON u.userID = d.userID");
    $doctors = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
    return $doctors;
}

function getPatients() {
    global $pdo;
    $stmt = $pdo->query("SELECT u.userID FROM User u JOIN Patient p ON u.userID = p.userID");
    $patients = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
    return $patients;
}

function sendNotification($recipientID, $message, $type) {
    // Implementation would depend on your email/SMS service
    error_log("Sending $type notification to user $recipientID: $message");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notification Center - Dokotela Admin</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
:root{
    --blue-1: #0f4d92;
    --blue-2: #1CA9C9;
    --pastel: #E6F6FF;
    --bright-red: #ff2d55;
    --muted: #64748b;
    --bg: #f6fbff;
    --card-bg: rgba(255,255,255,0.75);
    --glass-border: rgba(255,255,255,0.35);
    --shadow: 0 6px 18px rgba(16,24,40,0.08);
    --radius: 12px;
    --glass-blur: 8px;
    --text-dark: #0f1724;
    --text-muted: #475569;
    --gap: 1rem;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%}
body{
    font-family: "Segoe UI", system-ui, -apple-system, "Helvetica Neue", Arial;
    background: #f1f8ff;
    background: radial-gradient(circle at top left, #e6f6ff 0%, #f1f8ff 100%);
    color: var(--text-dark);
}

.dashboard-container{
    display:flex;
    min-height:100vh;
    gap:var(--gap);
    transition: all 0.3s ease;
}
.sidebar{
    width:260px;
    background: linear-gradient(180deg, rgba(255,255,255,0.7), rgba(246,249,255,0.55));
    border-radius: calc(var(--radius) + 4px);
    padding:1rem;
    display:flex;
    flex-direction:column;
    gap:0.75rem;
    align-items:stretch;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(6px);
    transition: width 0.28s cubic-bezier(.22,.9,.36,1), transform 0.3s ease;
}
.sidebar.collapsed{ width:72px; padding:0.6rem; align-items:center }
.sidebar.collapsed .sidebar-header h2,
.sidebar.collapsed .nav-text,
.sidebar.collapsed .profile-info { display:none }
.sidebar.collapsed .nav-btn { justify-content:center }
.sidebar-header{
    display:flex;
    align-items:center;
    gap:0.75rem;
    padding:0.6rem 0.6rem;
}
.logo-mark{
    width:44px;height:44px;border-radius:10px;
    display:grid;place-items:center;color:white;
    background: linear-gradient(135deg,var(--blue-1),var(--blue-2));
    box-shadow: 0 6px 18px rgba(15,77,146,0.18);
    font-weight:700;
    font-size:1.05rem;
}
.sidebar-header h2{ color:var(--blue-1); font-size:1.05rem; font-weight:700; }
.sidebar-nav{
    display:flex;flex-direction:column;gap:6px;padding:0.5rem 0;
    width:100%;
}
.nav-btn{
    display:flex;align-items:center;gap:0.75rem;
    background:transparent;border:none;padding:0.6rem 0.8rem;border-radius:10px;
    cursor:pointer;color:var(--text-muted);font-size:0.95rem;transition: all 0.18s ease;
    text-decoration:none;
}
.nav-btn .fa-fw{ width:20px; text-align:center }
.nav-btn:hover{ transform:translateY(-2px); color:var(--blue-1); background: rgba(15,77,146,0.04) }
.nav-btn.active{
    background: linear-gradient(90deg, rgba(15,77,146,0.06), rgba(28,169,201,0.03));
    color:var(--blue-1);
    border-left: 3px solid var(--blue-2);
}
.nav-text{ flex:1 }
.user-profile{
    margin-top:auto;display:flex;align-items:center;gap:0.75rem;padding:0.6rem;border-radius:10px;
    background: linear-gradient(180deg, rgba(255,255,255,0.35), rgba(255,255,255,0.2));
    border: 1px solid rgba(255,255,255,0.25);
    backdrop-filter: blur(4px);
}
.user-profile img{ width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid white; box-shadow: 0 6px 14px rgba(16,24,40,0.06) }
.profile-info h4{ font-size:0.95rem; margin-bottom:2px }
.profile-info span{ font-size:0.82rem; color:var(--text-muted) }
.main-content{
    flex:1;padding:1.5rem;overflow:auto;
}
.topbar{
    display:flex;align-items:center;justify-content:space-between;gap:1rem;margin-bottom:1.25rem;
}
.topbar-left{
    display:flex;align-items:center;gap:1rem;
}
.hamburger{
    background:transparent;border:none;padding:0.5rem;cursor:pointer;color:var(--text-muted);
    border-radius:6px;transition:all 0.2s ease;
}
.hamburger:hover{background:rgba(15,77,146,0.06);color:var(--blue-1);}

.welcome-header{
    background: linear-gradient(135deg, rgba(15,77,146,0.95), rgba(28,169,201,0.95));
    color:white;padding:1.6rem;border-radius:14px;box-shadow: 0 12px 30px rgba(15,77,146,0.12);
    display:flex;flex-direction:column;gap:0.4rem;
}
.welcome-header h1{ font-size:1.6rem; font-weight:700 }
.welcome-header p{ opacity:0.95; font-size:0.95rem }
.grid{
    display:grid;
    grid-template-columns: repeat(12, 1fr);
    gap:1rem;
    margin-top:1rem;
}
.card{
    background: var(--card-bg);
    border-radius: var(--radius);
    padding:1rem;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(var(--glass-blur));
}
.stats-grid{ grid-column: span 12; display:grid; grid-template-columns: repeat(4,1fr); gap:1rem; }
.stat-card{
    padding:1.5rem; 
    background: linear-gradient(135deg, rgba(255,255,255,0.8), rgba(255,255,255,0.6));
    border-radius: 12px;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(8px);
    transition: all 0.3s ease;
    text-align: center;
}
.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 30px rgba(15,77,146,0.15);
}
.stat-icon{ 
    font-size: 2rem; 
    background: linear-gradient(135deg, var(--blue-1), var(--blue-2));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 0.5rem;
}
.stat-value{ 
    font-size: 2rem; 
    font-weight: 700; 
    color: var(--blue-1); 
    margin-bottom: 0.5rem;
    display: block;
}
.stat-label{ 
    color: var(--text-muted); 
    font-size: 0.9rem; 
    font-weight: 500;
}
.stat-change {
    font-size: 0.8rem;
    margin-top: 0.5rem;
}
.stat-change.positive {
    color: #059669;
}
    
.btn{ display:inline-flex; align-items:center; gap:0.5rem; padding:0.55rem 0.9rem; border-radius:10px; border:none; cursor:pointer; font-weight:600; text-decoration:none; transition: all 0.2s ease; }
    
.btn-primary{ background: linear-gradient(90deg,var(--blue-1),var(--blue-2)); color:white }
.btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(15,77,146,0.3); }
.btn-ghost{ background:transparent; color:var(--text-dark); border:1px solid rgba(15,77,146,0.06) }
.btn-ghost:hover { background: rgba(15,77,146,0.04); }
.btn-danger{ background:var(--bright-red); color:white }
.btn-danger:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(255,45,85,0.3); }
.btn-secondary{
    background: linear-gradient(90deg, rgba(28,169,201,0.1), rgba(15,77,146,0.1));
    color: var(--blue-1);
    border: 1px solid rgba(15,77,146,0.2);
}
.btn-secondary:hover { background: linear-gradient(90deg, rgba(28,169,201,0.15), rgba(15,77,146,0.15)); }
.btn-info {
    background: linear-gradient(90deg, rgba(59, 130, 246, 0.1), rgba(37, 99, 235, 0.1));
    color: #2563eb;
    border: 1px solid rgba(37, 99, 235, 0.2);
}
.btn-info:hover { background: linear-gradient(90deg, rgba(59, 130, 246, 0.15), rgba(37, 99, 235, 0.15)); }

/* Modal Styles */
.modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(2,6,23,0.45);
    backdrop-filter: blur(4px);
    z-index: 1200;
    align-items: center;
    justify-content: center;
}

.modal-overlay.active {
    display: flex;
}

.modal-content {
    background: white;
    width: 90%;
    max-width: 600px;
    border-radius: 16px;
    box-shadow: 0 20px 50px rgba(2,6,23,0.25);
    overflow: hidden;
}

.modal-header {
    background: linear-gradient(135deg, var(--blue-1), var(--blue-2));
    color: white;
    padding: 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 {
    margin: 0;
    font-size: 1.4rem;
    font-weight: 600;
}

.modal-close {
    background: none;
    border: none;
    color: white;
    font-size: 1.5rem;
    cursor: pointer;
    padding: 0;
    width: 30px;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 6px;
    transition: background 0.2s;
}

.modal-close:hover {
    background: rgba(255,255,255,0.2);
}

.modal-body {
    padding: 2rem;
}

.modal-footer {
    padding: 1.5rem 2rem;
    background: #f8fafc;
    display: flex;
    justify-content: flex-end;
    gap: 1rem;
    border-top: 1px solid #e2e8f0;
}

.glass-accent{ background: linear-gradient(180deg, rgba(255,255,255,0.6), rgba(255,255,255,0.35)); border-radius:10px; border:1px solid rgba(255,255,255,0.25); backdrop-filter: blur(6px) }

/* Form Styles */
.form-group {
    margin-bottom: 1.5rem;
}

.form-label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    color: var(--text-dark);
}

.form-control {
    width: 100%;
    padding: 0.75rem 1rem;
    border: 1px solid rgba(15, 77, 146, 0.2);
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.7);
    transition: all 0.2s ease;
    font-size: 0.95rem;
}

.form-control:focus {
    outline: none;
    border-color: var(--blue-2);
    box-shadow: 0 0 0 3px rgba(28, 169, 201, 0.1);
    background: white;
}

.form-select {
    width: 100%;
    padding: 0.75rem 1rem;
    border: 1px solid rgba(15, 77, 146, 0.2);
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.7);
    transition: all 0.2s ease;
    font-size: 0.95rem;
}

.form-select:focus {
    outline: none;
    border-color: var(--blue-2);
    box-shadow: 0 0 0 3px rgba(28, 169, 201, 0.1);
    background: white;
}

.alert {
    padding: 0.75rem 1rem;
    border-radius: 8px;
    margin-bottom: 1rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.alert-success {
    background-color: rgba(16, 185, 129, 0.1);
    color: #059669;
    border: 1px solid rgba(16, 185, 129, 0.2);
}

.alert-error {
    background-color: rgba(239, 68, 68, 0.1);
    color: #dc2626;
    border: 1px solid rgba(239, 68, 68, 0.2);
}

.alert-dismissible .btn-close {
    background: transparent;
    border: none;
    font-size: 1.25rem;
    cursor: pointer;
    color: inherit;
}

.badge {
    padding: 0.35rem 0.65rem;
    border-radius: 6px;
    font-size: 0.75rem;
    font-weight: 600;
}

.badge-success {
    background-color: rgba(16, 185, 129, 0.1);
    color: #059669;
}

.badge-warning {
    background-color: rgba(245, 158, 11, 0.1);
    color: #d97706;
}

.badge-info {
    background-color: rgba(59, 130, 246, 0.1);
    color: #2563eb;
}

.user-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
    background: var(--card-bg);
    border-radius: var(--radius);
    overflow: hidden;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
}

.user-table th, .user-table td {
    padding: 0.75rem 1rem;
    text-align: left;
    border-bottom: 1px solid rgba(15, 77, 146, 0.08);
}

.user-table th {
    background-color: rgba(15, 77, 146, 0.05);
    font-weight: 600;
    color: var(--blue-1);
}

.user-table tr:hover {
    background-color: rgba(15, 77, 146, 0.02);
}

.notification-card {
    background: var(--card-bg);
    border-radius: var(--radius);
    padding: 1.5rem;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(var(--glass-blur));
    margin-bottom: 1.5rem;
}

.notification-card .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid rgba(15, 77, 146, 0.1);
}

.notification-card .card-header h5 {
    margin: 0;
    color: var(--blue-1);
    font-size: 1.2rem;
}

.notification-card .card-header h5 i {
    margin-right: 0.5rem;
}

.table-responsive {
    overflow-x: auto;
}

@media (max-width: 1000px){
    .stats-grid{ grid-template-columns: repeat(2,1fr) }
}
@media (max-width: 720px){
    .dashboard-container{ flex-direction:column }
    .sidebar{ width:100%; flex-direction:row; align-items:center; gap:0.6rem; padding:0.6rem; border-radius:10px }
    .sidebar.collapsed{ width:100% }
    .sidebar-header h2{ display:none }
    .nav-btn{ padding:0.55rem; font-size:0.9rem }
    .grid{ grid-template-columns: 1fr; }
    .stats-grid{ grid-template-columns: 1fr }
    .welcome-header h1{ font-size:1.25rem }
}
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="logo-mark">D</div>
                <h2>Dokotela</h2>
            </div>
            
            <div class="sidebar-nav">
                <a href="admin_dashboard.php" class="nav-btn">
                    <i class="fas fa-tachometer-alt fa-fw"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
                <a href="admin_users.php" class="nav-btn">
                    <i class="fas fa-users fa-fw"></i>
                    <span class="nav-text">User Management</span>
                </a>
                <a href="admin_appointments.php" class="nav-btn">
                    <i class="fas fa-calendar-alt fa-fw"></i>
                    <span class="nav-text">Appointments</span>
                </a>
                <a href="admin_doctors.php" class="nav-btn">
                    <i class="fas fa-user-md fa-fw"></i>
                    <span class="nav-text">Doctors</span>
                </a>
                <a href="admin_payments.php" class="nav-btn">
                    <i class="fas fa-money-bill-wave fa-fw"></i>
                    <span class="nav-text">Payments</span>
                </a>
                <a href="admin_services.php" class="nav-btn">
                    <i class="fas fa-concierge-bell fa-fw"></i>
                    <span class="nav-text">Services</span>
                </a>
                <a href="admin_notifications.php" class="nav-btn active">
                    <i class="fas fa-bell fa-fw"></i>
                    <span class="nav-text">Notifications</span>
                </a>
                <a href="admin_support.php" class="nav-btn">
                    <i class="fas fa-headset fa-fw"></i>
                    <span class="nav-text">Support Tickets</span>
                </a>
                <a href="admin_announcements.php" class="nav-btn">
                    <i class="fas fa-bullhorn fa-fw"></i>
                    <span class="nav-text">Announcements</span>
                </a>
                <a href="admin_settings.php" class="nav-btn">
                    <i class="fas fa-cogs fa-fw"></i>
                    <span class="nav-text">Settings</span>
                </a>
                <a href="../auth/logout.php" class="nav-btn">
                    <i class="fas fa-sign-out-alt fa-fw"></i>
                    <span class="nav-text">Logout</span>
                </a>
            </div>
            
            <div class="user-profile">
                <img src="https://ui-avatars.com/api/?name=Admin+User&background=0f4d92&color=fff" alt="Admin User">
                <div class="profile-info">
                    <h4>Admin User</h4>
                    <span>Administrator</span>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="topbar">
                <div class="topbar-left">
                    <button class="hamburger">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h1>Notification Center</h1>
                </div>
            </div>

            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-success alert-dismissible">
                    <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
                    <button type="button" class="btn-close">&times;</button>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-error alert-dismissible">
                    <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close">&times;</button>
                </div>
            <?php endif; ?>

            <!-- Stats Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-value"><?php echo $totalUsers; ?></div>
                    <div class="stat-label">Total Users</div>
                    <div class="stat-change positive">
                        <i class="fas fa-arrow-up"></i> Active
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-user-md"></i>
                    </div>
                    <div class="stat-value"><?php echo $totalDoctors; ?></div>
                    <div class="stat-label">Total Doctors</div>
                    <div class="stat-change positive">
                        <i class="fas fa-arrow-up"></i> Active
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-user-injured"></i>
                    </div>
                    <div class="stat-value"><?php echo $totalPatients; ?></div>
                    <div class="stat-label">Total Patients</div>
                    <div class="stat-change positive">
                        <i class="fas fa-arrow-up"></i> Active
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-bell"></i>
                    </div>
                    <div class="stat-value"><?php echo $totalNotifications; ?></div>
                    <div class="stat-label">Total Notifications</div>
                    <div class="stat-change positive">
                        <i class="fas fa-arrow-up"></i> <?php echo $sentToday; ?> today
                    </div>
                </div>
            </div>

            <div class="grid">
                <!-- Send Notification Form -->
                <div class="card" style="grid-column: span 6;">
                    <div class="notification-card">
                        <div class="card-header">
                            <h5><i class="fas fa-paper-plane"></i> Send New Notification</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="send_notification" value="1">
                                <div class="form-group">
                                    <label for="recipient_type" class="form-label">Send To</label>
                                    <select class="form-select" id="recipient_type" name="recipient_type" required>
                                        <option value="all">All Users</option>
                                        <option value="doctors">All Doctors</option>
                                        <option value="patients">All Patients</option>
                                        <option value="specific">Specific User</option>
                                    </select>
                                </div>
                                <div class="form-group" id="specific_recipient_container" style="display: none;">
                                    <label for="specific_recipient" class="form-label">User Email</label>
                                    <input type="email" class="form-control" id="specific_recipient" name="specific_recipient" placeholder="Enter user email">
                                </div>
                                <div class="form-group">
                                    <label for="type" class="form-label">Notification Type</label>
                                    <select class="form-select" id="type" name="type" required>
                                        <option value="Email">Email</option>
                                        <option value="SMS">SMS</option>
                                        <option value="Push">Push Notification</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="message" class="form-label">Message</label>
                                    <textarea class="form-control" id="message" name="message" rows="5" required placeholder="Enter your notification message..."></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane me-2"></i>Send Notification
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Notification History -->
                <div class="card" style="grid-column: span 6;">
                    <div class="notification-card">
                        <div class="card-header">
                            <h5><i class="fas fa-history"></i> Notification History</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="user-table">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Type</th>
                                            <th>Recipient</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($notifications)): ?>
                                            <tr>
                                                <td colspan="4" style="text-align: center; padding: 2rem; color: var(--text-muted);">
                                                    No notifications found
                                                </td>
                                            </tr>
                                        <?php else: ?>
                                            <?php foreach ($notifications as $notification): ?>
                                            <tr>
                                                <td><?php echo date('M j, H:i', strtotime($notification['sentDate'])); ?></td>
                                                <td>
                                                    <span class="badge badge-info">
                                                        <i class="fas fa-<?php 
                                                            echo $notification['type'] === 'Email' ? 'envelope' : 
                                                                  ($notification['type'] === 'SMS' ? 'comment' : 'bell'); 
                                                        ?> me-1"></i>
                                                        <?php echo $notification['type']; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php if ($notification['firstName']): ?>
                                                        <div class="fw-bold"><?php echo htmlspecialchars($notification['firstName'] . ' ' . $notification['lastName']); ?></div>
                                                        <small class="text-muted"><?php echo htmlspecialchars($notification['email']); ?></small>
                                                    <?php else: ?>
                                                        <em>All Users</em>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <span class="badge badge-<?php echo $notification['status'] === 'Sent' ? 'success' : 'warning'; ?>">
                                                        <?php echo $notification['status']; ?>
                                                    </span>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Toggle sidebar
        document.querySelector('.hamburger').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('collapsed');
        });

        // Toggle specific recipient field
        document.getElementById('recipient_type').addEventListener('change', function() {
            const specificContainer = document.getElementById('specific_recipient_container');
            specificContainer.style.display = this.value === 'specific' ? 'block' : 'none';
        });

        // Alert dismiss functionality
        document.querySelectorAll('.btn-close').forEach(button => {
            button.addEventListener('click', function() {
                this.closest('.alert').style.display = 'none';
            });
        });

        // Form validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const message = document.getElementById('message');
            if (!message.value.trim()) {
                e.preventDefault();
                message.style.borderColor = 'var(--bright-red)';
                alert('Please enter a notification message.');
            }
        });
    </script>
</body>
</html>