<?php
// admin_settings.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if admin is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

$userID = intval($_SESSION['userID']);

// Create database connection
try {
    $host = 'sql206.byetcluster.com';
    $dbname = 'if0_40031860_dok';
    $username = 'if0_40031860';
    $password = "qzJkHEejybefK";  
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_settings'])) {
        $privacy_policy = $_POST['privacy_policy'];
        $terms_of_service = $_POST['terms_of_service'];
        $consent_policy = $_POST['consent_policy'];
        $data_retention_policy = $_POST['data_retention_policy'];
        
        try {
            // Update settings in database
            $stmt = $pdo->prepare("INSERT INTO PlatformSettings (setting_key, setting_value, updatedBy) 
                                   VALUES 
                                   ('privacy_policy', ?, ?),
                                   ('terms_of_service', ?, ?),
                                   ('consent_policy', ?, ?),
                                   ('data_retention_policy', ?, ?)
                                   ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updatedBy = VALUES(updatedBy)");
            
            $stmt->execute([$privacy_policy, $userID, $terms_of_service, $userID, $consent_policy, $userID, $data_retention_policy, $userID]);
            
            $_SESSION['message'] = "Settings updated successfully!";
        } catch (PDOException $e) {
            $_SESSION['error'] = "Error updating settings: " . $e->getMessage();
        }
        header("Location: admin_settings.php");
        exit();
    }
}

// Get current settings
try {
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM PlatformSettings");
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    $error = "Error loading settings: " . $e->getMessage();
}

// Get settings statistics
try {
    $total_policies = $pdo->query("SELECT COUNT(*) FROM PlatformSettings")->fetchColumn();
    $updated_today = $pdo->query("SELECT COUNT(*) FROM PlatformSettings WHERE DATE(updatedAt) = CURDATE()")->fetchColumn();
    $privacy_exists = $pdo->query("SELECT COUNT(*) FROM PlatformSettings WHERE setting_key = 'privacy_policy'")->fetchColumn();
    $terms_exists = $pdo->query("SELECT COUNT(*) FROM PlatformSettings WHERE setting_key = 'terms_of_service'")->fetchColumn();
    $consent_exists = $pdo->query("SELECT COUNT(*) FROM PlatformSettings WHERE setting_key = 'consent_policy'")->fetchColumn();
    $data_retention_exists = $pdo->query("SELECT COUNT(*) FROM PlatformSettings WHERE setting_key = 'data_retention_policy'")->fetchColumn();
} catch (PDOException $e) {
    // Continue without stats if there's an error
    $total_policies = $updated_today = $privacy_exists = $terms_exists = $consent_exists = $data_retention_exists = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Platform Settings - Dokotela Admin</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
:root{
    --blue-1: #0f4d92;
    --blue-2: #1CA9C9;
    --pastel: #E6F6FF;
    --bright-red: #ff2d55;
    --muted: #64748b;
    --bg: #f6fbff;
    --card-bg: rgba(255,255,255,0.75);
    --glass-border: rgba(255,255,255,0.35);
    --shadow: 0 6px 18px rgba(16,24,40,0.08);
    --radius: 12px;
    --glass-blur: 8px;
    --text-dark: #0f1724;
    --text-muted: #475569;
    --gap: 1rem;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%}
body{
    font-family: "Segoe UI", system-ui, -apple-system, "Helvetica Neue", Arial;
    background: #f1f8ff;
    background: radial-gradient(circle at top left, #e6f6ff 0%, #f1f8ff 100%);
    color: var(--text-dark);
}

.dashboard-container{
    display:flex;
    min-height:100vh;
    gap:var(--gap);
    transition: all 0.3s ease;
}
.sidebar{
    width:260px;
    background: linear-gradient(180deg, rgba(255,255,255,0.7), rgba(246,249,255,0.55));
    border-radius: calc(var(--radius) + 4px);
    padding:1rem;
    display:flex;
    flex-direction:column;
    gap:0.75rem;
    align-items:stretch;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(6px);
    transition: width 0.28s cubic-bezier(.22,.9,.36,1), transform 0.3s ease;
}
.sidebar.collapsed{ width:72px; padding:0.6rem; align-items:center }
.sidebar.collapsed .sidebar-header h2,
.sidebar.collapsed .nav-text,
.sidebar.collapsed .profile-info { display:none }
.sidebar.collapsed .nav-btn { justify-content:center }
.sidebar-header{
    display:flex;
    align-items:center;
    gap:0.75rem;
    padding:0.6rem 0.6rem;
}
.logo-mark{
    width:44px;height:44px;border-radius:10px;
    display:grid;place-items:center;color:white;
    background: linear-gradient(135deg,var(--blue-1),var(--blue-2));
    box-shadow: 0 6px 18px rgba(15,77,146,0.18);
    font-weight:700;
    font-size:1.05rem;
}
.sidebar-header h2{ color:var(--blue-1); font-size:1.05rem; font-weight:700; }
.sidebar-nav{
    display:flex;flex-direction:column;gap:6px;padding:0.5rem 0;
    width:100%;
}
.nav-btn{
    display:flex;align-items:center;gap:0.75rem;
    background:transparent;border:none;padding:0.6rem 0.8rem;border-radius:10px;
    cursor:pointer;color:var(--text-muted);font-size:0.95rem;transition: all 0.18s ease;
    text-decoration:none;
}
.nav-btn .fa-fw{ width:20px; text-align:center }
.nav-btn:hover{ transform:translateY(-2px); color:var(--blue-1); background: rgba(15,77,146,0.04) }
.nav-btn.active{
    background: linear-gradient(90deg, rgba(15,77,146,0.06), rgba(28,169,201,0.03));
    color:var(--blue-1);
    border-left: 3px solid var(--blue-2);
}
.nav-text{ flex:1 }
.user-profile{
    margin-top:auto;display:flex;align-items:center;gap:0.75rem;padding:0.6rem;border-radius:10px;
    background: linear-gradient(180deg, rgba(255,255,255,0.35), rgba(255,255,255,0.2));
    border: 1px solid rgba(255,255,255,0.25);
    backdrop-filter: blur(4px);
}
.user-profile img{ width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid white; box-shadow: 0 6px 14px rgba(16,24,40,0.06) }
.profile-info h4{ font-size:0.95rem; margin-bottom:2px }
.profile-info span{ font-size:0.82rem; color:var(--text-muted) }
.main-content{
    flex:1;padding:1.5rem;overflow:auto;
}
.topbar{
    display:flex;align-items:center;justify-content:space-between;gap:1rem;margin-bottom:1.25rem;
}
.topbar-left{
    display:flex;align-items:center;gap:1rem;
}
.hamburger{
    background:transparent;border:none;padding:0.5rem;cursor:pointer;color:var(--text-muted);
    border-radius:6px;transition:all 0.2s ease;
}
.hamburger:hover{background:rgba(15,77,146,0.06);color:var(--blue-1);}

.stats-grid{ display:grid; grid-template-columns: repeat(6,1fr); gap:1rem; margin-bottom: 1.5rem; }
.stat-card{
    padding:1.5rem; 
    background: linear-gradient(135deg, rgba(255,255,255,0.8), rgba(255,255,255,0.6));
    border-radius: 12px;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(8px);
    transition: all 0.3s ease;
    text-align: center;
}
.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 30px rgba(15,77,146,0.15);
}
.stat-icon{ 
    font-size: 2rem; 
    background: linear-gradient(135deg, var(--blue-1), var(--blue-2));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 0.5rem;
}
.stat-value{ 
    font-size: 2rem; 
    font-weight: 700; 
    margin-bottom: 0.5rem;
    display: block;
}
.stat-label{ 
    color: var(--text-muted); 
    font-size: 0.9rem; 
    font-weight: 500;
}
.stat-card.total .stat-value { color: var(--blue-1); }
.stat-card.updated .stat-value { color: #f59e0b; }
.stat-card.privacy .stat-value { color: #3b82f6; }
.stat-card.terms .stat-value { color: #10b981; }
.stat-card.consent .stat-value { color: #8b5cf6; }
.stat-card.data .stat-value { color: #ef4444; }
    
.btn{ display:inline-flex; align-items:center; gap:0.5rem; padding:0.55rem 0.9rem; border-radius:10px; border:none; cursor:pointer; font-weight:600; text-decoration:none; transition: all 0.2s ease; }
    
.btn-primary{ background: linear-gradient(90deg,var(--blue-1),var(--blue-2)); color:white }
.btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(15,77,146,0.3); }
.btn-ghost{ background:transparent; color:var(--text-dark); border:1px solid rgba(15,77,146,0.06) }
.btn-ghost:hover { background: rgba(15,77,146,0.04); }
.btn-danger{ background:var(--bright-red); color:white }
.btn-danger:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(255,45,85,0.3); }
.btn-secondary{
    background: linear-gradient(90deg, rgba(28,169,201,0.1), rgba(15,77,146,0.1));
    color: var(--blue-1);
    border: 1px solid rgba(15,77,146,0.2);
}
.btn-secondary:hover { background: linear-gradient(90deg, rgba(28,169,201,0.15), rgba(15,77,146,0.15)); }

/* Settings Card Styles */
.settings-card {
    background: var(--card-bg);
    border-radius: var(--radius);
    padding: 1.5rem;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(var(--glass-blur));
    margin-bottom: 1.5rem;
    border-left: 4px solid var(--blue-2);
}

.settings-card .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid rgba(15, 77, 146, 0.1);
}

.settings-card .card-header h5 {
    margin: 0;
    color: var(--blue-1);
    font-size: 1.2rem;
}

.settings-card .card-header h5 i {
    margin-right: 0.5rem;
}

.alert {
    padding: 0.75rem 1rem;
    border-radius: 8px;
    margin-bottom: 1rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.alert-success {
    background-color: rgba(16, 185, 129, 0.1);
    color: #059669;
    border: 1px solid rgba(16, 185, 129, 0.2);
}

.alert-error {
    background-color: rgba(239, 68, 68, 0.1);
    color: #dc2626;
    border: 1px solid rgba(239, 68, 68, 0.2);
}

.alert-dismissible .btn-close {
    background: transparent;
    border: none;
    font-size: 1.25rem;
    cursor: pointer;
    color: inherit;
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    color: var(--text-dark);
}

.form-control, .form-select {
    width: 100%;
    padding: 0.75rem 1rem;
    border: 1px solid rgba(15, 77, 146, 0.2);
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.7);
    transition: all 0.2s ease;
    font-size: 0.95rem;
}

.form-control:focus, .form-select:focus {
    outline: none;
    border-color: var(--blue-2);
    box-shadow: 0 0 0 3px rgba(28, 169, 201, 0.1);
    background: white;
}

.form-text {
    color: var(--text-muted);
    font-size: 0.85rem;
    margin-top: 0.25rem;
}

.quick-actions-card {
    background: var(--card-bg);
    border-radius: var(--radius);
    padding: 1.5rem;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(var(--glass-blur));
    margin-bottom: 1.5rem;
}

.quick-actions-card .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid rgba(15, 77, 146, 0.1);
}

.quick-actions-card .card-header h6 {
    margin: 0;
    color: var(--blue-1);
    font-size: 1rem;
}

.quick-actions-card .card-header h6 i {
    margin-right: 0.5rem;
}

.system-info-card {
    background: var(--card-bg);
    border-radius: var(--radius);
    padding: 1.5rem;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(var(--glass-blur));
    margin-bottom: 1.5rem;
}

.system-info-card .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid rgba(15, 77, 146, 0.1);
}

.system-info-card .card-header h6 {
    margin: 0;
    color: var(--blue-1);
    font-size: 1rem;
}

.system-info-card .card-header h6 i {
    margin-right: 0.5rem;
}

.info-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.5rem 0;
    border-bottom: 1px solid rgba(15, 77, 146, 0.05);
}

.info-item:last-child {
    border-bottom: none;
}

.info-label {
    color: var(--text-muted);
    font-size: 0.9rem;
}

.info-value {
    color: var(--text-dark);
    font-weight: 500;
    font-size: 0.9rem;
}

.grid {
    display: grid;
    grid-template-columns: repeat(12, 1fr);
    gap: 1.5rem;
}

@media (max-width: 1000px){
    .stats-grid{ grid-template-columns: repeat(3,1fr) }
}
@media (max-width: 720px){
    .dashboard-container{ flex-direction:column }
    .sidebar{ width:100%; flex-direction:row; align-items:center; gap:0.6rem; padding:0.6rem; border-radius:10px }
    .sidebar.collapsed{ width:100% }
    .sidebar-header h2{ display:none }
    .nav-btn{ padding:0.55rem; font-size:0.9rem }
    .stats-grid{ grid-template-columns: repeat(2,1fr) }
    .grid { grid-template-columns: 1fr; }
}
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="logo-mark">D</div>
                <h2>Dokotela</h2>
            </div>
            
            <div class="sidebar-nav">
                <a href="admin_dashboard.php" class="nav-btn">
                    <i class="fas fa-tachometer-alt fa-fw"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
                <a href="admin_users.php" class="nav-btn">
                    <i class="fas fa-users fa-fw"></i>
                    <span class="nav-text">User Management</span>
                </a>
                <a href="admin_appointments.php" class="nav-btn">
                    <i class="fas fa-calendar-alt fa-fw"></i>
                    <span class="nav-text">Appointments</span>
                </a>
                <a href="admin_doctors.php" class="nav-btn">
                    <i class="fas fa-user-md fa-fw"></i>
                    <span class="nav-text">Doctors</span>
                </a>
                <a href="admin_payments.php" class="nav-btn">
                    <i class="fas fa-money-bill-wave fa-fw"></i>
                    <span class="nav-text">Payments</span>
                </a>
                <a href="admin_services.php" class="nav-btn">
                    <i class="fas fa-concierge-bell fa-fw"></i>
                    <span class="nav-text">Services</span>
                </a>
                <a href="admin_notifications.php" class="nav-btn">
                    <i class="fas fa-bell fa-fw"></i>
                    <span class="nav-text">Notifications</span>
                </a>
                <a href="admin_support.php" class="nav-btn">
                    <i class="fas fa-headset fa-fw"></i>
                    <span class="nav-text">Support Tickets</span>
                </a>
                <a href="admin_announcements.php" class="nav-btn">
                    <i class="fas fa-bullhorn fa-fw"></i>
                    <span class="nav-text">Announcements</span>
                </a>
                <a href="admin_settings.php" class="nav-btn active">
                    <i class="fas fa-cogs fa-fw"></i>
                    <span class="nav-text">Settings</span>
                </a>
                <a href="../auth/logout.php" class="nav-btn">
                    <i class="fas fa-sign-out-alt fa-fw"></i>
                    <span class="nav-text">Logout</span>
                </a>
            </div>
            
            <div class="user-profile">
                <img src="https://ui-avatars.com/api/?name=Admin+User&background=0f4d92&color=fff" alt="Admin User">
                <div class="profile-info">
                    <h4>Admin User</h4>
                    <span>Administrator</span>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="topbar">
                <div class="topbar-left">
                    <button class="hamburger">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h1>Platform Settings & Policies</h1>
                </div>
            </div>

            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-success alert-dismissible">
                    <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
                    <button type="button" class="btn-close">&times;</button>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-error alert-dismissible">
                    <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close">&times;</button>
                </div>
            <?php endif; ?>

            <!-- Settings Statistics -->
            <div class="stats-grid">
                <div class="stat-card total">
                    <div class="stat-icon">
                        <i class="fas fa-cogs"></i>
                    </div>
                    <div class="stat-value"><?php echo $total_policies; ?></div>
                    <div class="stat-label">Total Policies</div>
                </div>
                <div class="stat-card updated">
                    <div class="stat-icon">
                        <i class="fas fa-sync"></i>
                    </div>
                    <div class="stat-value"><?php echo $updated_today; ?></div>
                    <div class="stat-label">Updated Today</div>
                </div>
                <div class="stat-card privacy">
                    <div class="stat-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <div class="stat-value"><?php echo $privacy_exists; ?></div>
                    <div class="stat-label">Privacy Policy</div>
                </div>
                <div class="stat-card terms">
                    <div class="stat-icon">
                        <i class="fas fa-file-contract"></i>
                    </div>
                    <div class="stat-value"><?php echo $terms_exists; ?></div>
                    <div class="stat-label">Terms of Service</div>
                </div>
                <div class="stat-card consent">
                    <div class="stat-icon">
                        <i class="fas fa-user-check"></i>
                    </div>
                    <div class="stat-value"><?php echo $consent_exists; ?></div>
                    <div class="stat-label">Consent Policy</div>
                </div>
                <div class="stat-card data">
                    <div class="stat-icon">
                        <i class="fas fa-database"></i>
                    </div>
                    <div class="stat-value"><?php echo $data_retention_exists; ?></div>
                    <div class="stat-label">Data Retention</div>
                </div>
            </div>

            <div class="grid">
                <!-- Main Settings Form -->
                <div style="grid-column: span 8;">
                    <div class="settings-card">
                        <div class="card-header">
                            <h5><i class="fas fa-shield-alt"></i> Platform Policies & Consent Management</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="update_settings" value="1">
                                
                                <div class="form-group">
                                    <label for="privacy_policy" class="form-label">Privacy Policy</label>
                                    <textarea class="form-control" id="privacy_policy" name="privacy_policy" rows="6" required placeholder="Enter platform privacy policy..."><?php echo htmlspecialchars($settings['privacy_policy'] ?? 'We are committed to protecting your privacy and personal information. This policy outlines how we collect, use, and safeguard your data.'); ?></textarea>
                                    <div class="form-text">Platform privacy policy displayed to all users.</div>
                                </div>
                                
                                <div class="form-group">
                                    <label for="terms_of_service" class="form-label">Terms of Service</label>
                                    <textarea class="form-control" id="terms_of_service" name="terms_of_service" rows="6" required placeholder="Enter terms of service..."><?php echo htmlspecialchars($settings['terms_of_service'] ?? 'By using our platform, you agree to these terms and conditions. Please read them carefully.'); ?></textarea>
                                    <div class="form-text">Terms and conditions for using the platform.</div>
                                </div>
                                
                                <div class="form-group">
                                    <label for="consent_policy" class="form-label">Medical Consent Policy</label>
                                    <textarea class="form-control" id="consent_policy" name="consent_policy" rows="6" required placeholder="Enter medical consent policy..."><?php echo htmlspecialchars($settings['consent_policy'] ?? 'By using our telemedicine services, you consent to medical consultations and understand the limitations of remote healthcare.'); ?></textarea>
                                    <div class="form-text">Medical consent policy for telemedicine services.</div>
                                </div>
                                
                                <div class="form-group">
                                    <label for="data_retention_policy" class="form-label">Data Retention Policy</label>
                                    <textarea class="form-control" id="data_retention_policy" name="data_retention_policy" rows="4" required placeholder="Enter data retention policy..."><?php echo htmlspecialchars($settings['data_retention_policy'] ?? 'We retain medical records for 7 years as required by law. Other personal data is retained only as long as necessary for service provision.'); ?></textarea>
                                    <div class="form-text">Policy outlining how long different types of data are stored.</div>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-2"></i>Save All Policies
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- Sidebar Cards -->
                <div style="grid-column: span 4;">
                    <!-- System Information -->
                    <div class="system-info-card">
                        <div class="card-header">
                            <h6><i class="fas fa-info-circle"></i> System Information</h6>
                        </div>
                        <div class="card-body">
                            <div class="info-item">
                                <span class="info-label">Platform Version</span>
                                <span class="info-value">2.1.0</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Last Updated</span>
                                <span class="info-value"><?php echo date('M j, Y'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Policy Count</span>
                                <span class="info-value"><?php echo $total_policies; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Status</span>
                                <span class="info-value" style="color: #10b981;">Active</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Quick Actions -->
                    <div class="quick-actions-card">
                        <div class="card-header">
                            <h6><i class="fas fa-bolt"></i> Quick Actions</h6>
                        </div>
                        <div class="card-body">
                            <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                                <a href="admin_announcements.php" class="btn btn-secondary">
                                    <i class="fas fa-bullhorn me-2"></i>Create Announcement
                                </a>
                                <a href="admin_notifications.php" class="btn btn-secondary">
                                    <i class="fas fa-bell me-2"></i>Send Notification
                                </a>
                                <a href="admin_support.php" class="btn btn-secondary">
                                    <i class="fas fa-headset me-2"></i>Support Tickets
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Policy Status -->
                    <div class="system-info-card">
                        <div class="card-header">
                            <h6><i class="fas fa-clipboard-check"></i> Policy Status</h6>
                        </div>
                        <div class="card-body">
                            <div class="info-item">
                                <span class="info-label">Privacy Policy</span>
                                <span class="info-value" style="color: <?php echo $privacy_exists ? '#10b981' : '#ef4444'; ?>;">
                                    <?php echo $privacy_exists ? 'Active' : 'Missing'; ?>
                                </span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Terms of Service</span>
                                <span class="info-value" style="color: <?php echo $terms_exists ? '#10b981' : '#ef4444'; ?>;">
                                    <?php echo $terms_exists ? 'Active' : 'Missing'; ?>
                                </span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Consent Policy</span>
                                <span class="info-value" style="color: <?php echo $consent_exists ? '#10b981' : '#ef4444'; ?>;">
                                    <?php echo $consent_exists ? 'Active' : 'Missing'; ?>
                                </span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Data Retention</span>
                                <span class="info-value" style="color: <?php echo $data_retention_exists ? '#10b981' : '#ef4444'; ?>;">
                                    <?php echo $data_retention_exists ? 'Active' : 'Missing'; ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Toggle sidebar
        document.querySelector('.hamburger').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('collapsed');
        });

        // Alert dismiss functionality
        document.querySelectorAll('.btn-close').forEach(button => {
            button.addEventListener('click', function() {
                this.closest('.alert').style.display = 'none';
            });
        });

        // Auto-expand textareas on focus
        document.querySelectorAll('textarea').forEach(textarea => {
            textarea.addEventListener('focus', function() {
                this.style.height = 'auto';
                this.style.height = (this.scrollHeight) + 'px';
            });
        });

        // Form validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const requiredFields = this.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = 'var(--bright-red)';
                } else {
                    field.style.borderColor = '';
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                alert('Please fill all required policy fields.');
            }
        });
    </script>
</body>
</html>