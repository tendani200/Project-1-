<?php
// get_available_slots.php
session_start();
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Admin') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Set South Africa timezone
date_default_timezone_set('Africa/Johannesburg');

// Database connection
try {
    $host = 'sql206.byetcluster.com';
    $dbname = 'if0_40031860_dok';
    $username = 'if0_40031860';
    $password = "qzJkHEejybefK";
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit();
}

$appointmentId = $_GET['appointment_id'] ?? null;
$selectedDate = $_GET['date'] ?? null;

if (!$appointmentId || !$selectedDate) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Appointment ID and date are required']);
    exit();
}

try {
    // Get the doctor ID from the appointment
    $doctorStmt = $pdo->prepare("SELECT doctorID FROM Appointments WHERE appointmentID = ?");
    $doctorStmt->execute([$appointmentId]);
    $appointment = $doctorStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$appointment) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Appointment not found']);
        exit();
    }
    
    $doctorId = $appointment['doctorID'];
    
    // Get available slots for the selected date
    $slotsStmt = $pdo->prepare("
        SELECT slot_id, start_time, end_time, is_booked 
        FROM appointment_slots 
        WHERE doctor_id = ? AND slot_date = ? 
        ORDER BY start_time
    ");
    $slotsStmt->execute([$doctorId, $selectedDate]);
    $slots = $slotsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // If no slots exist in appointment_slots, generate standard hourly slots (9 AM - 5 PM)
    if (empty($slots)) {
        $slots = [];
        $startHour = 9; // 9 AM
        $endHour = 17;  // 5 PM
        
        for ($hour = $startHour; $hour < $endHour; $hour++) {
            $startTime = sprintf("%02d:00:00", $hour);
            $endTime = sprintf("%02d:00:00", $hour + 1);
            
            $slots[] = [
                'start_time' => $startTime,
                'end_time' => $endTime,
                'is_available' => true // Assume available if not in the system
            ];
        }
    } else {
        // Format the slots with availability
        foreach ($slots as &$slot) {
            $slot['is_available'] = $slot['is_booked'] == 0;
        }
    }
    
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'slots' => $slots]);
    
} catch (PDOException $e) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>