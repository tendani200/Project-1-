<?php
// admin_appointments.php - Single File Version
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Set South Africa timezone
date_default_timezone_set('Africa/Johannesburg');

session_start();

// Check if admin is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

// Create database connection
try {
    $host = 'sql206.byetcluster.com';
    $dbname = 'if0_40031860_dok';
    $username = 'if0_40031860';
    $password = "qzJkHEejybefK";
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// --- Filter Logic (removed pagination) ---
$searchTerm = $_GET['search'] ?? '';
$statusFilter = $_GET['status'] ?? 'all';
$dateFilter = $_GET['date'] ?? '';

// Get today's date for default filtering
$today = date('Y-m-d');

// If no date filter is set, default to today
if (empty($dateFilter)) {
    $dateFilter = $today;
}

// --- Fetch Appointments ---
$appointments = [];
$db_error = '';

if ($pdo) {
    try {
        $sql = "
            SELECT 
                a.appointmentID, 
                CONCAT(pu.firstName, ' ', pu.lastName) as patient_name,
                pu.phone as patient_phone,
                CONCAT(du.firstName, ' ', du.lastName) as doctor_name,
                d.specialty,
                ms.serviceName, 
                a.appointmentDate, 
                a.appointmentTime, 
                a.status, 
                a.createdAt,
                a.reason,
                a.cancellationReason,
                a.rescheduleReason,
                a.doctorID,
                a.patientID
            FROM Appointments a
            JOIN Patient pt ON a.patientID = pt.patientID
            JOIN User pu ON pt.userID = pu.userID
            JOIN Doctor d ON a.doctorID = d.doctorID
            JOIN User du ON d.userID = du.userID
            JOIN MedicalService ms ON a.serviceID = ms.serviceID
            WHERE 1=1
        ";
        
        $params = [];
        
        // Build conditions based on filters
        $conditions = [];
        
        // Date filter - always apply date filter, default to today
        if (!empty($dateFilter)) {
            $conditions[] = "a.appointmentDate = ?";
            $params[] = $dateFilter;
        }
        
        // Search filter
        if (!empty($searchTerm)) {
            $conditions[] = "(CONCAT(pu.firstName, ' ', pu.lastName) LIKE ? OR CONCAT(du.firstName, ' ', du.lastName) LIKE ? OR ms.serviceName LIKE ?)";
            $params[] = "%$searchTerm%";
            $params[] = "%$searchTerm%";
            $params[] = "%$searchTerm%";
        }
        
        // Status filter
        if (!empty($statusFilter) && $statusFilter !== 'all') {
            $conditions[] = "a.status = ?";
            $params[] = $statusFilter;
        }
        
        // Add conditions to SQL
        if (!empty($conditions)) {
            $sql .= " AND " . implode(" AND ", $conditions);
        }

        // Add sorting
        $sql .= " ORDER BY a.appointmentTime ASC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        $db_error = "Error fetching appointments: " . $e->getMessage();
        error_log($db_error);
    }
}

// Handle form actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    $appointmentId = $_POST['appointment_id'] ?? null;
    $response = ['success' => false, 'message' => 'Unknown action'];
    
    try {
        switch ($_POST['action']) {
            case 'update_status':
                $status = $_POST['status'] ?? '';
                $notes = $_POST['notes'] ?? '';
                
                $updateStmt = $pdo->prepare("
                    UPDATE Appointments 
                    SET status = ?, reason = COALESCE(?, reason), updatedAt = NOW() 
                    WHERE appointmentID = ?
                ");
                $updateStmt->execute([$status, $notes, $appointmentId]);
                
                // Log the action
                $logStmt = $pdo->prepare("
                    INSERT INTO AppointmentAuditLog 
                    (appointmentID, action, actionBy, reason, createdAt) 
                    VALUES (?, 'updated', 'admin', ?, NOW())
                ");
                $logStmt->execute([$appointmentId, "Status changed to: $status. Notes: $notes"]);
                
                $response = ['success' => true, 'message' => "Appointment status updated successfully!"];
                break;
                
            case 'reschedule':
                $newDate = $_POST['new_date'] ?? '';
                $newTime = $_POST['new_time'] ?? '';
                $reason = $_POST['reason'] ?? '';
                
                // Get current appointment details
                $currentStmt = $pdo->prepare("
                    SELECT appointmentDate, appointmentTime, doctorID FROM Appointments 
                    WHERE appointmentID = ?
                ");
                $currentStmt->execute([$appointmentId]);
                $current = $currentStmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$current) {
                    $response = ['success' => false, 'message' => 'Appointment not found'];
                    break;
                }
                
                // Update appointment
                $updateStmt = $pdo->prepare("
                    UPDATE Appointments 
                    SET appointmentDate = ?, appointmentTime = ?, status = 'rescheduled', 
                        rescheduleReason = ?, rescheduledAt = NOW(), rescheduledBy = 'admin',
                        updatedAt = NOW()
                    WHERE appointmentID = ?
                ");
                $updateStmt->execute([$newDate, $newTime, $reason, $appointmentId]);
                
                // Log the action
                $logStmt = $pdo->prepare("
                    INSERT INTO AppointmentAuditLog 
                    (appointmentID, action, actionBy, oldDate, oldTime, newDate, newTime, reason, createdAt) 
                    VALUES (?, 'rescheduled', 'admin', ?, ?, ?, ?, ?, NOW())
                ");
                $logStmt->execute([
                    $appointmentId, 
                    $current['appointmentDate'], 
                    $current['appointmentTime'],
                    $newDate,
                    $newTime,
                    $reason
                ]);
                
                $response = ['success' => true, 'message' => "Appointment rescheduled successfully!"];
                break;
                
            case 'cancel':
                $reason = $_POST['reason'] ?? '';
                
                // Update appointment
                $updateStmt = $pdo->prepare("
                    UPDATE Appointments 
                    SET status = 'cancelled', cancellationReason = ?, 
                        cancelledAt = NOW(), cancelledBy = 'admin', updatedAt = NOW()
                    WHERE appointmentID = ?
                ");
                $updateStmt->execute([$reason, $appointmentId]);
                
                // Log the action
                $logStmt = $pdo->prepare("
                    INSERT INTO AppointmentAuditLog 
                    (appointmentID, action, actionBy, reason, createdAt) 
                    VALUES (?, 'cancelled', 'admin', ?, NOW())
                ");
                $logStmt->execute([$appointmentId, $reason]);
                
                $response = ['success' => true, 'message' => "Appointment cancelled successfully!"];
                break;
        }
    } catch (PDOException $e) {
        $response = ['success' => false, 'message' => 'Database error: ' . $e->getMessage()];
    }
    
    echo json_encode($response);
    exit();
}

// Get appointment details for view modal
if (isset($_GET['get_details']) && isset($_GET['id'])) {
    header('Content-Type: application/json');
    
    $appointmentId = $_GET['id'];
    $response = ['success' => false, 'message' => 'Failed to fetch appointment details'];
    
    try {
        $sql = "
            SELECT 
                a.*,
                CONCAT(pu.firstName, ' ', pu.lastName) as patient_name,
                pu.phone as patient_phone,
                pu.email as patient_email,
                CONCAT(du.firstName, ' ', du.lastName) as doctor_name,
                d.specialty,
                ms.serviceName,
                ms.serviceFee
            FROM Appointments a
            JOIN Patient pt ON a.patientID = pt.patientID
            JOIN User pu ON pt.userID = pu.userID
            JOIN Doctor d ON a.doctorID = d.doctorID
            JOIN User du ON d.userID = du.userID
            JOIN MedicalService ms ON a.serviceID = ms.serviceID
            WHERE a.appointmentID = ?
        ";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$appointmentId]);
        $appointment = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($appointment) {
            $response = ['success' => true, 'appointment' => $appointment];
        } else {
            $response = ['success' => false, 'message' => 'Appointment not found'];
        }
    } catch (PDOException $e) {
        $response = ['success' => false, 'message' => 'Database error: ' . $e->getMessage()];
    }
    
    echo json_encode($response);
    exit();
}

// Get unique statuses for filter dropdown
$statuses = [];
if ($pdo) {
    try {
        $statusStmt = $pdo->query("SELECT DISTINCT status FROM Appointments ORDER BY status");
        $statuses = $statusStmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        // Continue without status filter if this fails
    }
}

// Get unique dates for calendar filter
$dates = [];
if ($pdo) {
    try {
        $dateStmt = $pdo->query("SELECT DISTINCT appointmentDate FROM Appointments WHERE appointmentDate >= CURDATE() ORDER BY appointmentDate ASC");
        $dates = $dateStmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        // Continue without date filter if this fails
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointments - Dokotela Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css" rel="stylesheet">
    
    <style>
        /* --- START OF CUSTOM GLASS/ANIMATED CSS --- */
        :root{
            --blue-1: #0f4d92;
            --blue-2: #1CA9C9;
            --pastel: #E6F6FF;
            --bright-red: #ff2d55;
            --success-color: #10b981;
            --muted: #64748b;
            --bg: #f6fbff;
            --card-bg: rgba(255,255,255,0.75);
            --glass-border: rgba(255,255,255,0.35);
            --shadow: 0 6px 18px rgba(16,24,40,0.08);
            --radius: 12px;
            --glass-blur: 8px;
            --text-dark: #0f1724;
            --text-muted: #475569;
            --gap: 1.5rem;
        }
        *{box-sizing:border-box;margin:0;padding:0}
        html,body{height:100%}
        body{
            font-family: "Segoe UI", system-ui, -apple-system, "Helvetica Neue", Arial;
            background: #f1f8ff;
            background: radial-gradient(circle at top left, #e6f6ff 0%, #f1f8ff 100%);
            color: var(--text-dark);
        }
        .container-fluid {
            padding: 0;
            margin: 0;
            width: 100%;
        }
        .dashboard-container{
            display:flex;
            min-height:100vh;
            transition: all 0.3s ease;
        }

        /* Standard Sidebar */
        .sidebar{
            width:260px;
            background: linear-gradient(180deg, rgba(255,255,255,0.7), rgba(246,249,255,0.55));
            padding:1rem;
            display:flex;
            flex-direction:column;
            gap:0.75rem;
            align-items:stretch;
            box-shadow: var(--shadow);
            border-right: 1px solid var(--glass-border);
            backdrop-filter: blur(6px);
            -webkit-backdrop-filter: blur(6px);
            transition: width 0.28s cubic-bezier(.22,.9,.36,1);
            position: sticky;
            top: 0;
            height: 100vh;
            z-index: 1000;
        }
        .sidebar-header{
            display:flex;align-items:center;gap:0.75rem;padding:0.6rem 0.6rem;
        }
        .logo-mark{
            width:44px;height:44px;border-radius:10px;
            display:grid;place-items:center;color:white;
            background: linear-gradient(135deg,var(--blue-1),var(--blue-2));
            box-shadow: 0 6px 18px rgba(15,77,146,0.18);
            font-weight:700;
            font-size:1.05rem;
        }
        .sidebar-header h4{ color:var(--blue-1); font-size:1.05rem; font-weight:700; }
        .sidebar-nav{
            display:flex;flex-direction:column;gap:6px;padding:0.5rem 0;
            width:100%;
        }
        .nav-btn{
            display:flex;align-items:center;gap:0.75rem;
            background:transparent;border:none;padding:0.6rem 0.8rem;border-radius:10px;
            cursor:pointer;color:var(--text-muted);font-size:0.95rem;transition: all 0.18s ease;
            text-decoration:none;
        }
        .nav-btn .fa-fw{ width:20px; text-align:center }
        .nav-btn:hover{ transform:translateY(-2px); color:var(--blue-1); background: rgba(15,77,146,0.04) }
        .nav-btn.active{
            background: linear-gradient(90deg, rgba(15,77,146,0.06), rgba(28,169,201,0.03));
            color:var(--blue-1);
            border-left: 3px solid var(--blue-2);
        }
        
        /* Main Content */
        .main-content{
            flex:1;padding:var(--gap);
        }
        .main-header{
            margin-bottom: var(--gap);
            padding-top: 1rem;
        }
        .page-title {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--text-dark);
        }

        /* Search and Filter Box Styling */
        .search-filter-container {
            display: flex;
            gap: 1rem;
            align-items: center;
            flex-wrap: wrap;
            margin-bottom: 1.5rem;
        }
        .search-box {
            display: flex;
            align-items: center;
            background: var(--card-bg);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius);
            padding: 0; 
            height: 40px;
            backdrop-filter: blur(var(--glass-blur));
            -webkit-backdrop-filter: blur(var(--glass-blur));
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 350px;
        }
        .search-box form {
            display: flex;
            width: 100%;
            align-items: center;
            padding: 0 5px; 
        }
        .search-box input {
            border: none !important; 
            outline: none;
            background: transparent;
            width: 100%;
            font-size: 0.95rem;
            color: var(--text-dark);
            padding: 0 10px; 
            box-shadow: none !important;
            height: 38px;
        }
        .search-box button {
            background: transparent;
            color: var(--blue-1);
            border: none;
            padding: 0 8px;
            cursor: pointer;
            font-size: 1rem;
            box-shadow: none;
            transition: color 0.2s;
        }
        .search-box button:hover {
            color: var(--blue-2);
        }
        .filter-select {
            background: var(--card-bg);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius);
            padding: 0.5rem 1rem;
            backdrop-filter: blur(var(--glass-blur));
            -webkit-backdrop-filter: blur(var(--glass-blur));
            box-shadow: var(--shadow);
            color: var(--text-dark);
            min-width: 150px;
        }
        
        /* Calendar Filter */
        .calendar-filter {
            max-width: 200px;
        }
        .calendar-filter .form-control {
            background: var(--card-bg);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius);
            backdrop-filter: blur(var(--glass-blur));
            -webkit-backdrop-filter: blur(var(--glass-blur));
            box-shadow: var(--shadow);
        }
        
        /* Date Navigation */
        .date-navigation {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 1rem;
        }
        .date-nav-btn {
            background: var(--card-bg);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius);
            padding: 0.5rem 1rem;
            backdrop-filter: blur(var(--glass-blur));
            -webkit-backdrop-filter: blur(var(--glass-blur));
            box-shadow: var(--shadow);
            color: var(--blue-1);
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .date-nav-btn:hover {
            background: var(--blue-1);
            color: white;
            transform: translateY(-2px);
        }
        .current-date-display {
            font-weight: 600;
            color: var(--blue-1);
            padding: 0.5rem 1rem;
            background: var(--pastel);
            border-radius: var(--radius);
        }
        
        /* Table Card Styling */
        .admin-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(var(--glass-blur));
            -webkit-backdrop-filter: blur(var(--glass-blur));
            padding: 0;
            overflow: hidden;
            animation: fadeIn 0.8s ease-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .table-responsive {
            margin-bottom: 0;
        }
        .table {
            --bs-table-bg: transparent; 
            --bs-table-hover-bg: rgba(28,169,201,0.05);
            margin-bottom: 0;
        }
        .table th {
            color: var(--blue-1);
            font-weight: 700;
            background: var(--pastel); 
            border-bottom: 2px solid var(--blue-2);
            padding: 1rem 1rem;
            position: sticky;
            top: 0;
        }
        .table td {
             padding: 0.75rem 1rem;
             vertical-align: middle;
        }
        .table td, .table th {
            border-color: rgba(15,77,146,0.1);
        }
        .table tr {
            transition: all 0.2s ease;
        }
        .table tr:hover {
            transform: translateX(5px);
            box-shadow: 0 4px 12px rgba(15,77,146,0.1);
        }
        
        /* Status Badges */
        .status-badge {
            padding: 5px 10px;
            border-radius: 50px;
            font-weight: 600;
            font-size: 0.8rem;
            display: inline-block;
            min-width: 80px;
            text-align: center;
            transition: transform 0.2s ease;
        }
        .status-badge:hover {
            transform: scale(1.05);
        }

        .status-booked {
            background-color: var(--blue-1);
            color: white;
        }
        .status-confirmed, .status-approved {
            background-color: var(--success-color);
            color: white;
        }
        .status-cancelled {
            background-color: var(--bright-red);
            color: white;
        }
        .status-pending, .status-rescheduled {
             background-color: #ffc107;
             color: var(--text-dark);
        }
        .status-completed {
            background-color: var(--blue-2);
            color: white;
        }

        /* Custom Action Button Styling */
        .btn-action {
            display: inline-flex; 
            align-items: center; 
            justify-content: center;
            width: 32px; 
            height: 32px;
            border-radius: 6px;
            margin: 0 2px;
            transition: all 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border-width: 1px !important;
            font-size: 0.8rem;
        }
        .btn-action:hover {
            transform: scale(1.1);
            box-shadow: 0 4px 8px rgba(15, 77, 146, 0.1);
        }
        .btn-edit { color: var(--blue-1); border-color: var(--blue-1); background: rgba(15,77,146,0.05); }
        .btn-edit:hover { background: var(--blue-1); color: white; }
        .btn-view { color: var(--blue-2); border-color: var(--blue-2); background: rgba(28,169,201,0.05); }
        .btn-view:hover { background: var(--blue-2); color: white; }
        .btn-reschedule { color: #ffc107; border-color: #ffc107; background: rgba(255,193,7,0.05); }
        .btn-reschedule:hover { background: #ffc107; color: var(--text-dark); }
        .btn-cancel { color: var(--bright-red); border-color: var(--bright-red); background: rgba(255,45,85,0.05); }
        .btn-cancel:hover { background: var(--bright-red); color: white; }
        
        /* Primary Button */
        .btn-primary-export {
            background: var(--blue-1);
            border-color: var(--blue-1);
            color: white;
            font-weight: 600;
            padding: 0.5rem 1.25rem;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(15, 77, 146, 0.2);
            transition: all 0.2s ease;
        }
        .btn-primary-export:hover {
            background: var(--blue-2);
            border-color: var(--blue-2);
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(28, 169, 201, 0.3);
        }

        /* Date Styling */
        .today-appointment {
            background: rgba(16, 185, 129, 0.05) !important;
            border-left: 3px solid var(--success-color);
        }
        .past-appointment {
            background: rgba(100, 116, 139, 0.05) !important;
            color: var(--muted);
        }
        .date-highlight {
            font-weight: 600;
            color: var(--blue-1);
        }
        .time-display {
            font-size: 0.9rem;
            color: var(--text-muted);
        }

        /* Modal Animation */
        .modal.fade .modal-dialog {
            transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275), opacity 0.3s ease-out;
            transform: scale(0.95) translate(0, -20px);
        }
        .modal.fade.show .modal-dialog {
            transform: scale(1) translate(0, 0);
        }
        .modal-content {
            border-radius: var(--radius);
            box-shadow: 0 20px 50px rgba(15, 77, 146, 0.25);
            border: none;
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--blue-2);
            box-shadow: 0 0 0 0.25rem rgba(28,169,201,0.25);
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: var(--text-muted);
        }
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--blue-2);
        }
        
        /* Animation for success messages */
        @keyframes slideInDown {
            from {
                transform: translateY(-100%);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .alert-slide {
            animation: slideInDown 0.5s ease-out;
        }

        /* Loading states */
        .btn-loading {
            position: relative;
            color: transparent !important;
        }
        .btn-loading::after {
            content: '';
            position: absolute;
            width: 16px;
            height: 16px;
            top: 50%;
            left: 50%;
            margin-left: -8px;
            margin-top: -8px;
            border: 2px solid #ffffff;
            border-radius: 50%;
            border-right-color: transparent;
            animation: spinner 0.75s linear infinite;
        }
        
        @keyframes spinner {
            to { transform: rotate(360deg); }
        }
        
        .modal-loading {
            position: relative;
        }
        .modal-loading::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.8);
            z-index: 1000;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .modal-loading::after {
            content: 'Processing...';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 1001;
            background: var(--blue-1);
            color: white;
            padding: 10px 20px;
            border-radius: var(--radius);
            font-weight: 600;
        }
        
        /* --- END OF CUSTOM GLASS/ANIMATED CSS --- */
    </style>
</head>
<body>
    <div class="container-fluid dashboard-container">
        <nav class="sidebar">
            <div class="sidebar-header">
                <div class="logo-mark"><i class="fas fa-notes-medical"></i></div>
                <h4>Dokotela Admin</h4>
            </div>
            <div class="sidebar-nav">
                <a class="nav-btn" href="admin_dashboard.php"><i class="fas fa-tachometer-alt fa-fw"></i>Dashboard</a>
                <a class="nav-btn" href="admin_users.php"><i class="fas fa-users fa-fw"></i>User Management</a>
                <a class="nav-btn active" href="admin_appointments.php"><i class="fas fa-calendar-alt fa-fw"></i>Appointments</a>
                <a class="nav-btn" href="admin_doctors.php"><i class="fas fa-user-md fa-fw"></i>Doctors</a>
                <a class="nav-btn" href="admin_payments.php"><i class="fas fa-money-bill-wave fa-fw"></i>Payments</a>
                <a class="nav-btn" href="admin_services.php"><i class="fas fa-concierge-bell fa-fw"></i>Services</a>
                <a class="nav-btn" href="admin_reports.php"><i class="fas fa-chart-bar fa-fw"></i>Reports</a>
            </div>
            <a class="nav-btn mt-auto" href="../auth/logout.php"><i class="fas fa-sign-out-alt fa-fw"></i>Logout</a>
        </nav>

        <main class="main-content">
            <div class="main-header">
                <div class="row align-items-center g-3">
                    <div class="col-md-4">
                        <h1 class="page-title">Appointments</h1>
                    </div>
                    <div class="col-md-8 text-end">
                        <div class="d-flex justify-content-end align-items-center gap-3">
                            <a href="export_appointments.php?search=<?php echo urlencode($searchTerm); ?>&status=<?php echo urlencode($statusFilter); ?>&date=<?php echo urlencode($dateFilter); ?>" class="btn btn-primary-export" title="Export to CSV">
                                <i class="fas fa-download"></i> Export
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Date Navigation -->
            <div class="date-navigation">
                <button class="date-nav-btn" onclick="navigateDate(-1)" title="Previous Day">
                    <i class="fas fa-chevron-left"></i>
                </button>
                
                <div class="current-date-display">
                    <i class="fas fa-calendar-day"></i>
                    <?php 
                    $displayDate = $dateFilter === $today ? 'Today' : date('M j, Y', strtotime($dateFilter));
                    echo $displayDate; 
                    ?>
                </div>
                
                <button class="date-nav-btn" onclick="navigateDate(1)" title="Next Day">
                    <i class="fas fa-chevron-right"></i>
                </button>
                
                <button class="date-nav-btn" onclick="goToToday()" title="Go to Today">
                    <i class="fas fa-home"></i> Today
                </button>
            </div>

            <!-- Search and Filter Section -->
            <div class="search-filter-container">
                <div class="search-box">
                    <form method="GET" class="w-100">
                        <input type="text" name="search" placeholder="Search Patient, Doctor, Service..." value="<?php echo htmlspecialchars($searchTerm); ?>">
                        <button type="submit" title="Search"><i class="fas fa-search"></i></button>
                        <!-- Hidden fields to preserve other filters -->
                        <input type="hidden" name="status" value="<?php echo htmlspecialchars($statusFilter); ?>">
                        <input type="hidden" name="date" value="<?php echo htmlspecialchars($dateFilter); ?>">
                    </form>
                </div>
                
                <!-- Calendar Date Filter -->
                <div class="calendar-filter">
                    <input type="text" class="form-control datepicker" placeholder="Select date..." 
                           name="date" value="<?php echo htmlspecialchars($dateFilter); ?>"
                           onchange="this.form.submit()" form="filterForm">
                </div>
                
                <select class="filter-select" name="status" onchange="this.form.submit()" form="filterForm">
                    <option value="all" <?php echo $statusFilter === 'all' ? 'selected' : ''; ?>>All Statuses</option>
                    <?php foreach ($statuses as $status): ?>
                        <option value="<?php echo htmlspecialchars($status); ?>" <?php echo $statusFilter === $status ? 'selected' : ''; ?>>
                            <?php echo ucfirst(htmlspecialchars($status)); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <form id="filterForm" method="GET" style="display: none;">
                    <input type="text" name="search" value="<?php echo htmlspecialchars($searchTerm); ?>">
                </form>
                
                <div class="ms-auto text-muted small">
                    <i class="fas fa-info-circle"></i> 
                    Showing <?php echo count($appointments); ?> appointment(s) for <?php echo $displayDate; ?>
                </div>
            </div>

            <!-- Appointments Table -->
            <div class="admin-card">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Patient</th>
                                <th>Doctor & Specialty</th>
                                <th>Service</th>
                                <th>Time</th>
                                <th>Status</th>
                                <th>Booked On</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($appointments)): ?>
                                <tr>
                                    <td colspan="8" class="empty-state">
                                        <i class="fas fa-calendar-times"></i>
                                        <h5>No appointments found</h5>
                                        <p>No appointments scheduled for <?php echo $displayDate; ?>.</p>
                                        <?php if ($dateFilter === $today): ?>
                                            <p class="mt-2"><small>All appointments for today are displayed here.</small></p>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php 
                                $today = date('Y-m-d');
                                foreach ($appointments as $appointment): 
                                    $appointmentDate = $appointment['appointmentDate'];
                                    $isToday = $appointmentDate === $today;
                                ?>
                                    <tr class="<?php echo $isToday ? 'today-appointment' : ''; ?>">
                                        <td>
                                            <strong>#<?php echo $appointment['appointmentID']; ?></strong>
                                        </td>
                                        <td>
                                            <div class="fw-semibold"><?php echo htmlspecialchars($appointment['patient_name']); ?></div>
                                            <small class="text-muted"><?php echo htmlspecialchars($appointment['patient_phone'] ?? 'N/A'); ?></small>
                                        </td>
                                        <td>
                                            <div class="fw-semibold"><?php echo htmlspecialchars($appointment['doctor_name']); ?></div>
                                            <small class="text-muted"><?php echo htmlspecialchars($appointment['specialty']); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($appointment['serviceName']); ?></td>
                                        <td>
                                            <div class="time-display">
                                                <i class="fas fa-clock me-1"></i>
                                                <?php echo date('g:i A', strtotime($appointment['appointmentTime'])); ?>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="status-badge status-<?php echo strtolower($appointment['status']); ?>">
                                                <?php echo ucfirst($appointment['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <small class="text-muted"><?php echo date('M j, Y', strtotime($appointment['createdAt'])); ?></small>
                                        </td>
                                        <td class="text-center">
                                            <button class="btn btn-action btn-view" title="View Details"
                                                    data-bs-toggle="modal" data-bs-target="#viewDetailsModal" 
                                                    data-id="<?php echo $appointment['appointmentID']; ?>">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            
                                            <button class="btn btn-action btn-edit" title="Edit Appointment" 
                                                    data-bs-toggle="modal" data-bs-target="#editAppointmentModal" 
                                                    data-id="<?php echo $appointment['appointmentID']; ?>">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            
                                            <?php if (strtolower($appointment['status']) !== 'cancelled' && strtolower($appointment['status']) !== 'completed' && $appointmentDate >= $today): ?>
                                            <button class="btn btn-action btn-reschedule" title="Reschedule"
                                                    data-bs-toggle="modal" data-bs-target="#rescheduleModal" 
                                                    data-id="<?php echo $appointment['appointmentID']; ?>">
                                                <i class="fas fa-calendar-check"></i>
                                            </button>
                                            <?php endif; ?>
                                            
                                            <?php if (strtolower($appointment['status']) !== 'cancelled' && $appointmentDate >= $today): ?>
                                            <button class="btn btn-action btn-cancel" title="Cancel Appointment"
                                                    data-bs-toggle="modal" data-bs-target="#cancelModal" 
                                                    data-id="<?php echo $appointment['appointmentID']; ?>">
                                                <i class="fas fa-times"></i>
                                            </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <!-- View Details Modal -->
    <div class="modal fade" id="viewDetailsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" style="color: var(--blue-2);">
                        <i class="fas fa-eye"></i> Appointment Details <span id="view_id_display"></span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="appointment_details_content">
                    <div class="text-center">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <p class="mt-2">Loading appointment details...</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Appointment Modal -->
    <div class="modal fade" id="editAppointmentModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" style="color: var(--blue-1);">
                        <i class="fas fa-edit"></i> Edit Appointment <span id="edit_id_display"></span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="editAppointmentForm">
                    <div class="modal-body">
                        <input type="hidden" name="appointment_id" id="edit_appointment_id">
                        <input type="hidden" name="action" value="update_status">
                        <div class="mb-3">
                            <label for="edit_status" class="form-label">Status</label>
                            <select class="form-select" id="edit_status" name="status" required>
                                <option value="booked">Booked</option>
                                <option value="pending">Pending</option>
                                <option value="rescheduled">Rescheduled</option>
                                <option value="completed">Completed</option>
                                <option value="cancelled">Cancelled</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="edit_notes" class="form-label">Notes</label>
                            <textarea class="form-control" id="edit_notes" name="notes" rows="3" placeholder="Add appointment notes..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" style="background-color: var(--blue-1); border-color: var(--blue-1);">
                            <i class="fas fa-save"></i> Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Reschedule Modal -->
    <div class="modal fade" id="rescheduleModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" style="color: #ffc107;">
                        <i class="fas fa-calendar-check"></i> Reschedule Appointment <span id="reschedule_id_display"></span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="rescheduleForm">
                    <div class="modal-body">
                        <input type="hidden" name="appointment_id" id="reschedule_appointment_id">
                        <input type="hidden" name="action" value="reschedule">
                        <div class="mb-3">
                            <label for="new_date" class="form-label">New Date</label>
                            <input type="date" class="form-control" id="new_date" name="new_date" required min="<?php echo date('Y-m-d'); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="new_time" class="form-label">New Time</label>
                            <input type="time" class="form-control" id="new_time" name="new_time" required>
                        </div>
                        <div class="mb-3">
                            <label for="reschedule_reason" class="form-label">Reason for Rescheduling</label>
                            <textarea class="form-control" id="reschedule_reason" name="reason" rows="2" placeholder="Optional reason for rescheduling..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-warning" style="background-color: #ffc107; color: var(--text-dark);">
                            <i class="fas fa-save"></i> Reschedule
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Cancel Appointment Modal -->
    <div class="modal fade" id="cancelModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" style="color: var(--bright-red);">
                        <i class="fas fa-times-circle"></i> Cancel Appointment <span id="cancel_id_display"></span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="cancelForm">
                    <div class="modal-body">
                        <input type="hidden" name="appointment_id" id="cancel_appointment_id">
                        <input type="hidden" name="action" value="cancel">
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle"></i>
                            <strong>Warning:</strong> This action cannot be undone. The patient will be notified of the cancellation.
                        </div>
                        <div class="mb-3">
                            <label for="cancel_reason" class="form-label">Cancellation Reason</label>
                            <textarea class="form-control" id="cancel_reason" name="reason" rows="3" placeholder="Please provide a reason for cancellation..." required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keep Appointment</button>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-times"></i> Confirm Cancellation
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        // Initialize calendar picker
        flatpickr(".datepicker", {
            dateFormat: "Y-m-d",
            allowInput: true,
            defaultDate: "<?php echo $dateFilter; ?>"
        });

        // Date navigation functions
        function navigateDate(days) {
            const currentDate = "<?php echo $dateFilter; ?>";
            const newDate = new Date(currentDate);
            newDate.setDate(newDate.getDate() + days);
            
            const formattedDate = newDate.toISOString().split('T')[0];
            updateDateFilter(formattedDate);
        }

        function goToToday() {
            const today = new Date().toISOString().split('T')[0];
            updateDateFilter(today);
        }

        function updateDateFilter(date) {
            const form = document.getElementById('filterForm');
            const dateInput = form.querySelector('input[name="date"]');
            dateInput.value = date;
            form.submit();
        }

        // --- Action Button Handlers ---
        document.addEventListener('DOMContentLoaded', function () {
            const modals = [
                { 
                    id: 'viewDetailsModal', 
                    input: 'view_id_display', 
                    trigger: 'view',
                    callback: loadAppointmentDetails 
                },
                { 
                    id: 'editAppointmentModal', 
                    input: 'edit_id_display', 
                    inputField: 'edit_appointment_id',
                    trigger: 'edit',
                    callback: loadAppointmentForEdit 
                },
                { 
                    id: 'rescheduleModal', 
                    input: 'reschedule_id_display', 
                    inputField: 'reschedule_appointment_id',
                    trigger: 'reschedule',
                    callback: loadAppointmentForReschedule 
                },
                { 
                    id: 'cancelModal', 
                    input: 'cancel_id_display', 
                    inputField: 'cancel_appointment_id',
                    trigger: 'cancel' 
                }
            ];

            modals.forEach(modalInfo => {
                const modalElement = document.getElementById(modalInfo.id);
                if (modalElement) {
                    modalElement.addEventListener('show.bs.modal', function (event) {
                        const button = event.relatedTarget;
                        const id = button.getAttribute('data-id');
                        
                        // Set the ID in the display span
                        const idDisplay = modalElement.querySelector(`#${modalInfo.input}`);
                        if (idDisplay) idDisplay.textContent = `#${id}`;

                        // Set the ID in the hidden input field (if applicable)
                        if (modalInfo.inputField) {
                            const idInput = modalElement.querySelector(`#${modalInfo.inputField}`);
                            if (idInput) idInput.value = id;
                        }

                        // Call the callback function if provided
                        if (modalInfo.callback) {
                            modalInfo.callback(id, modalElement);
                        }
                    });
                }
            });

            // Form submission handlers with AJAX
            const editForm = document.getElementById('editAppointmentForm');
            const rescheduleForm = document.getElementById('rescheduleForm');
            const cancelForm = document.getElementById('cancelForm');
            
            if (editForm) editForm.addEventListener('submit', handleEditAppointment);
            if (rescheduleForm) rescheduleForm.addEventListener('submit', handleRescheduleAppointment);
            if (cancelForm) cancelForm.addEventListener('submit', handleCancelAppointment);
        });

        // Load appointment details for view modal
        function loadAppointmentDetails(appointmentId, modalElement) {
            const contentDiv = modalElement.querySelector('#appointment_details_content');
            
            contentDiv.innerHTML = `
                <div class="text-center">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2">Loading appointment details...</p>
                </div>
            `;
            
            // Use the same file to fetch appointment details
            fetch('?get_details=1&id=' + appointmentId)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        const appointment = data.appointment;
                        const appointmentDate = new Date(appointment.appointmentDate + 'T00:00:00');
                        const createdAt = new Date(appointment.createdAt);
                        
                        contentDiv.innerHTML = `
                            <div class="row">
                                <div class="col-md-6">
                                    <h6 class="text-primary">Patient Information</h6>
                                    <p><strong>Name:</strong> ${escapeHtml(appointment.patient_name)}</p>
                                    <p><strong>Contact:</strong><br>${escapeHtml(appointment.patient_phone || 'N/A')}<br>${escapeHtml(appointment.patient_email || '')}</p>
                                </div>
                                <div class="col-md-6">
                                    <h6 class="text-primary">Appointment Details</h6>
                                    <p><strong>Doctor:</strong> ${escapeHtml(appointment.doctor_name)}</p>
                                    <p><strong>Specialty:</strong> ${escapeHtml(appointment.specialty)}</p>
                                    <p><strong>Service:</strong> ${escapeHtml(appointment.serviceName)}</p>
                                    <p><strong>Fee:</strong> R${parseFloat(appointment.serviceFee || 0).toFixed(2)}</p>
                                    <p><strong>Date & Time:</strong> ${appointmentDate.toLocaleDateString('en-ZA')} at ${formatTime(appointment.appointmentTime)}</p>
                                    <p><strong>Status:</strong> <span class="status-badge status-${appointment.status.toLowerCase()}">${appointment.status}</span></p>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                    <h6 class="text-primary">Appointment Notes</h6>
                                    <div class="border rounded p-3 bg-light">
                                        ${appointment.reason ? escapeHtml(appointment.reason) : '<em class="text-muted">No notes available</em>'}
                                    </div>
                                </div>
                            </div>
                            ${appointment.cancellationReason ? `
                            <div class="row mt-3">
                                <div class="col-12">
                                    <h6 class="text-danger">Cancellation Reason</h6>
                                    <div class="border rounded p-3 bg-light">
                                        ${escapeHtml(appointment.cancellationReason)}
                                    </div>
                                </div>
                            </div>
                            ` : ''}
                            ${appointment.rescheduleReason ? `
                            <div class="row mt-3">
                                <div class="col-12">
                                    <h6 class="text-warning">Reschedule Reason</h6>
                                    <div class="border rounded p-3 bg-light">
                                        ${escapeHtml(appointment.rescheduleReason)}
                                    </div>
                                </div>
                            </div>
                            ` : ''}
                            <div class="row mt-3">
                                <div class="col-12">
                                    <small class="text-muted">
                                        <i class="fas fa-calendar-plus"></i> Booked on: ${createdAt.toLocaleDateString('en-ZA')} at ${createdAt.toLocaleTimeString('en-ZA', {hour: '2-digit', minute:'2-digit'})}
                                    </small>
                                </div>
                            </div>
                        `;
                    } else {
                        contentDiv.innerHTML = `
                            <div class="alert alert-danger">
                                <i class="fas fa-exclamation-triangle"></i> ${escapeHtml(data.message || 'Error loading appointment details')}
                            </div>
                        `;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    contentDiv.innerHTML = `
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle"></i> Error loading appointment details. Please try again.
                        </div>
                    `;
                });
        }

        // Load appointment for editing
        function loadAppointmentForEdit(appointmentId, modalElement) {
            // Use the same file to fetch appointment details
            fetch('?get_details=1&id=' + appointmentId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const appointment = data.appointment;
                        document.getElementById('edit_status').value = appointment.status;
                        document.getElementById('edit_notes').value = appointment.reason || '';
                    }
                })
                .catch(error => {
                    console.error('Error loading appointment for edit:', error);
                });
        }

        // Load appointment for reschedule
        function loadAppointmentForReschedule(appointmentId, modalElement) {
            // Use the same file to fetch appointment details
            fetch('?get_details=1&id=' + appointmentId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const appointment = data.appointment;
                        // Set current date and time as default values
                        document.getElementById('new_date').value = appointment.appointmentDate;
                        document.getElementById('new_time').value = appointment.appointmentTime;
                    }
                })
                .catch(error => {
                    console.error('Error loading appointment for reschedule:', error);
                });
        }

        // Handle edit appointment form submission
        function handleEditAppointment(event) {
            event.preventDefault();
            const form = event.target;
            const submitBtn = form.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...';
            submitBtn.disabled = true;
            
            const formData = new FormData(form);
            
            fetch('', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAlert(data.message, 'success');
                    bootstrap.Modal.getInstance(form.closest('.modal')).hide();
                    // Reload the page to reflect changes
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showAlert(data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred. Please try again.', 'danger');
            })
            .finally(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            });
        }

        // Handle reschedule form submission
        function handleRescheduleAppointment(event) {
            event.preventDefault();
            const form = event.target;
            const submitBtn = form.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Rescheduling...';
            submitBtn.disabled = true;
            
            const formData = new FormData(form);
            
            fetch('', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAlert(data.message, 'success');
                    bootstrap.Modal.getInstance(form.closest('.modal')).hide();
                    // Reload the page to reflect changes
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showAlert(data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred. Please try again.', 'danger');
            })
            .finally(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            });
        }

        // Handle cancel form submission
        function handleCancelAppointment(event) {
            event.preventDefault();
            const form = event.target;
            const submitBtn = form.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Cancelling...';
            submitBtn.disabled = true;
            
            const formData = new FormData(form);
            
            fetch('', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAlert(data.message, 'success');
                    bootstrap.Modal.getInstance(form.closest('.modal')).hide();
                    // Reload the page to reflect changes
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showAlert(data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred. Please try again.', 'danger');
            })
            .finally(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            });
        }

        // Helper function to show alerts
        function showAlert(message, type) {
            // Remove any existing alerts
            const existingAlert = document.querySelector('.alert-slide');
            if (existingAlert) {
                existingAlert.remove();
            }
            
            const alert = document.createElement('div');
            alert.className = `alert alert-${type} alert-slide position-fixed top-0 start-50 translate-middle-x mt-3`;
            alert.style.zIndex = '1060';
            alert.innerHTML = `
                <div class="d-flex align-items-center">
                    <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle'} me-2"></i>
                    <div>${message}</div>
                    <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
                </div>
            `;
            
            document.body.appendChild(alert);
            
            // Auto-dismiss after 5 seconds
            setTimeout(() => {
                if (alert.parentNode) {
                    alert.remove();
                }
            }, 5000);
        }

        // Helper function to format time
        function formatTime(timeString) {
            const time = new Date('1970-01-01T' + timeString);
            return time.toLocaleTimeString('en-ZA', {hour: '2-digit', minute:'2-digit'});
        }

        // Helper function to escape HTML
        function escapeHtml(unsafe) {
            if (unsafe === null || unsafe === undefined) return '';
            return unsafe
                .toString()
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;");
        }
    </script>
</body>
</html>