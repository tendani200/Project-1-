<?php
// admin_reports.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if admin is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

// Create database connection
try {
    $host = 'sql206.byetcluster.com';
    $dbname = 'if0_40031860_dok';
    $username = 'if0_40031860';
    $password = "qzJkHEejybefK";
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get report data
$monthlyRevenue = $pdo->query("
    SELECT MONTH(paymentDate) as month, SUM(amount) as revenue
    FROM Payments 
    WHERE status = 'paid' AND YEAR(paymentDate) = YEAR(CURDATE())
    GROUP BY MONTH(paymentDate)
    ORDER BY month
")->fetchAll();

$topServices = $pdo->query("
    SELECT ms.serviceName, COUNT(p.paymentID) as appointment_count, SUM(p.amount) as revenue
    FROM MedicalService ms
    JOIN Payments p ON ms.serviceID = p.serviceID
    WHERE p.status = 'paid'
    GROUP BY ms.serviceID
    ORDER BY revenue DESC
    LIMIT 5
")->fetchAll();

$doctorPerformance = $pdo->query("
    SELECT CONCAT(u.firstName, ' ', u.lastName) as doctor_name,
           COUNT(a.appointmentID) as appointments,
           SUM(p.amount) as revenue
    FROM Doctor d
    JOIN User u ON d.userID = u.userID
    JOIN Appointments a ON d.doctorID = a.doctorID
    JOIN Payments p ON a.appointmentID = p.appointmentID
    WHERE p.status = 'paid'
    GROUP BY d.doctorID
    ORDER BY revenue DESC
")->fetchAll();

// Prepare data for charts
$months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
$revenueData = array_fill(0, 12, 0);
foreach ($monthlyRevenue as $revenue) {
    $revenueData[$revenue['month'] - 1] = floatval($revenue['revenue']);
}

$serviceNames = array_column($topServices, 'serviceName');
$serviceRevenue = array_column($topServices, 'revenue');

// Get stats for the cards
$monthlyAppointments = $pdo->query("SELECT COUNT(*) FROM Appointments WHERE MONTH(createdAt) = MONTH(CURDATE())")->fetch()[0];
$monthlyRevenueTotal = $pdo->query("SELECT SUM(amount) FROM Payments WHERE status = 'paid' AND MONTH(paymentDate) = MONTH(CURDATE())")->fetch()[0] ?? 0;
$totalPatients = $pdo->query("SELECT COUNT(*) FROM Patient")->fetch()[0];
$activeDoctors = $pdo->query("SELECT COUNT(*) FROM Doctor")->fetch()[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Dokotela Admin</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
:root{
    --blue-1: #0f4d92;
    --blue-2: #1CA9C9;
    --pastel: #E6F6FF;
    --bright-red: #ff2d55;
    --muted: #64748b;
    --bg: #f6fbff;
    --card-bg: rgba(255,255,255,0.75);
    --glass-border: rgba(255,255,255,0.35);
    --shadow: 0 6px 18px rgba(16,24,40,0.08);
    --radius: 12px;
    --glass-blur: 8px;
    --text-dark: #0f1724;
    --text-muted: #475569;
    --gap: 1rem;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%}
body{
    font-family: "Segoe UI", system-ui, -apple-system, "Helvetica Neue", Arial;
    background: #f1f8ff;
    background: radial-gradient(circle at top left, #e6f6ff 0%, #f1f8ff 100%);
    color: var(--text-dark);
}

.dashboard-container{
    display:flex;
    min-height:100vh;
    gap:var(--gap);
    transition: all 0.3s ease;
}
.sidebar{
    width:260px;
    background: linear-gradient(180deg, rgba(255,255,255,0.7), rgba(246,249,255,0.55));
    border-radius: calc(var(--radius) + 4px);
    padding:1rem;
    display:flex;
    flex-direction:column;
    gap:0.75rem;
    align-items:stretch;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(6px);
    transition: width 0.28s cubic-bezier(.22,.9,.36,1), transform 0.3s ease;
}
.sidebar.collapsed{ width:72px; padding:0.6rem; align-items:center }
.sidebar.collapsed .sidebar-header h2,
.sidebar.collapsed .nav-text,
.sidebar.collapsed .profile-info { display:none }
.sidebar.collapsed .nav-btn { justify-content:center }
.sidebar-header{
    display:flex;
    align-items:center;
    gap:0.75rem;
    padding:0.6rem 0.6rem;
}
.logo-mark{
    width:44px;height:44px;border-radius:10px;
    display:grid;place-items:center;color:white;
    background: linear-gradient(135deg,var(--blue-1),var(--blue-2));
    box-shadow: 0 6px 18px rgba(15,77,146,0.18);
    font-weight:700;
    font-size:1.05rem;
}
.sidebar-header h2{ color:var(--blue-1); font-size:1.05rem; font-weight:700; }
.sidebar-nav{
    display:flex;flex-direction:column;gap:6px;padding:0.5rem 0;
    width:100%;
}
.nav-btn{
    display:flex;align-items:center;gap:0.75rem;
    background:transparent;border:none;padding:0.6rem 0.8rem;border-radius:10px;
    cursor:pointer;color:var(--text-muted);font-size:0.95rem;transition: all 0.18s ease;
    text-decoration:none;
}
.nav-btn .fa-fw{ width:20px; text-align:center }
.nav-btn:hover{ transform:translateY(-2px); color:var(--blue-1); background: rgba(15,77,146,0.04) }
.nav-btn.active{
    background: linear-gradient(90deg, rgba(15,77,146,0.06), rgba(28,169,201,0.03));
    color:var(--blue-1);
    border-left: 3px solid var(--blue-2);
}
.nav-text{ flex:1 }
.user-profile{
    margin-top:auto;display:flex;align-items:center;gap:0.75rem;padding:0.6rem;border-radius:10px;
    background: linear-gradient(180deg, rgba(255,255,255,0.35), rgba(255,255,255,0.2));
    border: 1px solid rgba(255,255,255,0.25);
    backdrop-filter: blur(4px);
}
.user-profile img{ width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid white; box-shadow: 0 6px 14px rgba(16,24,40,0.06) }
.profile-info h4{ font-size:0.95rem; margin-bottom:2px }
.profile-info span{ font-size:0.82rem; color:var(--text-muted) }
.main-content{
    flex:1;padding:1.5rem;overflow:auto;
}
.topbar{
    display:flex;align-items:center;justify-content:space-between;gap:1rem;margin-bottom:1.25rem;
}
.topbar-left{
    display:flex;align-items:center;gap:1rem;
}
.hamburger{
    background:transparent;border:none;padding:0.5rem;cursor:pointer;color:var(--text-muted);
    border-radius:6px;transition:all 0.2s ease;
}
.hamburger:hover{background:rgba(15,77,146,0.06);color:var(--blue-1);}

.welcome-header{
    background: linear-gradient(135deg, rgba(15,77,146,0.95), rgba(28,169,201,0.95));
    color:white;padding:1.6rem;border-radius:14px;box-shadow: 0 12px 30px rgba(15,77,146,0.12);
    display:flex;flex-direction:column;gap:0.4rem;
}
.welcome-header h1{ font-size:1.6rem; font-weight:700 }
.welcome-header p{ opacity:0.95; font-size:0.95rem }
.grid{
    display:grid;
    grid-template-columns: repeat(12, 1fr);
    gap:1rem;
    margin-top:1rem;
}
.card{
    background: var(--card-bg);
    border-radius: var(--radius);
    padding:1rem;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(var(--glass-blur));
}
.stats-grid{ grid-column: span 12; display:grid; grid-template-columns: repeat(4,1fr); gap:1rem; }
.stat-card{
    padding:0.9rem; display:flex; align-items:center; gap:0.9rem; border-radius:10px;
}
.stat-icon{ font-size:1.75rem; background: linear-gradient(180deg, rgba(255,255,255,0.8), rgba(255,255,255,0.6)); padding:0.6rem; border-radius:10px;}
.stat-info .stat-value{ font-size:1.45rem; color:var(--blue-1); font-weight:700 }
.stat-info .stat-label{ color:var(--text-muted); font-size:0.9rem }
.schedule-card{ grid-column: span 12; padding:1rem }
    
.schedule-list ul{ list-style:none; display:flex; flex-direction:column; gap:0.6rem; margin-top:0.6rem }
.schedule-list li{ padding:0.6rem; border-radius:8px; background: rgba(255,255,255,0.65); display:flex; justify-content:space-between; align-items:center; border-left:4px solid rgba(28,169,201,0.18); }
.patients-grid{ grid-column: span 5; display:grid; gap:0.75rem; grid-auto-rows:min-content }
.patient-card{ padding:0.8rem; border-radius:8px; background: rgba(255,255,255,0.75); display:flex; flex-direction:column; gap:0.4rem; border-left:4px solid rgba(15,77,146,0.08) }
.appointments-table .placeholder{ padding:1rem; color:var(--text-muted) }
.btn{ display:inline-flex; align-items:center; gap:0.5rem; padding:0.55rem 0.9rem; border-radius:10px; border:none; cursor:pointer; font-weight:600; text-decoration:none; }
    
.btn-primary{ background: linear-gradient(90deg,var(--blue-1),var(--blue-2)); color:white }
.btn-ghost{ background:transparent; color:var(--text-dark); border:1px solid rgba(15,77,146,0.06) }
.btn-danger{ background:var(--bright-red); color:white }
.btn-secondary{
    background: linear-gradient(90deg, rgba(28,169,201,0.1), rgba(15,77,146,0.1));
    color: var(--blue-1);
    border: 1px solid rgba(15,77,146,0.2);
}
.btn-consult {
    background-color: #2563eb;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 0.55rem 0.9rem;
    cursor: pointer;
    font-weight: 600;
    transition: background 0.2s, box-shadow 0.2s;
}

.btn-consult:hover {
    background-color: #1e4fd4;
    box-shadow: 0 4px 12px rgba(37, 99, 235, 0.4);
}

.modal{ display:none; position:fixed; inset:0; z-index:1200; background: rgba(2,6,23,0.45); backdrop-filter: blur(4px) }
.modal .modal-content{ background: white; max-width:720px; margin:6% auto; padding:1.4rem; border-radius:12px; box-shadow: 0 20px 50px rgba(2,6,23,0.25) }
.glass-accent{ background: linear-gradient(180deg, rgba(255,255,255,0.6), rgba(255,255,255,0.35)); border-radius:10px; border:1px solid rgba(255,255,255,0.25); backdrop-filter: blur(6px) }

/* Search container */
.search-container {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-left: 1rem;
}

.search-box {
  display: flex;
  align-items: center;
  background: rgba(255, 255, 255, 0.15);
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 12px;
  padding: 6px 10px;
  height: 38px;
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
  transition: border 0.2s ease, background 0.2s ease, box-shadow 0.2s ease;
}

.search-box input {
  border: none;
  outline: none;
  background: transparent;
  width: 180px;
  font-size: 14px;
  color: var(--text-dark);
  backdrop-filter: blur(5px);
}

.search-box button {
  background-color: #2563eb;
  color: white;
  border: none;
  border-radius: 8px;
  padding: 6px 10px;
  cursor: pointer;
  font-size: 14px;
  transition: background 0.2s, box-shadow 0.2s;
  margin-left: 6px;
  box-shadow: 0 4px 15px rgba(37, 99, 235, 0.4);
}

.search-box button:hover {
  background-color: #1e4fd4;
  box-shadow: 0 6px 20px rgba(37, 99, 235, 0.5);
}

/* Weekly Overview */
.weekly-overview {
  background: white;
  border-radius: 10px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
  width: 300px;
  padding: 20px;
  margin-top: 40px;
}

.weekly-overview h3 {
  margin-top: 0;
  font-size: 16px;
  font-weight: 600;
  color: #111827;
}

.days {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 8px;
  margin-top: 10px;
  margin-bottom: 20px;
}

.day {
  background: #f3f4f6;
  border-radius: 8px;
  text-align: center;
  padding: 10px 0;
  font-weight: 500;
  color: #374151;
  transition: all 0.2s;
}

.day.active {
  background-color: #2563eb;
  color: white;
  box-shadow: 0 2px 6px rgba(37, 99, 235, 0.4);
}

@media (max-width: 1000px){
    .stats-grid{ grid-template-columns: repeat(2,1fr) }
    .schedule-card{ grid-column: span 12 }
    .patients-grid{ grid-column: span 12 }
}
@media (max-width: 720px){
    .dashboard-container{ flex-direction:column }
    .sidebar{ width:100%; flex-direction:row; align-items:center; gap:0.6rem; padding:0.6rem; border-radius:10px }
    .sidebar.collapsed{ width:100% }
    .sidebar-header h2{ display:none }
    .nav-btn{ padding:0.55rem; font-size:0.9rem }
    .grid{ grid-template-columns: 1fr; }
    .stats-grid{ grid-template-columns: 1fr }
    .welcome-header h1{ font-size:1.25rem }
    .search-container {
        justify-content: flex-end;
        margin-left: 0;
    }
    .search-box {
        width: 100%;
        max-width: 220px;
    }
    .search-box input {
        width: 100%;
    }
}
.muted { color:var(--text-muted); font-size:0.9rem }
.small { font-size:0.85rem }

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

th, td {
    padding: 0.75rem;
    text-align: left;
    border-bottom: 1px solid #e2e8f0;
}

th {
    background-color: rgba(15, 77, 146, 0.05);
    font-weight: 600;
    color: var(--blue-1);
}

tr:hover {
    background-color: rgba(15, 77, 146, 0.02);
}
    .btn-sm {
    padding: 0.4rem 0.8rem;
    font-size: 0.85rem;
}

/* Analytics Specific Styles */
.analytics-kpi {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.analytics-kpi:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.chart-bar {
    transition: all 0.3s ease;
    cursor: pointer;
}

.chart-bar:hover {
    opacity: 0.8;
    transform: scale(1.05);
}

.performance-metric {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.75rem 0;
    border-bottom: 1px solid #e5e7eb;
    transition: background-color 0.2s ease;
}

.performance-metric:hover {
    background-color: rgba(59, 130, 246, 0.05);
    border-radius: 4px;
    margin: 0 -0.5rem;
    padding: 0.75rem 0.5rem;
}

.recent-patient-item {
    transition: background-color 0.2s ease;
    border-radius: 6px;
    margin: 0 -0.5rem;
    padding: 0.75rem 0.5rem;
}

.recent-patient-item:hover {
    background-color: rgba(16, 185, 129, 0.05);
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

.analytics-loading {
    animation: pulse 2s infinite;
}

/* Responsive analytics adjustments */
@media (max-width: 768px) {
    .grid {
        grid-template-columns: 1fr !important;
    }
    
    #weeklyChart, #monthlyChart {
        height: 200px !important;
    }
    
    .analytics-kpi {
        text-align: center;
    }
}

.medical-record-item {
    transition: all 0.3s ease;
}

.medical-record-item:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

/* Chart container styles */
.chart-container {
    position: relative;
    height: 300px;
    width: 100%;
}

/* Reports specific styles */
.reports-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
}

.reports-header h1 {
    font-size: 1.8rem;
    color: var(--blue-1);
    margin: 0;
}

.reports-actions {
    display: flex;
    gap: 0.75rem;
}

.chart-card {
    grid-column: span 8;
}

.donut-card {
    grid-column: span 4;
}

.table-card {
    grid-column: span 12;
}

/* Adjust chart sizes for better layout */
.chart-wrapper {
    height: 250px;
    margin-top: 1rem;
}

/* Ensure proper spacing in tables */
.table-responsive {
    border-radius: var(--radius);
    overflow: hidden;
}

/* Fix for chart responsiveness */
@media (max-width: 1000px) {
    .chart-card, .donut-card {
        grid-column: span 12;
    }
}
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="logo-mark">D</div>
                <h2>Dokotela Admin</h2>
            </div>
            
            <nav class="sidebar-nav">
                <a href="admin_dashboard.php" class="nav-btn">
                    <i class="fas fa-tachometer-alt fa-fw"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
                <a href="admin_users.php" class="nav-btn">
                    <i class="fas fa-users fa-fw"></i>
                    <span class="nav-text">User Management</span>
                </a>
                <a href="admin_appointments.php" class="nav-btn">
                    <i class="fas fa-calendar-alt fa-fw"></i>
                    <span class="nav-text">Appointments</span>
                </a>
                <a href="admin_doctors.php" class="nav-btn">
                    <i class="fas fa-user-md fa-fw"></i>
                    <span class="nav-text">Doctors</span>
                </a>
                <a href="admin_payments.php" class="nav-btn">
                    <i class="fas fa-money-bill-wave fa-fw"></i>
                    <span class="nav-text">Payments</span>
                </a>
                <a href="admin_services.php" class="nav-btn">
                    <i class="fas fa-concierge-bell fa-fw"></i>
                    <span class="nav-text">Services</span>
                </a>
                <a href="admin_reports.php" class="nav-btn active">
                    <i class="fas fa-chart-bar fa-fw"></i>
                    <span class="nav-text">Reports</span>
                </a>
            </nav>
            
            <div class="user-profile">
                <img src="https://ui-avatars.com/api/?name=Admin+User&background=0f4d92&color=fff" alt="Admin User">
                <div class="profile-info">
                    <h4>Admin User</h4>
                    <span>Administrator</span>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="topbar">
                <div class="topbar-left">
                    <button class="hamburger" id="sidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <div class="reports-header">
                        <h1>Analytics & Reports</h1>
                    </div>
                </div>
                <div class="reports-actions">
                    <button class="btn btn-secondary" onclick="exportReports()">
                        <i class="fas fa-download"></i> Export Report
                    </button>
                    <button class="btn btn-primary" onclick="window.print()">
                        <i class="fas fa-print"></i> Print
                    </button>
                </div>
            </div>

            <!-- Welcome Header -->
            <div class="welcome-header">
                <h1>Financial Overview</h1>
                <p>Track revenue, service performance, and doctor analytics</p>
            </div>

            <!-- Quick Stats -->
            <div class="grid">
                <div class="stats-grid">
                    <div class="card stat-card analytics-kpi">
                        <div class="stat-icon" style="color: var(--blue-1);">
                            <i class="fas fa-calendar-check"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-value"><?php echo $monthlyAppointments; ?></div>
                            <div class="stat-label">This Month Appointments</div>
                        </div>
                    </div>
                    <div class="card stat-card analytics-kpi">
                        <div class="stat-icon" style="color: var(--blue-2);">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-value">R<?php echo number_format($monthlyRevenueTotal, 0); ?></div>
                            <div class="stat-label">Monthly Revenue</div>
                        </div>
                    </div>
                    <div class="card stat-card analytics-kpi">
                        <div class="stat-icon" style="color: #10b981;">
                            <i class="fas fa-user-injured"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-value"><?php echo $totalPatients; ?></div>
                            <div class="stat-label">Total Patients</div>
                        </div>
                    </div>
                    <div class="card stat-card analytics-kpi">
                        <div class="stat-icon" style="color: #f59e0b;">
                            <i class="fas fa-user-md"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-value"><?php echo $activeDoctors; ?></div>
                            <div class="stat-label">Active Doctors</div>
                        </div>
                    </div>
                </div>

                <!-- Charts -->
                <div class="card chart-card">
                    <h3>Monthly Revenue Report</h3>
                    <div class="chart-wrapper">
                        <canvas id="revenueChart"></canvas>
                    </div>
                </div>
                
                <div class="card donut-card">
                    <h3>Top Services by Revenue</h3>
                    <div class="chart-wrapper">
                        <canvas id="servicesChart"></canvas>
                    </div>
                </div>

                <!-- Doctor Performance -->
                <div class="card table-card">
                    <h3>Doctor Performance</h3>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Doctor</th>
                                    <th>Appointments</th>
                                    <th>Revenue</th>
                                    <th>Average per Appointment</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($doctorPerformance as $doctor): ?>
                                <tr class="performance-metric">
                                    <td><?php echo htmlspecialchars($doctor['doctor_name']); ?></td>
                                    <td><?php echo $doctor['appointments']; ?></td>
                                    <td>R<?php echo number_format($doctor['revenue'], 2); ?></td>
                                    <td>R<?php echo number_format($doctor['revenue'] / max($doctor['appointments'], 1), 2); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Service Performance -->
                <div class="card table-card">
                    <h3>Service Performance</h3>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Service</th>
                                    <th>Appointments</th>
                                    <th>Total Revenue</th>
                                    <th>Average Revenue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($topServices as $service): ?>
                                <tr class="performance-metric">
                                    <td><?php echo htmlspecialchars($service['serviceName']); ?></td>
                                    <td><?php echo $service['appointment_count']; ?></td>
                                    <td>R<?php echo number_format($service['revenue'], 2); ?></td>
                                    <td>R<?php echo number_format($service['revenue'] / max($service['appointment_count'], 1), 2); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Sidebar toggle functionality
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('collapsed');
        });

        // Initialize charts
        document.addEventListener('DOMContentLoaded', function() {
            // Revenue Chart
            const revenueCtx = document.getElementById('revenueChart').getContext('2d');
            const revenueChart = new Chart(revenueCtx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($months); ?>,
                    datasets: [{
                        label: 'Revenue (R)',
                        data: <?php echo json_encode($revenueData); ?>,
                        backgroundColor: 'rgba(15, 77, 146, 0.8)',
                        borderColor: 'rgba(15, 77, 146, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return 'R' + value;
                                }
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });

            // Services Chart
            const servicesCtx = document.getElementById('servicesChart').getContext('2d');
            const servicesChart = new Chart(servicesCtx, {
                type: 'doughnut',
                data: {
                    labels: <?php echo json_encode($serviceNames); ?>,
                    datasets: [{
                        data: <?php echo json_encode($serviceRevenue); ?>,
                        backgroundColor: [
                            'rgba(15, 77, 146, 0.8)',
                            'rgba(28, 169, 201, 0.8)',
                            'rgba(16, 185, 129, 0.8)',
                            'rgba(245, 158, 11, 0.8)',
                            'rgba(239, 68, 68, 0.8)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        });

        function exportReports() {
            alert('Export functionality would be implemented here. ');
            // In a real implementation, this would make an AJAX call to generate and download reports
        }
    </script>
</body>
</html>