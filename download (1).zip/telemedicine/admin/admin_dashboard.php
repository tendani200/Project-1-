<?php
// admin_dashboard.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if admin is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

$userID = intval($_SESSION['userID']);

// Create database connection directly (without relying on db_connect.php)
try {
    $host = 'sql206.byetcluster.com';
    $dbname = 'if0_40031860_dok';
    $username = 'if0_40031860';
    $password = "qzJkHEejybefK";  
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Test the connection
    $pdo->query("SELECT 1");
    
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get dashboard statistics with accurate calculations
function getDashboardStats($pdo) {
    $stats = [];
    
    try {
        // Total Patients
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM Patient");
        $stats['total_patients'] = $stmt->fetch()['total'] ?? 0;
        
        // Total Doctors
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM Doctor");
        $stats['total_doctors'] = $stmt->fetch()['total'] ?? 0;
        
        // Appointments Today
        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM Appointments WHERE appointmentDate = CURDATE() AND status != 'cancelled'");
        $stmt->execute();
        $stats['appointments_today'] = $stmt->fetch()['total'] ?? 0;
        
        // Total Appointments This Week
        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM Appointments WHERE YEARWEEK(appointmentDate) = YEARWEEK(CURDATE()) AND status != 'cancelled'");
        $stmt->execute();
        $stats['appointments_week'] = $stmt->fetch()['total'] ?? 0;
        
        // Total Revenue (from paid payments)
        $stmt = $pdo->query("SELECT SUM(amount) as total FROM Payments WHERE status = 'paid'");
        $result = $stmt->fetch();
        $stats['total_revenue'] = $result['total'] ?? 0;
        
        // Pending Payments
        $stmt = $pdo->query("SELECT SUM(amount) as total FROM Payments WHERE status = 'pending'");
        $result = $stmt->fetch();
        $stats['pending_revenue'] = $result['total'] ?? 0;
        
        // Revenue this month
        $stmt = $pdo->prepare("SELECT SUM(amount) as total FROM Payments WHERE status = 'paid' AND MONTH(paymentDate) = MONTH(CURDATE()) AND YEAR(paymentDate) = YEAR(CURDATE())");
        $stmt->execute();
        $result = $stmt->fetch();
        $stats['revenue_this_month'] = $result['total'] ?? 0;
        
        // Revenue last month
        $stmt = $pdo->prepare("SELECT SUM(amount) as total FROM Payments WHERE status = 'paid' AND MONTH(paymentDate) = MONTH(CURDATE() - INTERVAL 1 MONTH) AND YEAR(paymentDate) = YEAR(CURDATE() - INTERVAL 1 MONTH)");
        $stmt->execute();
        $result = $stmt->fetch();
        $stats['revenue_last_month'] = $result['total'] ?? 0;
        
        // Patients this month
        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM Patient p JOIN User u ON p.userID = u.userID WHERE MONTH(u.createdAt) = MONTH(CURDATE()) AND YEAR(u.createdAt) = YEAR(CURDATE())");
        $stmt->execute();
        $stats['patients_this_month'] = $stmt->fetch()['total'] ?? 0;
        
        // Patients last month
        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM Patient p JOIN User u ON p.userID = u.userID WHERE MONTH(u.createdAt) = MONTH(CURDATE() - INTERVAL 1 MONTH) AND YEAR(u.createdAt) = YEAR(CURDATE() - INTERVAL 1 MONTH)");
        $stmt->execute();
        $stats['patients_last_month'] = $stmt->fetch()['total'] ?? 0;
        
        // Monthly appointments data for chart - Last 6 months including current
        $stmt = $pdo->query("
            SELECT 
                DATE_FORMAT(NOW() - INTERVAL (5-seq.seq) MONTH, '%Y-%m') as month_date,
                DATE_FORMAT(NOW() - INTERVAL (5-seq.seq) MONTH, '%b') as month_name,
                COALESCE(COUNT(a.appointmentID), 0) as count
            FROM (
                SELECT 0 as seq UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5
            ) seq
            LEFT JOIN Appointments a ON 
                DATE_FORMAT(a.appointmentDate, '%Y-%m') = DATE_FORMAT(NOW() - INTERVAL (5-seq.seq) MONTH, '%Y-%m')
                AND a.status != 'cancelled'
            GROUP BY month_date, month_name
            ORDER BY month_date
        ");
        
        $monthly_appointments_data = [];
        $monthly_appointments_labels = [];
        while ($row = $stmt->fetch()) {
            $monthly_appointments_data[] = $row['count'];
            $monthly_appointments_labels[] = $row['month_name'];
        }
        $stats['monthly_appointments_data'] = $monthly_appointments_data;
        $stats['monthly_appointments_labels'] = $monthly_appointments_labels;
        
        // Revenue by service type for current month
        $stmt = $pdo->query("
            SELECT ms.serviceName, COALESCE(SUM(p.amount), 0) as revenue
            FROM MedicalService ms
            LEFT JOIN Payments p ON ms.serviceID = p.serviceID 
                AND p.status = 'paid' 
                AND MONTH(p.paymentDate) = MONTH(CURDATE()) 
                AND YEAR(p.paymentDate) = YEAR(CURDATE())
            GROUP BY ms.serviceName
            ORDER BY revenue DESC
            LIMIT 6
        ");
        
        $stats['revenue_by_service'] = [];
        while ($row = $stmt->fetch()) {
            if ($row['revenue'] > 0) {
                $stats['revenue_by_service'][] = $row;
            }
        }
        
        // Get admin name for welcome message
        $stmt = $pdo->prepare("SELECT firstName, lastName FROM User WHERE userID = ?");
        $stmt->execute([$GLOBALS['userID']]);
        $admin = $stmt->fetch();
        $stats['admin_name'] = $admin ? $admin['firstName'] . ' ' . $admin['lastName'] : 'Admin';
        
        // Recent activities
        $stmt = $pdo->query("
            (SELECT 'appointment' as type, appointmentID as id, CONCAT('New appointment booked - #', appointmentID) as description, createdAt as date 
             FROM Appointments 
             ORDER BY createdAt DESC LIMIT 3)
            UNION
            (SELECT 'payment' as type, paymentID as id, CONCAT('Payment received - R', amount) as description, paymentDate as date 
             FROM Payments 
             WHERE status = 'paid' 
             ORDER BY paymentDate DESC LIMIT 3)
            UNION
            (SELECT 'user' as type, userID as id, CONCAT('New user registered - ', firstName, ' ', lastName) as description, createdAt as date 
             FROM User 
             ORDER BY createdAt DESC LIMIT 3)
            ORDER BY date DESC 
            LIMIT 5
        ");
        
        $stats['recent_activities'] = $stmt->fetchAll();
        
        // Calculate growth percentages
        $stats['revenue_growth'] = $stats['revenue_last_month'] > 0 ? 
            round((($stats['revenue_this_month'] - $stats['revenue_last_month']) / $stats['revenue_last_month']) * 100, 1) : 0;
        
        $stats['patients_growth'] = $stats['patients_last_month'] > 0 ? 
            round((($stats['patients_this_month'] - $stats['patients_last_month']) / $stats['patients_last_month']) * 100, 1) : 0;
        
    } catch (PDOException $e) {
        error_log("Database error in getDashboardStats: " . $e->getMessage());
        // Set default values on error
        $stats = [
            'total_patients' => 0,
            'total_doctors' => 0,
            'appointments_today' => 0,
            'appointments_week' => 0,
            'total_revenue' => 0,
            'pending_revenue' => 0,
            'revenue_this_month' => 0,
            'revenue_last_month' => 0,
            'patients_this_month' => 0,
            'patients_last_month' => 0,
            'monthly_appointments_data' => [0, 0, 0, 0, 0, 0],
            'monthly_appointments_labels' => ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            'revenue_by_service' => [],
            'admin_name' => 'Admin',
            'recent_activities' => [],
            'revenue_growth' => 0,
            'patients_growth' => 0
        ];
    }
    
    return $stats;
}

// Get user management table data - LIMITED TO 3 ROWS
function getUserManagementTable($pdo) {
    $html = '';
    try {
        $stmt = $pdo->query("
            SELECT u.userID, u.firstName, u.lastName, u.email, u.userType, u.phone,
                   CASE 
                       WHEN u.userType = 'Patient' THEN 'Active'
                       WHEN u.userType = 'Doctor' THEN 'Active'
                       ELSE 'Active'
                   END as status
            FROM User u
            ORDER BY u.createdAt DESC
            LIMIT 3
        ");
        
        while ($row = $stmt->fetch()) {
            $statusClass = $row['status'] == 'Active' ? 'bg-success' : 'bg-secondary';
            $html .= "
            <tr class='table-row'>
                <td>{$row['firstName']} {$row['lastName']}</td>
                <td>{$row['email']}</td>
                <td><span class='badge bg-primary'>{$row['userType']}</span></td>
                <td><span class='badge {$statusClass}'>{$row['status']}</span></td>
                <td>
                    <button class='btn btn-sm btn-outline-primary btn-action' title='Edit'><i class='fas fa-edit'></i></button>
                    <button class='btn btn-sm btn-outline-danger btn-action' title='Delete'><i class='fas fa-trash'></i></button>
                    <button class='btn btn-sm btn-outline-info btn-action' title='View'><i class='fas fa-eye'></i></button>
                </td>
            </tr>";
        }
    } catch (PDOException $e) {
        error_log("Database error in getUserManagementTable: " . $e->getMessage());
        $html = "<tr><td colspan='5' class='text-center text-muted'>Error loading user data</td></tr>";
    }
    
    return $html;
}

// Get recent appointments for quick overview - LIMITED TO 3 ROWS
function getRecentAppointments($pdo) {
    $html = '';
    try {
        $stmt = $pdo->query("
            SELECT a.appointmentID, CONCAT(pu.firstName, ' ', pu.lastName) as patient_name,
                   CONCAT(du.firstName, ' ', du.lastName) as doctor_name,
                   a.appointmentDate, a.appointmentTime, a.status
            FROM Appointments a
            JOIN Patient pt ON a.patientID = pt.patientID
            JOIN User pu ON pt.userID = pu.userID
            JOIN Doctor d ON a.doctorID = d.doctorID
            JOIN User du ON d.userID = du.userID
            ORDER BY a.appointmentDate DESC, a.appointmentTime DESC
            LIMIT 3
        ");
        
        while ($row = $stmt->fetch()) {
            $statusClass = $row['status'] == 'booked' ? 'bg-primary' : 
                          ($row['status'] == 'completed' ? 'bg-success' : 
                          ($row['status'] == 'cancelled' ? 'bg-danger' : 'bg-warning'));
            $html .= "
            <tr class='table-row'>
                <td>#{$row['appointmentID']}</td>
                <td>{$row['patient_name']}</td>
                <td>{$row['doctor_name']}</td>
                <td><span class='badge {$statusClass}'>{$row['status']}</span></td>
            </tr>";
        }
    } catch (PDOException $e) {
        error_log("Database error in getRecentAppointments: " . $e->getMessage());
        $html = "<tr><td colspan='4' class='text-center text-muted'>Error loading appointments</td></tr>";
    }
    
    return $html;
}

// Get recent payments for quick overview - LIMITED TO 3 ROWS
function getRecentPayments($pdo) {
    $html = '';
    try {
        $stmt = $pdo->query("
            SELECT p.paymentID, CONCAT(u.firstName, ' ', u.lastName) as patient_name, 
                   ms.serviceName, p.amount, p.status, p.paymentDate
            FROM Payments p
            JOIN Patient pt ON p.patientID = pt.patientID
            JOIN User u ON pt.userID = u.userID
            JOIN MedicalService ms ON p.serviceID = ms.serviceID
            ORDER BY p.paymentDate DESC
            LIMIT 3
        ");
        
        while ($row = $stmt->fetch()) {
            $statusClass = $row['status'] == 'paid' ? 'bg-success' : 
                          ($row['status'] == 'pending' ? 'bg-warning' : 'bg-danger');
            $formattedDate = date('M j, Y', strtotime($row['paymentDate']));
            $html .= "
            <tr class='table-row'>
                <td>#{$row['paymentID']}</td>
                <td>{$row['patient_name']}</td>
                <td>{$row['serviceName']}</td>
                <td>R" . number_format($row['amount'], 2) . "</td>
                <td><span class='badge {$statusClass}'>{$row['status']}</span></td>
                <td>{$formattedDate}</td>
            </tr>";
        }
    } catch (PDOException $e) {
        error_log("Database error in getRecentPayments: " . $e->getMessage());
        $html = "<tr><td colspan='6' class='text-center text-muted'>Error loading payments</td></tr>";
    }
    
    return $html;
}

$stats = getDashboardStats($pdo);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Dokotela</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        /* Your existing CSS remains exactly the same */
        :root {
            --blue-1: #0f4d92;
            --blue-2: #1CA9C9;
            --pastel: #E6F6FF;
            --bright-red: #ff2d55;
            --success-color: #10b981;
            --muted: #64748b;
            --bg: #f6fbff;
            --card-bg: rgba(255,255,255,0.85);
            --glass-border: rgba(255,255,255,0.35);
            --shadow: 0 6px 18px rgba(16,24,40,0.08);
            --radius: 12px;
            --glass-blur: 8px;
            --text-dark: #0f1724;
            --text-muted: #475569;
            --gap: 1.5rem;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html, body {
            height: 100%;
            font-family: "Segoe UI", system-ui, -apple-system, "Helvetica Neue", Arial;
            background: #f1f8ff;
            background: radial-gradient(circle at top left, #e6f6ff 0%, #f1f8ff 100%);
            color: var(--text-dark);
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
            transition: all 0.3s ease;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, rgba(255,255,255,0.7), rgba(246,249,255,0.55));
            padding: 1rem;
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
            align-items: stretch;
            box-shadow: var(--shadow);
            border-right: 1px solid var(--glass-border);
            backdrop-filter: blur(6px);
            -webkit-backdrop-filter: blur(6px);
            transition: width 0.28s cubic-bezier(.22,.9,.36,1);
            position: sticky;
            top: 0;
            height: 100vh;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.6rem 0.6rem;
        }

        .logo-mark {
            width: 44px;
            height: 44px;
            border-radius: 10px;
            display: grid;
            place-items: center;
            color: white;
            background: linear-gradient(135deg, var(--blue-1), var(--blue-2));
            box-shadow: 0 6px 18px rgba(15,77,146,0.18);
            font-weight: 700;
            font-size: 1.05rem;
        }

        .sidebar-header h4 {
            color: var(--blue-1);
            font-size: 1.05rem;
            font-weight: 700;
        }

        .sidebar-nav {
            display: flex;
            flex-direction: column;
            gap: 6px;
            padding: 0.5rem 0;
            width: 100%;
        }

        .nav-btn {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: transparent;
            border: none;
            padding: 0.6rem 0.8rem;
            border-radius: 10px;
            cursor: pointer;
            color: var(--text-muted);
            font-size: 0.95rem;
            transition: all 0.18s ease;
            text-decoration: none;
        }

        .nav-btn .fa-fw {
            width: 20px;
            text-align: center;
        }

        .nav-btn:hover {
            transform: translateY(-2px);
            color: var(--blue-1);
            background: rgba(15,77,146,0.04);
        }

        .nav-btn.active {
            background: linear-gradient(90deg, rgba(15,77,146,0.06), rgba(28,169,201,0.03));
            color: var(--blue-1);
            border-left: 3px solid var(--blue-2);
        }

        /* Main Content */
        .main-content {
            flex: 1;
            padding: var(--gap);
            animation: fadeIn 0.8s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .main-header {
            margin-bottom: var(--gap);
            animation: slideDown 0.5s ease-out;
        }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .page-title {
            font-size: 2.2rem;
            font-weight: 700;
            color: var(--blue-1);
            background: linear-gradient(135deg, var(--blue-1), var(--blue-2));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin: 0;
        }

        .admin-info {
            display: flex;
            align-items: center;
            gap: 1rem;
            background: var(--card-bg);
            padding: 1rem 1.5rem;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(var(--glass-blur));
        }

        .admin-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--blue-1), var(--blue-2));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2rem;
            box-shadow: 0 4px 12px rgba(15,77,146,0.3);
        }

        /* Stat Cards */
        .stat-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 1.5rem;
            box-shadow: var(--shadow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(var(--glass-blur));
            margin-bottom: var(--gap);
            transition: all 0.3s ease;
            text-align: center;
            height: 100%;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 25px rgba(15, 77, 146, 0.15);
        }

        .stat-icon {
            width: 70px;
            height: 70px;
            margin: 0 auto 1rem;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--blue-1), var(--blue-2));
            box-shadow: 0 4px 12px rgba(15, 77, 146, 0.3);
            display: grid;
            place-items: center;
            animation: pulse 2s infinite ease-out;
        }

        @keyframes pulse {
            0% { box-shadow: 0 4px 12px rgba(15, 77, 146, 0.3); }
            50% { box-shadow: 0 4px 20px rgba(15, 77, 146, 0.5); }
            100% { box-shadow: 0 4px 12px rgba(15, 77, 146, 0.3); }
        }

        .stat-icon i {
            color: white;
            font-size: 1.8rem;
        }

        .stat-number {
            font-size: 2.2rem;
            font-weight: bold;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }

        .stat-label {
            color: var(--text-muted);
            font-size: 0.95rem;
            margin-bottom: 0.5rem;
        }

        .stat-change {
            font-size: 0.85rem;
        }

        .stat-change.positive {
            color: var(--success-color);
        }

        .stat-change.negative {
            color: var(--bright-red);
        }

        /* Dashboard Cards */
        .dashboard-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 1.5rem;
            box-shadow: var(--shadow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(var(--glass-blur));
            margin-bottom: var(--gap);
            transition: all 0.3s ease;
            overflow: hidden;
        }

        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 25px rgba(15, 77, 146, 0.15);
        }

        .dashboard-card .card-header {
            background: transparent;
            border-bottom: 1px solid rgba(15,77,146,0.1);
            padding: 0 0 1rem 0;
            margin-bottom: 1rem;
        }

        .dashboard-card h5 {
            color: var(--blue-1);
            font-weight: 600;
            margin: 0;
        }

        .dashboard-card h5 i {
            margin-right: 0.5rem;
            color: var(--blue-2);
        }

        /* Tables */
        .table {
            margin-bottom: 0;
        }

        .table th {
            border-top: none;
            font-weight: 600;
            color: var(--text-dark);
            background-color: rgba(15,77,146,0.05);
        }

        .table-row {
            transition: all 0.2s ease;
        }

        .table-row:hover {
            background-color: rgba(15,77,146,0.03);
        }

        .badge {
            border-radius: 6px;
            font-weight: 600;
            padding: 0.4em 0.6em;
        }

        /* Compact table styling */
        .compact-table {
            font-size: 0.875rem;
        }
        
        .compact-table th,
        .compact-table td {
            padding: 0.5rem 0.75rem;
        }

        /* Buttons */
        .btn {
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.2s ease;
        }

        .btn-primary {
            background: var(--blue-1);
            border-color: var(--blue-1);
            color: white;
            box-shadow: 0 4px 10px rgba(15, 77, 146, 0.2);
        }

        .btn-primary:hover {
            background: var(--blue-2);
            border-color: var(--blue-2);
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(28, 169, 201, 0.3);
        }

        .btn-outline-primary {
            color: var(--blue-1);
            border-color: var(--blue-1);
        }

        .btn-outline-primary:hover {
            background: var(--blue-1);
            border-color: var(--blue-1);
        }

        .btn-action {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border-radius: 8px;
            margin: 0 2px;
            transition: all 0.2s ease;
        }

        /* Chart Containers */
        .chart-container {
            position: relative;
            height: 250px;
            width: 100%;
        }

        .chart-controls {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1rem;
        }

        .chart-controls .btn {
            padding: 0.25rem 0.75rem;
            font-size: 0.8rem;
        }

        .slide-up {
            animation: slideUp 0.5s ease-out;
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .fade-in {
            animation: fadeIn 0.5s ease-out;
        }

        /* Empty States */
        .empty-state {
            text-align: center;
            padding: 2rem;
            color: var(--text-muted);
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--blue-2);
        }

        /* Activity Feed */
        .activity-item {
            display: flex;
            align-items: flex-start;
            gap: 1rem;
            padding: 0.75rem 0;
            border-bottom: 1px solid rgba(15,77,146,0.1);
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 0.9rem;
            flex-shrink: 0;
        }

        .activity-icon.appointment {
            background: linear-gradient(135deg, var(--blue-1), var(--blue-2));
        }

        .activity-icon.payment {
            background: linear-gradient(135deg, #10b981, #059669);
        }

        .activity-icon.user {
            background: linear-gradient(135deg, #f59e0b, #d97706);
        }

        .activity-content {
            flex: 1;
        }

        .activity-time {
            font-size: 0.75rem;
            color: var(--text-muted);
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="logo-mark">DK</div>
                <h4>Dokotela</h4>
            </div>
            <div class="sidebar-nav">
                <a href="admin_dashboard.php" class="nav-btn active">
                    <i class="fas fa-tachometer-alt fa-fw"></i>
                    <span>Dashboard</span>
                </a>
                <a href="admin_users.php" class="nav-btn">
                    <i class="fas fa-users fa-fw"></i>
                    <span>User Management</span>
                </a>
                <a href="admin_appointments.php" class="nav-btn">
                    <i class="fas fa-calendar-alt fa-fw"></i>
                    <span>Appointments</span>
                </a>
                <a href="admin_doctors.php" class="nav-btn">
                    <i class="fas fa-user-md fa-fw"></i>
                    <span>Doctors</span>
                </a>
                <a href="admin_payments.php" class="nav-btn">
                    <i class="fas fa-money-bill-wave fa-fw"></i>
                    <span>Payments</span>
                </a>
                <a href="admin_services.php" class="nav-btn">
                    <i class="fas fa-concierge-bell fa-fw"></i>
                    <span>Services</span>
                </a>
                <a href="admin_notifications.php" class="nav-btn">
                    <i class="fas fa-bell fa-fw"></i>
                    <span>Notifications</span>
                </a>
                <a href="admin_support.php" class="nav-btn">
                    <i class="fas fa-headset fa-fw"></i>
                    <span>Support Tickets</span>
                </a>
                <a href="admin_announcements.php" class="nav-btn">
                    <i class="fas fa-bullhorn fa-fw"></i>
                    <span>Announcements</span>
                </a>
                <a href="admin_settings.php" class="nav-btn">
                    <i class="fas fa-cogs fa-fw"></i>
                    <span>Settings</span>
                </a>
                <a href="../auth/logout.php" class="nav-btn">
                    <i class="fas fa-sign-out-alt fa-fw"></i>
                    <span>Logout</span>
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="main-header d-flex justify-content-between align-items-center">
                <h1 class="page-title">Admin Dashboard</h1>
                <div class="admin-info">
                    <div class="admin-avatar">
                        <i class="fas fa-user-shield"></i>
                    </div>
                    <div>
                        <h5 class="mb-0"><?php echo $stats['admin_name']; ?></h5>
                        <small class="text-muted">Administrator</small>
                    </div>
                </div>
            </div>

            <!-- Analytics Overview -->
            <div class="row">
                <div class="col-xl-3 col-md-6">
                    <div class="stat-card slide-up">
                        <div class="stat-icon">
                            <i class="fas fa-user-injured"></i>
                        </div>
                        <div class="stat-number"><?php echo $stats['total_patients']; ?></div>
                        <div class="stat-label">Total Patients</div>
                        <div class="stat-change <?php echo $stats['patients_growth'] >= 0 ? 'positive' : 'negative'; ?>">
                            <i class="fas fa-<?php echo $stats['patients_growth'] >= 0 ? 'arrow-up' : 'arrow-down'; ?>"></i>
                            <?php echo abs($stats['patients_growth']); ?>% this month
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="stat-card slide-up" style="animation-delay: 0.1s">
                        <div class="stat-icon">
                            <i class="fas fa-user-md"></i>
                        </div>
                        <div class="stat-number"><?php echo $stats['total_doctors']; ?></div>
                        <div class="stat-label">Active Doctors</div>
                        <div class="stat-change positive">
                            <i class="fas fa-check-circle"></i>
                            All systems operational
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="stat-card slide-up" style="animation-delay: 0.2s">
                        <div class="stat-icon">
                            <i class="fas fa-calendar-check"></i>
                        </div>
                        <div class="stat-number"><?php echo $stats['appointments_today']; ?></div>
                        <div class="stat-label">Today's Appointments</div>
                        <div class="stat-change positive">
                            <i class="fas fa-calendar"></i>
                            <?php echo $stats['appointments_week']; ?> this week
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="stat-card slide-up" style="animation-delay: 0.3s">
                        <div class="stat-icon">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <div class="stat-number">R<?php echo number_format($stats['total_revenue'], 0); ?></div>
                        <div class="stat-label">Total Revenue</div>
                        <div class="stat-change <?php echo $stats['revenue_growth'] >= 0 ? 'positive' : 'negative'; ?>">
                            <i class="fas fa-<?php echo $stats['revenue_growth'] >= 0 ? 'arrow-up' : 'arrow-down'; ?>"></i>
                            <?php echo abs($stats['revenue_growth']); ?>% this month
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts and Quick Stats -->
            <div class="row">
                <!-- Appointments Chart -->
                <div class="col-lg-8">
                    <div class="dashboard-card slide-up">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><i class="fas fa-chart-line"></i>Appointments Trend (Last 6 Months)</h5>
                            <div class="chart-controls">
                                <button class="btn btn-sm btn-outline-primary" onclick="updateChart('6M')">6M</button>
                                <button class="btn btn-sm btn-outline-primary" onclick="updateChart('3M')">3M</button>
                                <button class="btn btn-sm btn-outline-primary active" onclick="updateChart('1M')">1M</button>
                            </div>
                        </div>
                        <div class="chart-container">
                            <canvas id="appointmentsChart"></canvas>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Activity -->
                <div class="col-lg-4">
                    <div class="dashboard-card slide-up">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><i class="fas fa-bell"></i>Recent Activity</h5>
                        </div>
                        <div class="activity-feed">
                            <?php if (!empty($stats['recent_activities'])): ?>
                                <?php foreach ($stats['recent_activities'] as $activity): ?>
                                    <div class="activity-item">
                                        <div class="activity-icon <?php echo $activity['type']; ?>">
                                            <i class="fas fa-<?php 
                                                echo $activity['type'] == 'appointment' ? 'calendar-check' : 
                                                    ($activity['type'] == 'payment' ? 'money-bill-wave' : 'user-plus'); 
                                            ?>"></i>
                                        </div>
                                        <div class="activity-content">
                                            <div class="activity-description"><?php echo htmlspecialchars($activity['description']); ?></div>
                                            <div class="activity-time"><?php echo date('M j, g:i A', strtotime($activity['date'])); ?></div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="empty-state">
                                    <i class="fas fa-bell-slash"></i>
                                    <p>No recent activity</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Overview Tables -->
            <div class="row">
                <!-- Recent Appointments -->
                <div class="col-lg-6">
                    <div class="dashboard-card slide-up">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><i class="fas fa-clock"></i>Recent Appointments</h5>
                            <a href="admin_appointments.php" class="btn btn-sm btn-outline-primary">View All</a>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover compact-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Patient</th>
                                        <th>Doctor</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php echo getRecentAppointments($pdo); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Recent Payments -->
                <div class="col-lg-6">
                    <div class="dashboard-card slide-up">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><i class="fas fa-money-bill-wave"></i>Recent Payments</h5>
                            <a href="admin_payments.php" class="btn btn-sm btn-outline-primary">View All</a>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover compact-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Patient</th>
                                        <th>Service</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php echo getRecentPayments($pdo); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- User Management -->
            <div class="row">
                <div class="col-12">
                    <div class="dashboard-card slide-up">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><i class="fas fa-users"></i>User Management</h5>
                            <a href="admin_users.php" class="btn btn-sm btn-outline-primary">View All</a>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover compact-table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Role</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php echo getUserManagementTable($pdo); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        let appointmentsChart;
        let currentChartRange = '6M';

        // Initialize charts
        document.addEventListener('DOMContentLoaded', function() {
            initializeAppointmentsChart();
        });

        function initializeAppointmentsChart() {
            const appointmentsCtx = document.getElementById('appointmentsChart').getContext('2d');
            
            const data = {
                labels: <?php echo json_encode($stats['monthly_appointments_labels']); ?>,
                datasets: [{
                    label: 'Appointments',
                    data: <?php echo json_encode($stats['monthly_appointments_data']); ?>,
                    borderColor: '#0f4d92',
                    backgroundColor: 'rgba(15, 77, 146, 0.1)',
                    tension: 0.4,
                    fill: true,
                    borderWidth: 3,
                    pointBackgroundColor: '#0f4d92',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 5,
                    pointHoverRadius: 7
                }]
            };

            appointmentsChart = new Chart(appointmentsCtx, {
                type: 'line',
                data: data,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            backgroundColor: 'rgba(15, 77, 146, 0.8)',
                            titleColor: '#ffffff',
                            bodyColor: '#ffffff',
                            borderColor: '#0f4d92',
                            borderWidth: 1,
                            callbacks: {
                                label: function(context) {
                                    return `Appointments: ${context.parsed.y}`;
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                drawBorder: false,
                                color: 'rgba(15, 77, 146, 0.1)'
                            },
                            ticks: {
                                color: '#475569',
                                precision: 0
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            },
                            ticks: {
                                color: '#475569'
                            }
                        }
                    },
                    interaction: {
                        intersect: false,
                        mode: 'index'
                    },
                    animation: {
                        duration: 1000,
                        easing: 'easeOutQuart'
                    }
                }
            });
        }

        function updateChart(range) {
            currentChartRange = range;
            
            // Update active button state
            document.querySelectorAll('.chart-controls .btn').forEach(btn => {
                btn.classList.remove('active');
            });
            event.target.classList.add('active');

            // Simulate data filtering based on range
            const originalData = <?php echo json_encode($stats['monthly_appointments_data']); ?>;
            const originalLabels = <?php echo json_encode($stats['monthly_appointments_labels']); ?>;
            
            let filteredData, filteredLabels;
            
            switch(range) {
                case '1M':
                    filteredData = originalData.slice(-1);
                    filteredLabels = originalLabels.slice(-1);
                    break;
                case '3M':
                    filteredData = originalData.slice(-3);
                    filteredLabels = originalLabels.slice(-3);
                    break;
                case '6M':
                default:
                    filteredData = originalData;
                    filteredLabels = originalLabels;
                    break;
            }

            // Update chart data with animation
            appointmentsChart.data.labels = filteredLabels;
            appointmentsChart.data.datasets[0].data = filteredData;
            appointmentsChart.update('active');
        }

        // Add animation delays to cards
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.slide-up');
            cards.forEach((card, index) => {
                card.style.animationDelay = `${index * 0.1}s`;
            });
        });

        // Simple notification system for actions
        function showNotification(message, type = 'success') {
            const alert = document.createElement('div');
            alert.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
            alert.style.cssText = 'top: 20px; right: 20px; z-index: 1050; min-width: 300px;';
            alert.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'} me-2"></i>
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            document.body.appendChild(alert);
            
            setTimeout(() => {
                if (alert.parentNode) {
                    alert.remove();
                }
            }, 5000);
        }

        // Example of button actions
        document.addEventListener('click', function(e) {
            if (e.target.closest('.btn-outline-primary')) {
                showNotification('Edit action triggered', 'info');
            }
            if (e.target.closest('.btn-outline-danger')) {
                if (confirm('Are you sure you want to delete this item?')) {
                    showNotification('Item deleted successfully', 'success');
                }
            }
            if (e.target.closest('.btn-outline-info')) {
                showNotification('View details action', 'info');
            }
        });

        // Auto-refresh dashboard every 5 minutes
        setInterval(() => {
            // You can add auto-refresh logic here if needed
            console.log('Dashboard auto-refresh check');
        }, 300000);
    </script>
</body>
</html>