<?php
// admin_payments.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if admin is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

// Create database connection
try {
    // NOTE: Hardcoding credentials is a security risk. Use a config file or environment variables.
    $host = 'sql206.byetcluster.com';
    $dbname = 'if0_40031860_dok';
    $username = 'if0_40031860';
    $password = "qzJkHEejybefK";

    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// --- Action Handlers (Mark as Paid) ---
if (isset($_GET['action']) && $_GET['action'] === 'mark_paid' && isset($_GET['id'])) {
    $paymentID = $_GET['id'];
    try {
        $stmt = $pdo->prepare("UPDATE Payments SET status = 'paid', paymentDate = NOW() WHERE paymentID = ? AND status != 'paid'");
        $stmt->execute([$paymentID]);
        // Redirect to clear the GET parameters after success
        header("Location: admin_payments.php?success=paid&id=$paymentID");
        exit();
    } catch (PDOException $e) {
        // Handle error
        $error = "Failed to mark payment $paymentID as paid.";
    }
}

// --- Filtering and Pagination Parameters ---
$searchTerm = $_GET['search'] ?? '';
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';

// Pagination
$limit = 10;
$page = isset($_GET['p']) ? (int)$_GET['p'] : 1;
$offset = ($page - 1) * $limit;

// --- Build WHERE Clause and Parameters ---
$whereClauses = [];
$params = [];

// 1. Search Condition
if (!empty($searchTerm)) {
    // Check if the search term is a number (for Invoice ID)
    if (is_numeric($searchTerm)) {
        // Search by paymentID (Invoice ID)
        $whereClauses[] = "p.paymentID = :paymentID";
        $params[':paymentID'] = (int)$searchTerm;
    } else {
        // Search by patient name, service name, or status
        $whereClauses[] = "
            (CONCAT(u.firstName, ' ', u.lastName) LIKE :searchTerm
            OR ms.serviceName LIKE :searchTerm
            OR p.status LIKE :searchTerm)
        ";
        $params[':searchTerm'] = '%' . $searchTerm . '%';
    }
}

// 2. Date Range Condition (p.createdAt is used as the date reference)
if (!empty($startDate)) {
    $whereClauses[] = "DATE(p.createdAt) >= :startDate";
    $params[':startDate'] = $startDate;
}
if (!empty($endDate)) {
    $whereClauses[] = "DATE(p.createdAt) <= :endDate";
    $params[':endDate'] = $endDate;
}

$whereCondition = count($whereClauses) > 0 ? "WHERE " . implode(" AND ", $whereClauses) : "";

// --- Count Total Records (for pagination) ---
$countSql = "
    SELECT COUNT(p.paymentID)
    FROM Payments p
    JOIN Appointments a ON p.appointmentID = a.appointmentID
    JOIN Patient pt ON p.patientID = pt.patientID
    JOIN User u ON pt.userID = u.userID
    JOIN MedicalService ms ON p.serviceID = ms.serviceID
    $whereCondition
";
$countStmt = $pdo->prepare($countSql);
$countStmt->execute($params);
$totalRecords = $countStmt->fetchColumn();
$totalPages = ceil($totalRecords / $limit);


// --- Fetch Payments (with filters and pagination) ---
$sql = "
    SELECT p.paymentID,
           CONCAT(u.firstName, ' ', u.lastName) as patient_name,
           ms.serviceName,
           p.amount,
           p.paymentMethod,
           p.status,
           p.paymentDate,
           p.createdAt,
           a.appointmentID
    FROM Payments p
    JOIN Appointments a ON p.appointmentID = a.appointmentID
    JOIN Patient pt ON p.patientID = pt.patientID
    JOIN User u ON pt.userID = u.userID
    JOIN MedicalService ms ON p.serviceID = ms.serviceID
    $whereCondition
    ORDER BY p.createdAt DESC
    LIMIT :limit OFFSET :offset
";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

// Bind dynamic parameters
foreach ($params as $key => &$value) {
    $stmt->bindParam($key, $value);
}
unset($value); // Unset the reference

$stmt->execute();
$payments = $stmt->fetchAll();

// Calculate totals (without search/date filter, for KPI cards)
$totalRevenue = $pdo->query("SELECT SUM(amount) as total FROM Payments WHERE status = 'paid'")->fetch()['total'] ?? 0;
$pendingAmount = $pdo->query("SELECT SUM(amount) as total FROM Payments WHERE status = 'pending'")->fetch()['total'] ?? 0;
$totalTransactions = $pdo->query("SELECT COUNT(*) as total FROM Payments")->fetch()['total'] ?? 0;

// Set initial sidebar state (for this page's appearance)
$sidebarClass = 'sidebar'; // or 'sidebar collapsed'

// Function to get status badge class
function getStatusBadgeClass($status) {
    switch (strtolower($status)) {
        case 'paid':
            return 'success';
        case 'pending':
            return 'warning';
        case 'cancelled':
            return 'danger';
        default:
            return 'secondary';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payments - Dokotela Admin</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style>
        /* --- START OF INTEGRATED CSS TEMPLATE --- */
        :root{
            --blue-1: #0f4d92;
            --blue-2: #1CA9C9;
            --pastel: #E6F6FF;
            --bright-red: #ff2d55;
            --muted: #64748b;
            --bg: #f6fbff;
            --card-bg: rgba(255,255,255,0.75);
            --glass-border: rgba(255,255,255,0.35);
            --shadow: 0 6px 18px rgba(16,24,40,0.08);
            --radius: 12px;
            --glass-blur: 8px;
            --text-dark: #0f1724;
            --text-muted: #475569;
            --gap: 1rem;
        }
        *{box-sizing:border-box;margin:0;padding:0}
        html,body{height:100%}
        body{
            font-family: "Segoe UI", system-ui, -apple-system, "Helvetica Neue", Arial;
            background: #f1f8ff;
            background: radial-gradient(circle at top left, #e6f6ff 0%, #f1f8ff 100%);
            color: var(--text-dark);
        }
        .container-fluid, .row {
            padding: 0;
            margin: 0;
            width: 100%;
        }

        .dashboard-container{
            display:flex;
            min-height:100vh;
            gap:var(--gap);
            transition: all 0.3s ease;
        }
        .sidebar{
            width:260px;
            background: linear-gradient(180deg, rgba(255,255,255,0.7), rgba(246,249,255,0.55));
            border-radius: calc(var(--radius) + 4px);
            padding:1rem;
            display:flex;
            flex-direction:column;
            gap:0.75rem;
            align-items:stretch;
            box-shadow: var(--shadow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(6px);
            transition: width 0.28s cubic-bezier(.22,.9,.36,1), transform 0.3s ease;
            position: sticky;
            top: 0;
            height: 100vh;
        }
        .sidebar.collapsed{ width:72px; padding:0.6rem; align-items:center }
        .sidebar.collapsed .sidebar-header h2,
        .sidebar.collapsed .nav-text,
        .sidebar.collapsed .profile-info { display:none }
        .sidebar.collapsed .nav-btn { justify-content:center }
        .sidebar-header{
            display:flex;
            align-items:center;
            gap:0.75rem;
            padding:0.6rem 0.6rem;
        }
        .logo-mark{
            width:44px;height:44px;border-radius:10px;
            display:grid;place-items:center;color:white;
            background: linear-gradient(135deg,var(--blue-1),var(--blue-2));
            box-shadow: 0 6px 18px rgba(15,77,146,0.18);
            font-weight:700;
            font-size:1.05rem;
        }
        .sidebar-header h2{ color:var(--blue-1); font-size:1.05rem; font-weight:700; }
        .sidebar-nav{
            display:flex;flex-direction:column;gap:6px;padding:0.5rem 0;
            width:100%;
        }
        .nav-btn{
            display:flex;align-items:center;gap:0.75rem;
            background:transparent;border:none;padding:0.6rem 0.8rem;border-radius:10px;
            cursor:pointer;color:var(--text-muted);font-size:0.95rem;transition: all 0.18s ease;
            text-decoration:none;
        }
        .nav-btn .fa-fw{ width:20px; text-align:center }
        .nav-btn:hover{ transform:translateY(-2px); color:var(--blue-1); background: rgba(15,77,146,0.04) }
        .nav-btn.active{
            background: linear-gradient(90deg, rgba(15,77,146,0.06), rgba(28,169,201,0.03));
            color:var(--blue-1);
            border-left: 3px solid var(--blue-2);
        }
        .nav-text{ flex:1 }
        .user-profile{
            margin-top:auto;display:flex;align-items:center;gap:0.75rem;padding:0.6rem;border-radius:10px;
            background: linear-gradient(180deg, rgba(255,255,255,0.35), rgba(255,255,255,0.2));
            border: 1px solid rgba(255,255,255,0.25);
            backdrop-filter: blur(4px);
        }
        .user-profile img{ width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid white; box-shadow: 0 6px 14px rgba(16,24,40,0.06) }
        .profile-info h4{ font-size:0.95rem; margin-bottom:2px }
        .profile-info span{ font-size:0.82rem; color:var(--text-muted) }
        .main-content{
            flex:1;padding:1.5rem;overflow:auto;
        }
        .topbar{
            display:flex;align-items:center;justify-content:space-between;gap:1rem;margin-bottom:1.25rem;
        }
        .topbar-left{
            display:flex;align-items:center;gap:1rem;
        }
        .hamburger{
            background:transparent;border:none;padding:0.5rem;cursor:pointer;color:var(--text-muted);
            border-radius:6px;transition:all 0.2s ease;
        }
        .hamburger:hover{background:rgba(15,77,146,0.06);color:var(--blue-1);}

        .page-title {
            font-size: 1.6rem;
            font-weight: 700;
            color: var(--text-dark);
        }

        .grid{
            display:grid;
            grid-template-columns: repeat(12, 1fr);
            gap:1rem;
            margin-top:1rem;
        }
        .card{
            background: var(--card-bg);
            border-radius: var(--radius);
            padding:1rem;
            box-shadow: var(--shadow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(var(--glass-blur));
        }
        .stats-grid{ grid-column: span 12; display:grid; grid-template-columns: repeat(3,1fr); gap:1rem; }
        .stat-card{
            background: var(--card-bg);
            border-radius: var(--radius);
            padding:1rem;
            box-shadow: var(--shadow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(var(--glass-blur));
            
            display:flex; align-items:center; gap:0.9rem;
        }
        .stat-icon{ font-size:1.75rem; background: linear-gradient(180deg, rgba(255,255,255,0.8), rgba(255,255,255,0.6)); padding:0.6rem; border-radius:10px;}
        .stat-info .stat-value{ font-size:1.45rem; color:var(--blue-1); font-weight:700 }
        .stat-info .stat-label{ color:var(--text-muted); font-size:0.9rem }

        .btn{ display:inline-flex; align-items:center; justify-content:center; gap:0.5rem; padding:0.55rem 0.9rem; border-radius:10px; border:none; cursor:pointer; font-weight:600; text-decoration:none; transition: all 0.2s ease; }
        .btn-sm { padding: 0.4rem; font-size: 0.85rem; width: 34px; height: 34px; border-radius: 8px;}
        .btn-primary{ background: linear-gradient(90deg,var(--blue-1),var(--blue-2)); color:white }
        .btn-ghost{ background:transparent; color:var(--text-dark); border:1px solid rgba(15,77,146,0.06) }
        .btn-danger{ background:var(--bright-red); color:white }
        .btn-secondary{
            background: linear-gradient(90deg, rgba(28,169,201,0.1), rgba(15,77,146,0.1));
            color: var(--blue-1);
            border: 1px solid rgba(15,77,146,0.2);
        }
        .btn-view {
            background: rgba(28,169,201,0.15);
            color: var(--blue-2);
        }
        .btn-view:hover {
            background: rgba(28,169,201,0.3);
            box-shadow: 0 2px 8px rgba(28,169,201,0.3);
        }
        .btn-paid {
            background: rgba(16, 185, 129, 0.15);
            color: #10b981;
        }
        .btn-paid:hover {
            background: rgba(16, 185, 129, 0.3);
            box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3);
        }
        .btn-invoice {
            background: rgba(15,77,146,0.15);
            color: var(--blue-1);
        }
        .btn-invoice:hover {
            background: rgba(15,77,146,0.3);
            box-shadow: 0 2px 8px rgba(15,77,146,0.3);
        }

        /* Modal Styling */
        .modal{ 
            position:fixed; 
            inset:0; 
            z-index:1200; 
            background: rgba(2,6,23,0.45); 
            backdrop-filter: blur(4px);
            display: none; 
            align-items: center; 
            justify-content: center; 
        }
        .modal .modal-content{ 
            background: white; 
            max-width:720px; 
            width: 90%; 
            padding:1.4rem; 
            border-radius:12px; 
            box-shadow: 0 20px 50px rgba(2,6,23,0.25);
            animation: fadeIn 0.3s ease-out; 
        }
        /* Using same animation for generic modal and custom alert modal */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        /* Animation for closing the alert */
        @keyframes fadeOut {
            from { opacity: 1; transform: translateY(0); }
            to { opacity: 0; transform: translateY(20px); }
        }

        /* Custom Confirmation Alert Styling */
        #custom-alert-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(2,6,23,0.45);
            backdrop-filter: blur(4px);
            z-index: 1500;
            display: none;
            align-items: center;
            justify-content: center;
        }
        #custom-alert-box {
            background: white;
            padding: 2rem;
            border-radius: var(--radius);
            box-shadow: 0 10px 30px rgba(15, 77, 146, 0.2);
            max-width: 400px;
            text-align: center;
            /* Note: 'slideUp' animation is replaced by 'fadeIn' for consistency */
        }
        /* Class to trigger close animation */
        #custom-alert-box.closing {
            animation: fadeOut 0.3s ease-in forwards;
        }

        #custom-alert-box h4 {
            color: var(--blue-1);
            margin-bottom: 0.75rem;
        }
        #custom-alert-box p {
            color: var(--text-dark);
            margin-bottom: 1.5rem;
            font-weight: 500; /* Added weight for message clarity */
        }
        /* Styling for the bold text within the message */
        #custom-alert-message b {
            font-weight: 700;
            color: var(--blue-2); /* Highlighted color */
        }

        #custom-alert-box button {
            margin: 0 0.5rem;
            min-width: 100px;
        }
        .btn-confirm { background: var(--blue-1); color: white; }
        .btn-cancel { background: var(--text-muted); color: white; }


        /* Filtering/Search Section */
        .filter-section {
            display: flex;
            align-items: center;
            gap: 15px; /* Increased gap for better spacing */
            margin-bottom: 1rem;
            flex-wrap: wrap;
        }

        .filter-section label {
            font-size: 0.9rem;
            color: var(--text-dark);
            font-weight: 600;
            margin-right: -5px; /* Pull label closer to input */
        }

        .filter-section input[type="date"] {
            padding: 8px 10px;
            border: 1px solid var(--glass-border);
            border-radius: 8px;
            background: var(--card-bg);
            box-shadow: 0 1px 3px rgba(16,24,40,0.05);
            outline: none;
            transition: border-color 0.2s;
            color: var(--text-dark);
            
            /* **CALENDAR STYLING FIXES** */
            height: 40px; 
            font-size: 0.95rem;
            
            -webkit-appearance: none;
            appearance: none;
            
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='%230f4d92' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='4' width='18' height='18' rx='2' ry='2'%3E%3C/rect%3E%3Cline x1='16' y1='2' x2='16' y2='6'%3E%3C/line%3E%3Cline x1='8' y1='2' x2='8' y2='6'%3E%3C/line%3E%3Cline x1='3' y1='10' x2='21' y2='10'%3E%3C/line%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 10px center;
            background-size: 18px 18px;
            padding-right: 35px; /* Make space for the icon */
        }
        
        .filter-section input[type="date"]::-webkit-calendar-picker-indicator {
            opacity: 0;
            position: absolute; 
            width: 30px;
            height: 100%;
            right: 0;
            top: 0;
            cursor: pointer;
        }
        .filter-section input[type="date"]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        .filter-section input[type="date"]:focus {
            border-color: var(--blue-2);
            box-shadow: 0 0 0 3px rgba(28,169,201,0.1);
        }
        
        /* Styling for the search bar input */
        .search-box input[type="text"] {
            padding: 8px 10px;
            border: 1px solid var(--glass-border);
            border-radius: 8px;
            background: var(--card-bg);
            box-shadow: 0 1px 3px rgba(16,24,40,0.05);
            outline: none;
            transition: border-color 0.2s;
            color: var(--text-dark);
        }

        .search-container {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            flex-grow: 1;
        }

        .search-box {
            display: flex;
            align-items: center;
            background: var(--card-bg);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius);
            padding: 0; 
            height: 40px;
            backdrop-filter: blur(var(--glass-blur));
            -webkit-backdrop-filter: blur(var(--glass-blur));
            box-shadow: var(--shadow);
            width: 300px;
        }

        .search-box form {
            display: flex;
            width: 100%;
            align-items: center;
            padding: 0 5px; 
        }
        .search-box input {
            border: none !important; 
            outline: none;
            background: transparent;
            width: 100%;
            font-size: 0.95rem;
            color: var(--text-dark);
            padding: 0 10px; 
            box-shadow: none !important;
            height: 38px;
        }
        .search-box button {
            background: transparent;
            color: var(--blue-1);
            border: none;
            padding: 0 8px;
            cursor: pointer;
            font-size: 1rem;
            box-shadow: none;
            transition: color 0.2s;
        }

        .search-box button:hover {
            color: var(--blue-2);
        }

        /* Status Badges */
        .badge {
            display: inline-flex;
            align-items: center;
            padding: 0.3em 0.6em;
            font-size: 0.85em;
            font-weight: 600;
            line-height: 1;
            color: white;
            text-align: center;
            white-space: nowrap;
            vertical-align: baseline;
            border-radius: 0.375rem;
        }
        .bg-success { background-color: #10b981 !important; }
        .bg-warning { background-color: #f59e0b !important; }
        .bg-danger { background-color: #ef4444 !important; }
        .bg-primary { background-color: #3b82f6 !important; }
        .bg-secondary { background-color: #64748b !important; }

        /* Tables */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        th, td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        th {
            background-color: rgba(15, 77, 146, 0.05);
            font-weight: 600;
            color: var(--blue-1);
        }
        tr:hover {
            background-color: rgba(15, 77, 146, 0.02);
        }

        /* Pagination Styling */
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 1rem;
            gap: 0.5rem;
        }
        .pagination a, .pagination span {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem 0.75rem;
            border-radius: 8px;
            text-decoration: none;
            color: var(--blue-1);
            border: 1px solid rgba(15,77,146,0.1);
            transition: all 0.2s ease;
            background: white;
        }
        .pagination a:hover {
            background: var(--blue-1);
            color: white;
            border-color: var(--blue-1);
        }
        .pagination .current-page {
            background: var(--blue-1);
            color: white;
            font-weight: 600;
            border-color: var(--blue-1);
            cursor: default;
        }
        .pagination .disabled {
            opacity: 0.5;
            cursor: not-allowed;
            background: #f1f5f9;
        }


        @media (max-width: 1000px){
            .stats-grid{ grid-template-columns: repeat(2,1fr) }
        }
        @media (max-width: 720px){
            .dashboard-container{ flex-direction:column; gap:0 }
            .sidebar{ width:100%; flex-direction:row; align-items:center; gap:0.6rem; padding:0.6rem; border-radius:0; height: auto; position:relative; }
            .sidebar.collapsed{ width:100% }
            .sidebar-header h2{ display:none }
            .nav-btn{ padding:0.55rem; font-size:0.9rem }
            .stats-grid{ grid-template-columns: 1fr }
            .main-content{ padding:1rem 0.5rem; }
            .topbar{ flex-direction: column; align-items:flex-start; margin-bottom: 0.5rem; }
            .topbar-left { margin-bottom: 0.5rem; }
            .search-container {
                justify-content: flex-start;
                margin-left: 0;
            }
            .search-box {
                width: 100%;
                max-width: 100%;
            }
            .search-box input {
                width: 100%;
            }
            .filter-section {
                flex-direction: column;
                align-items: stretch;
            }
        }
        /* --- END OF INTEGRATED CSS TEMPLATE --- */
    </style>
</head>
<body>
    <div class="dashboard-container">
        <nav class="<?php echo $sidebarClass; ?>">
            <div class="sidebar-header">
                <div class="logo-mark"><i class="fas fa-stethoscope"></i></div>
                <h2>Dokotela</h2>
            </div>
            <div class="sidebar-nav">
                <a class="nav-btn" href="admin_dashboard.php"><i class="fas fa-tachometer-alt fa-fw"></i><span class="nav-text">Dashboard</span></a>
                <a class="nav-btn" href="admin_users.php"><i class="fas fa-users fa-fw"></i><span class="nav-text">User Management</span></a>
                <a class="nav-btn" href="admin_appointments.php"><i class="fas fa-calendar-alt fa-fw"></i><span class="nav-text">Appointments</span></a>
                <a class="nav-btn" href="admin_doctors.php"><i class="fas fa-user-md fa-fw"></i><span class="nav-text">Doctors</span></a>
                <a class="nav-btn active" href="admin_payments.php"><i class="fas fa-money-bill-wave fa-fw"></i><span class="nav-text">Payments</span></a>
                <a class="nav-btn" href="admin_services.php"><i class="fas fa-concierge-bell fa-fw"></i><span class="nav-text">Services</span></a>
                <a class="nav-btn" href="admin_reports.php"><i class="fas fa-chart-bar fa-fw"></i><span class="nav-text">Reports</span></a>
            </div>
            <div class="user-profile">
                <img src="https://via.placeholder.com/48/0f4d92/FFFFFF?text=A" alt="Admin" />
                <div class="profile-info"><h4>Admin User</h4><span>Administrator</span></div>
            </div>
            <a class="nav-btn" href="../auth/logout.php"><i class="fas fa-sign-out-alt fa-fw"></i><span class="nav-text">Logout</span></a>
        </nav>

        <main class="main-content">
            <div class="topbar">
                <div class="topbar-left">
                    <button class="hamburger" id="sidebar-toggle" title="Toggle Sidebar"><i class="fas fa-bars fa-lg"></i></button>
                    <h1 class="page-title">Payment Management</h1>
                </div>
            </div>

            <?php if (isset($_GET['success'])): ?>
                <div class="card" style="background-color: #d1fae5; color: #065f46; border-color: #a7f3d0; margin-bottom: var(--gap);">
                    <p>✅ Payment INV<?php echo htmlspecialchars($_GET['id']); ?> successfully marked as **<?php echo htmlspecialchars($_GET['success']); ?>**.</p>
                </div>
            <?php endif; ?>
            <?php if (isset($error)): ?>
                <div class="card" style="background-color: #fee2e2; color: #991b1b; border-color: #fecaca; margin-bottom: var(--gap);">
                    <p>❌ Error: <?php echo htmlspecialchars($error); ?></p>
                </div>
            <?php endif; ?>

            <div class="grid stats-grid">
                <div class="card stat-card analytics-kpi">
                    <i class="fas fa-dollar-sign stat-icon" style="color:#10b981;"></i>
                    <div class="stat-info">
                        <div class="stat-value text-success">R<?php echo number_format($totalRevenue, 2); ?></div>
                        <div class="stat-label">Total Revenue</div>
                    </div>
                </div>
                <div class="card stat-card analytics-kpi">
                    <i class="fas fa-hourglass-half stat-icon" style="color:#f59e0b;"></i>
                    <div class="stat-info">
                        <div class="stat-value text-warning">R<?php echo number_format($pendingAmount, 2); ?></div>
                        <div class="stat-label">Pending Amount</div>
                    </div>
                </div>
                <div class="card stat-card analytics-kpi">
                    <i class="fas fa-exchange-alt stat-icon" style="color:var(--blue-1);"></i>
                    <div class="stat-info">
                        <div class="stat-value text-primary"><?php echo number_format($totalTransactions); ?></div>
                        <div class="stat-label">Total Transactions</div>
                    </div>
                </div>
            </div>

            <div class="card" style="grid-column: span 12; margin-top: 1rem;">
                <form method="GET" action="admin_payments.php" class="filter-form">
                    <div style="display: flex; gap: 15px; align-items: center; flex-wrap: wrap;">
                        
                        <div class="search-container" style="flex-grow: 1; max-width: 300px;">
                            <div class="search-box" style="width: 100%;">
                                <input type="text" name="search" placeholder="Search ID, Patient, or Service" value="<?php echo htmlspecialchars($searchTerm); ?>">
                                <button type="submit" title="Search">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>

                        <label for="start_date">From:</label>
                        <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($startDate); ?>">
                        
                        <label for="end_date">To:</label>
                        <input type="date" id="end_date" name="end_date" value="<?php echo htmlspecialchars($endDate); ?>">

                        <button type="submit" class="btn btn-primary" title="Apply Filters" style="height: 40px; margin-left: auto;">
                            <i class="fas fa-filter"></i> Apply
                        </button>
                        <a href="admin_payments.php" class="btn btn-ghost" title="Clear Filters" style="height: 40px;">
                            <i class="fas fa-times"></i> Clear
                        </a>
                    </div>
                </form>
            </div>
            
            <div class="card" style="grid-column: span 12;">
                <h3>Payments (Showing <?php echo count($payments); ?> of <?php echo $totalRecords; ?>)</h3>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Invoice ID</th>
                                <th>Patient</th>
                                <th>Service</th>
                                <th>Amount</th>
                                <th>Method</th>
                                <th>Status</th>
                                <th>Date Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($payments)): ?>
                                <tr>
                                    <td colspan="8" class="placeholder" style="text-align: center;">
                                        No payments found matching your criteria.
                                    </td>
                                </tr>
                            <?php endif; ?>
                            <?php foreach ($payments as $payment): ?>
                            <tr>
                                <td>INV<?php echo str_pad($payment['paymentID'], 3, '0', STR_PAD_LEFT); ?></td>
                                <td><?php echo htmlspecialchars($payment['patient_name']); ?></td>
                                <td><?php echo htmlspecialchars($payment['serviceName']); ?></td>
                                <td>R<?php echo number_format($payment['amount'], 2); ?></td>
                                <td>
                                    <span class="badge bg-secondary">
                                        <?php echo str_replace('_', ' ', ucfirst($payment['paymentMethod'])); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo getStatusBadgeClass($payment['status']); ?>">
                                        <?php echo ucfirst($payment['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M j, Y g:i A', strtotime($payment['createdAt'])); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-view view-details-btn" data-id="<?php echo $payment['paymentID']; ?>" title="View Details">
                                        <i class="fas fa-eye"></i>
                                    </button>

                                    <?php if ($payment['status'] === 'pending'): ?>
                                        <a href="javascript:void(0);" 
                                            class="btn btn-sm btn-paid mark-paid-btn" 
                                            data-id="<?php echo $payment['paymentID']; ?>" 
                                            data-patient="<?php echo htmlspecialchars($payment['patient_name']); ?>"
                                            title="Mark as Paid">
                                            <i class="fas fa-check"></i>
                                        </a>
                                    <?php else: ?>
                                        <button class="btn btn-sm btn-paid" title="Already Paid" disabled style="opacity:0.6; cursor: not-allowed;">
                                            <i class="fas fa-check"></i>
                                        </button>
                                    <?php endif; ?>

                                    <button class="btn btn-sm btn-invoice generate-invoice-btn" data-id="<?php echo $payment['paymentID']; ?>" title="Generate Invoice">
                                        <i class="fas fa-file-invoice"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="pagination">
                    <?php 
                    $params = $_GET; // Get current GET parameters
                    unset($params['p']); // Remove page param for generating new links
                    $queryString = http_build_query($params); // Build query string from remaining params

                    // Previous Page Link
                    $prevPage = $page - 1;
                    $prevDisabled = $page <= 1 ? 'disabled' : '';
                    $prevLink = $page <= 1 ? '#' : '?' . $queryString . '&p=' . $prevPage;
                    echo "<a href=\"$prevLink\" class=\"$prevDisabled\">Prev</a>";

                    // Page links (show a range)
                    $start_loop = max(1, $page - 2);
                    $end_loop = min($totalPages, $page + 2);

                    if ($start_loop > 1) { echo "<a href=\"?" . $queryString . "&p=1\">1</a>"; if ($start_loop > 2) { echo "<span>...</span>"; } }
                    for ($i = $start_loop; $i <= $end_loop; $i++):
                        $activeClass = $i == $page ? 'current-page' : '';
                        echo "<a href=\"?" . $queryString . "&p=$i\" class=\"$activeClass\">$i</a>";
                    endfor;
                    if ($end_loop < $totalPages) { if ($end_loop < $totalPages - 1) { echo "<span>...</span>"; } echo "<a href=\"?" . $queryString . "&p=$totalPages\">$totalPages</a>"; }

                    // Next Page Link
                    $nextPage = $page + 1;
                    $nextDisabled = $page >= $totalPages ? 'disabled' : '';
                    $nextLink = $page >= $totalPages ? '#' : '?' . $queryString . '&p=' . $nextPage;
                    echo "<a href=\"$nextLink\" class=\"$nextDisabled\">Next</a>";
                    ?>
                </div>
            </div>
        </main>
    </div>

    <div class="modal" id="paymentDetailsModal">
        <div class="modal-content">
            <h3 style="color: var(--blue-1);">Payment Details - <span id="modal-payment-id"></span></h3>
            <p><strong>Patient:</strong> <span id="modal-patient-name"></span></p>
            <p><strong>Service:</strong> <span id="modal-service-name"></span></p>
            <p><strong>Amount:</strong> <span id="modal-amount"></span></p>
            <p><strong>Method:</strong> <span id="modal-method"></span></p>
            <p><strong>Status:</strong> <span id="modal-status"></span></p>
            <p><strong>Payment Date:</strong> <span id="modal-date"></span></p>
            <p><strong>Created At:</strong> <span id="modal-created-at"></span></p>
            <button onclick="document.getElementById('paymentDetailsModal').style.display='none'" class="btn btn-secondary" style="margin-top:1rem;">Close</button>
        </div>
    </div>

    <div id="custom-alert-overlay">
        <div id="custom-alert-box">
            <h4>Confirm Action</h4>
            <p id="custom-alert-message"></p>
            <button class="btn btn-sm btn-confirm" id="confirm-yes">Yes, Proceed</button>
            <button class="btn btn-sm btn-cancel" id="confirm-no">Cancel</button>
        </div>
    </div>


    <script>
        // Store PHP data in a JS variable for modal/actions
        const paymentsData = <?php echo json_encode($payments); ?>;
        const paymentsMap = paymentsData.reduce((acc, payment) => {
            acc[payment.paymentID] = payment;
            return acc;
        }, {});

        // --- Core Functions ---
        /**
         * Shows an animated confirmation dialog and waits for user input.
         * The message supports basic HTML for bolding.
         * @param {string} message - The message text.
         * @returns {Promise<boolean>} - Resolves true for 'Yes, Proceed', false for 'Cancel'.
         */
        function customConfirm(message) {
            return new Promise(resolve => {
                const overlay = document.getElementById('custom-alert-overlay');
                const box = document.getElementById('custom-alert-box');
                const messageEl = document.getElementById('custom-alert-message');
                const btnYes = document.getElementById('confirm-yes');
                const btnNo = document.getElementById('confirm-no');

                // Set message (allows simple HTML for bolding, like <b>text</b>)
                messageEl.innerHTML = message;
                
                // Show with animation class
                box.classList.remove('closing');
                overlay.style.display = 'flex';
                box.style.animation = 'fadeIn 0.3s ease-out'; // Apply opening animation

                const confirmAction = () => {
                    // Start closing animation
                    box.style.animation = '';
                    box.classList.add('closing');
                    
                    // Cleanup and resolve after animation finishes
                    setTimeout(() => {
                        overlay.style.display = 'none';
                        box.classList.remove('closing');
                        btnYes.removeEventListener('click', handleYes);
                        btnNo.removeEventListener('click', handleNo);
                        resolve(true);
                    }, 300); // Match CSS fadeOut duration
                };

                const cancelAction = () => {
                    // Start closing animation
                    box.style.animation = '';
                    box.classList.add('closing');

                    // Cleanup and resolve after animation finishes
                    setTimeout(() => {
                        overlay.style.display = 'none';
                        box.classList.remove('closing');
                        btnYes.removeEventListener('click', handleYes);
                        btnNo.removeEventListener('click', handleNo);
                        resolve(false);
                    }, 300); // Match CSS fadeOut duration
                };
                
                const handleYes = () => confirmAction();
                const handleNo = () => cancelAction();

                btnYes.addEventListener('click', handleYes);
                btnNo.addEventListener('click', handleNo);
            });
        }


        // --- Event Listeners ---

        // 1. Sidebar Toggle Script
        document.getElementById('sidebar-toggle').addEventListener('click', function() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('collapsed');
        });

        // 2. View Details Modal Script
        document.querySelectorAll('.view-details-btn').forEach(button => {
            button.addEventListener('click', function() {
                const paymentID = this.getAttribute('data-id');
                const payment = paymentsMap[paymentID];
                const modal = document.getElementById('paymentDetailsModal');

                if (payment) {
                    document.getElementById('modal-payment-id').textContent = 'INV' + payment.paymentID.padStart(3, '0');
                    document.getElementById('modal-patient-name').textContent = payment.patient_name;
                    document.getElementById('modal-service-name').textContent = payment.serviceName;
                    document.getElementById('modal-amount').textContent = 'R' + parseFloat(payment.amount).toFixed(2);
                    document.getElementById('modal-method').textContent = payment.paymentMethod.replace('_', ' ').charAt(0).toUpperCase() + payment.paymentMethod.replace('_', ' ').slice(1);
                    document.getElementById('modal-status').textContent = payment.status.charAt(0).toUpperCase() + payment.status.slice(1);

                    // Handle potentially null/empty dates (e.g., if status is pending)
                    const paymentDate = payment.paymentDate && payment.paymentDate !== '0000-00-00 00:00:00' 
                        ? new Date(payment.paymentDate).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true }) 
                        : 'N/A';
                    
                    const createdAt = payment.createdAt 
                        ? new Date(payment.createdAt).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true }) 
                        : 'N/A';
                    
                    document.getElementById('modal-date').textContent = paymentDate;
                    document.getElementById('modal-created-at').textContent = createdAt;

                    // Show the modal
                    modal.style.display = 'flex'; 
                }
            });
        });

        // Close modal when clicking outside
        document.getElementById('paymentDetailsModal').addEventListener('click', function(e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });

        // 3. Mark as Paid Script (Using animated customConfirm)
        document.querySelectorAll('.mark-paid-btn').forEach(button => {
            button.addEventListener('click', async function(e) {
                e.preventDefault();
                const paymentID = this.getAttribute('data-id');
                const patientName = this.getAttribute('data-patient');
                const invoiceIdPadded = paymentID.padStart(3, '0');

                // Message with HTML bold tags
                const message = `Are you sure you want to mark payment INV<b>${invoiceIdPadded}</b> for <b>${patientName}</b> as PAID? This action cannot be undone.`;

                const confirmed = await customConfirm(message);
                
                if (confirmed) {
                    // Preserve existing query parameters (search, date range, etc.) but clear page number
                    const url = new URL(window.location.href);
                    url.searchParams.set('action', 'mark_paid');
                    url.searchParams.set('id', paymentID);
                    url.searchParams.delete('p'); // Clear pagination
                    
                    window.location.href = url.toString();
                }
            });
        });

        // 4. Generate Invoice Script Placeholder
        document.querySelectorAll('.generate-invoice-btn').forEach(button => {
            button.addEventListener('click', function() {
                const paymentID = this.getAttribute('data-id');
                const payment = paymentsMap[paymentID];
                
                alert(`Generating invoice for INV${paymentID.padStart(3, '0')} (Patient: ${payment.patient_name}).\n\n( this would securely generate and download a PDF invoice.)`);
            });
        });
    </script>
</body>
</html>