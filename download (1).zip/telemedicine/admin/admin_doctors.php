<?php
// admin_doctors.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if admin is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

// Create database connection
try {
    // NOTE: Hardcoding credentials is a security risk. Use a config file or environment variables.
    // Replace with your actual database details
    $host = 'sql206.byetcluster.com';
    $dbname = 'if0_40031860_dok';
    $username = 'if0_40031860';
    $password = "qzJkHEejybefK"; 
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// --- Fetch all Medical Services (for the Add/Edit Modal) ---
$servicesStmt = $pdo->query("SELECT serviceID, serviceName FROM MedicalService ORDER BY serviceName");
$allServices = $servicesStmt->fetchAll(PDO::FETCH_ASSOC);

/**
 * Handles the logic for inserting new services and updating links.
 * This function is critical for the "Add Unlisted Service" feature.
 * @param PDO $pdo The database connection object.
 * @param int $doctorID The ID of the doctor being modified.
 * @param array $selectedServices Array of existing service IDs.
 * @param string $newServiceName Name of the new service to add.
 * @throws PDOException If a database error occurs.
 */
function updateDoctorServices($pdo, $doctorID, $selectedServices, $newServiceName) {
    // 1. Unlink all current services for this doctor
    $stmt = $pdo->prepare("UPDATE MedicalService SET doctorID = NULL WHERE doctorID = ?");
    $stmt->execute([$doctorID]);

    // 2. Add new service if provided
    if (!empty($newServiceName)) {
        // Check if the service already exists (case-insensitive check for simplicity)
        $stmtCheck = $pdo->prepare("SELECT serviceID FROM MedicalService WHERE LOWER(serviceName) = LOWER(?)");
        $stmtCheck->execute([$newServiceName]);
        $existingService = $stmtCheck->fetch(PDO::FETCH_ASSOC);

        if ($existingService) {
            // Service exists, just link it
            $selectedServices[] = $existingService['serviceID'];
        } else {
            // Service does not exist, insert it
            $stmtInsert = $pdo->prepare("INSERT INTO MedicalService (serviceName, description) VALUES (?, 'Service added via Admin Doctors Panel')");
            $stmtInsert->execute([$newServiceName]);
            $newServiceID = $pdo->lastInsertId();
            $selectedServices[] = $newServiceID;
        }
    }

    // 3. Link the final set of selected and new services to the doctor
    if (!empty($selectedServices)) {
        // Ensure unique IDs and cast to int
        $selectedServices = array_unique(array_filter(array_map('intval', $selectedServices)));
        foreach ($selectedServices as $serviceID) {
            $stmt = $pdo->prepare("UPDATE MedicalService SET doctorID = ? WHERE serviceID = ?");
            $stmt->execute([$doctorID, $serviceID]);
        }
    }
}


// --- Handle doctor actions (Add, Edit, Delete) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        try {
            $pdo->beginTransaction();

            switch ($_POST['action']) {
                case 'delete_doctor':
                    $doctorID = intval($_POST['doctor_id']);
                    // Clean up service links first (if not cascaded) and delete
                    $stmt = $pdo->prepare("UPDATE MedicalService SET doctorID = NULL WHERE doctorID = ?");
                    $stmt->execute([$doctorID]);

                    $stmt = $pdo->prepare("DELETE FROM Doctor WHERE doctorID = ?");
                    $stmt->execute([$doctorID]);
                    $_SESSION['message'] = "Doctor deleted successfully";
                    break;
                    
                case 'add_doctor':
                    $firstName = $_POST['first_name'];
                    $lastName = $_POST['last_name'];
                    $email = $_POST['email'];
                    $phone = $_POST['phone'];
                    $specialty = $_POST['specialty'];
                    $startTime = $_POST['start_time'];
                    $endTime = $_POST['end_time'];
                    $description = $_POST['description'];
                    $selectedServices = $_POST['services'] ?? [];
                    // New field for unlisted service
                    $newServiceName = trim($_POST['new_service_name'] ?? '');

                    $availability = trim("$startTime - $endTime");
                    
                    // 1. Create User
                    $passwordHash = password_hash('temp123', PASSWORD_DEFAULT); // Temporary password
                    $stmt = $pdo->prepare("INSERT INTO User (firstName, lastName, email, passwordHash, phone, userType) VALUES (?, ?, ?, ?, ?, 'Doctor')");
                    $stmt->execute([$firstName, $lastName, $email, $passwordHash, $phone]);
                    $userID = $pdo->lastInsertId();
                    
                    // 2. Create Doctor
                    $stmt = $pdo->prepare("INSERT INTO Doctor (userID, specialty, availability, description) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$userID, $specialty, $availability, $description]);
                    $doctorID = $pdo->lastInsertId();

                    // 3. Link Services to Doctor (including new one)
                    updateDoctorServices($pdo, $doctorID, $selectedServices, $newServiceName);
                    
                    $_SESSION['message'] = "Dr. $lastName added successfully";
                    break;

                case 'edit_doctor':
                    $doctorID = intval($_POST['doctor_id']);
                    $firstName = $_POST['first_name'];
                    $lastName = $_POST['last_name'];
                    $email = $_POST['email'];
                    $phone = $_POST['phone'];
                    $specialty = $_POST['specialty'];
                    $startTime = $_POST['start_time'];
                    $endTime = $_POST['end_time'];
                    $description = $_POST['description'];
                    $selectedServices = $_POST['services'] ?? [];
                    // New field for unlisted service
                    $newServiceName = trim($_POST['new_service_name'] ?? '');

                    $availability = trim("$startTime - $endTime");

                    // 1. Update User
                    $stmt = $pdo->prepare("
                        UPDATE User u
                        JOIN Doctor d ON u.userID = d.userID
                        SET u.firstName = ?, u.lastName = ?, u.email = ?, u.phone = ?
                        WHERE d.doctorID = ?
                    ");
                    $stmt->execute([$firstName, $lastName, $email, $phone, $doctorID]);

                    // 2. Update Doctor
                    $stmt = $pdo->prepare("
                        UPDATE Doctor SET specialty = ?, availability = ?, description = ? WHERE doctorID = ?
                    ");
                    $stmt->execute([$specialty, $availability, $description, $doctorID]);

                    // 3. Update Service Links (including new one)
                    updateDoctorServices($pdo, $doctorID, $selectedServices, $newServiceName);

                    $_SESSION['message'] = "Dr. $lastName updated successfully";
                    break;
            }
            
            $pdo->commit();

        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            // Check for unique constraint violation (likely on email)
            if ($e->getCode() == 23000) {
                 $_SESSION['error'] = "Error: The email address is already registered.";
            } else {
                 $_SESSION['error'] = "Database Error: " . $e->getMessage();
            }
        }
        header("Location: admin_doctors.php");
        exit();
    }
}

// --- Filtering and Search ---
$searchTerm = $_GET['search'] ?? '';
$whereClauses = [];
$params = [];

if (!empty($searchTerm)) {
    $whereClauses[] = "
        (CONCAT(u.firstName, ' ', u.lastName) LIKE :searchTerm
        OR d.specialty LIKE :searchTerm
        OR u.email LIKE :searchTerm
        OR u.phone LIKE :searchTerm)
    ";
    $params[':searchTerm'] = '%' . $searchTerm . '%';
}

$whereCondition = count($whereClauses) > 0 ? "WHERE " . implode(" AND ", $whereClauses) : "";

// --- Get all doctors with their services and user info ---
$sql = "
    SELECT d.doctorID, u.userID, u.firstName, u.lastName, u.email, u.phone, 
           d.specialty, d.availability, d.description,
           GROUP_CONCAT(ms.serviceName) as service_names,
           COUNT(ms.serviceID) as services_count
    FROM Doctor d
    JOIN User u ON d.userID = u.userID
    LEFT JOIN MedicalService ms ON d.doctorID = ms.doctorID
    $whereCondition
    GROUP BY d.doctorID, u.userID, u.firstName, u.lastName, u.email, u.phone, d.specialty, d.availability, d.description
    ORDER BY u.lastName, u.firstName
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$doctors = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Function to safely split availability string into start and end times
function parseAvailability($availability) {
    if (preg_match('/^(\d{2}:\d{2}) - (\d{2}:\d{2})$/', trim($availability), $matches)) {
        return ['start' => $matches[1], 'end' => $matches[2]];
    }
    return ['start' => '09:00', 'end' => '17:00']; // Default
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctors - Dokotela Admin</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
        /* --- START OF CUSTOM GLASS/ANIMATED CSS --- */
        :root{
            --blue-1: #0f4d92;
            --blue-2: #1CA9C9;
            --pastel: #E6F6FF;
            --bright-red: #ff2d55;
            --success-color: #10b981;
            --muted: #64748b;
            --bg: #f6fbff;
            --card-bg: rgba(255,255,255,0.75);
            --glass-border: rgba(255,255,255,0.35);
            --shadow: 0 6px 18px rgba(16,24,40,0.08);
            --radius: 12px;
            --glass-blur: 8px;
            --text-dark: #0f1724;
            --text-muted: #475569;
            --gap: 1.5rem;
        }
        *{box-sizing:border-box;margin:0;padding:0}
        html,body{height:100%}
        body{
            font-family: "Segoe UI", system-ui, -apple-system, "Helvetica Neue", Arial;
            background: #f1f8ff;
            background: radial-gradient(circle at top left, #e6f6ff 0%, #f1f8ff 100%);
            color: var(--text-dark);
        }
        .container-fluid {
            padding: 0;
            margin: 0;
            width: 100%;
        }

        .dashboard-container{
            display:flex;
            min-height:100vh;
            transition: all 0.3s ease;
        }

        /* Standard Sidebar */
        .sidebar{
            width:260px;
            background: linear-gradient(180deg, rgba(255,255,255,0.7), rgba(246,249,255,0.55));
            padding:1rem;
            display:flex;
            flex-direction:column;
            gap:0.75rem;
            align-items:stretch;
            box-shadow: var(--shadow);
            border-right: 1px solid var(--glass-border);
            backdrop-filter: blur(6px);
            -webkit-backdrop-filter: blur(6px);
            transition: width 0.28s cubic-bezier(.22,.9,.36,1);
            position: sticky;
            top: 0;
            height: 100vh;
        }
        .sidebar-header{
            display:flex;align-items:center;gap:0.75rem;padding:0.6rem 0.6rem;
        }
        .logo-mark{
            width:44px;height:44px;border-radius:10px;
            display:grid;place-items:center;color:white;
            background: linear-gradient(135deg,var(--blue-1),var(--blue-2));
            box-shadow: 0 6px 18px rgba(15,77,146,0.18);
            font-weight:700;
            font-size:1.05rem;
        }
        .sidebar-header h4{ color:var(--blue-1); font-size:1.05rem; font-weight:700; }
        .sidebar-nav{
            display:flex;flex-direction:column;gap:6px;padding:0.5rem 0;
            width:100%;
        }
        .nav-btn{
            display:flex;align-items:center;gap:0.75rem;
            background:transparent;border:none;padding:0.6rem 0.8rem;border-radius:10px;
            cursor:pointer;color:var(--text-muted);font-size:0.95rem;transition: all 0.18s ease;
            text-decoration:none;
        }
        .nav-btn .fa-fw{ width:20px; text-align:center }
        .nav-btn:hover{ transform:translateY(-2px); color:var(--blue-1); background: rgba(15,77,146,0.04) }
        .nav-btn.active{
            background: linear-gradient(90deg, rgba(15,77,146,0.06), rgba(28,169,201,0.03));
            color:var(--blue-1);
            border-left: 3px solid var(--blue-2);
        }

        /* Main Content */
        .main-content{
            flex:1;padding:var(--gap);
        }
        .main-header{
            margin-bottom: var(--gap);
        }
        .page-title {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--text-dark);
        }

        /* Search Box Styling */
        .search-box {
            display: flex;
            align-items: center;
            background: var(--card-bg);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius);
            padding: 0; 
            height: 40px;
            backdrop-filter: blur(var(--glass-blur));
            -webkit-backdrop-filter: blur(var(--glass-blur));
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 350px;
            margin-bottom: 0;
        }
        .search-box form {
            display: flex;
            width: 100%;
            align-items: center;
            padding: 0 5px; 
        }
        .search-box input {
            border: none !important; 
            outline: none;
            background: transparent;
            width: 100%;
            font-size: 0.95rem;
            color: var(--text-dark);
            padding: 0 10px; 
            box-shadow: none !important;
            height: 38px;
        }
        .search-box button {
            background: transparent;
            color: var(--blue-1);
            border: none;
            padding: 0 8px;
            cursor: pointer;
            font-size: 1rem;
            box-shadow: none;
            transition: color 0.2s;
        }
        .search-box button:hover {
            color: var(--blue-2);
        }

        /* Doctor Card Styling & Animation */
        .doctor-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 1.25rem;
            box-shadow: var(--shadow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(var(--glass-blur));
            -webkit-backdrop-filter: blur(var(--glass-blur));
            margin-bottom: var(--gap);
            transition: all 0.3s ease;
            height: 100%; /* Ensure uniform height in rows */
            display: flex;
            flex-direction: column;
        }
        .doctor-card:hover {
            transform: translateY(-5px) scale(1.02);
            box-shadow: 0 10px 25px rgba(15, 77, 146, 0.1);
        }
        .doctor-icon-container {
            width: 80px; height: 80px;
            margin: 0 auto 1rem;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--blue-1), var(--blue-2));
            box-shadow: 0 4px 12px rgba(15, 77, 146, 0.3);
            display: grid; place-items: center;
            animation: pulse 2s infinite ease-out;
        }
        .doctor-icon-container i {
            color: white; font-size: 2.2rem;
        }
        @keyframes pulse {
            0% { box-shadow: 0 4px 12px rgba(15, 77, 146, 0.3); }
            50% { box-shadow: 0 4px 20px rgba(15, 77, 146, 0.5); }
            100% { box-shadow: 0 4px 12px rgba(15, 77, 146, 0.3); }
        }
        .doctor-info p {
            font-size: 0.95rem;
            color: var(--text-dark);
        }
        .doctor-info i {
            width: 20px;
            color: var(--blue-2);
            margin-right: 5px;
        }
        .services-tag {
            display: inline-block;
            background: var(--pastel);
            color: var(--blue-1);
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 0.8rem;
            font-weight: 600;
            margin-top: 5px;
        }
        .doctor-card .text-center.mt-3 {
            margin-top: auto; /* Push actions to the bottom */
            padding-top: 1rem;
            border-top: 1px solid rgba(15,77,146,0.1);
        }

        /* Custom Button Styling */
        .btn-action {
            display: inline-flex; align-items: center; justify-content: center;
            width: 36px; height: 36px;
            border-radius: 8px;
            margin: 0 3px;
            transition: all 0.2s ease;
            border-width: 2px !important;
        }
        .btn-edit { color: var(--blue-1); border-color: var(--blue-1); background: rgba(15,77,146,0.05); }
        .btn-edit:hover { background: var(--blue-1); color: white; transform: scale(1.05); }
        .btn-delete { color: var(--bright-red); border-color: var(--bright-red); background: rgba(255,45,85,0.05); }
        .btn-delete:hover { background: var(--bright-red); color: white; transform: scale(1.05); }
        .btn-schedule { color: var(--success-color); border-color: var(--success-color); background: rgba(16, 185, 129, 0.05); }
        .btn-schedule:hover { background: var(--success-color); color: white; transform: scale(1.05); }

        /* --- PRIMARY ACTION BUTTON (ADD NEW DOCTOR) --- */
        .btn-primary {
            /* Override default Bootstrap primary */
            background: var(--blue-1);
            border-color: var(--blue-1);
            color: white;
            font-weight: 600;
            padding: 0.5rem 1.25rem;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(15, 77, 146, 0.2);
            transition: all 0.2s ease;
        }
        .btn-primary:hover {
            background: var(--blue-2);
            border-color: var(--blue-2);
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(28, 169, 201, 0.3);
        }
        .btn-primary:active, .btn-primary:focus {
            background: var(--blue-2) !important;
            border-color: var(--blue-2) !important;
            box-shadow: 0 0 0 0.25rem rgba(28,169,201,0.5) !important;
        }
        
        /* Modal Animation (Bootstrap Fade with custom touch) */
        .modal.fade .modal-dialog {
            transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275), opacity 0.3s ease-out;
            transform: scale(0.95) translate(0, -20px);
        }
        .modal.fade.show .modal-dialog {
            transform: scale(1) translate(0, 0);
        }
        .modal-content {
            border-radius: var(--radius);
            box-shadow: 0 20px 50px rgba(15, 77, 146, 0.25);
        }

        /* Form Controls */
        .form-control, .form-select {
            border-radius: 8px;
            border: 1px solid rgba(15,77,146,0.15);
            transition: all 0.2s;
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--blue-2);
            box-shadow: 0 0 0 0.25rem rgba(28,169,201,0.25);
        }
        
        /* Services Checkbox Layout */
        .services-checkbox-group {
            max-height: 150px;
            overflow-y: auto;
            border: 1px solid #e9ecef;
            padding: 10px;
            border-radius: 8px;
            background-color: #f8f9fa;
        }
        .services-checkbox-group .form-check {
            margin-bottom: 5px;
            padding-left: 2em;
        }
        .services-header {
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 8px;
            display: block;
        }
        .new-service-input {
            margin-top: 10px;
        }
        .new-service-input label {
             font-size: 0.9rem;
             color: var(--blue-1);
        }
        /* --- END OF CUSTOM GLASS/ANIMATED CSS --- */
    </style>
</head>
<body>
    <div class="dashboard-container">
        <nav class="sidebar">
            <div class="sidebar-header">
                <div class="logo-mark"><i class="fas fa-stethoscope"></i></div>
                <h4>Dokotela</h4>
            </div>
            <div class="sidebar-nav">
                <a class="nav-btn" href="admin_dashboard.php"><i class="fas fa-tachometer-alt fa-fw"></i>Dashboard</a>
                <a class="nav-btn" href="admin_users.php"><i class="fas fa-users fa-fw"></i>User Management</a>
                <a class="nav-btn" href="admin_appointments.php"><i class="fas fa-calendar-alt fa-fw"></i>Appointments</a>
                <a class="nav-btn active" href="admin_doctors.php"><i class="fas fa-user-md fa-fw"></i>Doctors</a>
                <a class="nav-btn" href="admin_payments.php"><i class="fas fa-money-bill-wave fa-fw"></i>Payments</a>
                <a class="nav-btn" href="admin_services.php"><i class="fas fa-concierge-bell fa-fw"></i>Services</a>
                <a class="nav-btn" href="admin_reports.php"><i class="fas fa-chart-bar fa-fw"></i>Reports</a>
            </div>
            <a class="nav-btn" href="../auth/logout.php" style="margin-top: auto;"><i class="fas fa-sign-out-alt fa-fw"></i>Logout</a>
        </nav>

        <main class="main-content">
            <div class="main-header">
                <div class="row align-items-center g-3">
                    <div class="col-md-6">
                        <h1 class="page-title">Doctor Management</h1>
                    </div>
                    <div class="col-md-6 text-md-end">
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addDoctorModal">
                            <i class="fas fa-plus"></i> Add New Doctor
                        </button>
                    </div>
                </div>
            </div>

            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="row mb-4">
                <div class="col-12">
                    <div class="search-box">
                        <form method="GET" action="admin_doctors.php">
                            <input type="text" name="search" placeholder="Search Doctor, Specialty, or Email" value="<?php echo htmlspecialchars($searchTerm); ?>">
                            <button type="submit" title="Search"><i class="fas fa-search"></i></button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="row">
                <?php if (empty($doctors)): ?>
                    <div class="col-12">
                        <div class="alert alert-info">No doctors found matching your criteria.</div>
                    </div>
                <?php endif; ?>
                <?php foreach ($doctors as $doctor): 
                    $availabilityTimes = parseAvailability($doctor['availability']);
                ?>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="doctor-card">
                        <div class="doctor-icon-container">
                            <i class="fas fa-user-md"></i>
                        </div>
                        <h5 class="text-center mb-1">Dr. <?php echo htmlspecialchars($doctor['firstName'] . ' ' . $doctor['lastName']); ?></h5>
                        <p class="text-muted text-center mb-3">
                            <small class="text-secondary"><?php echo htmlspecialchars($doctor['specialty']); ?></small>
                        </p>
                        
                        <div class="doctor-info flex-grow-1 mb-3">
                            <p><i class="fas fa-envelope fa-fw"></i> <?php echo htmlspecialchars($doctor['email']); ?></p>
                            <p><i class="fas fa-phone fa-fw"></i> <?php echo htmlspecialchars($doctor['phone']); ?></p>
                            <p>
                                <i class="fas fa-clock fa-fw"></i> 
                                <?php echo htmlspecialchars($availabilityTimes['start'] . ' - ' . $availabilityTimes['end']); ?>
                            </p>
                            <p class="mb-2">
                                <i class="fas fa-concierge-bell fa-fw"></i> 
                                <span class="services-tag"><?php echo $doctor['services_count']; ?> Services</span>
                            </p>
                            <?php if ($doctor['description']): ?>
                            <p class="small text-muted mt-2">
                                <i class="fas fa-info-circle fa-fw"></i>
                                <?php echo substr(htmlspecialchars($doctor['description']), 0, 70) . (strlen($doctor['description']) > 70 ? '...' : ''); ?>
                            </p>
                            <?php endif; ?>
                        </div>

                        <div class="text-center mt-3">
                            <button class="btn btn-action btn-edit edit-doctor-btn" 
                                data-bs-toggle="modal" 
                                data-bs-target="#editDoctorModal"
                                data-doctor-id="<?php echo $doctor['doctorID']; ?>"
                                data-first-name="<?php echo htmlspecialchars($doctor['firstName']); ?>"
                                data-last-name="<?php echo htmlspecialchars($doctor['lastName']); ?>"
                                data-email="<?php echo htmlspecialchars($doctor['email']); ?>"
                                data-phone="<?php echo htmlspecialchars($doctor['phone']); ?>"
                                data-specialty="<?php echo htmlspecialchars($doctor['specialty']); ?>"
                                data-start-time="<?php echo $availabilityTimes['start']; ?>"
                                data-end-time="<?php echo $availabilityTimes['end']; ?>"
                                data-description="<?php echo htmlspecialchars($doctor['description']); ?>"
                                title="Edit Doctor">
                                <i class="fas fa-edit"></i>
                            </button>

                            <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete Dr. <?php echo htmlspecialchars($doctor['lastName']); ?>? This cannot be undone.')">
                                <input type="hidden" name="action" value="delete_doctor">
                                <input type="hidden" name="doctor_id" value="<?php echo $doctor['doctorID']; ?>">
                                <button type="submit" class="btn btn-action btn-delete" title="Delete Doctor">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                            
                            <button class="btn btn-action btn-schedule view-schedule-btn" 
                                data-bs-toggle="modal" 
                                data-bs-target="#scheduleModal"
                                data-name="Dr. <?php echo htmlspecialchars($doctor['lastName']); ?>"
                                data-schedule="<?php echo htmlspecialchars($doctor['availability']); ?>"
                                data-services="<?php echo htmlspecialchars($doctor['service_names'] ?? 'None'); ?>"
                                title="View Schedule">
                                <i class="fas fa-calendar-alt"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </main>
    </div>

    <div class="modal fade" id="addDoctorModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" style="color: var(--blue-1);">Add New Doctor</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add_doctor">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">First Name *</label>
                                <input type="text" class="form-control" name="first_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Last Name *</label>
                                <input type="text" class="form-control" name="last_name" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email *</label>
                                <input type="email" class="form-control" name="email" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone</label>
                                <input type="text" class="form-control" name="phone">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Specialty *</label>
                            <input type="text" class="form-control" name="specialty" required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Availability Start Time</label>
                                <input type="time" class="form-control" name="start_time" value="09:00">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Availability End Time</label>
                                <input type="time" class="form-control" name="end_time" value="17:00">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="services-header">Select Existing Services</label>
                            <div class="services-checkbox-group">
                                <?php if (empty($allServices)): ?>
                                    <p class="text-muted">No medical services available. Add services in the Service Management page or below.</p>
                                <?php else: ?>
                                    <?php foreach ($allServices as $service): ?>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="services[]" value="<?php echo $service['serviceID']; ?>" id="add_service_<?php echo $service['serviceID']; ?>">
                                            <label class="form-check-label" for="add_service_<?php echo $service['serviceID']; ?>">
                                                <?php echo htmlspecialchars($service['serviceName']); ?>
                                            </label>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                            <div class="new-service-input">
                                <label class="form-label"><i class="fas fa-plus-circle"></i> **Add a New Service** (If not in the list)</label>
                                <input type="text" class="form-control" name="new_service_name" placeholder="Enter new service name, e.g., 'Virtual Cardiology'">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Doctor</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editDoctorModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" style="color: var(--blue-1);">Edit Doctor</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="editDoctorForm">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="edit_doctor">
                        <input type="hidden" name="doctor_id" id="edit_doctor_id">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">First Name *</label>
                                <input type="text" class="form-control" name="first_name" id="edit_first_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Last Name *</label>
                                <input type="text" class="form-control" name="last_name" id="edit_last_name" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email *</label>
                                <input type="email" class="form-control" name="email" id="edit_email" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone</label>
                                <input type="text" class="form-control" name="phone" id="edit_phone">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Specialty *</label>
                            <input type="text" class="form-control" name="specialty" id="edit_specialty" required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Availability Start Time</label>
                                <input type="time" class="form-control" name="start_time" id="edit_start_time" value="09:00">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Availability End Time</label>
                                <input type="time" class="form-control" name="end_time" id="edit_end_time" value="17:00">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="services-header">Select Existing Services</label>
                            <div class="services-checkbox-group" id="edit_services_container">
                                </div>
                            <div class="new-service-input">
                                <label class="form-label"><i class="fas fa-plus-circle"></i> **Add a New Service** (If not in the list)</label>
                                <input type="text" class="form-control" name="new_service_name" id="edit_new_service_name" placeholder="Enter new service name">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" id="edit_description" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="scheduleModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" style="color: var(--success-color);">Schedule & Services</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body schedule-details">
                    <h4 id="schedule_doctor_name" class="mb-3" style="color: var(--blue-1);"></h4>
                    <p><i class="fas fa-clock fa-fw"></i> Available Hours: <span id="schedule_availability"></span></p>
                    <p class="mt-3"><i class="fas fa-concierge-bell fa-fw"></i> Offered Services:</p>
                    <div id="schedule_services_list" style="margin-left: 25px;">
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Store PHP data in a JS variable for modal/actions
        const allServices = <?php echo json_encode($allServices); ?>;
        const doctorsData = <?php echo json_encode($doctors); ?>;
        const doctorsMap = doctorsData.reduce((acc, doctor) => {
            acc[doctor.doctorID] = doctor;
            return acc;
        }, {});

        /**
         * Parses the doctor's availability string into a {start, end} object.
         * @param {string} availability - The "HH:MM - HH:MM" string.
         * @returns {{start: string, end: string}}
         */
        function parseAvailability(availability) {
            const match = availability.trim().match(/^(\d{2}:\d{2}) - (\d{2}:\d{2})$/);
            return match ? { start: match[1], end: match[2] } : { start: '09:00', end: '17:00' };
        }

        // --- Event Listeners and Modal Population ---

        // 1. EDIT Doctor Modal Handler (Updated for new service field)
        document.querySelectorAll('.edit-doctor-btn').forEach(button => {
            button.addEventListener('click', async function() {
                const doctorID = this.getAttribute('data-doctor-id');
                const doctor = doctorsMap[doctorID];
                if (!doctor) return;

                // 1. Populate Doctor/User fields
                document.getElementById('edit_doctor_id').value = doctorID;
                document.getElementById('edit_first_name').value = doctor.firstName;
                document.getElementById('edit_last_name').value = doctor.lastName;
                document.getElementById('edit_email').value = doctor.email;
                document.getElementById('edit_phone').value = doctor.phone;
                document.getElementById('edit_specialty').value = doctor.specialty;
                document.getElementById('edit_description').value = doctor.description;

                // Clear the new service input for a fresh start
                document.getElementById('edit_new_service_name').value = '';

                // 2. Populate Availability
                const times = parseAvailability(doctor.availability);
                document.getElementById('edit_start_time').value = times.start;
                document.getElementById('edit_end_time').value = times.end;

                // 3. Populate Services checkbox list
                const serviceContainer = document.getElementById('edit_services_container');
                serviceContainer.innerHTML = '';
                
                // Get the services linked to the current doctor
                const linkedServices = doctor.service_names ? doctor.service_names.split(',').map(name => name.trim()) : [];

                allServices.forEach(service => {
                    const isChecked = linkedServices.includes(service.serviceName);
                    const div = document.createElement('div');
                    div.className = 'form-check';
                    div.innerHTML = `
                        <input class="form-check-input" type="checkbox" name="services[]" value="${service.serviceID}" id="edit_service_${service.serviceID}" ${isChecked ? 'checked' : ''}>
                        <label class="form-check-label" for="edit_service_${service.serviceID}">
                            ${service.serviceName}
                        </label>
                    `;
                    serviceContainer.appendChild(div);
                });
                
                // Show the modal
                const editModal = new bootstrap.Modal(document.getElementById('editDoctorModal'));
                editModal.show();
            });
        });


        // 2. VIEW Schedule Modal Handler
        document.querySelectorAll('.view-schedule-btn').forEach(button => {
            button.addEventListener('click', function() {
                const name = this.getAttribute('data-name');
                const schedule = this.getAttribute('data-schedule');
                const servicesString = this.getAttribute('data-services');
                
                document.getElementById('schedule_doctor_name').textContent = name;
                document.getElementById('schedule_availability').textContent = schedule;

                const servicesListEl = document.getElementById('schedule_services_list');
                servicesListEl.innerHTML = '';

                if (servicesString && servicesString !== 'None') {
                    const servicesArray = servicesString.split(',').map(s => s.trim());
                    servicesArray.forEach(serviceName => {
                        const p = document.createElement('span');
                        p.className = 'services-tag';
                        p.style.marginRight = '8px';
                        p.textContent = serviceName;
                        servicesListEl.appendChild(p);
                    });
                } else {
                    servicesListEl.innerHTML = '<p class="text-muted small">No services currently linked to this doctor.</p>';
                }

                // Show the modal
                const scheduleModal = new bootstrap.Modal(document.getElementById('scheduleModal'));
                scheduleModal.show();
            });
        });
    </script>
</body>
</html>