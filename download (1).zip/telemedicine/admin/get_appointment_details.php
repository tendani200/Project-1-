<?php
// get_appointment_details.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if admin is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Admin') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Create database connection
try {
    $host = 'sql206.byetcluster.com';
    $dbname = 'if0_40031860_dok';
    $username = 'if0_40031860';
    $password = "qzJkHEejybefK";
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit();
}

header('Content-Type: application/json');

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo json_encode(['success' => false, 'message' => 'Appointment ID is required']);
    exit();
}

$appointmentId = intval($_GET['id']);

try {
    $sql = "
        SELECT 
            a.appointmentID, 
            CONCAT(pu.firstName, ' ', pu.lastName) as patient_name,
            pu.phone as patient_phone,
            pu.email as patient_email,
            CONCAT(du.firstName, ' ', du.lastName) as doctor_name,
            d.specialty,
            ms.serviceName, 
            ms.serviceFee,
            a.appointmentDate, 
            a.appointmentTime, 
            a.status, 
            a.createdAt,
            a.reason,
            a.cancellationReason,
            a.rescheduleReason,
            a.doctorID,
            a.patientID
        FROM Appointments a
        JOIN Patient pt ON a.patientID = pt.patientID
        JOIN User pu ON pt.userID = pu.userID
        JOIN Doctor d ON a.doctorID = d.doctorID
        JOIN User du ON d.userID = du.userID
        JOIN MedicalService ms ON a.serviceID = ms.serviceID
        WHERE a.appointmentID = ?
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$appointmentId]);
    $appointment = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($appointment) {
        echo json_encode(['success' => true, 'appointment' => $appointment]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Appointment not found']);
    }
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>