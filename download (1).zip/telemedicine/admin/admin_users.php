<?php
// admin_users.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if admin is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

$userID = intval($_SESSION['userID']);

// Create database connection
try {
    $host = 'sql206.byetcluster.com';
    $dbname = 'if0_40031860_dok';
    $username = 'if0_40031860';
    $password = "qzJkHEejybefK";
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Handle user actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'delete_user':
                $userIDToDelete = intval($_POST['user_id']);
                if ($userIDToDelete !== $userID) { // Prevent self-deletion
                    $stmt = $pdo->prepare("DELETE FROM User WHERE userID = ?");
                    $stmt->execute([$userIDToDelete]);
                    $_SESSION['message'] = "User deleted successfully";
                }
                break;
            case 'add_user':
                $firstName = $_POST['firstName'] ?? '';
                $lastName = $_POST['lastName'] ?? '';
                $email = $_POST['email'] ?? '';
                $phone = $_POST['phone'] ?? '';
                $userType = $_POST['userType'] ?? '';
                $password = password_hash('default123', PASSWORD_DEFAULT); // Default password
                
                if (!empty($firstName) && !empty($lastName) && !empty($email) && !empty($userType)) {
                    $stmt = $pdo->prepare("INSERT INTO User (firstName, lastName, email, phone, userType, password) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$firstName, $lastName, $email, $phone, $userType, $password]);
                    $_SESSION['message'] = "User added successfully";
                } else {
                    $_SESSION['error'] = "Please fill all required fields";
                }
                break;
            case 'edit_user':
                $userIDToEdit = intval($_POST['user_id']);
                $firstName = $_POST['firstName'] ?? '';
                $lastName = $_POST['lastName'] ?? '';
                $email = $_POST['email'] ?? '';
                $phone = $_POST['phone'] ?? '';
                $userType = $_POST['userType'] ?? '';
                
                if (!empty($firstName) && !empty($lastName) && !empty($email) && !empty($userType)) {
                    $stmt = $pdo->prepare("UPDATE User SET firstName = ?, lastName = ?, email = ?, phone = ?, userType = ? WHERE userID = ?");
                    $stmt->execute([$firstName, $lastName, $email, $phone, $userType, $userIDToEdit]);
                    $_SESSION['message'] = "User updated successfully";
                } else {
                    $_SESSION['error'] = "Please fill all required fields";
                }
                break;
        }
        header("Location: admin_users.php");
        exit();
    }
}

// Handle search
$searchQuery = '';
$users = [];
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchQuery = $_GET['search'];
    $stmt = $pdo->prepare("
        SELECT u.userID, u.firstName, u.lastName, u.email, u.phone, u.userType, u.createdAt
        FROM User u
        WHERE u.firstName LIKE ? OR u.lastName LIKE ? OR u.email LIKE ? OR u.userType LIKE ?
        ORDER BY u.createdAt DESC
    ");
    $searchTerm = "%$searchQuery%";
    $stmt->execute([$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
    $users = $stmt->fetchAll();
} else {
    // Get all users
    $stmt = $pdo->query("
        SELECT u.userID, u.firstName, u.lastName, u.email, u.phone, u.userType, u.createdAt
        FROM User u
        ORDER BY u.createdAt DESC
    ");
    $users = $stmt->fetchAll();
}

// Get user for editing/viewing
$editUser = null;
$viewUser = null;
if (isset($_GET['edit'])) {
    $editUserID = intval($_GET['edit']);
    $stmt = $pdo->prepare("SELECT * FROM User WHERE userID = ?");
    $stmt->execute([$editUserID]);
    $editUser = $stmt->fetch();
}

if (isset($_GET['view'])) {
    $viewUserID = intval($_GET['view']);
    $stmt = $pdo->prepare("SELECT * FROM User WHERE userID = ?");
    $stmt->execute([$viewUserID]);
    $viewUser = $stmt->fetch();
}

// Get user stats
$totalUsers = $pdo->query("SELECT COUNT(*) FROM User")->fetchColumn();
$totalDoctors = $pdo->query("SELECT COUNT(*) FROM User WHERE userType = 'Doctor'")->fetchColumn();
$totalPatients = $pdo->query("SELECT COUNT(*) FROM User WHERE userType = 'Patient'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Dokotela Admin</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
:root{
    --blue-1: #0f4d92;
    --blue-2: #1CA9C9;
    --pastel: #E6F6FF;
    --bright-red: #ff2d55;
    --muted: #64748b;
    --bg: #f6fbff;
    --card-bg: rgba(255,255,255,0.75);
    --glass-border: rgba(255,255,255,0.35);
    --shadow: 0 6px 18px rgba(16,24,40,0.08);
    --radius: 12px;
    --glass-blur: 8px;
    --text-dark: #0f1724;
    --text-muted: #475569;
    --gap: 1rem;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%}
body{
    font-family: "Segoe UI", system-ui, -apple-system, "Helvetica Neue", Arial;
    background: #f1f8ff;
    background: radial-gradient(circle at top left, #e6f6ff 0%, #f1f8ff 100%);
    color: var(--text-dark);
}

.dashboard-container{
    display:flex;
    min-height:100vh;
    gap:var(--gap);
    transition: all 0.3s ease;
}
.sidebar{
    width:260px;
    background: linear-gradient(180deg, rgba(255,255,255,0.7), rgba(246,249,255,0.55));
    border-radius: calc(var(--radius) + 4px);
    padding:1rem;
    display:flex;
    flex-direction:column;
    gap:0.75rem;
    align-items:stretch;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(6px);
    transition: width 0.28s cubic-bezier(.22,.9,.36,1), transform 0.3s ease;
}
.sidebar.collapsed{ width:72px; padding:0.6rem; align-items:center }
.sidebar.collapsed .sidebar-header h2,
.sidebar.collapsed .nav-text,
.sidebar.collapsed .profile-info { display:none }
.sidebar.collapsed .nav-btn { justify-content:center }
.sidebar-header{
    display:flex;
    align-items:center;
    gap:0.75rem;
    padding:0.6rem 0.6rem;
}
.logo-mark{
    width:44px;height:44px;border-radius:10px;
    display:grid;place-items:center;color:white;
    background: linear-gradient(135deg,var(--blue-1),var(--blue-2));
    box-shadow: 0 6px 18px rgba(15,77,146,0.18);
    font-weight:700;
    font-size:1.05rem;
}
.sidebar-header h2{ color:var(--blue-1); font-size:1.05rem; font-weight:700; }
.sidebar-nav{
    display:flex;flex-direction:column;gap:6px;padding:0.5rem 0;
    width:100%;
}
.nav-btn{
    display:flex;align-items:center;gap:0.75rem;
    background:transparent;border:none;padding:0.6rem 0.8rem;border-radius:10px;
    cursor:pointer;color:var(--text-muted);font-size:0.95rem;transition: all 0.18s ease;
    text-decoration:none;
}
.nav-btn .fa-fw{ width:20px; text-align:center }
.nav-btn:hover{ transform:translateY(-2px); color:var(--blue-1); background: rgba(15,77,146,0.04) }
.nav-btn.active{
    background: linear-gradient(90deg, rgba(15,77,146,0.06), rgba(28,169,201,0.03));
    color:var(--blue-1);
    border-left: 3px solid var(--blue-2);
}
.nav-text{ flex:1 }
.user-profile{
    margin-top:auto;display:flex;align-items:center;gap:0.75rem;padding:0.6rem;border-radius:10px;
    background: linear-gradient(180deg, rgba(255,255,255,0.35), rgba(255,255,255,0.2));
    border: 1px solid rgba(255,255,255,0.25);
    backdrop-filter: blur(4px);
}
.user-profile img{ width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid white; box-shadow: 0 6px 14px rgba(16,24,40,0.06) }
.profile-info h4{ font-size:0.95rem; margin-bottom:2px }
.profile-info span{ font-size:0.82rem; color:var(--text-muted) }
.main-content{
    flex:1;padding:1.5rem;overflow:auto;
}
.topbar{
    display:flex;align-items:center;justify-content:space-between;gap:1rem;margin-bottom:1.25rem;
}
.topbar-left{
    display:flex;align-items:center;gap:1rem;
}
.hamburger{
    background:transparent;border:none;padding:0.5rem;cursor:pointer;color:var(--text-muted);
    border-radius:6px;transition:all 0.2s ease;
}
.hamburger:hover{background:rgba(15,77,146,0.06);color:var(--blue-1);}

.welcome-header{
    background: linear-gradient(135deg, rgba(15,77,146,0.95), rgba(28,169,201,0.95));
    color:white;padding:1.6rem;border-radius:14px;box-shadow: 0 12px 30px rgba(15,77,146,0.12);
    display:flex;flex-direction:column;gap:0.4rem;
}
.welcome-header h1{ font-size:1.6rem; font-weight:700 }
.welcome-header p{ opacity:0.95; font-size:0.95rem }
.grid{
    display:grid;
    grid-template-columns: repeat(12, 1fr);
    gap:1rem;
    margin-top:1rem;
}
.card{
    background: var(--card-bg);
    border-radius: var(--radius);
    padding:1rem;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(var(--glass-blur));
}
.stats-grid{ grid-column: span 12; display:grid; grid-template-columns: repeat(3,1fr); gap:1rem; }
.stat-card{
    padding:0.9rem; display:flex; align-items:center; gap:0.9rem; border-radius:10px;
}
.stat-icon{ font-size:1.75rem; background: linear-gradient(180deg, rgba(255,255,255,0.8), rgba(255,255,255,0.6)); padding:0.6rem; border-radius:10px;}
.stat-info .stat-value{ font-size:1.45rem; color:var(--blue-1); font-weight:700 }
.stat-info .stat-label{ color:var(--text-muted); font-size:0.9rem }
.schedule-card{ grid-column: span 12; padding:1rem }
    
.schedule-list ul{ list-style:none; display:flex; flex-direction:column; gap:0.6rem; margin-top:0.6rem }
.schedule-list li{ padding:0.6rem; border-radius:8px; background: rgba(255,255,255,0.65); display:flex; justify-content:space-between; align-items:center; border-left:4px solid rgba(28,169,201,0.18); }
.patients-grid{ grid-column: span 5; display:grid; gap:0.75rem; grid-auto-rows:min-content }
.patient-card{ padding:0.8rem; border-radius:8px; background: rgba(255,255,255,0.75); display:flex; flex-direction:column; gap:0.4rem; border-left:4px solid rgba(15,77,146,0.08) }
.appointments-table .placeholder{ padding:1rem; color:var(--text-muted) }
.btn{ display:inline-flex; align-items:center; gap:0.5rem; padding:0.55rem 0.9rem; border-radius:10px; border:none; cursor:pointer; font-weight:600; text-decoration:none; transition: all 0.2s ease; }
    
.btn-primary{ background: linear-gradient(90deg,var(--blue-1),var(--blue-2)); color:white }
.btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(15,77,146,0.3); }
.btn-ghost{ background:transparent; color:var(--text-dark); border:1px solid rgba(15,77,146,0.06) }
.btn-ghost:hover { background: rgba(15,77,146,0.04); }
.btn-danger{ background:var(--bright-red); color:white }
.btn-danger:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(255,45,85,0.3); }
.btn-secondary{
    background: linear-gradient(90deg, rgba(28,169,201,0.1), rgba(15,77,146,0.1));
    color: var(--blue-1);
    border: 1px solid rgba(15,77,146,0.2);
}
.btn-secondary:hover { background: linear-gradient(90deg, rgba(28,169,201,0.15), rgba(15,77,146,0.15)); }
.btn-info {
    background: linear-gradient(90deg, rgba(59, 130, 246, 0.1), rgba(37, 99, 235, 0.1));
    color: #2563eb;
    border: 1px solid rgba(37, 99, 235, 0.2);
}
.btn-info:hover { background: linear-gradient(90deg, rgba(59, 130, 246, 0.15), rgba(37, 99, 235, 0.15)); }
.btn-consult {
    background-color: #2563eb;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 0.55rem 0.9rem;
    cursor: pointer;
    font-weight: 600;
    transition: background 0.2s, box-shadow 0.2s;
}

.btn-consult:hover {
    background-color: #1e4fd4;
    box-shadow: 0 4px 12px rgba(37, 99, 235, 0.4);
}

/* Modal Styles */
.modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(2,6,23,0.45);
    backdrop-filter: blur(4px);
    z-index: 1200;
    align-items: center;
    justify-content: center;
}

.modal-overlay.active {
    display: flex;
}

.modal-content {
    background: white;
    width: 90%;
    max-width: 600px;
    border-radius: 16px;
    box-shadow: 0 20px 50px rgba(2,6,23,0.25);
    overflow: hidden;
}

.modal-header {
    background: linear-gradient(135deg, var(--blue-1), var(--blue-2));
    color: white;
    padding: 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 {
    margin: 0;
    font-size: 1.4rem;
    font-weight: 600;
}

.modal-close {
    background: none;
    border: none;
    color: white;
    font-size: 1.5rem;
    cursor: pointer;
    padding: 0;
    width: 30px;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 6px;
    transition: background 0.2s;
}

.modal-close:hover {
    background: rgba(255,255,255,0.2);
}

.modal-body {
    padding: 2rem;
}

.modal-footer {
    padding: 1.5rem 2rem;
    background: #f8fafc;
    display: flex;
    justify-content: flex-end;
    gap: 1rem;
    border-top: 1px solid #e2e8f0;
}

.glass-accent{ background: linear-gradient(180deg, rgba(255,255,255,0.6), rgba(255,255,255,0.35)); border-radius:10px; border:1px solid rgba(255,255,255,0.25); backdrop-filter: blur(6px) }

/* Search container */
.search-container {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-left: 1rem;
}

.search-box {
  display: flex;
  align-items: center;
  background: rgba(255, 255, 255, 0.15);
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 12px;
  padding: 6px 10px;
  height: 38px;
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
  transition: border 0.2s ease, background 0.2s ease, box-shadow 0.2s ease;
}

.search-box input {
  border: none;
  outline: none;
  background: transparent;
  width: 180px;
  font-size: 14px;
  color: var(--text-dark);
  backdrop-filter: blur(5px);
}

.search-box button {
  background-color: #2563eb;
  color: white;
  border: none;
  border-radius: 8px;
  padding: 6px 10px;
  cursor: pointer;
  font-size: 14px;
  transition: background 0.2s, box-shadow 0.2s;
  margin-left: 6px;
  box-shadow: 0 4px 15px rgba(37, 99, 235, 0.4);
}

.search-box button:hover {
  background-color: #1e4fd4;
  box-shadow: 0 6px 20px rgba(37, 99, 235, 0.5);
}

/* Weekly Overview */
.weekly-overview {
  background: white;
  border-radius: 10px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
  width: 300px;
  padding: 20px;
  margin-top: 40px;
}

.weekly-overview h3 {
  margin-top: 0;
  font-size: 16px;
  font-weight: 600;
  color: #111827;
}

.days {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 8px;
  margin-top: 10px;
  margin-bottom: 20px;
}

.day {
  background: #f3f4f6;
  border-radius: 8px;
  text-align: center;
  padding: 10px 0;
  font-weight: 500;
  color: #374151;
  transition: all 0.2s;
}

.day.active {
  background-color: #2563eb;
  color: white;
  box-shadow: 0 2px 6px rgba(37, 99, 235, 0.4);
}

@media (max-width: 1000px){
    .stats-grid{ grid-template-columns: repeat(2,1fr) }
    .schedule-card{ grid-column: span 12 }
    .patients-grid{ grid-column: span 12 }
}
@media (max-width: 720px){
    .dashboard-container{ flex-direction:column }
    .sidebar{ width:100%; flex-direction:row; align-items:center; gap:0.6rem; padding:0.6rem; border-radius:10px }
    .sidebar.collapsed{ width:100% }
    .sidebar-header h2{ display:none }
    .nav-btn{ padding:0.55rem; font-size:0.9rem }
    .grid{ grid-template-columns: 1fr; }
    .stats-grid{ grid-template-columns: 1fr }
    .welcome-header h1{ font-size:1.25rem }
    .search-container {
        justify-content: flex-end;
        margin-left: 0;
    }
    .search-box {
        width: 100%;
        max-width: 220px;
    }
    .search-box input {
        width: 100%;
    }
}
.muted { color:var(--text-muted); font-size:0.9rem }
.small { font-size:0.85rem }

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

th, td {
    padding: 0.75rem;
    text-align: left;
    border-bottom: 1px solid #e2e8f0;
}

th {
    background-color: rgba(15, 77, 146, 0.05);
    font-weight: 600;
    color: var(--blue-1);
}

tr:hover {
    background-color: rgba(15, 77, 146, 0.02);
}
    .btn-sm {
    padding: 0.4rem 0.8rem;
    font-size: 0.85rem;
}

/* Analytics Specific Styles */
.analytics-kpi {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.analytics-kpi:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.chart-bar {
    transition: all 0.3s ease;
    cursor: pointer;
}

.chart-bar:hover {
    opacity: 0.8;
    transform: scale(1.05);
}

.performance-metric {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.75rem 0;
    border-bottom: 1px solid #e5e7eb;
    transition: background-color 0.2s ease;
}

.performance-metric:hover {
    background-color: rgba(59, 130, 246, 0.05);
    border-radius: 4px;
    margin: 0 -0.5rem;
    padding: 0.75rem 0.5rem;
}

.recent-patient-item {
    transition: background-color 0.2s ease;
    border-radius: 6px;
    margin: 0 -0.5rem;
    padding: 0.75rem 0.5rem;
}

.recent-patient-item:hover {
    background-color: rgba(16, 185, 129, 0.05);
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

.analytics-loading {
    animation: pulse 2s infinite;
}

/* Responsive analytics adjustments */
@media (max-width: 768px) {
    .grid {
        grid-template-columns: 1fr !important;
    }
    
    #weeklyChart, #monthlyChart {
        height: 200px !important;
    }
    
    .analytics-kpi {
        text-align: center;
    }
}

.medical-record-item {
    transition: all 0.3s ease;
}

.medical-record-item:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

/* Custom styles for admin users page */
.admin-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
}

.user-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
    background: var(--card-bg);
    border-radius: var(--radius);
    overflow: hidden;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
}

.user-table th, .user-table td {
    padding: 0.75rem 1rem;
    text-align: left;
    border-bottom: 1px solid rgba(15, 77, 146, 0.08);
}

.user-table th {
    background-color: rgba(15, 77, 146, 0.05);
    font-weight: 600;
    color: var(--blue-1);
}

.user-table tr:hover {
    background-color: rgba(15, 77, 146, 0.02);
}

.badge {
    padding: 0.35rem 0.65rem;
    border-radius: 6px;
    font-size: 0.75rem;
    font-weight: 600;
}

.badge-admin {
    background-color: rgba(239, 68, 68, 0.1);
    color: #dc2626;
}

.badge-doctor {
    background-color: rgba(59, 130, 246, 0.1);
    color: #2563eb;
}

.badge-patient {
    background-color: rgba(16, 185, 129, 0.1);
    color: #059669;
}

.action-buttons {
    display: flex;
    gap: 0.5rem;
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    color: var(--text-dark);
}

.form-control {
    width: 100%;
    padding: 0.75rem 1rem;
    border: 1px solid rgba(15, 77, 146, 0.2);
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.7);
    transition: all 0.2s ease;
    font-size: 0.95rem;
}

.form-control:focus {
    outline: none;
    border-color: var(--blue-2);
    box-shadow: 0 0 0 3px rgba(28, 169, 201, 0.1);
    background: white;
}

.alert {
    padding: 0.75rem 1rem;
    border-radius: 8px;
    margin-bottom: 1rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.alert-success {
    background-color: rgba(16, 185, 129, 0.1);
    color: #059669;
    border: 1px solid rgba(16, 185, 129, 0.2);
}

.alert-error {
    background-color: rgba(239, 68, 68, 0.1);
    color: #dc2626;
    border: 1px solid rgba(239, 68, 68, 0.2);
}

.alert-dismissible .btn-close {
    background: transparent;
    border: none;
    font-size: 1.25rem;
    cursor: pointer;
    color: inherit;
}

.stats-card {
    background: linear-gradient(135deg, rgba(255,255,255,0.8), rgba(255,255,255,0.6));
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: var(--shadow);
    border: 1px solid var(--glass-border);
    backdrop-filter: blur(8px);
    transition: all 0.3s ease;
}

.stats-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 30px rgba(15,77,146,0.15);
}

.stats-value {
    font-size: 2rem;
    font-weight: 700;
    color: var(--blue-1);
    margin-bottom: 0.5rem;
}

.stats-label {
    color: var(--text-muted);
    font-size: 0.9rem;
    font-weight: 500;
}

.search-results {
    margin: 1rem 0;
    color: var(--text-muted);
    font-size: 0.9rem;
}

.user-details {
    background: #f8fafc;
    border-radius: 10px;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
}

.detail-row {
    display: flex;
    margin-bottom: 1rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid #e2e8f0;
}

.detail-row:last-child {
    margin-bottom: 0;
    padding-bottom: 0;
    border-bottom: none;
}

.detail-label {
    font-weight: 600;
    color: var(--text-dark);
    min-width: 120px;
}

.detail-value {
    color: var(--text-muted);
    flex: 1;
}

.view-actions {
    display: flex;
    gap: 1rem;
    margin-top: 1.5rem;
    padding-top: 1.5rem;
    border-top: 1px solid #e2e8f0;
}
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
       <div class="sidebar">
            <div class="sidebar-header">
                <div class="logo-mark">DK</div>
                <h4>Dokotela</h4>
            </div>
            <div class="sidebar-nav">
                <a href="admin_dashboard.php" class="nav-btn active">
                    <i class="fas fa-tachometer-alt fa-fw"></i>
                    <span>Dashboard</span>
                </a>
                <a href="admin_users.php" class="nav-btn">
                    <i class="fas fa-users fa-fw"></i>
                    <span>User Management</span>
                </a>
                <a href="admin_appointments.php" class="nav-btn">
                    <i class="fas fa-calendar-alt fa-fw"></i>
                    <span>Appointments</span>
                </a>
                <a href="admin_doctors.php" class="nav-btn">
                    <i class="fas fa-user-md fa-fw"></i>
                    <span>Doctors</span>
                </a>
                <a href="admin_payments.php" class="nav-btn">
                    <i class="fas fa-money-bill-wave fa-fw"></i>
                    <span>Payments</span>
                </a>
                <a href="admin_services.php" class="nav-btn">
                    <i class="fas fa-concierge-bell fa-fw"></i>
                    <span>Services</span>
                </a>
                <a href="admin_notifications.php" class="nav-btn">
                    <i class="fas fa-bell fa-fw"></i>
                    <span>Notifications</span>
                </a>
                <a href="admin_support.php" class="nav-btn">
                    <i class="fas fa-headset fa-fw"></i>
                    <span>Support Tickets</span>
                </a>
                <a href="admin_announcements.php" class="nav-btn">
                    <i class="fas fa-bullhorn fa-fw"></i>
                    <span>Announcements</span>
                </a>
                <a href="admin_settings.php" class="nav-btn">
                    <i class="fas fa-cogs fa-fw"></i>
                    <span>Settings</span>
                </a>
                <a href="../auth/logout.php" class="nav-btn">
                    <i class="fas fa-sign-out-alt fa-fw"></i>
                    <span>Logout</span>
                </a>
            </div>
        

            
            <div class="user-profile">
                <img src="https://ui-avatars.com/api/?name=Admin+User&background=0f4d92&color=fff" alt="Admin User">
                <div class="profile-info">
                    <h4>Admin User</h4>
                    <span>Administrator</span>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="topbar">
                <div class="topbar-left">
                    <button class="hamburger">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h1>User Management</h1>
                </div>
                <form method="GET" class="search-container">
                    <div class="search-box">
                        <input type="text" name="search" placeholder="Search users..." value="<?php echo htmlspecialchars($searchQuery); ?>">
                        <button type="submit"><i class="fas fa-search"></i></button>
                    </div>
                </form>
            </div>

            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-success alert-dismissible">
                    <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
                    <button type="button" class="btn-close">&times;</button>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-error alert-dismissible">
                    <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close">&times;</button>
                </div>
            <?php endif; ?>

            <!-- View User Modal -->
            <?php if ($viewUser): ?>
            <div class="modal-overlay active" id="viewUserModal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>User Details</h3>
                        <a href="admin_users.php" class="modal-close">&times;</a>
                    </div>
                    <div class="modal-body">
                        <div class="user-details">
                            <div class="detail-row">
                                <div class="detail-label">User ID:</div>
                                <div class="detail-value"><?php echo $viewUser['userID']; ?></div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Name:</div>
                                <div class="detail-value"><?php echo htmlspecialchars($viewUser['firstName'] . ' ' . $viewUser['lastName']); ?></div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Email:</div>
                                <div class="detail-value"><?php echo htmlspecialchars($viewUser['email']); ?></div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Phone:</div>
                                <div class="detail-value"><?php echo htmlspecialchars($viewUser['phone'] ?? 'Not provided'); ?></div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Role:</div>
                                <div class="detail-value">
                                    <span class="badge badge-<?php echo strtolower($viewUser['userType']); ?>">
                                        <?php echo $viewUser['userType']; ?>
                                    </span>
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Joined:</div>
                                <div class="detail-value"><?php echo date('F j, Y g:i A', strtotime($viewUser['createdAt'])); ?></div>
                            </div>
                        </div>
                        <div class="view-actions">
                            <a href="admin_users.php?edit=<?php echo $viewUser['userID']; ?>" class="btn btn-secondary">
                                <i class="fas fa-edit"></i> Edit User
                            </a>
                            <a href="admin_users.php" class="btn btn-ghost">Close</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Edit User Modal -->
            <?php if ($editUser): ?>
            <div class="modal-overlay active" id="editUserModal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Edit User</h3>
                        <a href="admin_users.php" class="modal-close">&times;</a>
                    </div>
                    <form method="POST" id="editUserForm">
                        <input type="hidden" name="action" value="edit_user">
                        <input type="hidden" name="user_id" value="<?php echo $editUser['userID']; ?>">
                        <div class="modal-body">
                            <div class="form-group">
                                <label class="form-label">First Name *</label>
                                <input type="text" name="firstName" class="form-control" value="<?php echo htmlspecialchars($editUser['firstName']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Last Name *</label>
                                <input type="text" name="lastName" class="form-control" value="<?php echo htmlspecialchars($editUser['lastName']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Email *</label>
                                <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($editUser['email']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Phone</label>
                                <input type="tel" name="phone" class="form-control" value="<?php echo htmlspecialchars($editUser['phone'] ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Role *</label>
                                <select name="userType" class="form-control" required>
                                    <option value="">Select Role</option>
                                    <option value="Patient" <?php echo $editUser['userType'] === 'Patient' ? 'selected' : ''; ?>>Patient</option>
                                    <option value="Doctor" <?php echo $editUser['userType'] === 'Doctor' ? 'selected' : ''; ?>>Doctor</option>
                                    <option value="Admin" <?php echo $editUser['userType'] === 'Admin' ? 'selected' : ''; ?>>Admin</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <a href="admin_users.php" class="btn btn-ghost">Cancel</a>
                            <button type="submit" class="btn btn-primary">Update User</button>
                        </div>
                    </form>
                </div>
            </div>
            <?php endif; ?>

            <!-- Stats Cards -->
            <div class="stats-grid">
                <div class="stats-card">
                    <div class="stats-value"><?php echo $totalUsers; ?></div>
                    <div class="stats-label">Total Users</div>
                </div>
                <div class="stats-card">
                    <div class="stats-value"><?php echo $totalDoctors; ?></div>
                    <div class="stats-label">Doctors</div>
                </div>
                <div class="stats-card">
                    <div class="stats-value"><?php echo $totalPatients; ?></div>
                    <div class="stats-label">Patients</div>
                </div>
            </div>

            <?php if (!empty($searchQuery)): ?>
                <div class="search-results">
                    Showing results for "<?php echo htmlspecialchars($searchQuery); ?>"
                    <a href="admin_users.php" class="btn btn-sm btn-ghost" style="margin-left: 1rem;">
                        <i class="fas fa-times"></i> Clear search
                    </a>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="admin-header">
                    <h2>All Users</h2>
                    <button class="btn btn-primary" id="addUserBtn">
                        <i class="fas fa-plus"></i> Add New User
                    </button>
                </div>
                
                <div class="table-responsive">
                    <table class="user-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Role</th>
                                <th>Joined</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($users)): ?>
                                <tr>
                                    <td colspan="7" style="text-align: center; padding: 2rem; color: var(--text-muted);">
                                        No users found
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?php echo $user['userID']; ?></td>
                                    <td><?php echo htmlspecialchars($user['firstName'] . ' ' . $user['lastName']); ?></td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td><?php echo htmlspecialchars($user['phone']); ?></td>
                                    <td>
                                        <span class="badge badge-<?php 
                                            echo strtolower($user['userType']);
                                        ?>">
                                            <?php echo $user['userType']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M j, Y', strtotime($user['createdAt'])); ?></td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="admin_users.php?edit=<?php echo $user['userID']; ?>" class="btn btn-sm btn-secondary" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <?php if ($user['userID'] !== $userID): ?>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this user?')">
                                                <input type="hidden" name="action" value="delete_user">
                                                <input type="hidden" name="user_id" value="<?php echo $user['userID']; ?>">
                                                <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                            <a href="admin_users.php?view=<?php echo $user['userID']; ?>" class="btn btn-sm btn-info" title="View">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Add User Modal -->
    <div class="modal-overlay" id="addUserModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Add New User</h3>
                <button type="button" class="modal-close" id="closeModal">&times;</button>
            </div>
            <form method="POST" id="addUserForm">
                <input type="hidden" name="action" value="add_user">
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-label">First Name *</label>
                        <input type="text" name="firstName" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Last Name *</label>
                        <input type="text" name="lastName" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email *</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Phone</label>
                        <input type="tel" name="phone" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Role *</label>
                        <select name="userType" class="form-control" required>
                            <option value="">Select Role</option>
                            <option value="Patient">Patient</option>
                            <option value="Doctor">Doctor</option>
                            <option value="Admin">Admin</option>
                        </select>
                    </div>
                    <div class="muted small">
                        * Required fields. New users will be created with a default password.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-ghost" id="cancelBtn">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add User</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Toggle sidebar
        document.querySelector('.hamburger').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('collapsed');
        });

        // Modal functionality
        const addUserBtn = document.getElementById('addUserBtn');
        const addUserModal = document.getElementById('addUserModal');
        const closeModal = document.getElementById('closeModal');
        const cancelBtn = document.getElementById('cancelBtn');

        addUserBtn.addEventListener('click', function() {
            addUserModal.classList.add('active');
        });

        function closeUserModal() {
            addUserModal.classList.remove('active');
            document.getElementById('addUserForm').reset();
        }

        closeModal.addEventListener('click', closeUserModal);
        cancelBtn.addEventListener('click', closeUserModal);

        // Close modal when clicking outside
        window.addEventListener('click', function(event) {
            if (event.target === addUserModal) {
                closeUserModal();
            }
        });

        // Alert dismiss functionality
        document.querySelectorAll('.btn-close').forEach(button => {
            button.addEventListener('click', function() {
                this.closest('.alert').style.display = 'none';
            });
        });

        // Form validation
        document.getElementById('addUserForm').addEventListener('submit', function(e) {
            const requiredFields = this.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = 'var(--bright-red)';
                } else {
                    field.style.borderColor = '';
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                alert('Please fill all required fields.');
            }
        });

        // Edit form validation
        const editForm = document.getElementById('editUserForm');
        if (editForm) {
            editForm.addEventListener('submit', function(e) {
                const requiredFields = this.querySelectorAll('[required]');
                let isValid = true;
                
                requiredFields.forEach(field => {
                    if (!field.value.trim()) {
                        isValid = false;
                        field.style.borderColor = 'var(--bright-red)';
                    } else {
                        field.style.borderColor = '';
                    }
                });
                
                if (!isValid) {
                    e.preventDefault();
                    alert('Please fill all required fields.');
                }
            });
        }
    </script>
</body>
</html>