<?php
// export_appointments.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if admin is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'Admin') {
    header("Location: ../auth/login.php");
    exit();
}

// Create database connection
try {
    $host = 'sql206.byetcluster.com';
    $dbname = 'if0_40031860_dok';
    $username = 'if0_40031860';
    $password = "qzJkHEejybefK";
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get filter parameters
$searchTerm = $_GET['search'] ?? '';
$statusFilter = $_GET['status'] ?? 'all';
$dateFilter = $_GET['date'] ?? '';

try {
    $sql = "
        SELECT 
            a.appointmentID, 
            CONCAT(pu.firstName, ' ', pu.lastName) as patient_name,
            pu.phone as patient_phone,
            CONCAT(du.firstName, ' ', du.lastName) as doctor_name,
            d.specialty,
            ms.serviceName, 
            a.appointmentDate, 
            a.appointmentTime, 
            a.status, 
            a.createdAt,
            a.reason
        FROM Appointments a
        JOIN Patient pt ON a.patientID = pt.patientID
        JOIN User pu ON pt.userID = pu.userID
        JOIN Doctor d ON a.doctorID = d.doctorID
        JOIN User du ON d.userID = du.userID
        JOIN MedicalService ms ON a.serviceID = ms.serviceID
        WHERE 1=1
    ";
    
    $params = [];
    
    // Date filter
    if (!empty($dateFilter)) {
        $sql .= " AND a.appointmentDate = ?";
        $params[] = $dateFilter;
    } else {
        $sql .= " AND a.appointmentDate >= CURDATE()";
    }
    
    // Search filter
    if (!empty($searchTerm)) {
        $sql .= " AND (CONCAT(pu.firstName, ' ', pu.lastName) LIKE ? OR CONCAT(du.firstName, ' ', du.lastName) LIKE ? OR ms.serviceName LIKE ?)";
        $params[] = "%$searchTerm%";
        $params[] = "%$searchTerm%";
        $params[] = "%$searchTerm%";
    }
    
    // Status filter
    if (!empty($statusFilter) && $statusFilter !== 'all') {
        $sql .= " AND a.status = ?";
        $params[] = $statusFilter;
    }
    
    $sql .= " ORDER BY a.appointmentDate ASC, a.appointmentTime ASC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Set headers for CSV download
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=appointments_' . date('Y-m-d') . '.csv');
    
    $output = fopen('php://output', 'w');
    
    // Add BOM for Excel compatibility
    fputs($output, $bom = (chr(0xEF) . chr(0xBB) . chr(0xBF)));
    
    // CSV headers
    fputcsv($output, [
        'Appointment ID',
        'Patient Name',
        'Patient Phone',
        'Doctor Name',
        'Specialty',
        'Service',
        'Date',
        'Time',
        'Status',
        'Booked On',
        'Notes'
    ]);
    
    // CSV data
    foreach ($appointments as $appointment) {
        fputcsv($output, [
            $appointment['appointmentID'],
            $appointment['patient_name'],
            $appointment['patient_phone'],
            $appointment['doctor_name'],
            $appointment['specialty'],
            $appointment['serviceName'],
            $appointment['appointmentDate'],
            $appointment['appointmentTime'],
            $appointment['status'],
            $appointment['createdAt'],
            $appointment['reason']
        ]);
    }
    
    fclose($output);
    exit();
    
} catch (PDOException $e) {
    die("Error exporting appointments: " . $e->getMessage());
}
?>